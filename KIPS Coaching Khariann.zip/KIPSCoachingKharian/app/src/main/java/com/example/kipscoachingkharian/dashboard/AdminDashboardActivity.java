package com.example.kipscoachingkharian.dashboard;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminDashboardActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "AdminPrefs";
    private static final String KEY_EMAIL  = "admin_email";
    private static final String KEY_PASS   = "admin_pass";

    private DatabaseReference mDatabase;
    private FirebaseAuth mAuth;

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private ImageView ivMenuToggle, ivProfile;

    private CardView cardStudent, cardTeacher, cardParents, cardPayments,
            cardSystemReports, cardNotifications, cardPaymentConfig,
            cardSchedule, cardManageUser, cardFeedback, cardManageSubjects,
            cardManageClasses;

    private TextView tvparent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAuth     = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        if (mAuth.getCurrentUser() == null) {
            goToLoginSelection();
            return;
        }

        setContentView(R.layout.activity_admin_dashboard);

        initViews();
        setupNavigationDrawer();
        setupCardClicks();
        showAdminName(); // ✅ Updated
    }

    private void initViews() {
        drawerLayout      = findViewById(R.id.drawerLayout);
        navigationView    = findViewById(R.id.navigationView);
        ivMenuToggle      = findViewById(R.id.ivMenuToggle);
        ivProfile         = findViewById(R.id.ivProfile);

        cardStudent       = findViewById(R.id.Student);
        cardTeacher       = findViewById(R.id.Teacher);
        cardParents       = findViewById(R.id.Parents);
        cardFeedback      = findViewById(R.id.cardFeedback);
        cardPayments      = findViewById(R.id.Payments);
        cardSystemReports = findViewById(R.id.SystemReports);
        cardNotifications = findViewById(R.id.Notifications);
        cardPaymentConfig = findViewById(R.id.PaymentConfig);
        cardSchedule      = findViewById(R.id.cardTimetable);
        cardManageUser    = findViewById(R.id.cardManageUser);
        cardManageSubjects = findViewById(R.id.cardManageSubjects);
        cardManageClasses = findViewById(R.id.cardManageClasses);

        tvparent = findViewById(R.id.tvparent);
    }

    private void setupNavigationDrawer() {
        if (ivMenuToggle != null) {
            ivMenuToggle.setOnClickListener(v -> {
                if (!drawerLayout.isDrawerOpen(GravityCompat.START))
                    drawerLayout.openDrawer(GravityCompat.START, true);
                else
                    drawerLayout.closeDrawer(GravityCompat.START, true);
            });
        }

        if (ivProfile != null)
            ivProfile.setOnClickListener(v -> openProfileActivity());

        if (navigationView != null) {
            navigationView.setNavigationItemSelectedListener(item -> {
                int id = item.getItemId();
                if (id == R.id.nav_home) {
                    drawerLayout.closeDrawer(GravityCompat.START, true);
                    Toast.makeText(this, "You are already on Home Dashboard",
                            Toast.LENGTH_SHORT).show();
                } else if (id == R.id.nav_profile) {
                    drawerLayout.closeDrawer(GravityCompat.START, true);
                    openProfileActivity();
                }
                return true;
            });
        }
    }

    private void openProfileActivity() {
        startActivity(new Intent(this, AdminProfileActivity.class));
    }

    // ✅ FIX: Users/Admin se naam load karo — UID se nahi
    private void showAdminName() {
        mDatabase.child("Users").child("Admin").child("name")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String name = snapshot.getValue(String.class);
                        if (tvparent == null) return;
                        if (name != null && !name.trim().isEmpty()) {
                            tvparent.setText("Hi! " + name);
                        } else {
                            tvparent.setText("Hi! Admin");
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (tvparent != null) tvparent.setText("Hi! Admin");
                    }
                });
    }

    private void setupCardClicks() {
        cardStudent.setOnClickListener(v ->
                startActivity(new Intent(this, ManageStudentRequestsActivity.class)));

        cardTeacher.setOnClickListener(v ->
                startActivity(new Intent(this, AddTeacherActivity.class)));

        cardParents.setOnClickListener(v ->
                startActivity(new Intent(this, ManageParentRequestsActivity.class)));

        cardSchedule.setOnClickListener(v ->
                startActivity(new Intent(this, TimetableActivity.class)));

        cardFeedback.setOnClickListener(v ->
                startActivity(new Intent(this, FeedManagmentActivity.class)));

        cardNotifications.setOnClickListener(v ->
                startActivity(new Intent(this, ManageAnnouncementsActivity.class)));

        cardPayments.setOnClickListener(v ->
                startActivity(new Intent(this, AdminFeeActivity.class)));

        cardSystemReports.setOnClickListener(v ->
                startActivity(new Intent(this, SystemReportsActivity.class)));

        cardPaymentConfig.setOnClickListener(v ->
                startActivity(new Intent(this, AdminPaymentConfigActivity.class)));

        cardManageUser.setOnClickListener(v ->
                startActivity(new Intent(this, ManageUserActivity.class)));

        cardManageSubjects.setOnClickListener(v ->
                startActivity(new Intent(this, ManageSubjectsActivity.class)));

        cardManageClasses.setOnClickListener(v ->
                startActivity(new Intent(this, ManageClassesActivity.class)));
    }

    private void goToLoginSelection() {
        Intent intent = new Intent(this, LoginSelectionActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    public static void saveAdminCredentials(android.content.Context ctx,
                                            String email, String password) {
        ctx.getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                .putString(KEY_EMAIL, email)
                .putString(KEY_PASS,  password)
                .apply();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout != null && drawerLayout.isDrawerOpen(GravityCompat.START))
            drawerLayout.closeDrawer(GravityCompat.START, true);
        else
            super.onBackPressed();
    }
}