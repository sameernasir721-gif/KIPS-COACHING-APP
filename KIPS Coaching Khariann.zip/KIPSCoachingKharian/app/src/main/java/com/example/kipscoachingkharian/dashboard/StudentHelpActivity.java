package com.example.kipscoachingkharian.dashboard;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;

public class StudentHelpActivity extends AppCompatActivity {

    private ImageView btnBack;
    private LinearLayout layoutFaqContainer;

    // Student ke liye FAQ data: {question, answer}
    private final String[][] faqs = {
            {"How do I view my assignments?",
                    "Open 'Assignments' from your dashboard to see all assignments shared by your teacher. Tap any assignment to view details and submit your work."},
            {"How do I attempt a quiz?",
                    "Open 'Quizzes' from the dashboard, select the quiz you want to attempt and tap 'Start Quiz'. Answer all questions and submit before the deadline."},
            {"How do I check my progress and marks?",
                    "Open 'My Progress' from the dashboard to see your marks, quiz scores and performance reports for each subject."},
            {"How do I view announcements?",
                    "Tap the 'Notifications' bell icon or open 'Announcements' from the bottom navigation to see all latest announcements."},
            {"How do I update my profile?",
                    "Open 'My Profile' from the profile menu and tap the edit icon to update your name, phone number or password."},
            {"How do I change my password?",
                    "Open 'Settings' from this menu and tap 'Change Password'. Enter your current password and set a new one (minimum 8 characters)."},
            {"How do I view study materials?",
                    "Open 'Study Material' from the dashboard to access PDFs, notes and other resources uploaded by your teacher."},
            {"How do I pay my fee?",
                    "Open 'Fee' from the dashboard to see your fee details and payment options. You can pay online through the available payment method."}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_help);

        btnBack            = findViewById(R.id.btnBack);
        layoutFaqContainer = findViewById(R.id.layoutFaqContainer);

        btnBack.setOnClickListener(v -> finish());

        buildFaqList();
    }

    private void buildFaqList() {
        for (String[] faq : faqs) {
            layoutFaqContainer.addView(createFaqCard(faq[0], faq[1]));
        }
    }

    private CardView createFaqCard(String question, String answer) {
        int dp8  = dpToPx(8);
        int dp12 = dpToPx(12);
        int dp18 = dpToPx(18);

        CardView card = new CardView(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.bottomMargin = dp12;
        card.setLayoutParams(cardParams);
        card.setRadius(dpToPx(16));
        card.setCardElevation(dpToPx(3));
        card.setUseCompatPadding(true);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // Header row (question + chevron)
        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);
        headerRow.setPadding(dp18, dp18, dp18, dp18);
        headerRow.setClickable(true);
        headerRow.setFocusable(true);
        headerRow.setBackgroundResource(android.R.drawable.list_selector_background);

        TextView tvQuestion = new TextView(this);
        tvQuestion.setText(question);
        tvQuestion.setTextColor(0xFF263238);
        tvQuestion.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        tvQuestion.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams qParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tvQuestion.setLayoutParams(qParams);
        headerRow.addView(tvQuestion);

        ImageView ivChevron = new ImageView(this);
        ivChevron.setImageResource(R.drawable.ic_chevron_right);
        LinearLayout.LayoutParams chevronParams = new LinearLayout.LayoutParams(dpToPx(18), dpToPx(18));
        chevronParams.leftMargin = dp8;
        ivChevron.setLayoutParams(chevronParams);
        headerRow.addView(ivChevron);

        // Answer (hidden by default)
        TextView tvAnswer = new TextView(this);
        tvAnswer.setText(answer);
        tvAnswer.setTextColor(0xFF757575);
        tvAnswer.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        tvAnswer.setLineSpacing(dpToPx(2), 1f);
        LinearLayout.LayoutParams aParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        aParams.leftMargin   = dp18;
        aParams.rightMargin  = dp18;
        aParams.bottomMargin = dp18;
        tvAnswer.setLayoutParams(aParams);
        tvAnswer.setVisibility(View.GONE);

        headerRow.setOnClickListener(v -> {
            boolean isVisible = tvAnswer.getVisibility() == View.VISIBLE;
            tvAnswer.setVisibility(isVisible ? View.GONE : View.VISIBLE);
            ivChevron.setRotation(isVisible ? 0f : 90f);
        });

        container.addView(headerRow);
        container.addView(tvAnswer);
        card.addView(container);

        return card;
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (dp * density);
    }
}
