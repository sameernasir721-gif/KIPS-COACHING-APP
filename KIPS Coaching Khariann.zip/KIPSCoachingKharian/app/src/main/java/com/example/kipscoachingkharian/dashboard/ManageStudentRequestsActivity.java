package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ManageStudentRequestsActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private LinearLayout containerRequests;
    private TextView tvLoading;

    private String currentFilter = "Pending";
    private List<DataSnapshot> allStudentsList = new ArrayList<>();
    private int totalCount = 0, pendingCount = 0, approvedCount = 0, rejectedCount = 0;

    private static final int SECTION_CAPACITY = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.example.kipscoachingkharian.R.layout.activity_manage_students_requests);

        mDatabase         = FirebaseDatabase.getInstance().getReference();
        containerRequests = findViewById(com.example.kipscoachingkharian.R.id.containerStudentRequests);
        tvLoading         = findViewById(com.example.kipscoachingkharian.R.id.tvStudentLoading);

        fetchData();
    }

    // ── Firebase: SingleValueEvent — duplicate fire nahi hoga ────────────────
    private void fetchData() {
        if (tvLoading != null) tvLoading.setVisibility(View.VISIBLE);

        mDatabase.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                allStudentsList.clear();
                totalCount = 0; pendingCount = 0; approvedCount = 0; rejectedCount = 0;

                for (DataSnapshot userSnap : snapshot.getChildren()) {
                    String role = userSnap.child("role").getValue(String.class);
                    if (role == null || !"Student".equalsIgnoreCase(role)) continue;

                    String status = userSnap.child("status").getValue(String.class);
                    if (status == null) status = "Pending";

                    totalCount++;
                    if (status.equalsIgnoreCase("Pending"))       pendingCount++;
                    else if (status.equalsIgnoreCase("Approved")) approvedCount++;
                    else if (status.equalsIgnoreCase("Rejected")) rejectedCount++;

                    allStudentsList.add(userSnap);
                }
                updateUI();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {
                if (tvLoading != null) tvLoading.setVisibility(View.GONE);
            }
        });
    }

    private void updateUI() {
        containerRequests.removeAllViews();
        if (tvLoading != null) tvLoading.setVisibility(View.GONE);

        addSummaryCards();

        Button btnRefresh = new Button(this);
        btnRefresh.setText("🔄 Refresh Verification Status");
        btnRefresh.setBackgroundColor(0xFF1565C0);
        btnRefresh.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams refreshParams = new LinearLayout.LayoutParams(-1, -2);
        refreshParams.setMargins(0, dp(4), 0, dp(12));
        btnRefresh.setLayoutParams(refreshParams);
        btnRefresh.setOnClickListener(v -> fetchData());
        containerRequests.addView(btnRefresh);

        String headerTitle = currentFilter.equals("Total") ? "All Students" : currentFilter + " Requests";
        containerRequests.addView(makeSectionHeader(headerTitle, getHeaderColor(currentFilter)));

        boolean hasData = false;
        for (DataSnapshot userSnap : allStudentsList) {
            String status = userSnap.child("status").getValue(String.class);
            if (status == null) status = "Pending";
            if (!currentFilter.equals("Total") && !status.equalsIgnoreCase(currentFilter)) continue;

            hasData = true;
            String uid    = userSnap.getKey();
            String name   = userSnap.child("name").getValue(String.class);
            String email  = userSnap.child("email").getValue(String.class);
            String cls    = userSnap.child("className").getValue(String.class);
            String role   = userSnap.child("role").getValue(String.class);

            Object phoneObj = userSnap.child("phone").getValue();
            if (phoneObj == null) phoneObj = userSnap.child("phoneNumber").getValue();
            String phone = phoneObj != null ? String.valueOf(phoneObj).trim() : "N/A";

            // ✅ rejectionReason directly DataSnapshot se lo — fresh data
            String rejectionReason = userSnap.child("rejectionReason").getValue(String.class);

            Boolean emailVerifiedObj = userSnap.child("emailVerified").getValue(Boolean.class);
            boolean emailVerified = emailVerifiedObj != null && emailVerifiedObj;

            containerRequests.addView(makeStudentCard(uid, name, phone, email, cls,
                    getSubjects(userSnap), status, role, rejectionReason, emailVerified));
        }
        if (!hasData) showEmpty("No " + currentFilter.toLowerCase() + " records found.");
    }

    // ── Rejection Reason Dialog ───────────────────────────────────────────────
    private void showRejectionReasonDialog(String name, String reason) {
        // ✅ Firebase se fresh reason fetch karo — purana cached data nahi
        String displayReason = (reason != null && !reason.trim().isEmpty())
                ? reason : "Documentation incomplete or criteria not met.";

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(20), dp(24), dp(16));

        TextView tvTitle = new TextView(this);
        tvTitle.setText("❌  Request Rejected");
        tvTitle.setTextSize(17f);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setTextColor(0xFFB71C1C);
        tvTitle.setPadding(0, 0, 0, dp(8));
        layout.addView(tvTitle);

        TextView tvName = new TextView(this);
        tvName.setText("Student: " + (name != null ? name : "-"));
        tvName.setTextSize(14f);
        tvName.setTextColor(0xFF555555);
        tvName.setPadding(0, 0, 0, dp(12));
        layout.addView(tvName);

        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        divider.setBackgroundColor(0xFFEEEEEE);
        layout.addView(divider);

        TextView tvReasonLabel = new TextView(this);
        tvReasonLabel.setText("Reason for Rejection:");
        tvReasonLabel.setTextSize(13f);
        tvReasonLabel.setTextColor(0xFF888888);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-1, -2);
        llp.topMargin = dp(12);
        llp.bottomMargin = dp(6);
        tvReasonLabel.setLayoutParams(llp);
        layout.addView(tvReasonLabel);

        TextView tvReason = new TextView(this);
        tvReason.setText(displayReason);
        tvReason.setTextSize(15f);
        tvReason.setTextColor(0xFFB71C1C);
        tvReason.setTypeface(null, Typeface.BOLD);
        tvReason.setPadding(dp(14), dp(12), dp(14), dp(12));
        tvReason.setBackgroundColor(0xFFFFEBEE);
        tvReason.setLineSpacing(dp(4), 1f);
        layout.addView(tvReason);

        new AlertDialog.Builder(this)
                .setView(layout)
                .setPositiveButton("OK", null)
                .show();
    }

    // ── Rejection Reason — Firebase se live fetch karke dialog dikhao ─────────
    // Ye tab use hoga jab card pe click ho aur hum chahte hain bilkul fresh data
    private void fetchReasonAndShow(String uid, String name) {
        mDatabase.child("Users").child(uid).child("rejectionReason")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String freshReason = snapshot.getValue(String.class);
                        showRejectionReasonDialog(name, freshReason);
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        showRejectionReasonDialog(name, null);
                    }
                });
    }

    // ── Student Card ──────────────────────────────────────────────────────────
    private View makeStudentCard(String uid, String name, String phone, String email, String cls,
                                 String subjects, String status, String role, String rejectionReason,
                                 boolean emailVerified) {

        int cardBg;
        switch (status.toLowerCase()) {
            case "approved": cardBg = 0xFFF1FFF1; break;
            case "rejected": cardBg = 0xFFFFF1F1; break;
            default:         cardBg = 0xFFFFFFFF; break;
        }

        androidx.cardview.widget.CardView card = new androidx.cardview.widget.CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(cp);
        card.setRadius(dp(12));
        card.setCardElevation(dp(3));
        card.setCardBackgroundColor(cardBg);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(14), dp(14), dp(14), dp(14));

        // Name bold header
        TextView tvName = new TextView(this);
        tvName.setText(name != null ? name : "-");
        tvName.setTextSize(16f);
        tvName.setTypeface(null, Typeface.BOLD);
        tvName.setTextColor(0xFF1565C0);
        inner.addView(tvName);

        addInfoRow(inner, "👤 Role",     role);
        addInfoRow(inner, "📞 Phone",    phone);
        addInfoRow(inner, "📧 Email",    email);
        addInfoRow(inner, "✅ Email Status", emailVerified ? "Verified" : "Not Verified Yet");
        addInfoRow(inner, "🏫 Class",    cls);
        addInfoRow(inner, "📚 Subjects", subjects);

        // ── Rejected: clickable red banner ────────────────────────────────────
        if (status.equalsIgnoreCase("Rejected")) {
            TextView tvBanner = new TextView(this);
            tvBanner.setText("❌ Rejected — Tap to see reason");
            tvBanner.setTextSize(13f);
            tvBanner.setTextColor(0xFFB71C1C);
            tvBanner.setTypeface(null, Typeface.BOLD);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.topMargin = dp(10);
            tvBanner.setLayoutParams(rp);
            tvBanner.setPadding(dp(10), dp(10), dp(10), dp(10));
            tvBanner.setBackgroundColor(0xFFFFEBEE);

            // ✅ Firebase se fresh reason fetch karke dialog dikhao
            tvBanner.setOnClickListener(v -> fetchReasonAndShow(uid, name));
            card.setOnClickListener(v    -> fetchReasonAndShow(uid, name));

            inner.addView(tvBanner);
        }

        // ── Pending: Approve / Reject buttons ────────────────────────────────
        if (status.equalsIgnoreCase("Pending")) {
            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setPadding(0, dp(10), 0, 0);

            Button btnApprove = new Button(this);
            btnApprove.setText("✅ Approve");
            btnApprove.setBackgroundColor(0xFF388E3C);
            btnApprove.setTextColor(0xFFFFFFFF);
            LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, -2, 1f);
            p1.setMarginEnd(dp(5));
            btnApprove.setLayoutParams(p1);
            btnApprove.setOnClickListener(v -> {
                if (!emailVerified) {
                    new AlertDialog.Builder(this)
                            .setTitle("Email Not Verified")
                            .setMessage(name + " ne abhi tak apna email (" + email + ") verify nahi kiya. "
                                    + "Ho sakta hai yeh dummy/fake email ho. Phir bhi approve karna chahte hain?")
                            .setPositiveButton("Approve Anyway", (d, w) -> startAutoApproval(uid, name, email, cls))
                            .setNegativeButton("Cancel", null)
                            .show();
                } else {
                    startAutoApproval(uid, name, email, cls);
                }
            });

            Button btnReject = new Button(this);
            btnReject.setText("❌ Reject");
            btnReject.setBackgroundColor(0xFFB71C1C);
            btnReject.setTextColor(0xFFFFFFFF);
            btnReject.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
            btnReject.setOnClickListener(v -> promptReject(uid, name, email));

            btnRow.addView(btnApprove);
            btnRow.addView(btnReject);
            inner.addView(btnRow);
        }

        card.addView(inner);
        return card;
    }

    // ── Auto-approval ─────────────────────────────────────────────────────────
    private void startAutoApproval(String uid, String name, String email, String className) {
        String classDigit = className != null ? className.replaceAll("[^0-9]", "") : "9";
        if (classDigit.isEmpty()) classDigit = "9";
        final String finalClassDigit = classDigit;
        checkSectionCapacity(finalClassDigit, "A", uid, name, email);
    }

    private void checkSectionCapacity(String classDigit, String section,
                                      String uid, String name, String email) {
        mDatabase.child("Users")
                .orderByChild("className").equalTo(classDigit + section)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.getChildrenCount() < SECTION_CAPACITY) {
                            generateStudentIdAndSave(uid, name, email, section, classDigit + section);
                        } else {
                            char next = (char) (section.charAt(0) + 1);
                            checkSectionCapacity(classDigit, String.valueOf(next), uid, name, email);
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void generateStudentIdAndSave(String uid, String name, String email,
                                          String section, String formattedClass) {
        mDatabase.child("Metadata").child("studentCounter")
                .runTransaction(new Transaction.Handler() {
                    @NonNull @Override
                    public Transaction.Result doTransaction(@NonNull MutableData d) {
                        Long v = d.getValue(Long.class);
                        d.setValue(v == null ? 1 : v + 1);
                        return Transaction.success(d);
                    }
                    @Override
                    public void onComplete(DatabaseError error, boolean committed, DataSnapshot snap) {
                        if (committed) {
                            String uniqueId = "student" + String.format("%03d", (long) snap.getValue());
                            saveData(uid, name, email, section, formattedClass, uniqueId);
                        }
                    }
                });
    }

    private void saveData(String uid, String name, String email,
                          String section, String formattedClass, String id) {
        Map<String, Object> map = new HashMap<>();
        map.put("status", "Approved");
        map.put("registrationId", id);
        map.put("assignedSection", section);
        map.put("className", formattedClass);

        mDatabase.child("Users").child(uid).updateChildren(map)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this,
                            name + " Approved — Section " + section, Toast.LENGTH_SHORT).show();
                    sendMail(email, "Approved",
                            "Welcome " + name + "! Your ID is " + id
                                    + " and you are assigned to Class " + formattedClass);

                    // ✅ Naye approved student ko Rs. 50,000 welcome bonus wallet
                    // mein automatically credit karo (idempotent — dobara nahi milega)
                    WalletBonusHelper.creditWelcomeBonus(uid, name);

                    fetchData(); // ✅ List refresh karo
                });
    }

    // ── Reject dialog ─────────────────────────────────────────────────────────
    private void promptReject(String uid, String name, String email) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(16), dp(24), dp(8));

        EditText input = new EditText(this);
        input.setHint("Enter reason for rejection...");
        input.setMinLines(2);
        layout.addView(input);

        new AlertDialog.Builder(this)
                .setTitle("Reject Request")
                .setView(layout)
                .setPositiveButton("Reject & Send Mail", (dialog, which) -> {
                    String reason = input.getText().toString().trim();
                    if (reason.isEmpty()) reason = "Documentation incomplete or criteria not met.";
                    final String finalReason = reason;

                    Map<String, Object> rejectMap = new HashMap<>();
                    rejectMap.put("status", "Rejected");
                    rejectMap.put("rejectionReason", finalReason); // ✅ Firebase mein save

                    mDatabase.child("Users").child(uid).updateChildren(rejectMap)
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(this,
                                        name + " Rejected.", Toast.LENGTH_SHORT).show();
                                sendMail(email, "Rejected",
                                        "Dear " + name + ",\nYour request has been rejected.\nReason: "
                                                + finalReason);
                                fetchData(); // ✅ List refresh — rejected card ab dikhega
                            });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void sendMail(String email, String status, String message) {
        if (email == null || email.equals("-")) return;
        Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL,   new String[]{email});
        intent.putExtra(Intent.EXTRA_SUBJECT, "Registration " + status + " - KIPS");
        intent.putExtra(Intent.EXTRA_TEXT,    message);
        try { startActivity(Intent.createChooser(intent, "Send Email...")); } catch (Exception ignored) {}
    }

    // ── Summary Cards ─────────────────────────────────────────────────────────
    private void addSummaryCards() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(makeSummaryCard("Total",    totalCount,    0xFF1565C0, 0xFFE3F2FD));
        row.addView(makeSummaryCard("Pending",  pendingCount,  0xFFE65100, 0xFFFFF3E0));
        row.addView(makeSummaryCard("Approved", approvedCount, 0xFF2E7D32, 0xFFE8F5E9));
        row.addView(makeSummaryCard("Rejected", rejectedCount, 0xFFB71C1C, 0xFFFFEBEE));
        containerRequests.addView(row);
    }

    private View makeSummaryCard(String label, int count, int textColor, int bgColor) {
        androidx.cardview.widget.CardView card = new androidx.cardview.widget.CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
        cp.setMargins(dp(2), 0, dp(2), dp(10));
        card.setLayoutParams(cp);
        card.setRadius(dp(8));
        card.setCardBackgroundColor(bgColor);
        if (currentFilter.equalsIgnoreCase(label)) card.setCardElevation(dp(8));

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(5), dp(10), dp(5), dp(10));
        inner.setGravity(Gravity.CENTER);

        TextView tvNum = new TextView(this);
        tvNum.setText(String.valueOf(count));
        tvNum.setTextSize(18f);
        tvNum.setTextColor(textColor);
        tvNum.setTypeface(null, Typeface.BOLD);

        TextView tvLbl = new TextView(this);
        tvLbl.setText(label);
        tvLbl.setTextSize(10f);
        tvLbl.setTextColor(textColor);

        inner.addView(tvNum);
        inner.addView(tvLbl);
        card.addView(inner);
        card.setOnClickListener(v -> { currentFilter = label; updateUI(); });
        return card;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private void addInfoRow(LinearLayout parent, String label, String value) {
        TextView tv = new TextView(this);
        tv.setText(label + ": " + (value != null ? value : "-"));
        tv.setTextSize(13f);
        tv.setPadding(0, dp(2), 0, 0);
        parent.addView(tv);
    }

    private View makeSectionHeader(String title, int color) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(15f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(color);
        tv.setPadding(0, dp(10), 0, dp(10));
        return tv;
    }

    private String getSubjects(DataSnapshot snap) {
        DataSnapshot subsSnap = snap.child("enrolledSubjects");
        if (!subsSnap.exists()) return "None";
        List<String> list = new ArrayList<>();
        for (DataSnapshot s : subsSnap.getChildren()) {
            String sub = s.getValue(String.class);
            if (sub != null) list.add(sub);
        }
        return list.isEmpty() ? "None" : TextUtils.join(", ", list);
    }

    private int getHeaderColor(String status) {
        if (status.equalsIgnoreCase("Pending"))  return 0xFFE65100;
        if (status.equalsIgnoreCase("Approved")) return 0xFF2E7D32;
        if (status.equalsIgnoreCase("Rejected")) return 0xFFB71C1C;
        return 0xFF1565C0;
    }

    private void showEmpty(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(50), 0, 0);
        containerRequests.addView(tv);
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}