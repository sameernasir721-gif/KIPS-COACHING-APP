package com.example.kipscoachingkharian.dashboard;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.print.pdf.PrintedPdfDocument;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Student-facing "View Challan" screen — FeeActivity ke "VIEW CHALLAN"
 * button se launch hoti hai.
 *
 * IMPORTANT: Ye challan-card ka design/rows/colors bilkul WAISE HI hain
 * jaise admin ki FeeChallanActivity.buildChallanUI() mein hain (same to
 * same) — sirf farak itna hai ke ye READ-ONLY hai: koi Firebase-write,
 * koi notification-send, koi generate-logic nahi. Sirf "Fees/{uid}/{month}"
 * (jo admin ne pehle hi generate/save kiya hota hai) se data parh kar
 * dikhati hai.
 *
 * Subject-wise fee-breakdown dikhane ke liye "payment_config" (fee_per_subject,
 * fee_special_subject) bhi load kiya jata hai — bilkul jaisa admin-side
 * getFeeForSubject() karta hai — kyunke saved challan mein sirf aggregate
 * "baseFee" store hota hai, per-subject amount nahi.
 */
public class StudentViewChallanActivity extends AppCompatActivity {

    public static final String EXTRA_MONTH_KEY = "month_key";

    private LinearLayout challanContainer;
    private ImageView ivDownload;

    // Challan render hone ke baad yahan uska root-view (CardView) store
    // hota hai, taake "Download" button dabane par usi ko PDF mein
    // convert kiya ja sake. Jab tak challan load na ho, yeh null rehta
    // hai aur download button disabled rehta hai.
    private View challanPrintableView;
    private String downloadFileName = "FeeChallan";

    private long feePerSubject = 3000L;
    private long feeSpecial    = 2500L;

    private static final java.util.Set<String> SPECIAL_SUBJECTS = new java.util.HashSet<>(
            java.util.Arrays.asList(
                    "urdu",
                    "pakistan studies", "pak studies", "pak study", "pakistan study", "p.st", "pst",
                    "islamiat", "islamic studies", "islamiyat", "islamiyat studies"
            ));

    private long getFeeForSubject(String subject) {
        if (subject == null) return feePerSubject;
        return SPECIAL_SUBJECTS.contains(subject.trim().toLowerCase()) ? feeSpecial : feePerSubject;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ── Root — bilkul FeeChallanActivity jaisa structure (toolbar +
        // scrollable container), sirf search-bar nahi (student ko search
        // nahi karni — apna hi record dikhta hai) ────────────────────────
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF4F6FA);

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setBackgroundColor(0xFF2E7D32);
        toolbar.setPadding(dp(16), dp(14), dp(16), dp(14));

        android.widget.ImageView ivBack = new android.widget.ImageView(this);
        ivBack.setImageResource(android.R.drawable.ic_menu_revert);
        ivBack.setColorFilter(0xFFFFFFFF);
        ivBack.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(dp(24), dp(24));
        bLp.setMarginEnd(dp(14));
        ivBack.setLayoutParams(bLp);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Fee Challan");
        tvTitle.setTextSize(18f);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        // Weight=1 taake tvTitle available space le le aur download icon
        // hamesha toolbar ke sabse dayen taraf chala jaye
        tvTitle.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        ivDownload = new ImageView(this);
        ivDownload.setImageResource(R.drawable.ic_download_vector);
        ivDownload.setColorFilter(0xFFFFFFFF);
        // Jab tak challan load nahi ho jata, download disabled + dimmed
        ivDownload.setEnabled(false);
        ivDownload.setAlpha(0.4f);
        LinearLayout.LayoutParams dLp = new LinearLayout.LayoutParams(dp(24), dp(24));
        ivDownload.setLayoutParams(dLp);
        ivDownload.setOnClickListener(v -> downloadChallanAsPdf());

        toolbar.addView(ivBack);
        toolbar.addView(tvTitle);
        toolbar.addView(ivDownload);

        ScrollView sv = new ScrollView(this);
        challanContainer = new LinearLayout(this);
        challanContainer.setOrientation(LinearLayout.VERTICAL);
        challanContainer.setPadding(dp(14), dp(14), dp(14), dp(24));

        TextView tvLoading = new TextView(this);
        tvLoading.setText("Loading challan...");
        tvLoading.setTextSize(13f);
        tvLoading.setTextColor(0xFF999999);
        tvLoading.setGravity(Gravity.CENTER);
        tvLoading.setPadding(0, dp(60), 0, 0);
        challanContainer.addView(tvLoading);

        sv.addView(challanContainer);
        root.addView(toolbar);
        root.addView(sv);
        setContentView(root);

        loadFeePerSubject(() -> {
            String monthKeyFromIntent = getIntent().getStringExtra(EXTRA_MONTH_KEY);
            loadChallan(monthKeyFromIntent);
        });
    }

    private interface OnLoaded { void run(); }

    private void loadFeePerSubject(OnLoaded onLoaded) {
        FirebaseDatabase.getInstance().getReference("payment_config")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snap) {
                        if (snap.hasChild("fee_per_subject")) {
                            Long f = snap.child("fee_per_subject").getValue(Long.class);
                            if (f != null) feePerSubject = f;
                        }
                        if (snap.hasChild("fee_special_subject")) {
                            Long f = snap.child("fee_special_subject").getValue(Long.class);
                            if (f != null) feeSpecial = f;
                        }
                        onLoaded.run();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) { onLoaded.run(); }
                });
    }

    private void loadChallan(String monthKeyFromIntent) {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            showNoChallan();
            return;
        }
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot userSnap) {
                        String name  = userSnap.child("name").getValue(String.class);
                        String grade = userSnap.child("className").getValue(String.class);

                        FirebaseDatabase.getInstance().getReference("Fees").child(uid)
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot feeSnap) {
                                        if (!feeSnap.exists()) { showNoChallan(); return; }

                                        DataSnapshot chosen = null;

                                        if (monthKeyFromIntent != null && feeSnap.hasChild(monthKeyFromIntent)) {
                                            chosen = feeSnap.child(monthKeyFromIntent);
                                        } else {
                                            for (DataSnapshot s : feeSnap.getChildren()) {
                                                String status = s.child("status").getValue(String.class);
                                                if (status != null && status.equalsIgnoreCase("Unpaid")) {
                                                    chosen = s;
                                                    break;
                                                }
                                            }
                                            if (chosen == null) {
                                                long latestTime = -1;
                                                for (DataSnapshot s : feeSnap.getChildren()) {
                                                    Long gen = s.child("generatedAt").getValue(Long.class);
                                                    long t = (gen != null) ? gen : 0L;
                                                    if (t >= latestTime) { latestTime = t; chosen = s; }
                                                }
                                            }
                                        }

                                        if (chosen == null) { showNoChallan(); return; }
                                        renderChallan(name, grade, chosen);
                                    }
                                    @Override public void onCancelled(@NonNull DatabaseError e) { showNoChallan(); }
                                });
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) { showNoChallan(); }
                });
    }

    private void showNoChallan() {
        challanContainer.removeAllViews();
        TextView tv = new TextView(this);
        tv.setText("Abhi tak koi fee challan generate nahi hua.");
        tv.setTextSize(13f);
        tv.setTextColor(0xFF999999);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(60), 0, 0);
        challanContainer.addView(tv);

        // Koi challan hi nahi hai to download karne ke liye kuch nahi —
        // button disable rakhein
        challanPrintableView = null;
        if (ivDownload != null) {
            ivDownload.setEnabled(false);
            ivDownload.setAlpha(0.4f);
        }
    }

    private long parseLong(String s) {
        if (s == null || s.trim().isEmpty()) return 0;
        try { return Long.parseLong(s.trim()); }
        catch (NumberFormatException e) { return 0; }
    }

    private void renderChallan(String studentName, String grade, DataSnapshot challan) {
        String name    = (studentName != null) ? studentName : "Student";
        String cls     = (grade != null) ? grade : "";
        String month   = challan.child("month").getValue(String.class);
        String dueDate = challan.child("dueDate").getValue(String.class);
        String status  = challan.child("status").getValue(String.class);

        long baseFee  = parseLong(challan.child("baseFee").getValue(String.class));
        long fineAmt  = parseLong(challan.child("lateFine").getValue(String.class));
        String amountStr = challan.child("amount").getValue(String.class);
        long totalFee = (amountStr != null) ? parseLong(amountStr) : (baseFee + fineAmt);

        Long paidAt = challan.child("paidAt").getValue(Long.class);
        if (paidAt == null) paidAt = challan.child("savedAt").getValue(Long.class);

        boolean isPaid = "Paid".equalsIgnoreCase(status);
        boolean isLate = fineAmt > 0;

        List<String> subjects = new ArrayList<>();
        for (DataSnapshot s : challan.child("subjects").getChildren()) {
            String sub = s.getValue(String.class);
            if (sub != null) subjects.add(sub);
        }

        // ── Neeche se buildChallanUI() (FeeChallanActivity) — SAME TO SAME
        // rows/colors/design, sirf koi Firebase-write/notification nahi ────
        challanContainer.removeAllViews();

        CardView card = new CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, 0, 0, dp(16));
        card.setLayoutParams(cp);
        card.setRadius(dp(14));
        card.setCardElevation(dp(4));
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(18), dp(18), dp(18), dp(18));

        addRow(inner, "🏫 KIPS Coaching Kharian", null, 16f, Typeface.BOLD, 0xFF1565C0, 0xFF1565C0);
        addDivider(inner);
        addRow(inner, "FEE CHALLAN", null, 14f, Typeface.BOLD, 0xFF333333, 0xFF333333);
        addSpacer(inner, dp(10));

        addRow(inner, "Student Name:", name,                      13f, Typeface.NORMAL, 0xFF555555, 0xFF222222);
        addRow(inner, "Class:",        cls.isEmpty() ? "—" : cls, 13f, Typeface.NORMAL, 0xFF555555, 0xFF222222);
        addRow(inner, "Month:",        month != null ? month : "-", 13f, Typeface.NORMAL, 0xFF555555, 0xFF222222);
        addRow(inner, "Due Date:",     dueDate != null ? dueDate : "-", 13f, Typeface.BOLD, 0xFFE53935, 0xFFE53935);
        addSpacer(inner, dp(12));

        TextView tvHeader = new TextView(this);
        tvHeader.setText("Subject-wise Fee Breakdown");
        tvHeader.setTextSize(13f);
        tvHeader.setTypeface(null, Typeface.BOLD);
        tvHeader.setTextColor(0xFF1565C0);
        LinearLayout.LayoutParams thp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        thp.setMargins(0, 0, 0, dp(8));
        tvHeader.setLayoutParams(thp);
        inner.addView(tvHeader);
        addDivider(inner);

        if (subjects.isEmpty()) {
            TextView tvNoSub = new TextView(this);
            tvNoSub.setText("No subjects enrolled.");
            tvNoSub.setTextSize(13f);
            tvNoSub.setTextColor(0xFF888888);
            tvNoSub.setPadding(0, dp(4), 0, dp(4));
            inner.addView(tvNoSub);
        } else {
            for (String sub : subjects) {
                addRow(inner, sub, "Rs. " + getFeeForSubject(sub), 13f, Typeface.NORMAL, 0xFF333333, 0xFF1976D2);
            }
        }

        addDivider(inner);
        addSpacer(inner, dp(4));
        addRow(inner, "Total Subjects:", String.valueOf(subjects.size()), 13f, Typeface.BOLD,   0xFF333333, 0xFF333333);
        addRow(inner, "Subject Fee:",    "Rs. " + baseFee,                13f, Typeface.NORMAL, 0xFF555555, 0xFF333333);

        if (fineAmt > 0) {
            addRow(inner, "⚠ Late Fine:", "Rs. " + fineAmt, 13f, Typeface.BOLD, 0xFFE53935, 0xFFE53935);
        }

        addDivider(inner);
        addRow(inner, "Total Fee:", "Rs. " + totalFee, 15f, Typeface.BOLD, 0xFF222222, 0xFF2E7D32);
        addSpacer(inner, dp(12));
        addDivider(inner);

        LinearLayout badgeRow = new LinearLayout(this);
        badgeRow.setOrientation(LinearLayout.HORIZONTAL);
        badgeRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        brp.setMargins(0, dp(10), 0, 0);
        badgeRow.setLayoutParams(brp);

        TextView tvStatusLabel = new TextView(this);
        tvStatusLabel.setText("Payment Status:");
        tvStatusLabel.setTextSize(13f);
        tvStatusLabel.setTextColor(0xFF555555);
        tvStatusLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvBadge = new TextView(this);
        tvBadge.setText(isPaid ? "✓ Paid" : (isLate ? "⏰ Unpaid (Overdue)" : "⏳ Unpaid"));
        tvBadge.setTextSize(12f);
        tvBadge.setTextColor(0xFFFFFFFF);
        tvBadge.setTypeface(null, Typeface.BOLD);
        tvBadge.setPadding(dp(14), dp(6), dp(14), dp(6));
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(isPaid ? 0xFF43A047 : 0xFFE53935);
        badgeBg.setCornerRadius(dp(20));
        tvBadge.setBackground(badgeBg);
        badgeRow.addView(tvStatusLabel);
        badgeRow.addView(tvBadge);
        inner.addView(badgeRow);

        if (isPaid && paidAt != null && paidAt > 0) {
            TextView tvPaidOn = new TextView(this);
            tvPaidOn.setText("Paid on: " + new SimpleDateFormat(
                    "dd MMM yyyy, hh:mm a", Locale.getDefault()).format(new Date(paidAt)));
            tvPaidOn.setTextSize(12f);
            tvPaidOn.setTypeface(null, Typeface.BOLD);
            tvPaidOn.setTextColor(0xFF2E7D32);
            tvPaidOn.setPadding(0, dp(8), 0, 0);
            inner.addView(tvPaidOn);
        }

        TextView tvFooter = new TextView(this);
        if (isPaid) {
            tvFooter.setText("Fee per subject: Rs. " + feePerSubject + "  |  Thank you for your payment!");
        } else if (isLate) {
            tvFooter.setText("Fee per subject: Rs. " + feePerSubject
                    + "  |  Due date guzar gayi hai — fine laga di gayi hai.");
        } else {
            tvFooter.setText("Fee per subject: Rs. " + feePerSubject + "  |  Please pay by " + (dueDate != null ? dueDate : "-"));
        }
        tvFooter.setTextSize(11f);
        tvFooter.setTextColor(0xFF888888);
        tvFooter.setPadding(0, dp(10), 0, 0);
        inner.addView(tvFooter);

        card.addView(inner);
        challanContainer.addView(card);

        // ── Download ke liye is card ko save kar lein, aur file ka naam
        // (student-name + month se) taiyar kar lein ─────────────────────────
        challanPrintableView = card;
        String safeMonth = (month != null) ? month.replaceAll("[^A-Za-z0-9]", "_") : "Challan";
        String safeName  = name.replaceAll("[^A-Za-z0-9]", "_");
        downloadFileName = "FeeChallan_" + safeName + "_" + safeMonth;

        if (ivDownload != null) {
            ivDownload.setEnabled(true);
            ivDownload.setAlpha(1f);
        }
    }

    // ── UI Helpers — FeeChallanActivity se same-to-same copy ────────────────
    private void addRow(LinearLayout parent, String label, String value,
                        float textSize, int style, int labelColor, int valueColor) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.setMargins(0, 0, 0, dp(4));
        row.setLayoutParams(rp);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(textSize);
        tvLabel.setTypeface(null, style);
        tvLabel.setTextColor(labelColor);
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(tvLabel);

        if (value != null) {
            TextView tvValue = new TextView(this);
            tvValue.setText(value);
            tvValue.setTextSize(textSize);
            tvValue.setTypeface(null, style);
            tvValue.setTextColor(valueColor);
            tvValue.setGravity(Gravity.END);
            row.addView(tvValue);
        }
        parent.addView(row);
    }

    private void addDivider(LinearLayout parent) {
        View v = new View(this);
        v.setBackgroundColor(0xFFEEEEEE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(0, dp(6), 0, dp(6));
        v.setLayoutParams(lp);
        parent.addView(v);
    }

    private void addSpacer(LinearLayout parent, int height) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, height));
        parent.addView(v);
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }

    // ─── DOWNLOAD CHALLAN (PDF) ─────────────────────────────────────────────
    // Yahan Android ka built-in PrintManager use kiya gaya hai (bilkul
    // ParentFeeChallanActivity.printChallan() jaisa concept) — koi extra
    // library, koi runtime STORAGE permission, aur koi FileProvider setup
    // nahi chahiye. System ka "Print" dialog khulta hai jahan se user
    // "Save as PDF" choose karke challan seedha apne phone ke Downloads
    // folder (ya jahan chahe) mein save kar sakta hai.
    //
    // Farak sirf itna hai ke ParentFeeChallanActivity ek WebView (HTML) ko
    // print karti hai, jabke yahan challan native Views (CardView) se bana
    // hota hai — is liye custom PrintDocumentAdapter likha hai jo pehle
    // us View ko ek Bitmap mein render karta hai, phir woh Bitmap PDF ke
    // page par draw kar deta hai.
    private void downloadChallanAsPdf() {
        if (challanPrintableView == null) {
            Toast.makeText(this, "Challan abhi load ho raha hai, thora wait karein...",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
        if (printManager == null) {
            Toast.makeText(this, "Print service is not available on this device.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            PrintDocumentAdapter adapter =
                    new ChallanPrintDocumentAdapter(challanPrintableView, downloadFileName);
            printManager.print(downloadFileName, adapter, new PrintAttributes.Builder().build());
            // System print dialog yahan se khul jayega — user wahan se
            // "Save as PDF" select karke challan download kar sakta hai
        } catch (Exception e) {
            Toast.makeText(this, "Could not start download: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Ek chhota custom PrintDocumentAdapter jo di gayi View (challan-card)
     * ko ek single-page PDF mein convert karta hai. Android ke print
     * framework ke through call hota hai — onLayout() pehle chalta hai
     * (jahan hum View ko Bitmap mein "photograph" kar lete hain), phir
     * onWrite() chalta hai (jahan hum woh Bitmap asal PDF page par draw
     * karke destination file mein likh dete hain).
     */
    private class ChallanPrintDocumentAdapter extends PrintDocumentAdapter {
        private final View sourceView;
        private final String fileName;
        private PrintAttributes printAttributes;
        private Bitmap renderedBitmap;

        ChallanPrintDocumentAdapter(View sourceView, String fileName) {
            this.sourceView = sourceView;
            this.fileName = fileName;
        }

        @Override
        public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                             CancellationSignal cancellationSignal,
                             LayoutResultCallback callback, android.os.Bundle extras) {
            if (cancellationSignal.isCanceled()) {
                callback.onLayoutCancelled();
                return;
            }

            this.printAttributes = newAttributes;

            // View jitni chaurai screen par visible hai, usi chaurai par
            // render karein taake challan bilkul waisa hi dikhe jaisa
            // student ko screen par nazar aata hai. Height ko wrap-content
            // ki tarah measure karke poora content (koi cropping nahi)
            // capture karte hain.
            int currentWidth  = sourceView.getWidth();
            int currentHeight = sourceView.getHeight();
            int measureWidth  = currentWidth > 0 ? currentWidth : dp(340);

            sourceView.measure(
                    View.MeasureSpec.makeMeasureSpec(measureWidth, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            int measuredWidth  = sourceView.getMeasuredWidth();
            int measuredHeight = sourceView.getMeasuredHeight();
            sourceView.layout(0, 0, measuredWidth, measuredHeight);

            renderedBitmap = Bitmap.createBitmap(measuredWidth, measuredHeight, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(renderedBitmap);
            canvas.drawColor(Color.WHITE);
            sourceView.draw(canvas);

            // View ko wapas uski asal on-screen size par le aayein taake
            // screen ka layout is process se disturb na ho
            if (currentWidth > 0 && currentHeight > 0) {
                sourceView.layout(0, 0, currentWidth, currentHeight);
            }

            PrintDocumentInfo info = new PrintDocumentInfo.Builder(fileName + ".pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build();
            callback.onLayoutFinished(info, true);
        }

        @Override
        public void onWrite(android.print.PageRange[] pages, ParcelFileDescriptor destination,
                            CancellationSignal cancellationSignal, WriteResultCallback callback) {
            PrintedPdfDocument pdfDocument = new PrintedPdfDocument(
                    StudentViewChallanActivity.this, printAttributes);
            try {
                PdfDocument.Page page = pdfDocument.startPage(0);
                Canvas pageCanvas = page.getCanvas();

                // Bitmap ko page ke andar, aspect-ratio preserve karte
                // hue aur thora margin ke saath, center mein fit karein
                int pageWidth  = pageCanvas.getWidth();
                int pageHeight = pageCanvas.getHeight();
                int margin     = dp(8);

                float scale = Math.min(
                        (pageWidth - 2f * margin) / renderedBitmap.getWidth(),
                        (pageHeight - 2f * margin) / renderedBitmap.getHeight());

                float left = (pageWidth - renderedBitmap.getWidth() * scale) / 2f;
                float top  = margin;

                Matrix matrix = new Matrix();
                matrix.postScale(scale, scale);
                matrix.postTranslate(left, top);
                pageCanvas.drawBitmap(renderedBitmap, matrix, null);

                pdfDocument.finishPage(page);
                pdfDocument.writeTo(new FileOutputStream(destination.getFileDescriptor()));

                callback.onWriteFinished(new android.print.PageRange[]{android.print.PageRange.ALL_PAGES});
            } catch (Exception e) {
                callback.onWriteFailed(e.getMessage());
            } finally {
                pdfDocument.close();
            }
        }
    }
}