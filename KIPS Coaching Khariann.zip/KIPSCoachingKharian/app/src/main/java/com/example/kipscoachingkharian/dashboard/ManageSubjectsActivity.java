package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

/**
 * Admin screen: view all subjects and add new subjects.
 * Subjects are stored under the "Subjects" node in Firebase Realtime Database,
 * keyed by a sanitized version of the subject name, e.g.:
 *   Subjects/
 *     Physics: { name: "Physics" }
 *     Chemistry: { name: "Chemistry" }
 */
public class ManageSubjectsActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private LinearLayout containerSubjects;
    private TextView tvCount, tvLoading;
    private Button btnAddSubject;
    private ImageView ivBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_subjects);

        mDatabase          = FirebaseDatabase.getInstance().getReference();
        containerSubjects  = findViewById(R.id.containerSubjectsList);
        tvCount            = findViewById(R.id.tvTotalSubjectsCount);
        tvLoading          = findViewById(R.id.tvSubjectsLoading);
        btnAddSubject      = findViewById(R.id.btnAddNewSubject);
        ivBack             = findViewById(R.id.ivBack);

        if (ivBack != null) ivBack.setOnClickListener(v -> onBackPressed());

        btnAddSubject.setOnClickListener(v -> showAddDialog());

        loadSubjectsData();
    }

    // ── Firebase: load all subjects from the "Subjects" node ─────────────────
    private void loadSubjectsData() {
        if (tvLoading != null) tvLoading.setVisibility(View.VISIBLE);

        mDatabase.child("Subjects").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                containerSubjects.removeAllViews();
                if (tvLoading != null) tvLoading.setVisibility(View.GONE);

                int count = 0;
                for (DataSnapshot snap : snapshot.getChildren()) {
                    String key = snap.getKey();

                    String name = snap.child("name").getValue(String.class);
                    if (name == null || name.isEmpty()) name = key;

                    createSubjectCard(key, name);
                    count++;
                }

                if (tvCount != null) tvCount.setText(String.valueOf(count));
                if (count == 0) showEmptyState("No subjects have been added yet.");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (tvLoading != null) tvLoading.setVisibility(View.GONE);
                Toast.makeText(ManageSubjectsActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ── Subject card UI ─────────────────────────────────────────────────────
    private void createSubjectCard(String nodeKey, String name) {
        CardView card = new CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(cp);
        card.setRadius(dp(12));
        card.setCardElevation(dp(3));
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(14), dp(16), dp(14));

        TextView tvName = new TextView(this);
        tvName.setText("📚 " + name);
        tvName.setTextSize(15.5f);
        tvName.setTextColor(0xFF1E293B);
        tvName.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tvName.setLayoutParams(tp);
        row.addView(tvName);

        Button btnDelete = new Button(this);
        btnDelete.setText("🗑️ Delete");
        btnDelete.setBackgroundColor(0xFFE53935);
        btnDelete.setTextColor(0xFFFFFFFF);
        btnDelete.setOnClickListener(v -> promptDelete(nodeKey, name));
        row.addView(btnDelete);

        card.addView(row);
        containerSubjects.addView(card);
    }

    // ── Add Subject dialog ──────────────────────────────────────────────────
    private void showAddDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(16), dp(24), dp(8));

        TextView label = new TextView(this);
        label.setText("Subject Name");
        label.setTextSize(12f);
        label.setTextColor(0xFF888888);
        layout.addView(label);

        EditText etName = new EditText(this);
        etName.setHint("e.g. Physics");
        layout.addView(etName);

        new AlertDialog.Builder(this)
                .setTitle("Add New Subject")
                .setView(layout)
                .setPositiveButton("Add", (d, w) -> {
                    String name = etName.getText().toString().trim();

                    if (name.isEmpty()) {
                        Toast.makeText(this, "Subject name cannot be empty!",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    String key = sanitizeKey(name);

                    // Duplicate check
                    mDatabase.child("Subjects").child(key)
                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        Toast.makeText(ManageSubjectsActivity.this,
                                                "This subject already exists!",
                                                Toast.LENGTH_SHORT).show();
                                        return;
                                    }

                                    Map<String, Object> map = new HashMap<>();
                                    map.put("name", name);

                                    mDatabase.child("Subjects").child(key).setValue(map)
                                            .addOnSuccessListener(a -> {
                                                Toast.makeText(ManageSubjectsActivity.this,
                                                        "✅ Subject added!", Toast.LENGTH_SHORT).show();
                                                loadSubjectsData(); // refresh list
                                            })
                                            .addOnFailureListener(e -> Toast.makeText(
                                                    ManageSubjectsActivity.this,
                                                    "Error: " + e.getMessage(),
                                                    Toast.LENGTH_SHORT).show());
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
                                    Toast.makeText(ManageSubjectsActivity.this,
                                            "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Delete subject ──────────────────────────────────────────────────────
    private void promptDelete(String nodeKey, String name) {
        new AlertDialog.Builder(this)
                .setTitle("Confirm Delete")
                .setMessage("Do you want to delete \"" + name + "\"?")
                .setPositiveButton("Delete", (d, w) ->
                        mDatabase.child("Subjects").child(nodeKey).removeValue()
                                .addOnSuccessListener(a -> {
                                    Toast.makeText(this, name + " removed.",
                                            Toast.LENGTH_SHORT).show();
                                    loadSubjectsData();
                                }))
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private String sanitizeKey(String name) {
        // Firebase keys cannot contain . # $ [ ] /
        return name.trim()
                .replaceAll("[.#$\\[\\]/]", "_")
                .replaceAll("\\s+", "_");
    }

    private void showEmptyState(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(60), 0, 0);
        containerSubjects.addView(tv);
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}