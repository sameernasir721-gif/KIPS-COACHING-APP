package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FeeActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ImageView ivBack;
    private BottomNavigationView bottomNav;
    private NavigationView navigationView;
    private Button btnPayNow;
    private Button btnViewChallan;
    private EditText etSearch;

    private LinearLayout feeContainer;
    private TextView tvStudentNameFee, tvCurrentAmount, tvDueDateCurrent, tvFeeDueLabel, tvHeaderStudentInfo;

    private final List<FeeItem> allFeeItems = new ArrayList<>();

    // ── Current due month/amount + student info, taake Pay Now button
    //    seedha PayFastLauncher ko sahi values pass kar sake ──────────
    private String currentDueMonth  = "";
    private String currentDueAmount = "0";
    private boolean hasUnpaidFee    = false;
    private String studentNameForPay  = "Student";
    private String studentEmailForPay = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fee);

        // --- Initialization (Sab ko check karein ke IDs theek hain) ---
        drawerLayout     = findViewById(R.id.drawerLayout);
        // YE LINE MISSING THI
        bottomNav        = findViewById(R.id.bottomNav);
        navigationView   = findViewById(R.id.navigationView);
        feeContainer     = findViewById(R.id.feeContainer);
        tvStudentNameFee = findViewById(R.id.tvStudentNameFee);
        tvCurrentAmount  = findViewById(R.id.tvCurrentAmount);
        tvDueDateCurrent = findViewById(R.id.tvDueDateCurrent);

        tvHeaderStudentInfo = findViewById(R.id.tvHeaderStudentInfo);
        btnPayNow        = findViewById(R.id.btnPayNow);
        btnViewChallan   = findViewById(R.id.btnViewChallan);
        etSearch         = findViewById(R.id.etSearch);


        // --- Safety Check: Agar ivBack null nahi hai tab listener lagayein ---
        if (ivBack != null) {
            ivBack.setOnClickListener(v -> finish());
        }

        if (btnPayNow != null) {
            btnPayNow.setOnClickListener(v -> {
                if (!hasUnpaidFee) {
                    Toast.makeText(this, "No pending fee to pay right now.", Toast.LENGTH_SHORT).show();
                    return;
                }
                // ✅ FIX: Ab seedha PayFast khulne ke bajaye pehle Wallet screen
                // khulti hai (jaisa app mein doosri jagah — parent/student
                // selection ke baad — hota hai). Wahan wallet balance dikhega,
                // aur "Pay through PayFast" button se aage payment hogi.
                Intent walletIntent = new Intent(FeeActivity.this, WalletPaymentActivity.class);
                walletIntent.putExtra("fee_amount",    currentDueAmount);
                walletIntent.putExtra("student_name",  studentNameForPay);
                walletIntent.putExtra("student_email", studentEmailForPay);
                walletIntent.putExtra("fee_month",     currentDueMonth);
                walletIntent.putExtra("target_uid",    getIntent().getStringExtra("target_uid"));
                startActivity(walletIntent);
            });
        }

        if (btnViewChallan != null) {
            btnViewChallan.setOnClickListener(v -> {
                Intent challanIntent = new Intent(FeeActivity.this, StudentViewChallanActivity.class);
                // Agar current unpaid month pata hai to seedha wahi challan
                // khulega, warna StudentViewChallanActivity khud latest/unpaid
                // challan dhoond legi.
                if (currentDueMonth != null && !currentDueMonth.isEmpty()) {
                    challanIntent.putExtra(
                            StudentViewChallanActivity.EXTRA_MONTH_KEY,
                            currentDueMonth.replace(" ", "_"));
                }
                startActivity(challanIntent);
            });
        }

        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void afterTextChanged(Editable s) {}
                @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                    filterHistory(s.toString().trim());
                }
            });
        }

        if (bottomNav != null) {
            bottomNav.setOnItemSelectedListener(item -> {
                int id = item.getItemId();
                if (id == R.id.nav_bottom_home) {
                    finish();
                    return true;
                } else if (id == R.id.nav_bottom_feedback) {
                    startActivity(new Intent(this, FeedbackActivity.class));
                    return true;
                } else if (id == R.id.nav_bottom_profile) {
                    startActivity(new Intent(this, ProfileActivity.class));
                    return true;
                }
                return false;
            });
        }

        loadFeeData();
    }

    private void loadFeeData() {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot userSnap) {
                        String name  = userSnap.child("name").getValue(String.class);
                        String email = userSnap.child("email").getValue(String.class);
                        String grade = userSnap.child("className").getValue(String.class);

                        if (name != null && tvStudentNameFee != null)
                            tvStudentNameFee.setText(name);
                        if (name != null) studentNameForPay = name;
                        if (email != null) studentEmailForPay = email;
                        if (tvHeaderStudentInfo != null) {
                            String info = (grade != null ? "Grade: " + grade : "");
                            tvHeaderStudentInfo.setText(info);
                        }

                        FirebaseDatabase.getInstance().getReference("Fees").child(uid)
                                .addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot feeSnap) {
                                        allFeeItems.clear();
                                        String latestUnpaidMonth   = "";
                                        String latestUnpaidAmount  = "0";
                                        String latestUnpaidFine    = "0";
                                        String latestUnpaidDueDate = "-";
                                        boolean foundUnpaid = false;

                                        for (DataSnapshot snap : feeSnap.getChildren()) {
                                            String month     = snap.child("month").getValue(String.class);
                                            String amount    = snap.child("amount").getValue(String.class);
                                            String dueDate   = snap.child("dueDate").getValue(String.class);
                                            String status    = snap.child("status").getValue(String.class);

                                            // ✅ Late fine — Firebase field: "fineAmount" (already calculated)
                                            String lateFine = snap.child("fineAmount").getValue(String.class);
                                            if (lateFine == null) {
                                                Object fineObj = snap.child("fineAmount").getValue();
                                                if (fineObj != null) lateFine = fineObj.toString();
                                            }

                                            // ✅ Paid date/time — Firebase field: "paidAt" (fallback "savedAt")
                                            Long paidAt = snap.child("paidAt").getValue(Long.class);
                                            if (paidAt == null) paidAt = snap.child("savedAt").getValue(Long.class);

                                            if (month == null) continue;

                                            String dispAmount   = (amount   != null) ? amount   : "0";
                                            String dispDue      = (dueDate  != null) ? dueDate  : "-";
                                            String dispStatus   = (status   != null) ? status   : "Unpaid";
                                            String dispLateFine = (lateFine != null && !lateFine.trim().isEmpty()
                                                    && !lateFine.equals("0")) ? lateFine : null;

                                            if (!foundUnpaid && dispStatus.equalsIgnoreCase("Unpaid")) {
                                                latestUnpaidMonth   = month;
                                                latestUnpaidAmount  = dispAmount;
                                                latestUnpaidFine    = (dispLateFine != null) ? dispLateFine : "0";
                                                latestUnpaidDueDate = dispDue;
                                                foundUnpaid = true;
                                            }
                                            allFeeItems.add(new FeeItem(month, dispAmount, dispDue, dispStatus, dispLateFine, paidAt));
                                        }

                                        if (tvDueDateCurrent != null)
                                            tvDueDateCurrent.setText("Due Date: " + latestUnpaidDueDate);

                                        hasUnpaidFee = foundUnpaid;
                                        if (foundUnpaid) {
                                            currentDueMonth  = latestUnpaidMonth;
                                            long feeOnly  = parseLong(latestUnpaidAmount);
                                            long fineOnly = parseLong(latestUnpaidFine);
                                            currentDueAmount = String.valueOf(feeOnly + fineOnly);
                                            showCurrentDueBreakdown(latestUnpaidAmount, latestUnpaidFine);
                                        } else {
                                            currentDueMonth  = "";
                                            currentDueAmount = "0";
                                            if (tvFeeDueLabel != null) tvFeeDueLabel.setText("All fees cleared!");
                                            if (tvCurrentAmount != null) tvCurrentAmount.setText("0 PKR");
                                        }

                                        renderHistory(allFeeItems);
                                    }
                                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                                });
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    // ── Current due card: Total Fee + Total Fine = Grand Total ────────────────
    private void showCurrentDueBreakdown(String amountStr, String fineStr) {
        long fee  = parseLong(amountStr);
        long fine = parseLong(fineStr);
        long grandTotal = fee + fine;

        if (tvCurrentAmount != null) tvCurrentAmount.setText(grandTotal + " PKR");

        if (tvFeeDueLabel != null) {
            if (fine > 0) {
                tvFeeDueLabel.setText(
                        "Fee: " + fee + " PKR  +  ⚠️ Fine: " + fine + " PKR  =  " + grandTotal + " PKR");
            } else {
                tvFeeDueLabel.setText("Fee Due: " + fee + " PKR");
            }
        }
    }

    private long parseLong(String s) {
        if (s == null || s.trim().isEmpty()) return 0;
        try { return Long.parseLong(s.trim()); }
        catch (NumberFormatException e) { return 0; }
    }

    private void filterHistory(String query) {
        List<FeeItem> filtered = new ArrayList<>();
        for (FeeItem item : allFeeItems) {
            if (item.month.toLowerCase().contains(query.toLowerCase())) {
                filtered.add(item);
            }
        }
        renderHistory(filtered);
    }

    private void renderHistory(List<FeeItem> items) {
        if (feeContainer == null) return;
        feeContainer.removeAllViews();

        if (items.isEmpty()) {
            TextView tv = new TextView(this);
            tv.setText("No record found");
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, 50, 0, 50);
            feeContainer.addView(tv);
            return;
        }

        for (int i = 0; i < items.size(); i++) {
            addHistoryRow(items.get(i));
        }
    }

    private void addHistoryRow(FeeItem item) {
        boolean isPaid = item.status.equalsIgnoreCase("Paid");
        float dp = getResources().getDisplayMetrics().density;

        // ── Row wrapper — vertical taake breakdown lines neeche aa sakein ───────
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setPadding(0, 0, 0, (int)(4*dp));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding((int)(10*dp), (int)(15*dp), (int)(10*dp), (int)(15*dp));

        TextView tvMonth = new TextView(this);
        tvMonth.setText(item.month);
        tvMonth.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));

        long fee  = parseLong(item.amount);
        long fine = parseLong(item.lateFine);
        long total = fee + fine;

        TextView tvAmount = new TextView(this);
        tvAmount.setText(total + " PKR");
        tvAmount.setTypeface(null, Typeface.BOLD);
        tvAmount.setPadding(0, 0, (int)(10*dp), 0);

        TextView tvBadge = new TextView(this);
        tvBadge.setText(item.status);
        tvBadge.setTextColor(0xFFFFFFFF);
        tvBadge.setPadding((int)(10*dp), (int)(4*dp), (int)(10*dp), (int)(4*dp));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(isPaid ? 0xFF2E7D32 : 0xFFC62828); // Green for Paid, Red for Unpaid
        bg.setCornerRadius(5 * dp);
        tvBadge.setBackground(bg);

        row.addView(tvMonth);
        row.addView(tvAmount);
        row.addView(tvBadge);
        wrapper.addView(row);

        // ✅ Breakdown row — sirf tab dikhega jab fine maujood ho
        if (item.lateFine != null && fine > 0) {
            TextView tvBreakdown = new TextView(this);
            tvBreakdown.setText("Fee: " + fee + " PKR  +  ⚠️ Fine: " + fine + " PKR  =  " + total + " PKR");
            tvBreakdown.setTextColor(0xFFC62828);
            tvBreakdown.setTextSize(12f);
            tvBreakdown.setTypeface(null, Typeface.BOLD);
            tvBreakdown.setPadding((int)(10*dp), 0, (int)(10*dp), (int)(10*dp));
            wrapper.addView(tvBreakdown);
        }

        // ✅ Paid date/time — sirf tab dikhega jab Firebase mein available ho
        if (item.paidAt != null && item.paidAt > 0) {
            TextView tvPaidDate = new TextView(this);
            String formatted = new java.text.SimpleDateFormat(
                    "dd MMM yyyy, hh:mm a", java.util.Locale.getDefault())
                    .format(new java.util.Date(item.paidAt));
            tvPaidDate.setText("Paid on: " + formatted);
            tvPaidDate.setTextColor(0xFF555555);
            tvPaidDate.setTextSize(12f);
            tvPaidDate.setPadding((int)(10*dp), 0, (int)(10*dp), (int)(6*dp));
            wrapper.addView(tvPaidDate);
        }

        feeContainer.addView(wrapper);
    }

    private static class FeeItem {
        String month, amount, dueDate, status, lateFine;
        Long paidAt;
        FeeItem(String m, String a, String d, String s, String lf, Long paidAt) {
            month = m; amount = a; dueDate = d; status = s; lateFine = lf; this.paidAt = paidAt;
        }
    }
}