package com.example.kipscoachingkharian.dashboard;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;

import androidx.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * PayFastLauncher
 * ────────────────
 * Shared helper jo PayFast form banata hai aur PayFastWebViewActivity
 * launch karta hai. PaymentActivity aur WalletPaymentActivity — dono
 * isi class ko use karte hain, taake PayFast launch karne ka logic
 * sirf ek jagah maintain ho aur dono jagah se seedha (direct) PayFast
 * open ho, beech mein koi extra activity hop na ho.
 */
public final class PayFastLauncher {

    // ── PayFast SA Sandbox Credentials (fallback agar admin config na ho) ──
    private static final String DEFAULT_MERCHANT_ID  = "10050379";
    private static final String DEFAULT_MERCHANT_KEY = "7asdpor0djjhv";
    private static final String SANDBOX_URL = "https://sandbox.payfast.co.za/eng/process";
    private static final String LIVE_URL    = "https://www.payfast.co.za/eng/process";

    private PayFastLauncher() { }

    /**
     * Admin payment_config Firebase se fetch karo, phir PayFast WebView launch karo.
     *
     * @param activity      calling activity (context + finish() ke liye)
     * @param amount        fee amount (string, e.g. "2500")
     * @param studentName   student ka naam
     * @param studentEmail  student ka email
     * @param feeMonth      "June 2026" jaisa format
     * @param purpose       "fee" ya "wallet_topup"
     */
    public static void launch(@NonNull Activity activity,
                              @NonNull String amount,
                              @NonNull String studentName,
                              @NonNull String studentEmail,
                              @NonNull String feeMonth,
                              @NonNull String purpose) {

        ProgressDialog dialog = new ProgressDialog(activity);
        dialog.setTitle("Please Wait");
        dialog.setMessage("Payment is configuring...");
        dialog.setCancelable(false);
        dialog.show();

        FirebaseDatabase.getInstance().getReference("payment_config")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String merchantId  = DEFAULT_MERCHANT_ID;
                        String merchantKey = DEFAULT_MERCHANT_KEY;
                        String passphrase  = "";
                        boolean isSandbox  = true;

                        if (snapshot.exists()) {
                            String mid  = snapshot.child("merchant_id").getValue(String.class);
                            String mkey = snapshot.child("merchant_key").getValue(String.class);
                            String pass = snapshot.child("passphrase").getValue(String.class);
                            String env  = snapshot.child("environment").getValue(String.class);

                            if (mid  != null && !mid.isEmpty())  merchantId  = mid;
                            if (mkey != null && !mkey.isEmpty()) merchantKey = mkey;
                            if (pass != null) passphrase = pass;
                            isSandbox = !"live".equalsIgnoreCase(env);
                        }

                        dialog.dismiss();
                        buildFormAndLaunch(activity, amount, studentName, studentEmail,
                                feeMonth, purpose, merchantId, merchantKey, passphrase, isSandbox);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        dialog.dismiss();
                        buildFormAndLaunch(activity, amount, studentName, studentEmail,
                                feeMonth, purpose, DEFAULT_MERCHANT_ID, DEFAULT_MERCHANT_KEY, "", true);
                    }
                });
    }

    // ── Build PayFast HTML form, save initiated record, launch WebView ──────
    private static void buildFormAndLaunch(Activity activity,
                                           String amount, String studentName, String studentEmail,
                                           String feeMonth, String purpose,
                                           String merchantId, String merchantKey,
                                           String passphrase, boolean isSandbox) {

        String paymentId = "KIPS_" + System.currentTimeMillis();

        // Amount clean karo — "2500.0" → "2500.00"
        double amountDouble;
        try { amountDouble = Double.parseDouble(amount); }
        catch (NumberFormatException e) { amountDouble = 0; }
        String amountFormatted = String.format(Locale.ENGLISH, "%.2f", amountDouble);

        // ✅ FIX: LinkedHashMap use kiya hai (TreeMap NAHI) — PayFast signature
        // ki calculation SIRF isi fixed/documented order mein honi chahiye
        // (alphabetical order mein nahi, jo TreeMap deta tha). Pehle TreeMap
        // ki wajah se fields alphabetically sort ho jaate thay, jisse generated
        // signature PayFast ke apne calculation se match nahi karta tha, aur
        // PayFast "Signature Mismatch" de kar transaction reject kar deta tha —
        // isi wajah se fee kabhi pay nahi ho pati thi.
        LinkedHashMap<String, String> params = new LinkedHashMap<>();
        params.put("merchant_id",      merchantId);
        params.put("merchant_key",     merchantKey);
        params.put("return_url",       "https://kipscoaching.com/payment/success");
        params.put("cancel_url",       "https://kipscoaching.com/payment/cancel");
        params.put("notify_url",       "https://kipscoaching.com/payment/notify");
        params.put("name_first",       splitName(studentName)[0]);
        params.put("name_last",        splitName(studentName)[1]);
        params.put("email_address",    studentEmail == null || studentEmail.isEmpty() ? "student@kips.com" : studentEmail);
        params.put("m_payment_id",     paymentId);
        params.put("amount",           amountFormatted);
        params.put("item_name",        "KIPS Coaching Fee");
        params.put("item_description", "Monthly Fee - " + new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(new Date()));

        // Signature
        StringBuilder sigBuilder = new StringBuilder();
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (sigBuilder.length() > 0) sigBuilder.append("&");
            sigBuilder.append(entry.getKey()).append("=").append(urlEncode(entry.getValue()));
        }
        if (passphrase != null && !passphrase.isEmpty()) {
            sigBuilder.append("&passphrase=").append(urlEncode(passphrase));
        }
        String signature = md5(sigBuilder.toString());
        params.put("signature", signature);

        // HTML form
        String payUrl = isSandbox ? SANDBOX_URL : LIVE_URL;
        StringBuilder formInputs = new StringBuilder();
        for (Map.Entry<String, String> entry : params.entrySet()) {
            formInputs.append("<input type='hidden' name='")
                    .append(entry.getKey()).append("' value='")
                    .append(escapeHtml(entry.getValue())).append("'>\n");
        }
        String htmlForm = "<!DOCTYPE html><html><body>" +
                "<form id='pf' action='" + payUrl + "' method='post'>" +
                formInputs +
                "</form>" +
                "<script>document.getElementById('pf').submit();</script>" +
                "</body></html>";

        // Firebase payment record (initiated)
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            HashMap<String, Object> record = new HashMap<>();
            record.put("paymentId",   paymentId);
            record.put("amount",      amountFormatted);
            record.put("studentName", studentName);
            record.put("status",      "initiated");
            record.put("purpose",     purpose);
            record.put("timestamp",   System.currentTimeMillis());
            record.put("sandbox",     isSandbox);
            FirebaseDatabase.getInstance().getReference("Payments")
                    .child(uid).child(paymentId).setValue(record);
        }

        // WebView launch
        Intent intent = new Intent(activity, PayFastWebViewActivity.class);
        intent.putExtra("htmlData",   htmlForm);
        intent.putExtra("successUrl", "https://kipscoaching.com/payment/success");
        intent.putExtra("paymentId",  paymentId);
        intent.putExtra("fee_month",  feeMonth);
        intent.putExtra("fee_amount", amount);
        intent.putExtra("purpose",    purpose);
        // Parent scenario: jis student ki fee pay ho rahi hai uska uid aage bhejo
        intent.putExtra("target_uid", activity.getIntent().getStringExtra("target_uid"));
        activity.startActivity(intent);
        activity.finish(); // ✅ calling activity stack se hato — back press pe wapas na aaye
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private static String[] splitName(String fullName) {
        if (fullName == null || fullName.trim().isEmpty()) return new String[]{"Student", ""};
        String[] parts = fullName.trim().split(" ", 2);
        return parts.length == 2 ? parts : new String[]{parts[0], ""};
    }

    private static String urlEncode(String value) {
        try { return java.net.URLEncoder.encode(value, "UTF-8"); }
        catch (Exception e) { return value; }
    }

    private static String escapeHtml(String value) {
        return value.replace("&", "&amp;").replace("'", "&#39;").replace("\"", "&quot;");
    }

    private static String md5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(input.getBytes("UTF-8"));
            byte[] bytes = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                String hex = Integer.toHexString(0xFF & b);
                if (hex.length() < 2) sb.append("0");
                sb.append(hex);
            }
            return sb.toString();
        } catch (Exception e) { return ""; }
    }
}