package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Admin screen: Manage Classes & Sections.
 *
 * Flow implemented:
 *  1. Admin opens this screen (from Admin Dashboard -> Manage Classes & Sections card)
 *  2. Existing classes + their sections are loaded and displayed
 *  3. Admin can Add a Class — only from the fixed list: 9th, 10th, 11th, 12th
 *     (already-added classes are excluded from the picker); Admin can Delete a Class.
 *  4. Admin can Add a Section under a selected Class — only from the fixed list: A, B
 *     (already-added sections are excluded from the picker); Admin can Delete a Section.
 *  5. Every section also shows the list of Approved students (from Users/) whose
 *     className + assignedSection match that class/section, so admin can see at a
 *     glance who is enrolled where.
 *  6. All input is validated before saving (empty checks, duplicate checks, fixed-list checks)
 *  6. Data is stored in Firebase Realtime Database under a dedicated node
 *     ("AcademicClasses") — kept separate from the app's existing "Classes"
 *     node (which is used elsewhere for teacher class-schedule sessions) to
 *     avoid any data collision:
 *
 *     AcademicClasses/
 *       <classKey>/
 *          name: "9th"
 *          sections/
 *             <sectionKey>/ name: "A"
 *             <sectionKey>/ name: "B"
 *
 *  7. A confirmation Toast is shown after every successful add/edit/delete.
 */
public class ManageClassesActivity extends AppCompatActivity {

    // Only these sections are allowed per class.
    private static final String[] FIXED_SECTIONS = {"A", "B"};

    // Only these classes are allowed.
    private static final String[] FIXED_CLASSES = {"9th", "10th", "11th", "12th"};

    private DatabaseReference mDatabase;
    private LinearLayout containerClasses;
    private TextView tvCount, tvLoading;
    private Button btnAddClass;
    private ImageView ivBack;
    private final Set<String> existingClassNames = new HashSet<>();

    // gradeDigit ("9","10","11","12") -> section ("A","B") -> list of student names
    private final Map<String, Map<String, List<String>>> studentsByGradeSection = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_classes);

        mDatabase        = FirebaseDatabase.getInstance().getReference();
        containerClasses = findViewById(R.id.containerClassesList);
        tvCount          = findViewById(R.id.tvTotalClassesCount);
        tvLoading        = findViewById(R.id.tvClassesLoading);
        btnAddClass      = findViewById(R.id.btnAddNewClass);
        ivBack           = findViewById(R.id.ivBack);

        if (ivBack != null) ivBack.setOnClickListener(v -> onBackPressed());

        btnAddClass.setOnClickListener(v -> showAddClassPicker());

        loadStudentsThenClasses();
    }

    // ── Firebase: load approved students first (grouped by class+section), ────
    // ── then load Classes + Sections so student lists can be shown inline ─────
    private void loadStudentsThenClasses() {
        if (tvLoading != null) tvLoading.setVisibility(View.VISIBLE);

        mDatabase.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                studentsByGradeSection.clear();

                for (DataSnapshot userSnap : snapshot.getChildren()) {
                    String role = userSnap.child("role").getValue(String.class);
                    if (role == null || !"Student".equalsIgnoreCase(role)) continue;

                    String status = userSnap.child("status").getValue(String.class);
                    if (status == null || !"Approved".equalsIgnoreCase(status)) continue;

                    String name = userSnap.child("name").getValue(String.class);
                    if (name == null || name.isEmpty()) name = "Unnamed Student";

                    String rawClass = userSnap.child("className").getValue(String.class);
                    String rawSection = userSnap.child("assignedSection").getValue(String.class);
                    if (rawClass == null) continue;

                    // className might be e.g. "9", "9th", or combined "9A"
                    String gradeDigits = rawClass.replaceAll("[^0-9]", "");
                    if (gradeDigits.isEmpty()) continue;

                    String section = rawSection;
                    if (section == null || section.isEmpty()) {
                        // fallback: pull trailing letter out of className, e.g. "9A" -> "A"
                        String letters = rawClass.replaceAll("[^A-Za-z]", "");
                        section = letters.isEmpty() ? null : letters.substring(letters.length() - 1).toUpperCase();
                    }
                    if (section == null || section.isEmpty()) continue;
                    section = section.toUpperCase();

                    studentsByGradeSection
                            .computeIfAbsent(gradeDigits, k -> new HashMap<>())
                            .computeIfAbsent(section, k -> new ArrayList<>())
                            .add(name);
                }

                loadClassesData();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (tvLoading != null) tvLoading.setVisibility(View.GONE);
                Toast.makeText(ManageClassesActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ── Firebase: load all Classes + nested Sections ───────────────────────────
    private void loadClassesData() {
        if (tvLoading != null) tvLoading.setVisibility(View.VISIBLE);

        mDatabase.child("AcademicClasses").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                containerClasses.removeAllViews();
                existingClassNames.clear();
                if (tvLoading != null) tvLoading.setVisibility(View.GONE);

                int count = 0;
                for (DataSnapshot classSnap : snapshot.getChildren()) {
                    String classKey = classSnap.getKey();
                    String className = classSnap.child("name").getValue(String.class);
                    if (className == null || className.isEmpty()) className = classKey;

                    existingClassNames.add(className);
                    createClassCard(classKey, className, classSnap.child("sections"));
                    count++;
                }

                if (tvCount != null) tvCount.setText(String.valueOf(count));
                if (count == 0) showEmptyState("No classes have been added yet.");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (tvLoading != null) tvLoading.setVisibility(View.GONE);
                Toast.makeText(ManageClassesActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ── Class card UI (with nested sections) ────────────────────────────────
    private void createClassCard(String classKey, String className, DataSnapshot sectionsSnap) {
        CardView card = new CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(14));
        card.setLayoutParams(cp);
        card.setRadius(dp(14));
        card.setCardElevation(dp(3));
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(16), dp(14), dp(16), dp(14));

        // ── Header row: class name + delete ──
        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvClassName = new TextView(this);
        tvClassName.setText("🏫 " + className);
        tvClassName.setTextSize(16.5f);
        tvClassName.setTextColor(0xFF1E293B);
        tvClassName.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tvClassName.setLayoutParams(tp);
        headerRow.addView(tvClassName);

        Button btnDeleteClass = new Button(this);
        btnDeleteClass.setText("🗑️");
        btnDeleteClass.setBackgroundColor(0xFFE53935);
        btnDeleteClass.setTextColor(0xFFFFFFFF);
        btnDeleteClass.setOnClickListener(v -> promptDeleteClass(classKey, className));
        headerRow.addView(btnDeleteClass);

        outer.addView(headerRow);

        // ── Divider ──
        View divider = new View(this);
        LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(-1, dp(1));
        dp1.setMargins(0, dp(10), 0, dp(10));
        divider.setLayoutParams(dp1);
        divider.setBackgroundColor(0xFFE0E0E0);
        outer.addView(divider);

        // ── Sections label + Add Section button ──
        LinearLayout sectionHeaderRow = new LinearLayout(this);
        sectionHeaderRow.setOrientation(LinearLayout.HORIZONTAL);
        sectionHeaderRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvSectionsLabel = new TextView(this);
        tvSectionsLabel.setText("Sections");
        tvSectionsLabel.setTextSize(13f);
        tvSectionsLabel.setTextColor(0xFF888888);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0, -2, 1f);
        tvSectionsLabel.setLayoutParams(slp);
        sectionHeaderRow.addView(tvSectionsLabel);

        // ── Collect which of the fixed sections (A, B) already exist ──
        Set<String> existingSectionNames = new HashSet<>();
        if (sectionsSnap != null && sectionsSnap.exists()) {
            for (DataSnapshot secSnap : sectionsSnap.getChildren()) {
                String sectionName = secSnap.child("name").getValue(String.class);
                if (sectionName != null) existingSectionNames.add(sectionName);
            }
        }

        Button btnAddSection = new Button(this);
        btnAddSection.setText("+ Section");
        btnAddSection.setTextSize(12f);
        btnAddSection.setBackgroundColor(0xFF1E88E5);
        btnAddSection.setTextColor(0xFFFFFFFF);
        btnAddSection.setOnClickListener(v ->
                showAddSectionPicker(classKey, existingSectionNames));
        sectionHeaderRow.addView(btnAddSection);

        outer.addView(sectionHeaderRow);

        // ── Sections list ──
        LinearLayout sectionsContainer = new LinearLayout(this);
        sectionsContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams scp = new LinearLayout.LayoutParams(-1, -2);
        scp.setMargins(0, dp(8), 0, 0);
        sectionsContainer.setLayoutParams(scp);

        if (sectionsSnap != null && sectionsSnap.exists()) {
            String gradeDigits = classKey.replaceAll("[^0-9]", "");
            if (gradeDigits.isEmpty()) gradeDigits = className.replaceAll("[^0-9]", "");
            Map<String, List<String>> sectionsForGrade =
                    studentsByGradeSection.getOrDefault(gradeDigits, new HashMap<>());

            for (DataSnapshot secSnap : sectionsSnap.getChildren()) {
                String sectionKey = secSnap.getKey();
                String sectionName = secSnap.child("name").getValue(String.class);
                if (sectionName == null || sectionName.isEmpty()) sectionName = sectionKey;

                List<String> studentsInSection = sectionsForGrade.getOrDefault(
                        sectionName.toUpperCase(), new ArrayList<>());

                sectionsContainer.addView(
                        buildSectionRow(classKey, sectionKey, sectionName, studentsInSection));
            }
        } else {
            TextView tvNoSections = new TextView(this);
            tvNoSections.setText("No sections have been added yet.");
            tvNoSections.setTextSize(12.5f);
            tvNoSections.setTextColor(0xFFAAAAAA);
            sectionsContainer.addView(tvNoSections);
        }

        outer.addView(sectionsContainer);
        card.addView(outer);
        containerClasses.addView(card);
    }

    private View buildSectionRow(String classKey, String sectionKey, String sectionName,
                                 List<String> studentsInSection) {
        LinearLayout outerBlock = new LinearLayout(this);
        outerBlock.setOrientation(LinearLayout.VERTICAL);
        outerBlock.setBackgroundColor(0xFFF7F7F7);
        outerBlock.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams blockLp = new LinearLayout.LayoutParams(-1, -2);
        blockLp.setMargins(0, 0, 0, dp(6));
        outerBlock.setLayoutParams(blockLp);

        // ── Header: section name (+ student count) + delete ──
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvSection = new TextView(this);
        tvSection.setText("Section " + sectionName + "  (" + studentsInSection.size() + " students)");
        tvSection.setTextSize(14f);
        tvSection.setTextColor(0xFF333333);
        tvSection.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tvSection.setLayoutParams(tp);
        row.addView(tvSection);

        Button btnDelete = new Button(this);
        btnDelete.setText("🗑️");
        btnDelete.setTextSize(11f);
        btnDelete.setBackgroundColor(0xFFE53935);
        btnDelete.setTextColor(0xFFFFFFFF);
        btnDelete.setOnClickListener(v ->
                promptDeleteSection(classKey, sectionKey, sectionName));
        row.addView(btnDelete);

        outerBlock.addView(row);

        // ── Students list ──
        TextView tvStudents = new TextView(this);
        tvStudents.setTextSize(12.5f);
        tvStudents.setTextColor(0xFF555555);
        tvStudents.setPadding(dp(4), dp(6), dp(4), dp(2));
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2);
        stp.setMargins(0, dp(4), 0, 0);
        tvStudents.setLayoutParams(stp);

        if (studentsInSection.isEmpty()) {
            tvStudents.setText("There are no students in this section yet.");
            tvStudents.setTextColor(0xFFAAAAAA);
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < studentsInSection.size(); i++) {
                sb.append("• ").append(studentsInSection.get(i));
                if (i != studentsInSection.size() - 1) sb.append("\n");
            }
            tvStudents.setText(sb.toString());
        }
        outerBlock.addView(tvStudents);

        return outerBlock;
    }

    // ── Add Class picker (only fixed 9th/10th/11th/12th allowed) ────────────
    private void showAddClassPicker() {
        List<String> available = new ArrayList<>();
        for (String c : FIXED_CLASSES) {
            if (!existingClassNames.contains(c)) available.add(c);
        }

        // ── Validation: all 4 classes already added ──
        if (available.isEmpty()) {
            Toast.makeText(this, "All classes (9th, 10th, 11th, 12th) already exist!",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        String[] labels = available.toArray(new String[0]);

        new AlertDialog.Builder(this)
                .setTitle("Select Class")
                .setItems(labels, (d, which) -> addNewClass(available.get(which)))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void addNewClass(String name) {
        String key = sanitizeKey(name);

        mDatabase.child("AcademicClasses").child(key).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Toast.makeText(ManageClassesActivity.this,
                            "This class already exists!", Toast.LENGTH_SHORT).show();
                    return;
                }

                Map<String, Object> map = new HashMap<>();
                map.put("name", name);

                mDatabase.child("AcademicClasses").child(key).setValue(map)
                        .addOnSuccessListener(a -> {
                            Toast.makeText(ManageClassesActivity.this,
                                    "✅ Class added successfully!", Toast.LENGTH_SHORT).show();
                            loadClassesData();
                        })
                        .addOnFailureListener(e -> Toast.makeText(ManageClassesActivity.this,
                                "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ManageClassesActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void promptDeleteClass(String key, String name) {
        new AlertDialog.Builder(this)
                .setTitle("Confirm Delete")
                .setMessage("Do you want to delete \"" + name + "\" along with all its sections?")
                .setPositiveButton("Delete", (d, w) ->
                        mDatabase.child("AcademicClasses").child(key).removeValue()
                                .addOnSuccessListener(a -> {
                                    Toast.makeText(this, "✅ " + name + " deleted.",
                                            Toast.LENGTH_SHORT).show();
                                    loadClassesData();
                                })
                                .addOnFailureListener(e -> Toast.makeText(this,
                                        "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Add Section picker (only fixed A / B allowed) ───────────────────────
    private void showAddSectionPicker(String classKey, Set<String> existingNames) {
        List<String> available = new ArrayList<>();
        for (String s : FIXED_SECTIONS) {
            if (!existingNames.contains(s)) available.add(s);
        }

        // ── Validation: both sections already added ──
        if (available.isEmpty()) {
            Toast.makeText(this, "Both Section A and Section B already exist in this class!",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        String[] labels = new String[available.size()];
        for (int i = 0; i < available.size(); i++) labels[i] = "Section " + available.get(i);

        new AlertDialog.Builder(this)
                .setTitle("Select Section")
                .setItems(labels, (d, which) -> addNewSection(classKey, available.get(which)))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void addNewSection(String classKey, String name) {
        String sectionKey = sanitizeKey(name);
        DatabaseReference sectionsRef = mDatabase.child("AcademicClasses").child(classKey).child("sections");

        sectionsRef.child(sectionKey).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Toast.makeText(ManageClassesActivity.this,
                            "This section already exists!", Toast.LENGTH_SHORT).show();
                    return;
                }

                Map<String, Object> map = new HashMap<>();
                map.put("name", name);

                sectionsRef.child(sectionKey).setValue(map)
                        .addOnSuccessListener(a -> {
                            Toast.makeText(ManageClassesActivity.this,
                                    "✅ Section added successfully!", Toast.LENGTH_SHORT).show();
                            loadClassesData();
                        })
                        .addOnFailureListener(e -> Toast.makeText(ManageClassesActivity.this,
                                "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ManageClassesActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void promptDeleteSection(String classKey, String sectionKey, String sectionName) {
        new AlertDialog.Builder(this)
                .setTitle("Confirm Delete")
                .setMessage("Do you want to delete Section \"" + sectionName + "\"?")
                .setPositiveButton("Delete", (d, w) ->
                        mDatabase.child("AcademicClasses").child(classKey).child("sections")
                                .child(sectionKey).removeValue()
                                .addOnSuccessListener(a -> {
                                    Toast.makeText(this, "✅ Section " + sectionName + " deleted.",
                                            Toast.LENGTH_SHORT).show();
                                    loadClassesData();
                                })
                                .addOnFailureListener(e -> Toast.makeText(this,
                                        "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private String sanitizeKey(String name) {
        // Firebase keys cannot contain . # $ [ ] /
        return name.trim()
                .replaceAll("[.#$\\[\\]/]", "_")
                .replaceAll("\\s+", "_");
    }

    private void showEmptyState(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(60), 0, 0);
        containerClasses.addView(tv);
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}