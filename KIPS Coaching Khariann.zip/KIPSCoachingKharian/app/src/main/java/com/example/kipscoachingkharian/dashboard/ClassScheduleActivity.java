package com.example.kipscoachingkharian.dashboard;

import android.app.DownloadManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ClassScheduleActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    private ImageView ivMenu;
    private NavigationView navigationView;
    private BottomNavigationView bottomNav;
    private TextView tvStudentInfo, tvStudentNameTop, tvTimetableStatus;
    private View layoutPdfActions;
    private MaterialButton btnViewTimetablePdf;
    private MaterialButton btnShareTimetablePdf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_schedule);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, LoginSelectionActivity.class));
            finish();
            return;
        }

        // ── Views ──────────────────────────────────────────────────────────
        drawerLayout         = findViewById(R.id.drawerLayout);
        ivMenu               = findViewById(R.id.ivMenu);
        navigationView       = findViewById(R.id.navigationView);
        bottomNav            = findViewById(R.id.bottomNav);
        tvStudentInfo        = findViewById(R.id.tvStudentInfo);
        tvStudentNameTop     = findViewById(R.id.tvStudentNameTop);
        tvTimetableStatus    = findViewById(R.id.tvTimetableStatus);
        layoutPdfActions     = findViewById(R.id.layoutPdfActions);
        btnViewTimetablePdf  = findViewById(R.id.btnViewTimetablePdf);
        btnShareTimetablePdf = findViewById(R.id.btnShareTimetablePdf);

        // ── Button styles — screenshot se match ────────────────────────────
        styleButtons();

        if (ivMenu != null)
            ivMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        if (navigationView != null)
            navigationView.setNavigationItemSelectedListener(this);

        setupBottomNav();
        loadStudentInfo();
        loadLatestTimetablePdf();
    }

    // ── Buttons ko screenshot wali style do ───────────────────────────────────
    private void styleButtons() {
        if (btnViewTimetablePdf != null) {
            // VIEW button — light blue background, red text
            btnViewTimetablePdf.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(0xFFBBDEFB)); // light blue
            btnViewTimetablePdf.setTextColor(0xFFD50000);                    // red text
            btnViewTimetablePdf.setText("VIEW");
            btnViewTimetablePdf.setMaxLines(1);
            btnViewTimetablePdf.setEllipsize(android.text.TextUtils.TruncateAt.END);
            btnViewTimetablePdf.setStrokeColor(
                    android.content.res.ColorStateList.valueOf(0xFFBBDEFB));
        }

        if (btnShareTimetablePdf != null) {
            // DOWNLOAD button — red background, white text, download icon
            btnShareTimetablePdf.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(0xFFD50000)); // red
            btnShareTimetablePdf.setTextColor(0xFFFFFFFF);                   // white text
            btnShareTimetablePdf.setText("DOWNLOAD");
            btnShareTimetablePdf.setMaxLines(1);
            btnShareTimetablePdf.setEllipsize(android.text.TextUtils.TruncateAt.END);
        }
    }

    // ── Latest timetable PDF load karo ───────────────────────────────────────
    private void loadLatestTimetablePdf() {
        if (btnViewTimetablePdf == null) return;

        if (tvTimetableStatus != null) {
            tvTimetableStatus.setText("Loading timetable...");
            tvTimetableStatus.setVisibility(View.VISIBLE);
        }

        FirebaseDatabase.getInstance().getReference("Announcements").child("Students")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String latestPdfUrl = null;
                        long latestTimestamp = -1;

                        for (DataSnapshot item : snapshot.getChildren()) {
                            String type      = item.child("type").getValue(String.class);
                            String pdfUrl    = item.child("pdfUrl").getValue(String.class);
                            Long timestampL  = item.child("timestamp").getValue(Long.class);
                            long timestamp   = (timestampL != null) ? timestampL : 0;

                            if ("timetable".equals(type) && pdfUrl != null
                                    && !pdfUrl.isEmpty() && timestamp > latestTimestamp) {
                                latestTimestamp = timestamp;
                                latestPdfUrl    = pdfUrl;
                            }
                        }

                        if (latestPdfUrl != null) {
                            final String pdfUrlToOpen = latestPdfUrl;

                            // Status hide, buttons show
                            if (tvTimetableStatus != null)
                                tvTimetableStatus.setVisibility(View.GONE);
                            if (layoutPdfActions != null)
                                layoutPdfActions.setVisibility(View.VISIBLE);

                            btnViewTimetablePdf.setOnClickListener(v -> {
                                try {
                                    Intent pdfIntent = new Intent(Intent.ACTION_VIEW);
                                    pdfIntent.setDataAndType(Uri.parse(pdfUrlToOpen), "application/pdf");
                                    pdfIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                            | Intent.FLAG_GRANT_READ_URI_PERMISSION);

                                    if (pdfIntent.resolveActivity(getPackageManager()) != null) {
                                        startActivity(pdfIntent);
                                    } else {
                                        startActivity(new Intent(Intent.ACTION_VIEW,
                                                Uri.parse(pdfUrlToOpen)));
                                    }
                                } catch (Exception e) {
                                    Toast.makeText(ClassScheduleActivity.this,
                                            "Could not open PDF: " + e.getMessage(),
                                            Toast.LENGTH_LONG).show();
                                }
                            });

                            if (btnShareTimetablePdf != null)
                                btnShareTimetablePdf.setOnClickListener(v ->
                                        downloadTimetablePdf(pdfUrlToOpen));

                        } else {
                            // Koi timetable nahi mila
                            if (layoutPdfActions != null)
                                layoutPdfActions.setVisibility(View.GONE);
                            if (tvTimetableStatus != null) {
                                tvTimetableStatus.setText("No timetable has been uploaded yet.");
                                tvTimetableStatus.setVisibility(View.VISIBLE);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (layoutPdfActions != null)
                            layoutPdfActions.setVisibility(View.GONE);
                        if (tvTimetableStatus != null) {
                            tvTimetableStatus.setText("Could not load the timetable.");
                            tvTimetableStatus.setVisibility(View.VISIBLE);
                        }
                    }
                });
    }

    // ── PDF download ──────────────────────────────────────────────────────────
    private void downloadTimetablePdf(String pdfUrl) {
        try {
            String fileName = "KIPS_Timetable_" + System.currentTimeMillis() + ".pdf";

            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(pdfUrl));
            request.setTitle("KIPS Timetable");
            request.setDescription("Timetable PDF download ho rahi hai...");
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS, fileName);
            request.setMimeType("application/pdf");
            request.allowScanningByMediaScanner();

            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.enqueue(request);
                Toast.makeText(this,
                        "Download started — check your Downloads folder",
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Download service not available",
                        Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Download failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    // ── Student info — naam header mein aur profile icon ke neeche ───────────
    private void loadStudentInfo() {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String name  = snapshot.child("name").getValue(String.class);
                        String grade = snapshot.child("className").getValue(String.class);

                        String displayName = (name != null && !name.trim().isEmpty())
                                ? name : "Student";

                        // tvStudentNameTop — XML mein "Student" hardcoded hai, wahi rahega

                        // Header subtitle — sirf grade show hoga, name hata diya gaya
                        if (tvStudentInfo != null)
                            tvStudentInfo.setText("Grade: " + (grade != null ? grade : "--"));
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void setupBottomNav() {
        if (bottomNav == null) return;
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                finish(); return true;
            } else if (id == R.id.nav_bottom_feedback) {
                startActivity(new Intent(this, FeedbackActivity.class)); return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileActivity.class)); return true;
            }
            return false;
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.nav_logout) {
            FirebaseAuth.getInstance().signOut();
            Intent i = new Intent(this, LoginSelectionActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finishAffinity();
        }
        if (drawerLayout != null)
            drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}