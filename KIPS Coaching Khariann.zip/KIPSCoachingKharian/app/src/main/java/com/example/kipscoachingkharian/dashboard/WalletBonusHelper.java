package com.example.kipscoachingkharian.dashboard;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * WalletBonusHelper
 * ──────────────────
 * Har (approved) student ke wallet mein ek dafa Rs. 50,000 ka "Welcome
 * Bonus" automatically credit karta hai.
 *
 *  • creditWelcomeBonus(uid, name)  → EK student ko bonus deta hai
 *    (naya student jab Approve hota hai, tab call hota hai).
 *
 *  • runBulkCreditForAllStudents()  → EK dafa poori "Users" list check
 *    karta hai aur jin students ko abhi tak bonus nahi mila, unhe deta hai
 *    (already-approved purane students ke liye — app ke pehli baar chalne
 *    par admin dashboard khulte hi automatically chal jata hai).
 *
 * ✅ Idempotent: har student ke "Wallets/{uid}/welcomeBonusGiven" flag se
 *    check hota hai, isi liye koi student kabhi 2 dafa credit nahi hota,
 *    chahe ye function kitni bhi baar chale.
 */
public final class WalletBonusHelper {

    // ── Yahan se amount change kar sakte hain ───────────────────────────────
    public static final long WELCOME_BONUS_AMOUNT = 50000L;

    // ✅ Ye flag ek dafa "true" ho jaye to bulk migration dobara kabhi nahi
    // chalti — taake har admin login par poori Users list scan na ho.
    private static final String MIGRATION_DONE_PATH = "Metadata/walletBonusMigrationDone";

    private WalletBonusHelper() { }

    // ─────────────────────────────────────────────────────────────────────────
    // EK student ko welcome bonus do (agar pehle nahi mila)
    // ─────────────────────────────────────────────────────────────────────────
    public static void creditWelcomeBonus(@NonNull String studentUid, @NonNull String studentName) {
        DatabaseReference root = FirebaseDatabase.getInstance().getReference();
        DatabaseReference walletRef = root.child("Wallets").child(studentUid);

        walletRef.get().addOnSuccessListener(snap -> {
            Boolean alreadyGiven = snap.child("welcomeBonusGiven").getValue(Boolean.class);
            if (Boolean.TRUE.equals(alreadyGiven)) return; // ✅ pehle hi mil chuka — dobara mat do

            long currentBalance = 0;
            Object balObj = snap.child("balance").getValue();
            if (balObj != null) {
                try { currentBalance = Long.parseLong(balObj.toString()); }
                catch (NumberFormatException ignored) { }
            }
            long newBalance = currentBalance + WELCOME_BONUS_AMOUNT;
            String today = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());

            String txId = walletRef.child("transactions").push().getKey();

            Map<String, Object> updates = new HashMap<>();
            updates.put("balance",            newBalance);
            updates.put("welcomeBonusGiven",  true);
            updates.put("welcomeBonusAt",     System.currentTimeMillis());
            if (txId != null) {
                updates.put("transactions/" + txId + "/type",         "credit");
                updates.put("transactions/" + txId + "/amount",       WELCOME_BONUS_AMOUNT);
                updates.put("transactions/" + txId + "/description",  "Welcome Bonus (Auto Credit)");
                updates.put("transactions/" + txId + "/date",         today);
                updates.put("transactions/" + txId + "/balanceAfter", newBalance);
            }

            walletRef.updateChildren(updates);

            // ✅ Student ko notification bhi bhej dein taake use pata chale
            String announceId = root.child("Notifications").child(studentUid).push().getKey();
            if (announceId != null) {
                Map<String, Object> notif = new HashMap<>();
                notif.put("title",     "🎉 Welcome Bonus Credited!");
                notif.put("message",   "Rs. " + WELCOME_BONUS_AMOUNT
                        + " has been added to your wallet as a welcome bonus. New balance: Rs. " + newBalance);
                notif.put("type",      "wallet_bonus");
                notif.put("timestamp", System.currentTimeMillis());
                notif.put("isRead",    false);
                root.child("Notifications").child(studentUid).child(announceId).setValue(notif);
            }
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Ek dafa chalne wali migration: jitne students PEHLE se maujood/Approved
    // hain, unhe bhi bonus de do. Safe hai baar-baar call karne ke liye —
    // andar hi flag check hota hai.
    // ─────────────────────────────────────────────────────────────────────────
    public static void runBulkCreditForAllStudents() {
        DatabaseReference root = FirebaseDatabase.getInstance().getReference();

        root.child(MIGRATION_DONE_PATH).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot doneSnap) {
                Boolean done = doneSnap.getValue(Boolean.class);
                if (Boolean.TRUE.equals(done)) return; // ✅ ye migration pehle hi ho chuki hai

                root.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot usersSnap) {
                        for (DataSnapshot userSnap : usersSnap.getChildren()) {
                            String role   = userSnap.child("role").getValue(String.class);
                            String status = userSnap.child("status").getValue(String.class);
                            String name   = userSnap.child("name").getValue(String.class);

                            if (!"Student".equalsIgnoreCase(role)) continue;
                            if (!"Approved".equalsIgnoreCase(status)) continue; // sirf approved students

                            String uid = userSnap.getKey();
                            if (uid == null) continue;

                            creditWelcomeBonus(uid, name != null ? name : "Student");
                        }

                        // ✅ Migration complete mark karo — dobara kabhi nahi chalegi
                        root.child(MIGRATION_DONE_PATH).setValue(true);
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) { }
                });
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        });
    }
}
