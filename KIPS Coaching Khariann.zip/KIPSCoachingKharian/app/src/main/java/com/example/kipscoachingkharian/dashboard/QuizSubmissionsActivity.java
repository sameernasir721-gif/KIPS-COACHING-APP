package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.BuildConfig;
import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Set;

public class QuizSubmissionsActivity extends AppCompatActivity {

    public static final String EXTRA_QUIZ_ID    = "quiz_id";
    public static final String EXTRA_QUIZ_TITLE = "quiz_title";
    public static final String EXTRA_TEACHER_ID = "teacher_id";

    private RecyclerView rvAttempts;
    private LinearLayout layoutEmpty;
    private TextView tvTitle, tvCount;
    private AttemptsAdapter adapter;
    private final List<Map<String, Object>> attemptList = new ArrayList<>();

    private DatabaseReference attemptsRef;
    private ValueEventListener attemptsListener;
    private android.widget.Button btnCheckSimilarity;
    private android.widget.Button btnAiCheck;
    private String currentQuizId;
    private String currentTeacherUid;
    private OkHttpClient httpClient;
    private static final String GROQ_API_KEY = BuildConfig.GROQ_API_KEY;
    private static final String GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
    private static final String GROQ_MODEL = "openai/gpt-oss-120b";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_submissions);

        String quizId    = getIntent().getStringExtra(EXTRA_QUIZ_ID);
        String quizTitle = getIntent().getStringExtra(EXTRA_QUIZ_TITLE);

        rvAttempts  = findViewById(R.id.rvAttempts);
        layoutEmpty = findViewById(R.id.layoutEmpty);
        tvTitle     = findViewById(R.id.tvQuizTitle);
        tvCount     = findViewById(R.id.tvAttemptCount);
        ImageView ivBack = findViewById(R.id.ivBack);

        currentQuizId = quizId;
        currentTeacherUid = getIntent().getStringExtra(EXTRA_TEACHER_ID);
        if (quizTitle != null) tvTitle.setText(quizTitle);
        ivBack.setOnClickListener(v -> finish());

        // ── Check Similarity button ──────────────────────────────────────
        btnCheckSimilarity = findViewById(R.id.btnCheckSimilarity);
        if (btnCheckSimilarity != null) {
            btnCheckSimilarity.setOnClickListener(v -> checkSimilarity());
        }

        // ── AI Check button ──────────────────────────────────────────────
        httpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();
        btnAiCheck = findViewById(R.id.btnAiCheck);
        if (btnAiCheck != null) {
            btnAiCheck.setOnClickListener(v -> runAiSimilarityCheck());
        }

        rvAttempts.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AttemptsAdapter(attemptList);
        rvAttempts.setAdapter(adapter);

        if (quizId != null) loadAttempts(quizId);
        else showEmpty();

        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                startActivity(new Intent(this, TeacherDashboardActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_Announcment) {
                startActivity(new Intent(this, TeacherAnnouncementsActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileMenuActivity.class));
                finish(); return true;
            }
            return false;
        });
    }

    private void loadAttempts(String quizId) {
        attemptsRef = FirebaseDatabase.getInstance()
                .getReference("QuizAttempts").child(quizId);

        attemptsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                attemptList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> item = (Map<String, Object>) child.getValue();
                    if (item == null) continue;
                    // answers nested map properly parse karo
                    DataSnapshot answersSnap = child.child("answers");
                    if (answersSnap.exists()) {
                        Map<String, Object> answersMap = new java.util.LinkedHashMap<>();
                        for (DataSnapshot qSnap : answersSnap.getChildren()) {
                            Map<String, Object> qData = new java.util.LinkedHashMap<>();
                            for (DataSnapshot field : qSnap.getChildren()) {
                                qData.put(field.getKey(), field.getValue());
                            }
                            answersMap.put(qSnap.getKey(), qData);
                        }
                        item.put("answers", answersMap);
                    }
                    attemptList.add(item);
                }
                adapter.notifyDataSetChanged();
                int count = attemptList.size();
                tvCount.setText(count + (count == 1 ? " Attempt" : " Attempts"));
                if (count == 0) showEmpty();
                else {
                    rvAttempts.setVisibility(View.VISIBLE);
                    layoutEmpty.setVisibility(View.GONE);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(QuizSubmissionsActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };
        attemptsRef.addValueEventListener(attemptsListener);
    }

    private void showEmpty() {
        rvAttempts.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.VISIBLE);
        tvCount.setText("0 Attempts");
    }

    private String getVal(Map<String, Object> map, String key) {
        Object v = map.get(key); return v != null ? v.toString() : "";
    }

    // ── Similarity Detection ─────────────────────────────────────────────
    private void checkSimilarity() {
        if (attemptList.isEmpty()) {
            android.widget.Toast.makeText(this, "No submissions yet.", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }

        // Collect short answers per student per question
        // Structure: studentName -> questionIndex -> answer
        List<String> studentNames   = new ArrayList<>();
        List<Map<String, String>> studentAnswers = new ArrayList<>(); // per student: qIndex -> answer

        for (Map<String, Object> attempt : attemptList) {
            String name = getVal(attempt, "studentName");
            if (name.isEmpty()) name = getVal(attempt, "studentUid");

            Map<String, String> ansMap = new HashMap<>();
            Object answersObj = attempt.get("answers");
            if (answersObj instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> answers = (Map<String, Object>) answersObj;
                for (Map.Entry<String, Object> e : answers.entrySet()) {
                    if (e.getValue() instanceof Map) {
                        @SuppressWarnings("unchecked")
                        Map<String, Object> qData = (Map<String, Object>) e.getValue();
                        String type = qData.containsKey("type") ? qData.get("type").toString().toLowerCase() : "mcq";
                        // Only short answers
                        if (!type.contains("mcq") && !type.contains("multiple")) {
                            String ans = qData.containsKey("answer") ? qData.get("answer").toString().trim() : "";
                            if (!ans.isEmpty()) ansMap.put(e.getKey(), ans.toLowerCase());
                        }
                    }
                }
            }
            studentNames.add(name);
            studentAnswers.add(ansMap);
        }

        // Find all short question keys
        Set<String> allQKeys = new HashSet<>();
        for (Map<String, String> m : studentAnswers) allQKeys.addAll(m.keySet());

        if (allQKeys.isEmpty()) {
            android.widget.Toast.makeText(this,
                    "No short answers found to compare.", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }

        // Compare all pairs
        StringBuilder report = new StringBuilder();
        boolean anyFlag = false;

        for (int i = 0; i < studentAnswers.size(); i++) {
            for (int j = i + 1; j < studentAnswers.size(); j++) {
                for (String qKey : allQKeys) {
                    String a1 = studentAnswers.get(i).get(qKey);
                    String a2 = studentAnswers.get(j).get(qKey);
                    if (a1 == null || a2 == null || a1.isEmpty() || a2.isEmpty()) continue;

                    int sim = similarityPercent(a1, a2);
                    if (sim >= 70) {
                        anyFlag = true;
                        String emoji = sim >= 90 ? "🔴" : "🟡";
                        report.append(emoji).append(" ")
                                .append(studentNames.get(i)).append(" & ")
                                .append(studentNames.get(j))
                                .append(" — ").append(qKey.toUpperCase())
                                .append(": ").append(sim).append("% similar\n\n");
                    }
                }
            }
        }

        String msg = anyFlag ? report.toString().trim()
                : "✅ No suspicious similarity found.\n\nAll short answers appear original.";

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("🔍 Similarity Report")
                .setMessage(msg)
                .setPositiveButton("OK", null)
                .show();
    }

    // ── Jaccard similarity between two strings (word-level) ───────────────
    private int similarityPercent(String a, String b) {
        String[] wordsA = a.split("\\s+");
        String[] wordsB = b.split("\\s+");
        Set<String> setA = new HashSet<>();
        Set<String> setB = new HashSet<>();
        for (String w : wordsA) if (w.length() > 2) setA.add(w);
        for (String w : wordsB) if (w.length() > 2) setB.add(w);
        if (setA.isEmpty() && setB.isEmpty()) return 100;
        if (setA.isEmpty() || setB.isEmpty()) return 0;

        Set<String> intersection = new HashSet<>(setA);
        intersection.retainAll(setB);
        Set<String> union = new HashSet<>(setA);
        union.addAll(setB);

        return (int) ((intersection.size() * 100.0) / union.size());
    }

    // ── Groq AI Originality Check ───────────────────────────────────────
    private void runAiSimilarityCheck() {
        if (attemptList.isEmpty()) {
            Toast.makeText(this, "No submissions yet.", Toast.LENGTH_SHORT).show();
            return;
        }
        List<String> studentNames = new ArrayList<>();
        List<String> shortAnswers = new ArrayList<>();
        List<String> questionKeys = new ArrayList<>();

        for (Map<String, Object> attempt : attemptList) {
            String name = getVal(attempt, "studentName");
            if (name.isEmpty()) name = getVal(attempt, "studentUid");
            Object answersObj = attempt.get("answers");
            if (answersObj instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> answers = (Map<String, Object>) answersObj;
                for (Map.Entry<String, Object> e : answers.entrySet()) {
                    if (e.getValue() instanceof Map) {
                        @SuppressWarnings("unchecked")
                        Map<String, Object> qData = (Map<String, Object>) e.getValue();
                        String type = qData.containsKey("type") ? qData.get("type").toString().toLowerCase() : "mcq";
                        if (!type.contains("mcq") && !type.contains("multiple")) {
                            String ans = qData.containsKey("answer") ? qData.get("answer").toString().trim() : "";
                            if (!ans.isEmpty()) {
                                studentNames.add(name);
                                shortAnswers.add(ans);
                                questionKeys.add(e.getKey().toUpperCase());
                            }
                        }
                    }
                }
            }
        }
        if (shortAnswers.isEmpty()) {
            Toast.makeText(this, "No short answers found to check.", Toast.LENGTH_SHORT).show();
            return;
        }
        androidx.appcompat.app.AlertDialog loadingDialog = new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("🤖 AI Analyzing...")
                .setMessage("AI is checking each answer for originality. Please wait...")
                .setCancelable(false).create();
        loadingDialog.show();

        StringBuilder prompt = new StringBuilder();
        prompt.append("You are an academic integrity checker for a school quiz. ")
                .append("For EACH numbered entry below, judge independently (do NOT compare entries to each other). ")
                .append("Identify exact words/phrases in that entry's answer that look:\n")
                .append("- copied: copy-pasted from a textbook/website (not AI)\n")
                .append("- aiGenerated: written by an AI tool like ChatGPT — overly polished grammar, ")
                .append("generic/formal tone, robotic structure, phrases like 'Furthermore', 'In conclusion', 'Moreover', ")
                .append("unnaturally textbook-perfect wording, or — even in SHORT answers — sounds like a complete, ")
                .append("polished dictionary/textbook definition rather than how a student would casually phrase it ")
                .append("(e.g. a perfectly grammatical, generic phrase with no personal voice or hesitation)\n\n")
                .append("Respond with ONLY a raw JSON array, no markdown, no code fences, no extra text. ")
                .append("Each item must look exactly like this:\n")
                .append("{\"index\":0,\"copied\":[\"exact phrase from the answer\"],\"aiGenerated\":[\"exact phrase from the answer\"]}\n")
                .append("Both arrays must contain ONLY exact substrings that appear word-for-word in that entry's answer text. ")
                .append("If the whole answer looks copied/AI-generated, put the whole answer text as one phrase. ")
                .append("If the answer looks completely original/natural, leave both arrays empty: []. ")
                .append("Never invent text that isn't in the answer.\n\n");
        for (int i = 0; i < studentNames.size(); i++) {
            prompt.append("Entry ").append(i).append(" — Student: ").append(studentNames.get(i))
                    .append(" | Q: ").append(questionKeys.get(i))
                    .append("\nAnswer: ").append(shortAnswers.get(i)).append("\n\n");
        }
        prompt.append("Return one JSON object per entry above, in a single JSON array, matching each \"index\".");
        callGroq(prompt.toString(), loadingDialog, studentNames, shortAnswers, questionKeys);
    }

    private void callGroq(String prompt, androidx.appcompat.app.AlertDialog loadingDialog,
                          List<String> studentNames, List<String> shortAnswers, List<String> questionKeys) {
        try {
            org.json.JSONObject message = new org.json.JSONObject();
            message.put("role", "user");
            message.put("content", prompt);
            org.json.JSONArray messages = new org.json.JSONArray();
            messages.put(message);
            org.json.JSONObject body = new org.json.JSONObject();
            body.put("model", GROQ_MODEL);
            body.put("messages", messages);
            body.put("temperature", 0);

            RequestBody requestBody = RequestBody.create(body.toString(), MediaType.parse("application/json"));
            Request request = new Request.Builder().url(GROQ_URL)
                    .addHeader("Authorization", "Bearer " + GROQ_API_KEY)
                    .post(requestBody).build();

            httpClient.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull java.io.IOException e) {
                    runOnUiThread(() -> {
                        loadingDialog.dismiss();
                        new androidx.appcompat.app.AlertDialog.Builder(QuizSubmissionsActivity.this)
                                .setTitle("Error").setMessage("Network error: " + e.getMessage())
                                .setPositiveButton("OK", null).show();
                    });
                }
                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws java.io.IOException {
                    String responseBody = response.body() != null ? response.body().string() : "";
                    runOnUiThread(() -> {
                        loadingDialog.dismiss();
                        try {
                            org.json.JSONObject json = new org.json.JSONObject(responseBody);

                            // ── Agar Groq API ne error wapis bheja hai (e.g. invalid key,
                            // quota khatam) to user ko saaf, samajh aane wala message dikhao ──
                            if (json.has("error")) {
                                org.json.JSONObject err = json.getJSONObject("error");
                                String code  = err.optString("code", "");
                                String message;
                                if ("invalid_api_key".equals(code) || response.code() == 401) {
                                    message = "AI Check is not configured correctly — the API key is invalid or has expired. Please contact the app developer to update it.";
                                } else if ("rate_limit_exceeded".equals(code) || response.code() == 429) {
                                    message = "AI quota for today is exhausted. Please try again later.";
                                } else {
                                    message = err.optString("message", "Something went wrong while contacting the AI service.");
                                }
                                new androidx.appcompat.app.AlertDialog.Builder(QuizSubmissionsActivity.this)
                                        .setTitle("⚠️ AI Check Failed")
                                        .setMessage(message)
                                        .setPositiveButton("OK", null).show();
                                return;
                            }

                            String result = json.getJSONArray("choices")
                                    .getJSONObject(0).getJSONObject("message")
                                    .getString("content").trim();

                            // Kabhi kabhi model code-fence mein wrap kar deta hai, usko hata do
                            if (result.startsWith("```")) {
                                result = result.replaceAll("^```[a-zA-Z]*\\n?", "").replaceAll("```\\s*$", "").trim();
                            }

                            org.json.JSONArray arr = new org.json.JSONArray(result);
                            android.text.SpannableStringBuilder report = new android.text.SpannableStringBuilder();

                            for (int idx = 0; idx < arr.length(); idx++) {
                                org.json.JSONObject item = arr.getJSONObject(idx);
                                int entryIndex = item.optInt("index", -1);
                                if (entryIndex < 0 || entryIndex >= shortAnswers.size()) continue;

                                String name = studentNames.get(entryIndex);
                                String qKey = questionKeys.get(entryIndex);
                                String answerText = shortAnswers.get(entryIndex);
                                int totalLen = answerText.length();
                                if (totalLen == 0) continue;

                                // mark[i] = 0 (original) / 1 (copied) / 2 (aiGenerated) for each character
                                int[] mark = new int[totalLen];
                                markPhrases(answerText, mark, readPhraseArray(item, "copied"), 1);
                                markPhrases(answerText, mark, readPhraseArray(item, "aiGenerated"), 2);

                                int copiedChars = 0, aiChars = 0;
                                for (int m : mark) {
                                    if (m == 1) copiedChars++;
                                    else if (m == 2) aiChars++;
                                }
                                int copiedPct = Math.round(copiedChars * 100f / totalLen);
                                int aiPct = Math.round(aiChars * 100f / totalLen);
                                if (copiedPct + aiPct > 100) aiPct = 100 - copiedPct;
                                int originalPct = 100 - copiedPct - aiPct;

                                int headerStart = report.length();
                                report.append(name).append(" (").append(qKey).append(")\n");
                                report.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD),
                                        headerStart, report.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

                                report.append("Original: ").append(String.valueOf(originalPct)).append("%\n")
                                        .append("Copied: ").append(String.valueOf(copiedPct)).append("%\n")
                                        .append("AI-Generated: ").append(String.valueOf(aiPct)).append("%\n\n");

                                int answerHeadingStart = report.length();
                                report.append("Answer:\n");
                                report.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD),
                                        answerHeadingStart, report.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

                                // Poora answer text likho, sirf jo part copied/AI lage usi ko color karo
                                int answerStart = report.length();
                                report.append(answerText).append("\n");
                                int runStart = 0;
                                boolean hasCopied = copiedChars > 0, hasAi = aiChars > 0;
                                for (int i = 1; i <= totalLen; i++) {
                                    if (i == totalLen || mark[i] != mark[runStart]) {
                                        if (mark[runStart] != 0) {
                                            int spanStart = answerStart + runStart;
                                            int spanEnd = answerStart + i;
                                            int color = mark[runStart] == 1 ? android.graphics.Color.RED : 0xFFFF8800; // copied=red, AI=orange
                                            report.setSpan(new android.text.style.ForegroundColorSpan(color),
                                                    spanStart, spanEnd, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                                            report.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD),
                                                    spanStart, spanEnd, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                                        }
                                        runStart = i;
                                    }
                                }

                                if (hasCopied || hasAi) {
                                    int legendStart = report.length();
                                    if (hasAi) {
                                        int s = report.length();
                                        report.append("● AI-Generated");
                                        report.setSpan(new android.text.style.ForegroundColorSpan(0xFFFF8800),
                                                s, report.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                                    }
                                    if (hasAi && hasCopied) report.append("   ");
                                    if (hasCopied) {
                                        int s = report.length();
                                        report.append("● Copied");
                                        report.setSpan(new android.text.style.ForegroundColorSpan(android.graphics.Color.RED),
                                                s, report.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                                    }
                                    report.setSpan(new android.text.style.RelativeSizeSpan(0.8f),
                                            legendStart, report.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                                    report.append("\n");
                                }

                                report.append("\n");
                            }

                            new androidx.appcompat.app.AlertDialog.Builder(QuizSubmissionsActivity.this)
                                    .setTitle("🤖 AI Originality Report").setMessage(report)
                                    .setPositiveButton("OK", null).show();
                        } catch (Exception e) {
                            new androidx.appcompat.app.AlertDialog.Builder(QuizSubmissionsActivity.this)
                                    .setTitle("⚠️ AI Check Failed")
                                    .setMessage("Could not read the AI service response. Please try again later.")
                                    .setPositiveButton("OK", null).show();
                        }
                    });
                }
            });
        } catch (Exception e) {
            loadingDialog.dismiss();
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // ── AI Originality Check helpers ──────────────────────────────────────
    private List<String> readPhraseArray(org.json.JSONObject item, String key) {
        List<String> result = new ArrayList<>();
        org.json.JSONArray jsonArr = item.optJSONArray(key);
        if (jsonArr != null) {
            for (int i = 0; i < jsonArr.length(); i++) {
                String p = jsonArr.optString(i, "").trim();
                if (!p.isEmpty()) result.add(p);
            }
        } else {
            // Kabhi kabhi model array ki jagah plain string bhej deta hai
            String single = item.optString(key, "").trim();
            if (!single.isEmpty() && !single.equalsIgnoreCase("none")) {
                single = single.replaceAll("^\"|\"$", "");
                result.add(single);
            }
        }
        return result;
    }

    private void markPhrases(String answerText, int[] mark, List<String> phrases, int markValue) {
        String lowerAnswer = answerText.toLowerCase();
        for (String phrase : phrases) {
            String lowerPhrase = phrase.toLowerCase();
            if (lowerPhrase.isEmpty()) continue;
            int searchFrom = 0;
            int foundAt;
            while ((foundAt = lowerAnswer.indexOf(lowerPhrase, searchFrom)) != -1) {
                for (int i = foundAt; i < foundAt + lowerPhrase.length() && i < mark.length; i++) {
                    if (mark[i] == 0) mark[i] = markValue;
                }
                searchFrom = foundAt + lowerPhrase.length();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (attemptsRef != null && attemptsListener != null)
            attemptsRef.removeEventListener(attemptsListener);
    }

    // ── Adapter ─────────────────────────────────────────────────────────
    private class AttemptsAdapter extends RecyclerView.Adapter<AttemptsAdapter.VH> {

        private final List<Map<String, Object>> list;

        AttemptsAdapter(List<Map<String, Object>> list) { this.list = list; }

        @NonNull @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_quiz_attempt, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Map<String, Object> a = list.get(position);

            String name        = getVal(a, "studentName");
            String studentUid  = getVal(a, "studentUid");
            String studentId   = getVal(a, "studentId");
            String submittedAt = getVal(a, "submittedAt");

            // Date format fix
            if (!submittedAt.isEmpty()) {
                try {
                    long ts = Long.parseLong(submittedAt);
                    submittedAt = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date(ts));
                } catch (NumberFormatException ignored) {}
            } else {
                String ts = getVal(a, "timestamp");
                if (!ts.isEmpty()) {
                    try {
                        long tsLong = Long.parseLong(ts);
                        submittedAt = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date(tsLong));
                    } catch (NumberFormatException ignored) {}
                }
            }

            // MCQ score recalc
            int mcqScore = 0;
            int mcqTotal = 0;
            boolean hasMcq = false;
            boolean hasShort = false;
            boolean shortPending = false;
            List<Map.Entry<String, Map<String, Object>>> shortQuestions = new ArrayList<>();

            Object answersObj = a.get("answers");
            if (answersObj instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> answers = (Map<String, Object>) answersObj;
                // Sort by key for consistent order
                List<String> keys = new ArrayList<>(answers.keySet());
                java.util.Collections.sort(keys);
                for (String key : keys) {
                    Object qObj = answers.get(key);
                    if (!(qObj instanceof Map)) continue;
                    @SuppressWarnings("unchecked")
                    Map<String, Object> qData = (Map<String, Object>) qObj;
                    String type = qData.containsKey("type") ? qData.get("type").toString().toLowerCase() : "mcq";
                    boolean isMcq = type.contains("mcq") || type.contains("multiple") || type.isEmpty();

                    if (isMcq) {
                        hasMcq = true;
                        int marks = 1;
                        try { if (qData.containsKey("marks") && qData.get("marks") != null) marks = Integer.parseInt(qData.get("marks").toString()); } catch (Exception ignored) {}
                        mcqTotal += marks;

                        String studentAns = qData.containsKey("answer") ? qData.get("answer").toString().trim().toUpperCase() : "";
                        String correctAns = "";
                        if (qData.containsKey("correctAnswer") && qData.get("correctAnswer") != null) correctAns = qData.get("correctAnswer").toString().trim().toUpperCase();
                        else if (qData.containsKey("correct") && qData.get("correct") != null) correctAns = qData.get("correct").toString().trim().toUpperCase();

                        // isCorrect primary check
                        Object flag = qData.get("isCorrect");
                        boolean correct = false;
                        if (flag instanceof Boolean) correct = (Boolean) flag;
                        else if (flag != null) correct = "true".equalsIgnoreCase(flag.toString().trim());
                        // Fallback: answer string compare
                        if (!correct && !studentAns.isEmpty() && !correctAns.isEmpty()) {
                            correct = studentAns.equals(correctAns);
                        }
                        if (correct) mcqScore += marks;
                    } else {
                        hasShort = true;
                        // Check if teacher already gave marks
                        Object tm = qData.get("teacherMarks");
                        int tMarks = -1;
                        try { if (tm != null) tMarks = Integer.parseInt(tm.toString()); } catch (Exception ignored) {}
                        if (tMarks < 0) shortPending = true;
                        shortQuestions.add(new java.util.AbstractMap.SimpleEntry<>(key, qData));
                    }
                }
            }

            // Total score = mcqScore + teacher short marks
            int totalScore = mcqScore;
            String shortStatus = getVal(a, "shortMarksStatus");
            if (shortStatus.isEmpty()) shortStatus = hasShort ? "pending" : "done";

            // Add any already-given short marks
            for (Map.Entry<String, Map<String, Object>> entry : shortQuestions) {
                Object tm = entry.getValue().get("teacherMarks");
                try { if (tm != null) { int m = Integer.parseInt(tm.toString()); if (m > 0) totalScore += m; } } catch (Exception ignored) {}
            }

            // Name
            final String finalSubmittedAt = submittedAt;
            if (name.isEmpty() && !studentUid.isEmpty()) {
                h.tvStudentName.setText("Loading...");
                h.tvInitial.setText("?");
                h.tvStudentId.setText("ID: ...");
                FirebaseDatabase.getInstance().getReference("Users").child(studentUid).get()
                        .addOnSuccessListener(snap -> {
                            String fn = snap.child("name").getValue(String.class);
                            String fr = snap.child("registrationId").getValue(String.class);
                            if (fn == null || fn.isEmpty()) fn = "Unknown";
                            h.tvStudentName.setText(fn);
                            h.tvInitial.setText(fn.substring(0, 1).toUpperCase());
                            h.tvStudentId.setText("ID: " + (fr != null && !fr.isEmpty() ? fr : "N/A"));
                        });
            } else {
                h.tvStudentName.setText(name.isEmpty() ? "Unknown" : name);
                h.tvInitial.setText(name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase());
                boolean looksLikeUid = studentId.length() > 20;
                h.tvStudentId.setText("ID: " + (studentId.isEmpty() || looksLikeUid ? "N/A" : studentId));
            }
            h.tvSubmittedAt.setText("Attempted: " + (finalSubmittedAt.isEmpty() ? "N/A" : finalSubmittedAt));

            // Score display
            final boolean finalShortPending = shortPending && hasShort;
            final boolean finalHasMcq = hasMcq;
            final int finalMcqScore = mcqScore;
            final int finalMcqTotal = mcqTotal;
            final int finalTotalScore = totalScore;

            if (finalShortPending) {
                if (finalHasMcq) {
                    h.tvScore.setText("MCQ: " + finalMcqScore + "/" + finalMcqTotal);
                } else {
                    h.tvScore.setText("Short: Pending");
                }
                h.tvScore.setTextColor(0xFF1565C0);
                h.tvShortStatus.setVisibility(View.VISIBLE);
                h.tvShortStatus.setText("⏳ Short: Pending Review");
            } else if (hasShort) {
                if (finalHasMcq) {
                    h.tvScore.setText("Total: " + finalTotalScore);
                } else {
                    h.tvScore.setText("Short: " + finalTotalScore);
                }
                h.tvScore.setTextColor(0xFF2E7D32);
                h.tvShortStatus.setVisibility(View.VISIBLE);
                h.tvShortStatus.setText("✅ Short: Marked");
            } else {
                h.tvScore.setText("Score: " + finalMcqScore + "/" + finalMcqTotal);
                h.tvScore.setTextColor(0xFF2E7D32);
                h.tvShortStatus.setVisibility(View.GONE);
            }

            // Review Short button — only if short questions exist
            if (hasShort) {
                h.btnReviewShort.setVisibility(View.VISIBLE);
                final String finalStudentUid = studentUid;
                final List<Map.Entry<String, Map<String, Object>>> finalShortQs = shortQuestions;
                final String finalName = name.isEmpty() ? "Student" : name;

                h.btnReviewShort.setText(finalShortPending ? "📝 Review Short Answers & Give Marks" : "📝 View Short Answers");
                h.btnReviewShort.setOnClickListener(v -> showShortReviewDialog(
                        finalStudentUid, finalName, finalShortQs, finalMcqScore, finalMcqTotal, finalShortPending));
            } else {
                h.btnReviewShort.setVisibility(View.GONE);
            }
        }

        private void showShortReviewDialog(String studentUid, String studentName,
                                           List<Map.Entry<String, Map<String, Object>>> shortQs,
                                           int mcqScore, int mcqTotal, boolean isPending) {

            android.widget.ScrollView scrollView = new android.widget.ScrollView(QuizSubmissionsActivity.this);
            LinearLayout layout = new LinearLayout(QuizSubmissionsActivity.this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(40, 20, 40, 20);
            scrollView.addView(layout);

            // EditTexts for marks — one per short question
            List<android.widget.EditText> markInputs    = new ArrayList<>();
            List<android.widget.EditText> maxMarkInputs = new ArrayList<>();

            for (Map.Entry<String, Map<String, Object>> entry : shortQs) {
                String qKey = entry.getKey();
                Map<String, Object> qData = entry.getValue();
                String qText = qData.containsKey("question") ? qData.get("question").toString() : qKey;
                String answer = qData.containsKey("answer") ? qData.get("answer").toString() : "(No answer)";
                Object existingMarks = qData.get("teacherMarks");

                // Max marks for this question — teacher editable
                int maxM = 1;
                try {
                    Object mk = qData.get("marks");
                    if (mk != null) maxM = Integer.parseInt(mk.toString());
                } catch (Exception ignored) {}

                // Question text
                android.widget.TextView tvQ = new android.widget.TextView(QuizSubmissionsActivity.this);
                tvQ.setText("Q: " + qText);
                tvQ.setTextColor(0xFF1A1A2E);
                tvQ.setTextSize(14f);
                tvQ.setTypeface(null, android.graphics.Typeface.BOLD);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 16, 0, 4);
                tvQ.setLayoutParams(lp);
                layout.addView(tvQ);

                // Student answer
                android.widget.TextView tvA = new android.widget.TextView(QuizSubmissionsActivity.this);
                tvA.setText("Answer: " + answer);
                tvA.setTextColor(0xFF444444);
                tvA.setTextSize(13f);
                tvA.setBackgroundColor(0xFFF5F5F5);
                tvA.setPadding(16, 10, 16, 10);
                layout.addView(tvA);

                // Max marks label + input (teacher sets this)
                android.widget.TextView tvMaxLabel = new android.widget.TextView(QuizSubmissionsActivity.this);
                tvMaxLabel.setText("Total marks for this question:");
                tvMaxLabel.setTextColor(0xFF555555);
                tvMaxLabel.setTextSize(12f);
                layout.addView(tvMaxLabel);

                android.widget.EditText etMaxMarks = new android.widget.EditText(QuizSubmissionsActivity.this);
                etMaxMarks.setHint("e.g. 5");
                etMaxMarks.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                etMaxMarks.setTextSize(13f);
                etMaxMarks.setText(String.valueOf(maxM));
                if (!isPending) etMaxMarks.setEnabled(false);
                LinearLayout.LayoutParams maxLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                maxLp.setMargins(0, 2, 0, 2);
                etMaxMarks.setLayoutParams(maxLp);
                layout.addView(etMaxMarks);
                maxMarkInputs.add(etMaxMarks);

                // Obtained marks input
                android.widget.EditText etMarks = new android.widget.EditText(QuizSubmissionsActivity.this);
                etMarks.setHint("Marks obtained");
                etMarks.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                etMarks.setTextSize(13f);
                if (existingMarks != null) {
                    try {
                        int em = Integer.parseInt(existingMarks.toString());
                        if (em >= 0) etMarks.setText(String.valueOf(em));
                    } catch (Exception ignored) {}
                }
                LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                etLp.setMargins(0, 2, 0, 12);
                etMarks.setLayoutParams(etLp);
                if (!isPending) etMarks.setEnabled(false);
                layout.addView(etMarks);
                markInputs.add(etMarks);
            }

            androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(QuizSubmissionsActivity.this);
            builder.setTitle(isPending ? "Give Marks — " + studentName : "Short Answers — " + studentName);
            builder.setView(scrollView);

            if (isPending) {
                builder.setPositiveButton("Save Marks", (d, w) -> {
                    Map<String, Object> updates = new HashMap<>();
                    int shortTotal    = 0;
                    int shortQTotal   = 0;
                    boolean allFilled = true;

                    for (int i = 0; i < shortQs.size(); i++) {
                        String obtInput = markInputs.get(i).getText().toString().trim();
                        String maxInput = maxMarkInputs.get(i).getText().toString().trim();
                        if (obtInput.isEmpty() || maxInput.isEmpty()) { allFilled = false; break; }
                        int m    = 0; try { m    = Integer.parseInt(obtInput); } catch (Exception ignored) {}
                        int maxM = 1; try { maxM = Integer.parseInt(maxInput); } catch (Exception ignored) {}
                        if (m > maxM) {
                            Toast.makeText(QuizSubmissionsActivity.this,
                                    "Obtained cannot exceed total marks!", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        shortTotal  += m;
                        shortQTotal += maxM;
                        String qKey = shortQs.get(i).getKey();
                        updates.put("answers/" + qKey + "/teacherMarks", m);
                        updates.put("answers/" + qKey + "/marks",        maxM);
                        updates.put("answers/" + qKey + "/isCorrect",    m > 0);
                    }

                    if (!allFilled) {
                        Toast.makeText(QuizSubmissionsActivity.this,
                                "Please fill marks for all short questions", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int finalTotal = mcqScore + shortTotal;
                    updates.put("score",            finalTotal);
                    updates.put("shortMarks",       shortTotal);
                    updates.put("shortTotal",       shortQTotal);
                    updates.put("shortMarksStatus", "done");

                    FirebaseDatabase.getInstance().getReference("QuizAttempts")
                            .child(currentQuizId).child(studentUid)
                            .updateChildren(updates)
                            .addOnSuccessListener(u -> {
                                Toast.makeText(QuizSubmissionsActivity.this,
                                        "✅ Marks saved! Total: " + finalTotal, Toast.LENGTH_SHORT).show();
                            })
                            .addOnFailureListener(e -> Toast.makeText(QuizSubmissionsActivity.this,
                                    "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                });
            }

            builder.setNegativeButton("Close", null);
            builder.show();
        }

        @Override
        public int getItemCount() { return list.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView tvStudentName, tvInitial, tvStudentId, tvScore, tvSubmittedAt, tvShortStatus;
            android.widget.Button btnReviewShort;
            VH(@NonNull View v) {
                super(v);
                tvStudentName  = v.findViewById(R.id.tvStudentName);
                tvInitial      = v.findViewById(R.id.tvStudentInitial);
                tvStudentId    = v.findViewById(R.id.tvStudentId);
                tvScore        = v.findViewById(R.id.tvScore);
                tvSubmittedAt  = v.findViewById(R.id.tvSubmittedAt);
                tvShortStatus  = v.findViewById(R.id.tvShortStatus);
                btnReviewShort = v.findViewById(R.id.btnReviewShort);
            }
        }
    }
}