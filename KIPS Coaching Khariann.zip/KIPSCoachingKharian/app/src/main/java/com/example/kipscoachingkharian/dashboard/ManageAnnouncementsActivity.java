package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ManageAnnouncementsActivity extends AppCompatActivity {

    private static final String STUDENT_PATH      = "Announcements/Students";
    private static final String TEACHER_PATH      = "Announcements/Teachers";
    private static final String NOTIFICATIONS_PATH = "Notifications"; // ✅ per-student notifications
    private static final String FCM_SERVER_KEY    = "YOUR_FIREBASE_SERVER_KEY_HERE";

    // ✅ Item type tags for distinguishing announcement source in the card/buttons
    private static final String TYPE_ANNOUNCEMENT = "announcement";
    private static final String TYPE_NOTIFICATION  = "notification";

    private DatabaseReference mDatabase;
    private LinearLayout containerAnnouncements;
    private TextView tvLoading;
    private TextView tvTotalCount, tvAllCount, tvClassCount;

    private final List<String> classList = new ArrayList<>();

    // Merged lists — synchronized via runOnUiThread only
    private final List<AnnouncementItem> studentItems      = new ArrayList<>();
    private final List<AnnouncementItem> teacherItems      = new ArrayList<>();
    private final List<AnnouncementItem> notificationItems = new ArrayList<>();

    // ✅ Names cache for showing "to: <student name>" on notification cards
    private final Map<String, String> studentNameCache = new HashMap<>();

    private float dp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_announcements);

        dp = getResources().getDisplayMetrics().density;

        mDatabase              = FirebaseDatabase.getInstance().getReference();
        containerAnnouncements = findViewById(R.id.containerAnnouncements);
        tvLoading              = findViewById(R.id.tvAnnouncementsLoading);
        tvTotalCount           = findViewById(R.id.tvTotalAnnouncementsCount);
        tvAllCount              = findViewById(R.id.tvAnnouncementAllCount);
        tvClassCount           = findViewById(R.id.tvAnnouncementClassCount);

        View ivBack = findViewById(R.id.ivBack);
        if (ivBack != null) ivBack.setOnClickListener(v -> finish());

        loadClassList();
    }

    // ── 1. Load class list + student names cache ─────────────────────────────
    private void loadClassList() {
        mDatabase.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Set<String> classSet = new HashSet<>();
                studentNameCache.clear();
                for (DataSnapshot user : snapshot.getChildren()) {
                    String role = user.child("role").getValue(String.class);
                    String cls  = user.child("className").getValue(String.class);
                    String name = user.child("name").getValue(String.class);

                    if ("Student".equalsIgnoreCase(role)) {
                        if (cls != null && !cls.trim().isEmpty()) classSet.add(cls.trim());
                        // ✅ Naam cache karo taake notification card pe student ka naam dikha sakein
                        if (name != null) studentNameCache.put(user.getKey(), name);
                    }
                }
                classList.clear();
                classList.add("All Classes");
                classList.addAll(new ArrayList<>(classSet));
                addCreateButton();
                loadAnnouncements();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (classList.isEmpty()) classList.add("All Classes");
                addCreateButton();
                loadAnnouncements();
            }
        });
    }

    // ── 2. New Announcement button ────────────────────────────────────────────
    private void addCreateButton() {
        Button btnAdd = new Button(this);
        btnAdd.setText("➕ New Announcement");
        btnAdd.setBackgroundColor(0xFF1565C0);
        btnAdd.setTextColor(Color.WHITE);
        btnAdd.setTextSize(14f);
        btnAdd.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 0, 0, (int)(16 * dp));
        btnAdd.setLayoutParams(p);
        btnAdd.setOnClickListener(v -> showCreateDialog());
        containerAnnouncements.addView(btnAdd);
    }

    // ── 3. Load all 3 sources and merge ───────────────────────────────────────
    private void loadAnnouncements() {

        // Students/Admin announcements
        mDatabase.child(STUDENT_PATH).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    studentItems.clear();
                    for (DataSnapshot snap : snapshot.getChildren()) {
                        AnnouncementItem item = parseAnnouncement(snap, STUDENT_PATH);
                        if (item != null) studentItems.add(item);
                    }
                } catch (Exception e) {
                    android.util.Log.e("ManageAnnouncements", "STUDENT_PATH onDataChange failed", e);
                }
                renderAll();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { renderAll(); }
        });

        // Teacher announcements
        mDatabase.child(TEACHER_PATH).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    teacherItems.clear();
                    for (DataSnapshot snap : snapshot.getChildren()) {
                        AnnouncementItem item = parseAnnouncement(snap, TEACHER_PATH);
                        if (item != null) teacherItems.add(item);
                    }
                } catch (Exception e) {
                    android.util.Log.e("ManageAnnouncements", "TEACHER_PATH onDataChange failed", e);
                }
                renderAll();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { renderAll(); }
        });

        // ✅ Per-student Notifications/{uid}/{key} — sab students ka data merge karo
        mDatabase.child(NOTIFICATIONS_PATH).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    notificationItems.clear();
                    for (DataSnapshot studentSnap : snapshot.getChildren()) {
                        String studentUid = studentSnap.getKey();
                        for (DataSnapshot notifSnap : studentSnap.getChildren()) {
                            AnnouncementItem item = parseNotification(notifSnap, studentUid);
                            if (item != null) notificationItems.add(item);
                        }
                    }
                } catch (Exception e) {
                    android.util.Log.e("ManageAnnouncements", "NOTIFICATIONS_PATH onDataChange failed", e);
                }
                renderAll();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { renderAll(); }
        });
    }

    // ── Parse one announcement node ───────────────────────────────────────────
    private AnnouncementItem parseAnnouncement(DataSnapshot snap, String sourcePath) {
        try {
            String id          = snap.getKey();
            String title       = snap.child("title").getValue(String.class);
            String message     = snap.child("message").getValue(String.class);
            Long   timestamp   = safeLong(snap.child("timestamp").getValue());
            String targetClass = snap.child("targetClass").getValue(String.class);

            if (id == null) return null;
            if (title   == null || title.trim().isEmpty())
                title   = "⚠️ No Title (Update karein)";
            if (message == null || message.trim().isEmpty())
                message = "⚠️ No message saved — neeche Update se theek karein.";

            boolean isAll       = (targetClass == null || targetClass.trim().isEmpty());
            String displayClass = isAll ? "All Classes" : targetClass.trim();

            String dateStr = "";
            if (timestamp != null && timestamp > 0)
                dateStr = new SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.getDefault())
                        .format(new Date(timestamp));

            AnnouncementItem item = new AnnouncementItem(id, title, message, dateStr,
                    displayClass, isAll, sourcePath, TYPE_ANNOUNCEMENT);
            item.rawTimestamp = (timestamp != null) ? timestamp : 0L;
            return item;
        } catch (Exception e) {
            // ✅ FIX: Agar Firebase mein koi field unexpected type ka aaya
            // (e.g. timestamp String ke taur pe save hua), pehle yahan crash hota
            // tha aur poora addValueEventListener fail ho jata — saari
            // Announcements/Students entries ghayab ho jaati thin
            android.util.Log.e("ManageAnnouncements", "parseAnnouncement failed for key=" + snap.getKey(), e);
            return null;
        }
    }

    // ✅ Safe Object -> Long converter (Firebase Long/Double/String kuch bhi de sakta hai)
    private Long safeLong(Object value) {
        if (value == null) return null;
        if (value instanceof Long) return (Long) value;
        if (value instanceof Double) return ((Double) value).longValue();
        if (value instanceof Integer) return ((Integer) value).longValue();
        try { return Long.parseLong(String.valueOf(value)); }
        catch (Exception e) { return null; }
    }

    // ── ✅ Parse one per-student notification node ────────────────────────────
    private AnnouncementItem parseNotification(DataSnapshot snap, String studentUid) {
        try {
            String id        = snap.getKey();
            String title      = snap.child("title").getValue(String.class);
            String message    = snap.child("message").getValue(String.class);
            Long   timestamp  = safeLong(snap.child("timestamp").getValue());
            String type       = snap.child("type").getValue(String.class);

            if (id == null) return null;
            if (title   == null || title.trim().isEmpty())   title   = "🔔 Notification";
            if (message == null || message.trim().isEmpty()) message = "(No message)";

            String studentName = studentNameCache.containsKey(studentUid)
                    ? studentNameCache.get(studentUid) : "Unknown Student";

            String dateStr = "";
            if (timestamp != null && timestamp > 0)
                dateStr = new SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.getDefault())
                        .format(new Date(timestamp));

            AnnouncementItem item = new AnnouncementItem(id, title, message, dateStr,
                    "👤 " + studentName, false,
                    NOTIFICATIONS_PATH + "/" + studentUid, TYPE_NOTIFICATION);
            item.rawTimestamp = (timestamp != null) ? timestamp : 0L;
            item.notifType    = (type != null) ? type : "general";
            return item;
        } catch (Exception e) {
            android.util.Log.e("ManageAnnouncements", "parseNotification failed for key=" + snap.getKey(), e);
            return null;
        }
    }

    // ── Merge + render ────────────────────────────────────────────────────────
    private void renderAll() {
        runOnUiThread(() -> {
            while (containerAnnouncements.getChildCount() > 1)
                containerAnnouncements.removeViewAt(1);

            if (tvLoading != null) tvLoading.setVisibility(View.GONE);

            // ✅ Teeno sources merge karo
            List<AnnouncementItem> merged = new ArrayList<>();
            merged.addAll(studentItems);
            merged.addAll(teacherItems);
            merged.addAll(notificationItems);

            if (merged.isEmpty()) {
                updateCounts(0, 0, 0);
                showEmptyState("Koi announcement ya notification nahi mili.");
                return;
            }

            // ✅ Newest first — actual timestamp se sort (push-id string sort se zyada reliable)
            for (int i = 0; i < merged.size() - 1; i++) {
                for (int j = i + 1; j < merged.size(); j++) {
                    if (merged.get(i).rawTimestamp < merged.get(j).rawTimestamp) {
                        AnnouncementItem tmp = merged.get(i);
                        merged.set(i, merged.get(j));
                        merged.set(j, tmp);
                    }
                }
            }

            int total = merged.size(), allCount = 0, classCount = 0;
            for (AnnouncementItem item : merged) {
                try {
                    if (item.type.equals(TYPE_ANNOUNCEMENT)) {
                        if (item.isAllClasses) allCount++;
                        else classCount++;
                    }
                    createAnnouncementCard(item);
                } catch (Exception e) {
                    // ✅ FIX: Ek item ka error poori list ko render hone se nahi rokega ab
                    // Pehle agar studentItems/teacherItems mein koi field null hota
                    // (e.g. displayClass), poora loop yahin crash ho jata aur
                    // sirf notificationItems hi dikhti (jo list mein baad mein the)
                    android.util.Log.e("ManageAnnouncements",
                            "Card render failed for id=" + item.id + " type=" + item.type, e);
                }
            }
            updateCounts(total, allCount, classCount);
        });
    }

    // ── 4. Announcement / Notification Card ───────────────────────────────────
    private void createAnnouncementCard(AnnouncementItem item) {
        boolean isAll        = item.isAllClasses;
        boolean isNotif       = item.type.equals(TYPE_NOTIFICATION);

        CardView card = new CardView(this);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        clp.setMargins(0, 0, 0, (int)(14 * dp));
        card.setLayoutParams(clp);
        card.setRadius(12 * dp);
        card.setCardElevation(4 * dp);
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(16 * dp);
        inner.setPadding(pad, pad, pad, pad);
        inner.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // ✅ Top strip color: notifications ke liye teal, announcements ke liye blue/purple
        View strip = new View(this);
        GradientDrawable stripBg = new GradientDrawable();
        stripBg.setColor(isNotif ? 0xFF00897B : (isAll ? 0xFF1565C0 : 0xFF6A1B9A));
        stripBg.setCornerRadii(new float[]{12*dp,12*dp,12*dp,12*dp,0,0,0,0});
        strip.setBackground(stripBg);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (int)(5 * dp));
        slp.setMargins(-pad, -pad, -pad, (int)(12 * dp));
        strip.setLayoutParams(slp);
        inner.addView(strip);

        // Title row
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(item.title);
        tvTitle.setTextSize(15f);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setTextColor(0xFF222222);
        tvTitle.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvBadge = new TextView(this);
        // ✅ Notification cards pe student ka naam badge, announcement pe class badge
        tvBadge.setText(isNotif ? item.displayClass : (isAll ? "📢 All" : "📚 " + item.displayClass));
        tvBadge.setTextSize(11f);
        tvBadge.setTextColor(0xFFFFFFFF);
        tvBadge.setTypeface(null, Typeface.BOLD);
        int bph = (int)(10 * dp), bpv = (int)(4 * dp);
        tvBadge.setPadding(bph, bpv, bph, bpv);
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(isNotif ? 0xFF00897B : (isAll ? 0xFF1565C0 : 0xFF6A1B9A));
        badgeBg.setCornerRadius(20 * dp);
        tvBadge.setBackground(badgeBg);

        titleRow.addView(tvTitle);
        titleRow.addView(tvBadge);
        inner.addView(titleRow);

        // ✅ Source label: Notification / Teacher / Admin
        TextView tvSource = new TextView(this);
        String sourceLabel;
        int sourceColor;
        if (isNotif) {
            sourceLabel = "🔔 Notification (" + item.notifType + ")";
            sourceColor = 0xFF00897B;
        } else if (item.sourcePath.equals(TEACHER_PATH)) {
            sourceLabel = "👩‍🏫 Teacher Announcement";
            sourceColor = 0xFF6A1B9A;
        } else {
            sourceLabel = "🔑 Admin Announcement";
            sourceColor = 0xFF1565C0;
        }
        tvSource.setText(sourceLabel);
        tvSource.setTextSize(10f);
        tvSource.setTextColor(sourceColor);
        LinearLayout.LayoutParams srclp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        srclp.topMargin = (int)(2 * dp);
        tvSource.setLayoutParams(srclp);
        inner.addView(tvSource);

        // Date
        if (!item.dateStr.isEmpty()) {
            TextView tvDate = new TextView(this);
            tvDate.setText("🕒 " + item.dateStr);
            tvDate.setTextSize(11f);
            tvDate.setTextColor(0xFF888888);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            dlp.topMargin = (int)(4 * dp);
            tvDate.setLayoutParams(dlp);
            inner.addView(tvDate);
        }

        // Divider
        View divider = new View(this);
        divider.setBackgroundColor(0xFFEEEEEE);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1);
        divLp.setMargins(0, (int)(10*dp), 0, (int)(10*dp));
        divider.setLayoutParams(divLp);
        inner.addView(divider);

        // Message
        TextView tvMsg = new TextView(this);
        tvMsg.setText(item.message);
        tvMsg.setTextSize(13f);
        tvMsg.setTextColor(0xFF444444);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        mlp.bottomMargin = (int)(12 * dp);
        tvMsg.setLayoutParams(mlp);
        inner.addView(tvMsg);

        // ── Action buttons ──────────────────────────────────────────────────
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        if (isNotif) {
            // ✅ Per-student notifications sirf delete ho sakti hain — Update nahi
            // (kyunke yeh system-generated hain — marks/progress se auto-banti hain)
            Button btnDelete = new Button(this);
            btnDelete.setText("🗑️ Delete Notification");
            btnDelete.setBackgroundColor(0xFFB71C1C);
            btnDelete.setTextColor(Color.WHITE);
            btnDelete.setTextSize(12f);
            btnDelete.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            btnDelete.setOnClickListener(v -> confirmDelete(item.id, item.title, item.sourcePath));
            btnRow.addView(btnDelete);
        } else {
            Button btnUpdate = new Button(this);
            btnUpdate.setText("✏️ Update");
            btnUpdate.setBackgroundColor(0xFF388E3C);
            btnUpdate.setTextColor(Color.WHITE);
            btnUpdate.setTextSize(12f);
            LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp1.setMarginEnd((int)(8 * dp));
            btnUpdate.setLayoutParams(lp1);
            btnUpdate.setOnClickListener(v ->
                    showUpdateDialog(item.id, item.title, item.message,
                            item.displayClass.equals("All Classes") ? "" : item.displayClass,
                            item.sourcePath));

            Button btnDelete = new Button(this);
            btnDelete.setText("🗑️ Delete");
            btnDelete.setBackgroundColor(0xFFB71C1C);
            btnDelete.setTextColor(Color.WHITE);
            btnDelete.setTextSize(12f);
            btnDelete.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            btnDelete.setOnClickListener(v -> confirmDelete(item.id, item.title, item.sourcePath));

            btnRow.addView(btnUpdate);
            btnRow.addView(btnDelete);
        }
        inner.addView(btnRow);

        card.addView(inner);
        containerAnnouncements.addView(card);
    }

    // ── 5. Create Dialog (sirf announcements ke liye — notifications system-generated hain) ──
    private void showCreateDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("📢 New Announcement");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(44, 24, 44, 24);

        TextView tvTitleLabel = new TextView(this);
        tvTitleLabel.setText("Title:");
        tvTitleLabel.setTypeface(null, Typeface.BOLD);
        layout.addView(tvTitleLabel);

        final EditText etTitle = new EditText(this);
        etTitle.setHint("Announcement Title");
        layout.addView(etTitle);

        TextView tvMsgLabel = new TextView(this);
        tvMsgLabel.setText("Message:");
        tvMsgLabel.setPadding(0, 12, 0, 4);
        tvMsgLabel.setTypeface(null, Typeface.BOLD);
        layout.addView(tvMsgLabel);

        final EditText etMessage = new EditText(this);
        etMessage.setHint("Announcement Message");
        etMessage.setMinLines(3);
        layout.addView(etMessage);

        // ── Audience selector: Students / Teachers / Parents / All ──────────
        TextView tvAudienceLabel = new TextView(this);
        tvAudienceLabel.setText("Send To:");
        tvAudienceLabel.setPadding(0, 12, 0, 4);
        tvAudienceLabel.setTypeface(null, Typeface.BOLD);
        layout.addView(tvAudienceLabel);

        String[] audienceOptions = {"Students", "Teachers", "Parents", "All (Students + Teachers + Parents)"};
        final Spinner audienceSpinner = new Spinner(this);
        ArrayAdapter<String> audienceAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, audienceOptions);
        audienceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        audienceSpinner.setAdapter(audienceAdapter);
        audienceSpinner.setSelection(0);
        layout.addView(audienceSpinner);

        TextView tvClassLabel = new TextView(this);
        tvClassLabel.setText("Target Class:");
        tvClassLabel.setPadding(0, 12, 0, 4);
        tvClassLabel.setTypeface(null, Typeface.BOLD);
        layout.addView(tvClassLabel);

        final Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, classList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(0);
        layout.addView(spinner);

        // Class spinner sirf Students/Parents/All ke liye relevant hai — Teachers ke liye hide karo
        audienceSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) {
                boolean isTeachersOnly = audienceOptions[pos].equals("Teachers");
                tvClassLabel.setVisibility(isTeachersOnly ? View.GONE : View.VISIBLE);
                spinner.setVisibility(isTeachersOnly ? View.GONE : View.VISIBLE);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });

        builder.setView(layout);
        builder.setPositiveButton("Post", (dialog, which) -> {
            String newTitle   = etTitle.getText().toString().trim();
            String newMessage = etMessage.getText().toString().trim();
            String selClass   = spinner.getSelectedItem().toString();
            String audience   = audienceOptions[audienceSpinner.getSelectedItemPosition()];

            if (newTitle.isEmpty() || newMessage.isEmpty()) {
                Toast.makeText(this, "Title aur Message zaroori hain!", Toast.LENGTH_SHORT).show();
                return;
            }

            String classToSave = selClass.equals("All Classes") ? "" : selClass;
            boolean toStudents = audience.equals("Students") || audience.startsWith("All");
            boolean toTeachers = audience.equals("Teachers") || audience.startsWith("All");
            boolean toParents  = audience.equals("Parents")  || audience.startsWith("All");

            if (toStudents) {
                postToStudents(newTitle, newMessage, classToSave);
            }
            if (toTeachers) {
                postToTeachers(newTitle, newMessage);
            }
            if (toParents) {
                shareAnnouncementWithParents(newTitle, newMessage, classToSave);
            }

            if (!toStudents && !toTeachers && !toParents) return;
            Toast.makeText(this, "Announcement posted to " + audience + "!", Toast.LENGTH_SHORT).show();
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // ── Students path par post karo ───────────────────────────────────────
    private void postToStudents(String title, String message, String classToSave) {
        String newKey = mDatabase.child(STUDENT_PATH).push().getKey();
        if (newKey == null) return;

        Map<String, Object> data = new HashMap<>();
        data.put("title",       title);
        data.put("message",     message);
        data.put("targetClass", classToSave);
        data.put("timestamp",   ServerValue.TIMESTAMP);
        data.put("pdfUrl",      "");

        mDatabase.child(STUDENT_PATH).child(newKey).setValue(data)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        String topic = classToSave.isEmpty()
                                ? "students_all"
                                : "class_" + classToSave.replace(" ", "_");
                        sendFcmNotification(topic, title, message);
                    }
                });
    }

    // ── Teachers path par post karo ───────────────────────────────────────
    private void postToTeachers(String title, String message) {
        String newKey = mDatabase.child(TEACHER_PATH).push().getKey();
        if (newKey == null) return;

        Map<String, Object> data = new HashMap<>();
        data.put("title",     title);
        data.put("message",   message);
        data.put("timestamp", ServerValue.TIMESTAMP);
        data.put("pdfUrl",    "");

        mDatabase.child(TEACHER_PATH).child(newKey).setValue(data)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        sendFcmNotification("teachers_all", title, message);
                    }
                });
    }

    // ── Parents ko announcement share karo (Announcements/Parents/<pushKey>) ──
    // ✅ FIX: Pehle yahan har MATCHED PARENT ke liye ek entry
    //        "Announcements/Parents/<parentUid>/<pushKey>" (nested, bina
    //        registrationId field ke) likhi jaati thi. Lekin
    //        ParentAnnouncementsActivity "Announcements/Parents" ko FLAT
    //        padhta hai aur har child snapshot mein "registrationId" field
    //        dhoondta hai taake scope kar sake (targetId == null => General
    //        => SAB parents ko dikhao). Is nested-write se har parentUid wala
    //        node khud ek "child" ban jata tha jiska apna "registrationId"
    //        field hi nahi hota — is liye reader usay hamesha "General" samajh
    //        kar SAB approved parents ko dikha deta tha (fee-paid confirmation
    //        ho ya class-wise announcement, sab broadcast ho jaata tha).
    //
    //        Fix: ab flat structure use karte hain, bilkul PayFastWebViewActivity
    //        ki tarah — jis student (regId) ke liye announcement hai uska
    //        "registrationId" field seedha announcement node mein daala jata
    //        hai. Sirf usi bachay se linked parent(s) ko yeh dikhegi. "All
    //        Classes" ke case mein hi (jaan-boojh kar) registrationId khaali
    //        chhoda jata hai taake woh genuinely sab parents ko General ki
    //        tarah dikhe.
    private void shareAnnouncementWithParents(String title, String message, String targetClass) {
        mDatabase.child("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Map<String, Object> updates = new HashMap<>();

                        if (targetClass == null || targetClass.trim().isEmpty()) {
                            // Genuinely "All Classes" audience chosen — ek hi
                            // general entry, registrationId khaali (sab
                            // parents ke liye, jaisa purpose se matlab hai).
                            String pushKey = mDatabase.child("Announcements").child("Parents").push().getKey();
                            if (pushKey != null) {
                                Map<String, Object> parentAnn = new HashMap<>();
                                parentAnn.put("title",     "📢 " + title);
                                parentAnn.put("message",   message);
                                parentAnn.put("type",      "admin");
                                parentAnn.put("timestamp", ServerValue.TIMESTAMP);
                                updates.put("Announcements/Parents/" + pushKey, parentAnn);
                            }
                        } else {
                            // Sirf us class ke approved students ke distinct
                            // registrationId nikalo — har regId ke liye ek
                            // scoped entry, taake sirf usi bachay se linked
                            // parent(s) ko dikhe, baqi kisi ko nahi.
                            Set<String> matchedRegIds = new HashSet<>();
                            for (DataSnapshot user : snapshot.getChildren()) {
                                String role   = user.child("role").getValue(String.class);
                                String status = user.child("status").getValue(String.class);
                                if (!"Student".equalsIgnoreCase(role)) continue;
                                if (!"Approved".equalsIgnoreCase(status)) continue;

                                String regId = user.child("registrationId").getValue(String.class);
                                String cls   = user.child("className").getValue(String.class);
                                if (regId == null || regId.trim().isEmpty()) continue;
                                if (cls != null && cls.trim().equalsIgnoreCase(targetClass)) {
                                    matchedRegIds.add(regId.trim());
                                }
                            }

                            for (String regId : matchedRegIds) {
                                String pushKey = mDatabase.child("Announcements").child("Parents").push().getKey();
                                if (pushKey == null) continue;

                                Map<String, Object> parentAnn = new HashMap<>();
                                parentAnn.put("title",          "📢 " + title);
                                parentAnn.put("message",        message);
                                parentAnn.put("type",           "admin");
                                parentAnn.put("timestamp",      ServerValue.TIMESTAMP);
                                parentAnn.put("registrationId", regId); // ✅ scoping key

                                updates.put("Announcements/Parents/" + pushKey, parentAnn);
                            }
                        }

                        if (!updates.isEmpty()) {
                            mDatabase.updateChildren(updates);
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        android.util.Log.e("ManageAnnouncements",
                                "shareAnnouncementWithParents failed", error.toException());
                    }
                });
    }

    // ── 6. Update Dialog (announcements ke liye) ──────────────────────────────
    private void showUpdateDialog(String id, String oldTitle, String oldMessage,
                                  String oldClass, String sourcePath) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("✏️ Update Announcement");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(44, 24, 44, 24);

        TextView tvTitleLabel = new TextView(this);
        tvTitleLabel.setText("Title:");
        tvTitleLabel.setTypeface(null, Typeface.BOLD);
        layout.addView(tvTitleLabel);

        final EditText etTitle = new EditText(this);
        etTitle.setHint("Announcement Title");
        if (oldTitle != null) etTitle.setText(oldTitle);
        layout.addView(etTitle);

        TextView tvMsgLabel = new TextView(this);
        tvMsgLabel.setText("Message:");
        tvMsgLabel.setPadding(0, 12, 0, 4);
        tvMsgLabel.setTypeface(null, Typeface.BOLD);
        layout.addView(tvMsgLabel);

        final EditText etMessage = new EditText(this);
        etMessage.setHint("Announcement Message");
        etMessage.setMinLines(3);
        if (oldMessage != null) etMessage.setText(oldMessage);
        layout.addView(etMessage);

        TextView tvClassLabel = new TextView(this);
        tvClassLabel.setText("Target Class:");
        tvClassLabel.setPadding(0, 12, 0, 4);
        tvClassLabel.setTypeface(null, Typeface.BOLD);
        layout.addView(tvClassLabel);

        final Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, classList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        if (oldClass != null && !oldClass.trim().isEmpty()) {
            int pos = classList.indexOf(oldClass.trim());
            spinner.setSelection(pos >= 0 ? pos : 0);
        } else {
            spinner.setSelection(0);
        }
        layout.addView(spinner);

        builder.setView(layout);
        builder.setPositiveButton("Save", (dialog, which) -> {
            String updatedTitle   = etTitle.getText().toString().trim();
            String updatedMessage = etMessage.getText().toString().trim();
            String selClass       = spinner.getSelectedItem().toString();

            if (updatedTitle.isEmpty() || updatedMessage.isEmpty()) {
                Toast.makeText(this, "Fields cannot be blank!", Toast.LENGTH_SHORT).show();
                return;
            }

            String classToSave = selClass.equals("All Classes") ? "" : selClass;

            Map<String, Object> updates = new HashMap<>();
            updates.put("title",       updatedTitle);
            updates.put("message",     updatedMessage);
            updates.put("targetClass", classToSave);

            mDatabase.child(sourcePath).child(id).updateChildren(updates)
                    .addOnCompleteListener(task ->
                            Toast.makeText(this,
                                    task.isSuccessful() ? "Updated!" : "Update failed.",
                                    Toast.LENGTH_SHORT).show());
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // ── 7. FCM ────────────────────────────────────────────────────────────────
    private void sendFcmNotification(String topic, String title, String body) {
        OkHttpClient client = new OkHttpClient();
        MediaType mediaType = MediaType.parse("application/json; charset=utf-8");
        try {
            JSONObject jsonRoot         = new JSONObject();
            JSONObject jsonNotification = new JSONObject();
            JSONObject jsonData         = new JSONObject();

            jsonRoot.put("to", "/topics/" + topic);
            jsonNotification.put("title", title);
            jsonNotification.put("body",  body);
            jsonNotification.put("sound", "default");
            jsonData.put("targetClass", topic);
            jsonRoot.put("notification", jsonNotification);
            jsonRoot.put("data",         jsonData);

            RequestBody requestBody = RequestBody.create(jsonRoot.toString(), mediaType);
            Request request = new Request.Builder()
                    .url("https://fcm.googleapis.com/fcm/send")
                    .post(requestBody)
                    .addHeader("Authorization", "key=" + FCM_SERVER_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override public void onFailure(@NonNull Call call, @NonNull IOException e) {}
                @Override public void onResponse(@NonNull Call call, @NonNull Response response)
                        throws IOException { response.close(); }
            });
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ── 8. Delete (announcement ya notification — dono sourcePath se handle) ──
    private void confirmDelete(String id, String title, String sourcePath) {
        new AlertDialog.Builder(this)
                .setTitle("Delete?")
                .setMessage("Remove: '" + title + "'?")
                .setPositiveButton("Delete", (dialog, which) ->
                        mDatabase.child(sourcePath).child(id).removeValue()
                                .addOnCompleteListener(task -> {
                                    if (task.isSuccessful())
                                        Toast.makeText(this, "Deleted.", Toast.LENGTH_SHORT).show();
                                }))
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Counts update ─────────────────────────────────────────────────────────
    private void updateCounts(int total, int allC, int classC) {
        if (tvTotalCount != null) tvTotalCount.setText(String.valueOf(total));
        if (tvAllCount   != null) tvAllCount.setText(String.valueOf(allC));
        if (tvClassCount != null) tvClassCount.setText(String.valueOf(classC));
    }

    private void showEmptyState(String messageText) {
        TextView tv = new TextView(this);
        tv.setText(messageText);
        tv.setTextSize(15f);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, (int)(50 * dp), 0, 0);
        containerAnnouncements.addView(tv);
    }

    // ── Data class ────────────────────────────────────────────────────────────
    static class AnnouncementItem {
        String id, title, message, dateStr, displayClass, sourcePath, type, notifType;
        boolean isAllClasses;
        long rawTimestamp;

        AnnouncementItem(String id, String title, String message, String dateStr,
                         String displayClass, boolean isAllClasses, String sourcePath, String type) {
            this.id           = id;
            this.title        = title;
            this.message      = message;
            this.dateStr      = dateStr;
            this.displayClass = displayClass;
            this.isAllClasses = isAllClasses;
            this.sourcePath   = sourcePath;
            this.type         = type;
        }
    }
}