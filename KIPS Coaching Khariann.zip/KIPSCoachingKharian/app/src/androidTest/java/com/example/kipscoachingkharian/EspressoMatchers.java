package com.example.kipscoachingkharian;

import android.view.View;

import com.google.android.material.textfield.TextInputLayout;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;

public class EspressoMatchers {

    // Ye TextInputLayout ka error text check karta hai (jaise "Please enter email")
    public static Matcher<View> hasTextInputLayoutErrorText(final String expectedError) {
        return new TypeSafeMatcher<View>() {
            @Override
            public boolean matchesSafely(View view) {
                if (!(view instanceof TextInputLayout)) return false;
                CharSequence error = ((TextInputLayout) view).getError();
                if (expectedError == null) return error == null;
                return error != null && expectedError.contentEquals(error);
            }

            @Override
            public void describeTo(Description description) {
                description.appendText("with error text: " + expectedError);
            }
        };
    }
}