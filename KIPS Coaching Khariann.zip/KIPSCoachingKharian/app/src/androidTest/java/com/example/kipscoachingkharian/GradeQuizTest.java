package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.espresso.PerformException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.espresso.util.HumanReadables;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withHint;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

/**
 * Grade Quiz Submission Test — Teacher login karke Quizzes screen kholta
 * hai, pehle quiz ki "Submissions"/attempts list kholta hai, pehle
 * student ke attempt par "Review Short Answers & Give Marks" dabata
 * hai, short-answer question ke marks likh kar "Save Marks" karta hai.
 *
 * IMPORTANT SAMAJH LEIN — QUIZ GRADING KA TAREEQA APP MEIN ALAG HAI:
 *   • MCQ questions:  KHUD-BA-KHUD (auto) grade ho jate hain — teacher
 *                     ko kuch nahi karna parta, koi "Give Marks" button
 *                     nahi hota inke liye.
 *   • Short-answer:   Teacher ko "📝 Review Short Answers & Give Marks"
 *                     button dabana parta hai, phir har short question
 *                     ke liye marks likh kar "Save Marks" karna hota hai.
 *
 * ZAROORI SHART (test data): Kam az kam EK quiz maujood ho jisme kam az
 * kam EK "short answer" type question ho, aur kisi student ne wo quiz
 * attempt kiya ho, aur uske short answers abhi tak "pending" hon
 * (button "Review Short Answers & Give Marks" dikhana chahiye, na ke
 * "View Short Answers"). Is test mein sirf EK short question maan kar
 * chala hai — agar zyada hon to hints ("Marks obtained") multiple ban
 * jayenge aur is case mein index-based matching chahiye hogi.
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daal dein.
 */
@RunWith(AndroidJUnit4.class)
public class GradeQuizTest {

    // ── Yahan apni test-teacher ki details daalein ─────────────────────────
    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";
    private static final String MARKS_TO_GIVE = "4";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    // RecyclerView/ViewGroup item ke ANDAR wale specific button par click
    // karne ke liye (poore row par click karne se yeh button trigger
    // nahi hota). View.findViewById() subtree mein pehla match dhoondta
    // hai, is liye yeh ek plain container (jaise LinearLayout jisme
    // dynamically items add hue hon) par bhi kaam karta hai.
    // Container (jaise LinearLayout jisme quiz items dynamically add hote
    // hain) ke AAKHRI (last) child ke andar diye gaye button id ko dhoond
    // kar click karta hai — naye/latest items list ke aakhir mein aate hain.
    public static ViewAction clickButtonInLastChild(final int buttonId) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(android.view.ViewGroup.class);
            }

            @Override
            public String getDescription() {
                return "Click on a button inside the last child of a ViewGroup.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                android.view.ViewGroup container = (android.view.ViewGroup) view;
                int count = container.getChildCount();
                if (count == 0) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException("Container mein koi child hi nahi (list khali hai)"))
                            .build();
                }
                View lastChild = container.getChildAt(count - 1);
                View btn = lastChild.findViewById(buttonId);
                if (btn == null) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException("No view with id " + buttonId + " found inside last child"))
                            .build();
                }
                btn.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    public static ViewAction clickChildViewWithId(final int id) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Click on a child view with specified id.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View v = view.findViewById(id);
                if (v == null) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException("No view with id " + id + " found inside row"))
                            .build();
                }
                v.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    // Login ke baad Dashboard load hone ka INTEZAAR, fixed sleep ki jagah
    // baar baar check karta hai (har 1 second) — agar network slow ho aur
    // Firebase response der se aaye, tab bhi yeh sahi tarah wait karega,
    // bajaye ek fixed waqt ke baad hi giving up karne ke.
    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return; // Mil gaya, dashboard load ho chuka hai
            } catch (Exception e) {
                Thread.sleep(1000); // 1 second aur wait kar ke dobara try karo
            }
        }
        // Aakhri koshish — agar ab bhi na mile to asal exception throw hoga
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    @Test
    public void giveMarksToFirstPendingShortAnswer() throws InterruptedException {

        // ── Step 1: Login ──────────────────────────────────────────────────
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(25); // Dashboard load hone ka smart wait (max 25s)

        // ── Step 2: Dashboard se "Quizzes" card dabayen ──────────────────────
        onView(withId(R.id.cardQuizzes)).perform(click());
        Thread.sleep(3000); // Quiz list load hone ka wait

        // ── Step 3: SABSE NAYE quiz ke "Submissions" button par tap karein ───
        // NOTE: yeh list RecyclerView nahi, plain LinearLayout hai
        // (layoutQuizList) jisme items dynamically add hote hain, aur
        // naya/latest quiz list ke AAKHIR (last) mein aata hai — isi liye
        // pehla item (position 0) nahi, LAST child target kar rahe hain.
        onView(withId(R.id.layoutQuizList))
                .perform(clickButtonInLastChild(R.id.btnSubmissions));

        Thread.sleep(3000); // Attempts list load hone ka wait

        // ── Step 4: Pehle student ke attempt par "Review Short Answers" ─────
        onView(withId(R.id.rvAttempts)).perform(
                RecyclerViewActions.actionOnItemAtPosition(
                        0, clickChildViewWithId(R.id.btnReviewShort)));

        Thread.sleep(500);

        // ── Step 5: Short question ke marks likhein aur Save karein ─────────
        onView(withHint("Marks obtained"))
                .perform(typeText(MARKS_TO_GIVE), closeSoftKeyboard());
        onView(withText("Save Marks")).perform(click());

        Thread.sleep(3000); // Firebase par save hone ka wait

        // ── Step 6: Verify — success Toast ke bajaye status text check karein ─
        // (Toast verify karna Espresso mein extra setup maangta hai, is liye
        // seedha list refresh ho kar "Short: Marked" dikhna chahiye — neeche
        // wapas dialog khol kar confirm kar sakte hain ke button text badal
        // gaya "View Short Answers" mein.)
        Thread.sleep(1000);
        onView(withId(R.id.rvAttempts))
                .check(matches(isDisplayed()));
    }
}
