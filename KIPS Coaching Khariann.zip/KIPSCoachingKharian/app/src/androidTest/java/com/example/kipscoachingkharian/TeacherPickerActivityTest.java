package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;

import android.content.Context;
import android.content.Intent;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.dashboard.TeacherPickerActivity;

import org.junit.After;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class TeacherPickerActivityTest {

    private ActivityScenario<TeacherPickerActivity> scenario;

    // ⚠️ Firebase mein maujood teacher ka naam daalo:
    private static final String KNOWN_TEACHER_NAME = "Ayesha Ali";

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    private void launch() {
        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, TeacherPickerActivity.class);
        intent.putExtra("MY_NAME", "Ahad Ali");
        intent.putExtra("MY_ROLE", "Parent");
        scenario = ActivityScenario.launch(intent);

        sleep(9000); // Firebase se teacher list load hone ka time
    }

    @After
    public void tearDown() {
        if (scenario != null) {
            scenario.close();
        }
    }

    // ═══════════════════════════════════════════════════════════
    // #1 — Back button
    // ═══════════════════════════════════════════════════════════
    @Test
    public void backButton_click_finishesActivity() {
        launch();

        onView(withId(R.id.ivBack)).perform(click());
        sleep(1000);

        assertEquals(Lifecycle.State.DESTROYED, scenario.getState());
    }

    // ═══════════════════════════════════════════════════════════
    // #2 — Header title
    // ═══════════════════════════════════════════════════════════
    @Test
    public void headerTitle_showsSelectATeacher() {
        launch();

        onView(withId(R.id.tvPickerTitle)).check(matches(withText("Select a Teacher")));
    }

    // ═══════════════════════════════════════════════════════════
    // #3 — Real teacher data load ho
    // ═══════════════════════════════════════════════════════════
    @Test
    public void searchBox_typingMatchingName_showsFilteredResult() {
        launch();

        onView(withId(R.id.etSearch)).perform(
                typeText(KNOWN_TEACHER_NAME), closeSoftKeyboard());
        sleep(1000);

        onView(allOf(withId(R.id.tvPickName), withText(KNOWN_TEACHER_NAME)))
                .check(matches(isDisplayed()));
    }
    // ═══════════════════════════════════════════════════════════
    // #4 — Progress bar chupa ho load ke baad
    // ═══════════════════════════════════════════════════════════
    @Test
    public void progressBar_hidesAfterLoad() {
        launch();
sleep(3000);
        onView(withId(R.id.progressBar)).check(matches(not(isDisplayed())));
    }
    @Ignore("Redundant — covered by searchBox_typingMatchingName_showsFilteredResult, jo bhi confirm karta hai teachers load ho chuke hain")
    @Test
    public void teachersLoad_showAtLeastOneRow() {
        launch();

        onView(allOf(withId(R.id.tvPickName), withText(KNOWN_TEACHER_NAME)))
                .check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════
    // #6 — Search box mein na-milne wala text
    // ═══════════════════════════════════════════════════════════
    @Test
    public void searchBox_typingNonMatchingText_showsEmptyMessage() {
        launch();

        onView(withId(R.id.etSearch)).perform(
                typeText("such teacher"), closeSoftKeyboard());
        sleep(1000);

        onView(withId(R.id.tvEmpty)).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════
    // #7 — Row click → ChatActivity khule
    // ═══════════════════════════════════════════════════════════
    @Test
    public void clickingTeacherRow_opensChatActivity() {
        launch();

        onView(withId(R.id.rvParents)).perform(
                androidx.test.espresso.contrib.RecyclerViewActions.actionOnItemAtPosition(0, click()));
        sleep(15000);

        org.junit.Assert.assertNotEquals(Lifecycle.State.RESUMED, scenario.getState());
    }
}