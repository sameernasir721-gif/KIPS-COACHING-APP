package com.example.kipscoachingkharian;

import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.test.espresso.PerformException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.espresso.util.HumanReadables;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.List;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isDialog;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

/**
 * Student Progress Test — Teacher login karke Student Progress screen
 * kholta hai, pehle student ke "Enter Marks" button par tap karta hai,
 * dialog mein Classes Attended/Total, Assignment Marks, Quiz Marks
 * bhar kar Save karta hai, phir dobara dialog khol kar verify karta hai
 * ke values save ho gayi hain.
 *
 * NOTE: Yeh dialog PURI TARAH programmatically (Java code se) banta hai
 * — fields ke koi fixed resource-id ya hint nahi hain. Espresso ka
 * "index se Nth EditText pakadna" (withIndex matcher) is dialog ke sath
 * unreliable nikla (Espresso ke internal retry/polling se counter galat
 * ho jata hai). Is liye hum "Save" button ko anchor bana kar, dialog ke
 * poore window ke andar khud (manually) saare EditTexts dhoond kar,
 * seedha unka text set karte hain — yeh ek hi atomic step mein hota
 * hai, koi retry-related galti nahi hoti.
 *
 * Fields ki tarteeb:
 *   Index 0 → Classes Attended     Index 1 → Classes Total
 *   Index 2 → Assignment Obtained  Index 3 → Assignment Total
 *   Index 4 → Quiz Obtained        Index 5 → Quiz Total
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daal dein.
 */
@RunWith(AndroidJUnit4.class)
public class StudentProgressTest {

    // ── Yahan apni test-teacher ki details daalein ─────────────────────────
    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    // ── Yeh marks hum test ke liye enter karenge ────────────────────────────
    private static final String CLASS_ATTENDED  = "18";
    private static final String CLASS_TOTAL     = "20";
    private static final String ASSIGN_OBTAINED = "45";
    private static final String ASSIGN_TOTAL    = "50";
    private static final String QUIZ_OBTAINED   = "8";
    private static final String QUIZ_TOTAL      = "10";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    // RecyclerView item ke andar specific button par click.
    public static ViewAction clickChildViewWithId(final int id) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Click on a child view with specified id.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View v = view.findViewById(id);
                if (v == null) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException("No view with id " + id + " found inside row"))
                            .build();
                }
                v.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    // View tree mein saare EditTexts recursively dhoond kar list mein daalta
    // hai, DFS (top-to-bottom, left-to-right) tarteeb mein — bilkul waisi
    // tarteeb jaisi dialog banate waqt Java code mein views add hui thin.
    private static void collectEditTexts(View v, List<EditText> out) {
        if (v instanceof EditText) {
            out.add((EditText) v);
        } else if (v instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) v;
            for (int i = 0; i < group.getChildCount(); i++) {
                collectEditTexts(group.getChildAt(i), out);
            }
        }
    }

    // Diye gaye view ke poore window (root) mein se Nth EditText ka text
    // seedha set kar deta hai — ek hi atomic action mein, koi Espresso
    // matcher-retry involve nahi hoti is liye reliable hai.
    public static ViewAction setNthEditTextInWindow(final int index, final String value) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Set text on the Nth EditText found in this window.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View root = view.getRootView();
                List<EditText> editTexts = new ArrayList<>();
                collectEditTexts(root, editTexts);

                if (index >= editTexts.size()) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException(
                                    "Sirf " + editTexts.size() + " EditTexts mile, index " + index + " maujood nahi"))
                            .build();
                }

                EditText target = editTexts.get(index);

                // Asal Espresso click aur typing simulate karte hain (taake
                // phone/emulator screen par har character type hota HUA
                // nazar aaye — bilkul insaan jaisa typing, seedha setText()
                // se instant jump nahi).
                click().perform(uiController, target);
                uiController.loopMainThreadUntilIdle();
                clearText().perform(uiController, target);
                uiController.loopMainThreadUntilIdle();
                typeText(value).perform(uiController, target);
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    // RecyclerView item ke andar kisi child TextView ka text nikaalta hai
    // (verification ke liye, taake baad mein wahi student dobara dhoond
    // sakein — list Firebase update ke baad re-sort ho sakti hai, is liye
    // position 0 dobara wahi student na ho).
    public static ViewAction readChildTextWithId(final int id, final String[] outValue) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Read text from a child view with specified id.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View v = view.findViewById(id);
                if (v instanceof android.widget.TextView) {
                    outValue[0] = ((android.widget.TextView) v).getText().toString();
                }
            }
        };
    }

    // Diye gaye view ke poore window mein se Nth EditText ka current text
    // laut kar deta hai (verification ke liye) — array ke zariye taake
    // ViewAction ke andar se value bahar nikaali ja sake.
    public static ViewAction getNthEditTextInWindow(final int index, final String[] outValue) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Read text from the Nth EditText found in this window.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View root = view.getRootView();
                List<EditText> editTexts = new ArrayList<>();
                collectEditTexts(root, editTexts);
                if (index < editTexts.size()) {
                    outValue[0] = editTexts.get(index).getText().toString();
                }
            }
        };
    }

    // Login ke baad Dashboard load hone ka smart wait
    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(1000);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    // "Save" button ko anchor bana kar dialog ke Nth EditText mein value set
    // karte hain (Save button hamesha stable/locatable hota hai).
    private void fillDialogField(int index, String value) throws InterruptedException {
        onView(withText("Save")).inRoot(isDialog())
                .perform(setNthEditTextInWindow(index, value));
        Thread.sleep(400); // Thoda wait taake typing screen par nazar aaye
    }

    @Test
    public void enterMarks_verifySaved() throws InterruptedException {

        // ── Step 1: Login ──────────────────────────────────────────────────
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(25);

        // ── Step 2: Dashboard se "Student Progress" card dabayen ─────────────
        onView(withId(R.id.cardPerformance)).perform(scrollTo(), click());
        Thread.sleep(3000); // Student list load hone ka wait

        // ── Step 3: Pehle student ka naam capture karein (verification ke
        //            liye — list re-sort ho sakti hai, is liye position ki
        //            bajaye naam se dobara dhoondenge) ────────────────────────
        String[] studentName = new String[1];
        onView(withId(R.id.rvStudents)).perform(
                RecyclerViewActions.actionOnItemAtPosition(
                        0, readChildTextWithId(R.id.tvStudentName, studentName)));

        // ── Step 4: Us student ke "Enter Marks" button par tap karein ────────
        onView(withId(R.id.rvStudents)).perform(
                RecyclerViewActions.actionOnItemAtPosition(
                        0, clickChildViewWithId(R.id.btnEnterMarks)));
        Thread.sleep(1000); // Dialog open hone ka wait

        // ── Step 5: Dialog ke fields bharein ──────────────────────────────────
        fillDialogField(0, CLASS_ATTENDED);   // Classes Attended
        fillDialogField(1, CLASS_TOTAL);      // Classes Total
        fillDialogField(2, ASSIGN_OBTAINED);  // Assignment Obtained
        fillDialogField(3, ASSIGN_TOTAL);     // Assignment Total
        fillDialogField(4, QUIZ_OBTAINED);    // Quiz Obtained
        fillDialogField(5, QUIZ_TOTAL);       // Quiz Total

        // ── Step 6: "Save" dabayen (AlertDialog ka positive button) ──────────
        onView(withText("Save")).inRoot(isDialog()).perform(click());

        Thread.sleep(4000); // Firebase par save + list refresh hone ka wait

        // ── Step 7: Verify — USI student ko naam se dobara dhoond kar dialog
        //            kholein aur value check karein (position se nahi,
        //            kyunke list re-sort ho chuki ho sakti hai) ───────────────
        onView(withId(R.id.rvStudents)).perform(
                RecyclerViewActions.actionOnItem(
                        hasDescendant(withText(studentName[0])),
                        clickChildViewWithId(R.id.btnEnterMarks)));
        Thread.sleep(1000);

        onView(withText("Save")).inRoot(isDialog()).check(matches(isDisplayed()));

        String[] savedValue = new String[1];
        onView(withText("Save")).inRoot(isDialog())
                .perform(getNthEditTextInWindow(0, savedValue));

        org.junit.Assert.assertEquals(
                "Classes Attended ki value save nahi hui!",
                CLASS_ATTENDED, savedValue[0]);
    }
}