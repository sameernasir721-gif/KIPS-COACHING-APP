package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

/**
 * Student Login Flow — "smart" version: yeh check karta hai ke
 * "I've Verified" button screen par dikh raha hai ya nahi (kyunki
 * agar account pehle se verified ho chuka ho, to app yeh button
 * dikhati hi nahi — seedha Student-ID field chali jati hai).
 *
 * IMPORTANT: Neeche apni asal test-student ki details daal dein.
 */
@RunWith(AndroidJUnit4.class)
public class StudentLoginFlowTest {

    // ── Yahan apni test-student ki details daalein ─────────────────────────
    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void fullLoginFlow_navigatesToDashboard() throws InterruptedException {

        // Step 1 — Login tab par hain yeh confirm karein
        onView(withId(R.id.etStudentUsername))
                .check(matches(isDisplayed()));

        // Step 2 — Email type karein
        onView(withId(R.id.etStudentUsername))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        // Step 3 — Password type karein
        onView(withId(R.id.etStudentPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        // Step 4 — "I've Verified" button SIRF tab dabayen jab woh screen par
        // maujood ho (agar already-verified state hai, yeh button GONE hoga)
        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified))
                    .perform(click());

            // Firebase se verification-check response ka wait
            Thread.sleep(4000);
        }

        // Step 5 — Ab Student-ID field dikh chuki hogi (dono halaton mein)
        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        // Step 6 — Login button dabayen
        onView(withId(R.id.btnStudentLogin))
                .perform(click());

        // Step 7 — Login + Dashboard-load ke liye wait
        Thread.sleep(5000);

        // Step 8 — Verify karein ke Dashboard khul chuki hai
        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));
    }

    /**
     * Helper method — check karta hai ke di gayi ID wala view is waqt
     * screen par VISIBLE hai ya nahi (GONE/hidden ho to false return karega).
     */
    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }
}