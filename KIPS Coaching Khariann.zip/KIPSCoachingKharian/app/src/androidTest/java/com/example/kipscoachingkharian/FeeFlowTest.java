package com.example.kipscoachingkharian;

import android.os.IBinder;
import android.view.WindowManager;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.Root;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

/**
 * Fee Flow Test — Login karne ke baad Dashboard se "Fee" card
 * (cardFees) kholta hai, aur teen cheezein verify karta hai:
 *   1) Fee screen ke key elements (header, current-due card,
 *      payment-history) crash ke bina load ho jaate hain.
 *   2) "Pay Now" button — jab admin ki taraf se koi UNPAID challan
 *      Firebase mein maujood ho (hasUnpaidFee == true), tab button
 *      payment flow start karta hai ("Payment process starting..."
 *      Toast).
 *   3) "Pay Now" button — jab koi pending challan na ho
 *      (hasUnpaidFee == false), tab button "No pending fee to pay
 *      right now." Toast dikhata hai aur PayFast flow launch nahi
 *      karta.
 *
 * IMPORTANT — ek cheez FeeActivity.java mein abhi bhi DEAD CODE hai:
 *   "cardFeeChallan" layout mein maujood hai lekin FeeActivity.java
 *   mein iska koi click-listener wire nahi hua — is liye is button ko
 *   test nahi kiya gaya (dabane par filhaal kuch nahi hota).
 *
 * IMPORTANT: Neeche DO ALAG test-students ki details daalein —
 *   - TEST_EMAIL_UNPAID / TEST_STUDENT_ID_UNPAID / TEST_PASSWORD_UNPAID
 *     → aisa student jiske paas Firebase mein kam az kam ek "Unpaid"
 *     fee record ho (Fees/{uid}/.../status = "Unpaid").
 *   - TEST_EMAIL_PAID / TEST_STUDENT_ID_PAID / TEST_PASSWORD_PAID
 *     → aisa student jiske saare fee records "Paid" hon (ya koi record
 *     hi na ho).
 * Pehla constant-set (TEST_EMAIL/TEST_STUDENT_ID/TEST_PASSWORD) sirf
 * smoke-test (headerAndHistoryLoad) ke liye hai — us test ko fee-status
 * se farq nahi padta.
 */
@RunWith(AndroidJUnit4.class)
public class FeeFlowTest {

    // ── Smoke-test ke liye koi bhi student chalega ──────────────────────────
    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    // ── Scenario A: is student ke paas kam az kam ek UNPAID challan ho ──────
    private static final String TEST_EMAIL_UNPAID      = "TODO_unpaid_student@example.com";
    private static final String TEST_STUDENT_ID_UNPAID = "TODO_unpaid_student_id";
    private static final String TEST_PASSWORD_UNPAID   = "TODO_unpaid_password";

    // ── Scenario B: is student ke saare fees Paid hon (koi Unpaid na ho) ────
    private static final String TEST_EMAIL_PAID      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID_PAID = "student048";
    private static final String TEST_PASSWORD_PAID   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void openFee_directFromDashboard_headerAndHistoryLoad() throws InterruptedException {
        loginAndOpenFee(TEST_EMAIL, TEST_STUDENT_ID, TEST_PASSWORD);

        // ── Header section verify karein (student name + grade) ──────────────
        onView(withId(R.id.tvStudentNameFee)).check(matches(isDisplayed()));
        onView(withId(R.id.tvHeaderStudentInfo)).check(matches(isDisplayed()));

        // ── Current-due card verify karein (amount + due date) ───────────────
        onView(withId(R.id.tvCurrentAmount)).check(matches(isDisplayed()));
        onView(withId(R.id.tvDueDateCurrent)).check(matches(isDisplayed()));

        // ── "Pay Now" button visible hona chahiye — is test mein click NAHI
        // karte (dekhein payNow_* tests neeche jo dono scenarios cover
        // karte hain) ──────────────────────────────────────────────────────
        onView(withId(R.id.btnPayNow)).check(matches(isDisplayed()));

        // ── Payment-history container (feeContainer) verify karein — ya to
        // history rows dikh rahi hongi, ya "No record found" — dono soorat
        // mein container khud screen par mojood/displayed hona chahiye
        // (crash na hone ka pakka saboot) ──────────────────────────────────
        onView(withId(R.id.feeContainer)).check(matches(isDisplayed()));
    }

    // TODO: Unpaid-fee wala real test-account milte hi @Ignore hata dein
    // aur upar TEST_EMAIL_UNPAID / TEST_STUDENT_ID_UNPAID /
    // TEST_PASSWORD_UNPAID bhar dein.
    @Ignore("Unpaid-fee wala test-account abhi tak provide nahi hua")
    @Test
    public void payNow_withPendingChallan_startsPaymentFlow() throws InterruptedException {
        loginAndOpenFee(TEST_EMAIL_UNPAID, TEST_STUDENT_ID_UNPAID, TEST_PASSWORD_UNPAID);

        // NOTE: is click se asal mein PayFastLauncher.launch() chalta hai,
        // jo PayFastWebViewActivity (real payment WebView) open kar deta
        // hai. Toast dikhne ke turant baad hi wo activity launch ho jaati
        // hai, is liye Toast-check jaldi hona chahiye.
        onView(withId(R.id.btnPayNow)).perform(click());

        onView(withText("Payment process starting..."))
                .inRoot(isToast())
                .check(matches(isDisplayed()));
    }

    @Test
    public void payNow_withNoPendingChallan_showsNoFeeToast() throws InterruptedException {
        loginAndOpenFee(TEST_EMAIL_PAID, TEST_STUDENT_ID_PAID, TEST_PASSWORD_PAID);

        onView(withId(R.id.btnPayNow)).perform(click());

        onView(withText("No pending fee to pay right now."))
                .inRoot(isToast())
                .check(matches(isDisplayed()));

        // Screen abhi bhi Fee screen par hi honi chahiye — koi navigation
        // ya payment flow launch nahi hona chahiye.
        onView(withId(R.id.btnPayNow)).check(matches(isDisplayed()));
    }

    // ── Shared login + "Fee" card open karne ka helper ──────────────────────
    private void loginAndOpenFee(String email, String studentId, String password)
            throws InterruptedException {

        onView(withId(R.id.etStudentUsername))
                .perform(typeText(email), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(password), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(studentId), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));

        // Dashboard se "Fee" card dabayen (direct)
        // NOTE: cardFees dashboard ke ScrollView mein SABSE AAKHIR hai
        // (Subjects → StudyMaterial → Quizzes → Assignments → Reports →
        // Fees), is liye chhoti screens par yeh bina scroll kiye <90%
        // visible ho sakta hai aur Espresso click() reject kar deta hai.
        // scrollTo() pehle isay viewport mein la kar guarantee deta hai.
        onView(withId(R.id.cardFees)).perform(scrollTo(), click());

        // Fee screen load hone ka wait (Firebase se Users + Fees fetch
        // hoti hai — do sequential calls hain, isliye thoda zyada wait)
        Thread.sleep(3500);
    }

    /**
     * Helper — check karta hai ke di gayi ID wala view is waqt VISIBLE hai
     * ya nahi (GONE/hidden ho to false return karega).
     */
    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }

    /**
     * Matcher jo Toast ki window ko pehchanta hai — Toasts activity ke
     * DecorView se alag ek chhoti si system window mein render hote hain,
     * is liye normal onView() unhein directly nahi pakad sakta; inRoot()
     * ke sath is matcher ki zaroorat hoti hai.
     */
    private static Matcher<Root> isToast() {
        return new TypeSafeMatcher<Root>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("is toast");
            }

            @Override
            public boolean matchesSafely(Root root) {
                int type = root.getWindowLayoutParams().get().type;
                if (type == WindowManager.LayoutParams.TYPE_TOAST) {
                    IBinder windowToken = root.getDecorView().getWindowToken();
                    IBinder appToken = root.getDecorView().getApplicationWindowToken();
                    return windowToken == appToken;
                }
                return false;
            }
        };
    }
}