package com.example.kipscoachingkharian;

import android.view.View;
import android.view.ViewGroup;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;

/**
 * Quiz Flow Test — Login karne ke baad Dashboard se Quizzes screen kholta
 * hai, PEHLE "Start Quiz" button (chahe kitni bhi quizzes 'Start' state
 * mein ho) ko dabata hai, attempt-dialog khulne ka verify karta hai, bina
 * jawab diye Submit karta hai, aur result-dialog mein Score dikhne ka
 * verify karta hai.
 *
 * NOTE: Quiz ke cards/buttons is app mein code se dynamically banaye
 * jaate hain (fixed R.id nahi hoti), isliye humein buttons ko unke TEXT
 * se pakadna padta hai. Jab ek se zyada "Start Quiz" buttons screen par
 * hon, "first()" helper matcher sirf PEHLE wale ko target karta hai.
 *
 * IMPORTANT: Neeche apni asal test-student ki details daalein. Yeh test
 * tabhi kaam karega jab test-student ke paas kam se kam 1 attempt-able
 * ("Start Quiz" state wali) quiz ho.
 */
@RunWith(AndroidJUnit4.class)
public class QuizFlowTest {

    // ── Yahan apni test-student ki details daalein ─────────────────────────
    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void openQuiz_submitWithoutAnswering_showsResult() throws InterruptedException {

        // ── Step 1-6: Poora Login Flow ──────────────────────────────────────
        onView(withId(R.id.etStudentUsername))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));

        // ── Step 7: Dashboard se "Quizzes" card dabayen ─────────────────────
        onView(withId(R.id.cardQuizzes)).perform(click());

        // Quiz list load hone ka wait (Firebase se real data aata hai)
        Thread.sleep(3000);

        // ── Step 8: Pehla "Start Quiz" button dabayen (text se match) ───────
        onView(first(allOf(withText("Start Quiz"), isDisplayed())))
                .perform(click());

        // Questions load hone + dialog khulne ka wait
        Thread.sleep(2000);

        // ── Step 9: Attempt-dialog khul chuka hai yeh verify karein ─────────
        onView(withId(R.id.tvDialogQuizTitle))
                .check(matches(isDisplayed()));
        onView(withId(R.id.tvQuizTimer))
                .check(matches(isDisplayed()));

        // ── Step 10: Bina jawab diye Submit dabayen ─────────────────────────
        onView(withId(R.id.btnSubmitQuiz))
                .perform(click());

        // Firebase mein submission save hone + result-dialog khulne ka wait
        Thread.sleep(3000);

        // ── Step 11: Result-dialog mein Score dikhna chahiye ────────────────
        onView(first(withText(containsString("Score"))))
                .check(matches(isDisplayed()));
    }

    /**
     * Helper — check karta hai ke di gayi ID wala view is waqt VISIBLE hai
     * ya nahi (GONE/hidden ho to false return karega).
     */
    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }

    /**
     * Custom matcher — jab screen par ek jaisi (matching) MULTIPLE views
     * hon (jaise kai "Start Quiz" buttons), yeh sirf PEHLI wali ko target
     * karta hai, taake Espresso "AmbiguousViewMatcherException" na de.
     */
    private static Matcher<View> first(final Matcher<View> matcher) {
        return new TypeSafeMatcher<View>() {
            boolean isFirstMatchFound = false;

            @Override
            public void describeTo(Description description) {
                description.appendText("should return first matching view");
            }

            @Override
            public boolean matchesSafely(View view) {
                if (isFirstMatchFound) {
                    return false;
                }
                if (matcher.matches(view)) {
                    isFirstMatchFound = true;
                    return true;
                }
                return false;
            }
        };
    }
}
