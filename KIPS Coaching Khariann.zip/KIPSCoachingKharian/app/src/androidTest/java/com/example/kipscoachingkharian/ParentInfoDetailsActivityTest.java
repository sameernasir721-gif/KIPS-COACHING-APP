package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasErrorText;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isEnabled;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import android.content.Context;
import android.content.Intent;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;
import androidx.test.uiautomator.Until;

import com.example.kipscoachingkharian.dashboard.ParentInfoDetailsActivity;
import com.google.firebase.auth.FirebaseAuth;

import org.junit.After;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ParentInfoDetailsActivityTest {

    private ActivityScenario<ParentInfoDetailsActivity> scenario;

    private static final String TEST_EMAIL = "ama319709@gmail.com";
    private static final String TEST_PASSWORD = "Student048#";
    private static final String TEST_NAME = "Ahad Ali";

    @After
    public void tearDown() {
        if (scenario != null) {
            scenario.close();
        }
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    private void loginAndLaunch() {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(TEST_EMAIL, TEST_PASSWORD);
        sleep(6000);

        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentInfoDetailsActivity.class);
        scenario = ActivityScenario.launch(intent);

        sleep(5000);
    }

    private void enterEditMode() {
        onView(withId(R.id.ivEditProfile)).perform(click());
        sleep(1500);
    }

    // ═══════════════════════════════════════════════════════════
    // #1 — Session check
    // ═══════════════════════════════════════════════════════════
    @Test
    public void noUserLoggedIn_finishesActivity() {
        FirebaseAuth.getInstance().signOut();

        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentInfoDetailsActivity.class);
        scenario = ActivityScenario.launch(intent);

        sleep(2000);

        assertEquals(Lifecycle.State.DESTROYED, scenario.getState());
    }

    // ═══════════════════════════════════════════════════════════
    // #2 — Initial state
    // ═══════════════════════════════════════════════════════════
    @Test
    public void initialState_fieldsAreDisabledAndUpdateButtonHidden() {
        loginAndLaunch();

        onView(withId(R.id.etName)).check(matches(not(isEnabled())));
        onView(withId(R.id.etPhone)).check(matches(not(isEnabled())));
        onView(withId(R.id.etCurrentPassword)).check(matches(not(isEnabled())));
        onView(withId(R.id.layoutNewPassword)).check(matches(not(isDisplayed())));
        onView(withId(R.id.btnUpdateProfile)).check(matches(not(isDisplayed())));
    }

    // ═══════════════════════════════════════════════════════════
    // #3 — Firebase se data load
    // ═══════════════════════════════════════════════════════════
    @Test
    public void dataLoadsFromFirebase_fieldsShowCorrectValues() {
        loginAndLaunch();

        onView(withId(R.id.etName)).check(matches(
                androidx.test.espresso.matcher.ViewMatchers.withText(TEST_NAME)));
    }

    // ═══════════════════════════════════════════════════════════
    // #4 — Edit icon click
    // ═══════════════════════════════════════════════════════════
    @Test
    public void editIconClick_enablesPhoneAndPasswordFields() {
        loginAndLaunch();
        enterEditMode();

        onView(withId(R.id.etPhone)).check(matches(isEnabled()));
        onView(withId(R.id.etCurrentPassword)).check(matches(isEnabled()));
        onView(withId(R.id.layoutNewPassword)).check(matches(isDisplayed()));
        onView(withId(R.id.btnUpdateProfile)).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════
    // #5 — Current password clear hota hai
    // ═══════════════════════════════════════════════════════════
    @Test
    public void editIconClick_clearsCurrentPasswordField() {
        loginAndLaunch();
        enterEditMode();

        onView(withId(R.id.etCurrentPassword)).check(matches(
                androidx.test.espresso.matcher.ViewMatchers.withText("")));
    }

    // ═══════════════════════════════════════════════════════════
    // #6 — Cancel edit
    // ═══════════════════════════════════════════════════════════
    @Test
    public void cancelEdit_disablesFieldsAgain() {
        loginAndLaunch();
        enterEditMode();
        onView(withId(R.id.ivEditProfile)).perform( click());
        sleep(1500);

        onView(withId(R.id.etPhone)).check(matches(not(isEnabled())));
        onView(withId(R.id.etCurrentPassword)).check(matches(not(isEnabled())));
        onView(withId(R.id.btnUpdateProfile)).check(matches(not(isDisplayed())));
    }

    // ═══════════════════════════════════════════════════════════
    // #7 — Password toggle crash na ho
    // ═══════════════════════════════════════════════════════════
    @Test
    public void passwordToggle_doesNotCrash() {
        loginAndLaunch();

        onView(withId(R.id.ivToggleCurrentPass)).perform(scrollTo(), click());
        sleep(1000);

        onView(withId(R.id.etCurrentPassword)).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════
    // #8 — Empty old password
    // ═══════════════════════════════════════════════════════════
    @Test
    public void update_emptyOldPassword_showsError() {
        loginAndLaunch();
        enterEditMode();

        onView(withId(R.id.btnUpdateProfile)).perform(scrollTo(), click());
        sleep(1500);

        onView(withId(R.id.etCurrentPassword)).check(matches(hasErrorText("Old password required")));
    }

    // ═══════════════════════════════════════════════════════════
    // #9 — Wrong old password
    // ═══════════════════════════════════════════════════════════
    @Test
    public void update_wrongOldPassword_showsError() {
        loginAndLaunch();
        enterEditMode();

        onView(withId(R.id.etCurrentPassword)).perform(scrollTo(), typeText("WrongPassword1!"), closeSoftKeyboard());
        sleep(1000);
        onView(withId(R.id.btnUpdateProfile)).perform(scrollTo(), click());
        sleep(1500);

        onView(withId(R.id.etCurrentPassword)).check(matches(hasErrorText("Incorrect current password!")));
    }

    // ═══════════════════════════════════════════════════════════
    // #10 — New password without confirm
    // ═══════════════════════════════════════════════════════════
    @Test
    public void update_newPasswordWithoutConfirm_showsError() {
        loginAndLaunch();
        enterEditMode();

        onView(withId(R.id.etCurrentPassword)).perform(scrollTo(), typeText(TEST_PASSWORD), closeSoftKeyboard());
        sleep(2000);
        onView(withId(R.id.etNewPassword)).perform(scrollTo(), typeText("NewStrong1!@"), closeSoftKeyboard());
        sleep(2000);
        onView(withId(R.id.btnUpdateProfile)).perform(scrollTo(), click());
        sleep(2500);

        onView(withId(R.id.etConfirmPassword)).check(matches(hasErrorText("Please confirm your new password")));
    }

    // ═══════════════════════════════════════════════════════════
    // #11 — Password mismatch
    // ═══════════════════════════════════════════════════════════
    @Test
    public void update_passwordMismatch_showsError() {
        loginAndLaunch();
        enterEditMode();

        onView(withId(R.id.etCurrentPassword)).perform(scrollTo(), typeText(TEST_PASSWORD), closeSoftKeyboard());
        sleep(500);
        onView(withId(R.id.etNewPassword)).perform(scrollTo(), typeText("NewStrong1!@"), closeSoftKeyboard());
        sleep(500);
        onView(withId(R.id.etConfirmPassword)).perform(scrollTo(), typeText("Different1!@"), closeSoftKeyboard());
        sleep(500);
        onView(withId(R.id.btnUpdateProfile)).perform(scrollTo(), click());
        sleep(1500);

        onView(withId(R.id.etConfirmPassword)).check(matches(hasErrorText("Passwords do not match!")));
    }

    // ═══════════════════════════════════════════════════════════
    // #12 — Weak new password
    // ═══════════════════════════════════════════════════════════
    @Test
    public void update_weakNewPassword_showsError() {
        loginAndLaunch();
        enterEditMode();

        onView(withId(R.id.etCurrentPassword)).perform(scrollTo(), typeText(TEST_PASSWORD), closeSoftKeyboard());
        sleep(500);
        onView(withId(R.id.etNewPassword)).perform(scrollTo(), typeText("weak"), closeSoftKeyboard());
        sleep(500);
        onView(withId(R.id.etConfirmPassword)).perform(scrollTo(), typeText("weak"), closeSoftKeyboard());
        sleep(500);
        onView(withId(R.id.btnUpdateProfile)).perform(scrollTo(), click());
        sleep(1500);

        onView(withId(R.id.etNewPassword)).check(matches(hasErrorText("Weak password! Use 8+ chars with symbols.")));
    }

    // ═══════════════════════════════════════════════════════════
    // #13 — Sirf phone update, success
    // ═══════════════════════════════════════════════════════════
    @Ignore
    @Test
    public void update_phoneOnly_savesSuccessfully() {
        loginAndLaunch();
        enterEditMode();

        onView(withId(R.id.etCurrentPassword)).perform(scrollTo(), typeText(TEST_PASSWORD), closeSoftKeyboard());
        sleep(2000);
        onView(withId(R.id.btnUpdateProfile)).perform(scrollTo(), click());
        sleep(3000);

        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        device.waitForIdle();
        UiObject2 toast = device.wait(Until.findObject(By.textContains("Updated")), 15000);

        assertNotNull("Success Toast nahi mila", toast);
    }
    // ═══════════════════════════════════════════════════════════
    // #14 — New password set + reset wapas purane pe
    // ═══════════════════════════════════════════════════════════
    @Test
    public void update_withNewPassword_reAuthenticatesAndSaves() {
        loginAndLaunch();

        String oldPassword = "Student048#";
        String newPassword = "Student048@";

        enterEditMode();
        onView(withId(R.id.etCurrentPassword)).perform(scrollTo(), typeText(oldPassword), closeSoftKeyboard());
        sleep(500);
        onView(withId(R.id.etNewPassword)).perform(scrollTo(), typeText(newPassword), closeSoftKeyboard());
        sleep(500);
        onView(withId(R.id.etConfirmPassword)).perform(scrollTo(), typeText(newPassword), closeSoftKeyboard());
        sleep(500);
        onView(withId(R.id.btnUpdateProfile)).perform(scrollTo(), click());

        sleep(12000);

        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        device.waitForIdle();
        UiObject2 toast = device.wait(Until.findObject(By.textContains("Updated")), 10000);
        assertNotNull("Success Toast not found (password change)", toast);

        sleep(2000);
        enterEditMode();
        onView(withId(R.id.etCurrentPassword)).perform(scrollTo(), typeText(newPassword), closeSoftKeyboard());
        sleep(500);
        onView(withId(R.id.etNewPassword)).perform(scrollTo(), typeText(oldPassword), closeSoftKeyboard());
        sleep(500);
        onView(withId(R.id.etConfirmPassword)).perform(scrollTo(), typeText(oldPassword), closeSoftKeyboard());
        sleep(500);
        onView(withId(R.id.btnUpdateProfile)).perform(scrollTo(), click());

        sleep(12000);

        UiObject2 resetToast = device.wait(Until.findObject(By.textContains("Updated")), 10000);
        assertNotNull("Password reset Toast not found", resetToast);
    }
}