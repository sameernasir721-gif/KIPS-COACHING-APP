package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isEnabled;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.not;

/**
 * Profile Flow Test — Login karne ke baad bottom-nav ke "Profile" tab
 * (nav_bottom_profile) se ProfileActivity (menu screen: My Profile,
 * Notifications, Settings, Help, Logout) kholta hai, aur us mein se
 * "My Profile" par tap karke StudentProfileInfoActivity (asal details +
 * Edit toggle) test karta hai.
 * IMPORTANT — DO SCREENS HAIN:
 *   1) ProfileActivity        (activity_profile.xml)        — menu list
 *   2) StudentProfileInfoActivity (activity_student_profile_info.xml)
 *      — asal name/email/phone/studentId + "Edit" toggle
 * "My Profile" menu item (item_my_profile) (1) se (2) kholta hai.
 * IMPORTANT — bottom-nav ka "Profile" icon dashboard ke card-grid mein
 * NAHI, balke seedha bottom-navigation-bar mein hota hai. Es app ke
 * dashboard layout mein bottom-nav ko ek "curved" look dene ke liye
 * jaan-boojh kar NEGATIVE bottom-margin (-21dp) diya gaya hai
 * (activity_student_dashboard.xml) — jiski wajah se nav-items ka neeche
 * wala hissa screen ki visible boundary se thoda bahar chala jata hai.
 * Yeh permanent/structural hai (koi wait se theek nahi hota) — is liye
 * Espresso ka normal click() hamesha "<90% visible" reject deta hai.
 * FIX: hum yahan Espresso ki visibility-check bypass karke seedha
 * view.performClick() call karte hain (forceClick() helper dekhein) —
 * bilkul waisa hi jaisa AnnouncementFlowTest ke clickFirstChild() mein
 * kiya tha.
 * IMPORTANT: Neeche apni asal test-student ki details daalein.
 */
@RunWith(AndroidJUnit4.class)
public class ProfileFlowTest {

    // ── Yahan apni test-student ki details daalein ─────────────────────────
    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void profileMenu_headerAndMenuItemsLoad() throws InterruptedException {
        login();
        openProfileMenu();

        // ── Header (naam + role) crash ke bina load hone ka check ───────────
        onView(withId(R.id.tv_name)).check(matches(isDisplayed()));
        onView(withId(R.id.tv_role)).check(matches(isDisplayed()));

        // ── Saare 5 menu items visible hone ka check ─────────────────────────
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
        onView(withId(R.id.item_notifications)).check(matches(isDisplayed()));
        onView(withId(R.id.item_settings)).check(matches(isDisplayed()));
        onView(withId(R.id.item_help)).check(matches(isDisplayed()));
        onView(withId(R.id.item_logout)).check(matches(isDisplayed()));
    }

    @Test
    public void myProfileInfo_showsDataAndEditToggleWorks() throws InterruptedException {
        login();
        openProfileMenu();

        // ── "My Profile" menu item dabayen → StudentProfileInfoActivity khule ──
        onView(withId(R.id.item_my_profile)).perform(click());
        Thread.sleep(2500);

        // ── Fields load ho chuki hon aur (default) disabled/read-only hon ────
        onView(withId(R.id.etName)).check(matches(isDisplayed()));
        onView(withId(R.id.etEmail))
                .check(matches(isDisplayed()))
                .check(matches(withText(TEST_EMAIL)));
        onView(withId(R.id.etPhone)).check(matches(isDisplayed()));
        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .check(matches(not(isEnabled())));   // studentId hamesha read-only
        onView(withId(R.id.etName)).check(matches(not(isEnabled())));
        onView(withId(R.id.etPhone)).check(matches(not(isEnabled())));

        // ── "Edit" dabayen — phone editable ho jana chahiye, Update button
        // aur change-password arrow dikhna chahiye ───────────────────────────
        onView(withId(R.id.tvEditProfile))
                .check(matches(withText("Edit")))
                .perform(click());

        onView(withId(R.id.etPhone)).check(matches(isEnabled()));
        onView(withId(R.id.btnUpdateProfile)).check(matches(isDisplayed()));
        onView(withId(R.id.ivChangePasswordArrow)).check(matches(isDisplayed()));
        onView(withId(R.id.tvEditProfile)).check(matches(withText("Cancel")));

        // ── "Cancel" dabayen — wapas read-only state mein aana chahiye ───────
        onView(withId(R.id.tvEditProfile)).perform(click());

        onView(withId(R.id.etPhone)).check(matches(not(isEnabled())));
        onView(withId(R.id.tvEditProfile)).check(matches(withText("Edit")));

        // ── Back button se ProfileActivity par wapas jana chahiye ────────────
        onView(withId(R.id.btnBack)).perform(click());
        Thread.sleep(500);
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
    }

    @Test
    public void notifications_opensAnnouncementsScreen() throws InterruptedException {
        login();
        openProfileMenu();

        onView(withId(R.id.item_notifications)).perform(click());
        Thread.sleep(2500);

        // AnnouncementsActivity khul jani chahiye — iski list-container aur
        // search-box crash ke bina load honi chahiye (AnnouncementFlowTest
        // mein bhi yeh ids use hui thi)
        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));
        onView(withId(R.id.etSearch)).check(matches(isDisplayed()));
    }

    @Test
    public void settings_opensAndShowsOptionsAndBackWorks() throws InterruptedException {
        login();
        openProfileMenu();

        onView(withId(R.id.item_settings)).perform(click());
        Thread.sleep(1500);

        // Teeno setting-options (Font Size, Theme, Privacy) visible hone
        // ka check
        onView(withId(R.id.itemFontSize)).check(matches(isDisplayed()));
        onView(withId(R.id.itemTheme)).check(matches(isDisplayed()));
        onView(withId(R.id.itemPrivacy)).check(matches(isDisplayed()));

        // Back button se wapas ProfileActivity par jana chahiye
        onView(withId(R.id.btnBack)).perform(click());
        Thread.sleep(500);
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
    }

    @Test
    public void help_opensAndShowsFaqAndBackWorks() throws InterruptedException {
        login();
        openProfileMenu();

        onView(withId(R.id.item_help)).perform(click());
        Thread.sleep(1500);

        // FAQ container visible hone ka check (isme dynamically FAQ-cards
        // add hote hain)
        onView(withId(R.id.layoutFaqContainer)).check(matches(isDisplayed()));

        // Back button se wapas ProfileActivity par jana chahiye
        onView(withId(R.id.btnBack)).perform(click());
        Thread.sleep(500);
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
    }

    @Test
    public void logout_cancelKeepsUserOnProfileScreen() throws InterruptedException {
        login();
        openProfileMenu();

        onView(withId(R.id.item_logout)).perform(click());
        Thread.sleep(500);

        // Confirmation dialog verify karein
        onView(withText("Logout")).check(matches(isDisplayed()));
        onView(withText("Do you want to logout?")).check(matches(isDisplayed()));

        // "Cancel" dabayen — user profile screen par hi rehna chahiye
        onView(withText("Cancel")).perform(click());
        Thread.sleep(500);

        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
    }

    @Test
    public void logout_confirmSignsOutAndGoesToLoginScreen() throws InterruptedException {
        login();
        openProfileMenu();

        onView(withId(R.id.item_logout)).perform(click());
        Thread.sleep(500);

        // "Yes, Logout" dabayen
        onView(withText("Yes, Logout")).perform(click());
        Thread.sleep(2000);

        // Wapas StudentLoginActivity par pahunch jana chahiye
        onView(withId(R.id.etStudentUsername)).check(matches(isDisplayed()));
        onView(withId(R.id.btnStudentLogin)).check(matches(isDisplayed()));
    }

    // ── Shared login helper ──────────────────────────────────────────────────
    private void login() throws InterruptedException {
        onView(withId(R.id.etStudentUsername))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));
    }

    // ── Bottom-nav "Profile" icon dabane ka shared helper ────────────────────
    private void openProfileMenu() throws InterruptedException {
        // NOTE: yahan click() ki jagah forceClick() use kiya gaya hai —
        // wajah upar class-level javadoc mein di gayi hai (negative
        // bottom-margin ki wajah se view <90% visible register hoti hai).
        onView(withId(R.id.nav_bottom_profile)).perform(forceClick());
        // ProfileActivity load hone + Firebase se student-data fetch hone
        // ka wait
        Thread.sleep(2500);
    }

    /**
     * Helper — check karta hai ke di gayi ID wala view is waqt VISIBLE hai
     * ya nahi (GONE/hidden ho to false return karega).
     */
    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }

    /**
     * Custom ViewAction — Espresso ke normal click() ki "<90% visible"
     * constraint ko bypass karke seedha view.performClick() call karta
     * hai. Yeh un views ke liye zaroori hai jo design ki wajah se
     * (jaise is app ke bottom-nav ka negative-margin curved look)
     * hamesha thoda screen se bahar clip hote hain, is liye standard
     * click() unhein kabhi bhi "visible enough" nahi manta — chahe
     * kitna bhi wait kar liya jaye.
     */
    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isEnabled();
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing the 90%-visible constraint.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }
}