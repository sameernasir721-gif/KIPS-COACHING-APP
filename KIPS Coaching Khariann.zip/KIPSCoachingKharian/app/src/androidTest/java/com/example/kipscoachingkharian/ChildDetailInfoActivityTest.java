package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.assertion.ViewAssertions.doesNotExist;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import android.content.Context;
import android.content.Intent;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;
import androidx.test.uiautomator.Until;

import com.example.kipscoachingkharian.dashboard.ChildDetailInfoActivity;
import com.google.firebase.auth.FirebaseAuth;

import org.junit.After;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ChildDetailInfoActivityTest {

    private ActivityScenario<ChildDetailInfoActivity> scenario;

    private static final String TEST_EMAIL = "ama319709@gmail.com";
    private static final String TEST_PASSWORD = "Student048#";
    private static final String STUDENT_ID = "student048";
    private static final String STUDENT_NAME = "Haleema";

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    private void loginAndLaunch(String studentId) {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(TEST_EMAIL, TEST_PASSWORD);
        sleep(5000);

        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ChildDetailInfoActivity.class);
        if (studentId != null) intent.putExtra("STUDENT_ID", studentId);
        scenario = ActivityScenario.launch(intent);

        sleep(6000); // Firebase se student + schedule data load hone ka time
    }

    @After
    public void tearDown() {
        if (scenario != null) {
            scenario.close();
        }
    }

    // ═══════════════════════════════════════════════════════════
    // #1 — Student ID missing → error Toast
    // ═══════════════════════════════════════════════════════════
    @Ignore
    @Test
    public void noStudentId_showsErrorToast() {
        loginAndLaunch(null);

        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        UiObject2 toast = device.wait(Until.findObject(By.textContains("Student ID not provided")), 1000);

        assertNotNull("Error Toast not found", toast);
    }

    // ═══════════════════════════════════════════════════════════
    // #2 — Home tab click → Activity band ho
    // ═══════════════════════════════════════════════════════════
    @Test
    public void homeTab_click_finishesActivity() {
        loginAndLaunch(STUDENT_ID);

        onView(withId(R.id.llHomeTab)).perform(click());
        sleep(1000);

        assertEquals(Lifecycle.State.DESTROYED, scenario.getState());
    }

    // ═══════════════════════════════════════════════════════════
    // #3 — Profile tab click → Profile khule (band nahi hoti)
    // ═══════════════════════════════════════════════════════════
    @Test
    public void profileTab_click_navigatesToProfile() {
        loginAndLaunch(STUDENT_ID);

        org.junit.Assert.assertNotNull("User login not found",
                FirebaseAuth.getInstance().getCurrentUser());

        scenario.onActivity(activity -> {
            android.view.View profileTab = activity.findViewById(R.id.llProfileTab);
            profileTab.performClick();
        });
        sleep(3000);

        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        UiObject2 loginToast = device.findObject(By.textContains("Please Login Again"));
        org.junit.Assert.assertNull("Login Again Toast found", loginToast);


    }


    // ═══════════════════════════════════════════════════════════
    // #4 — Real Student ID se sahi details load hon
    // ═══════════════════════════════════════════════════════════
    @Test
    public void validStudentId_showsCorrectDetails() {
        loginAndLaunch(STUDENT_ID);

        onView(withId(R.id.tvStudentName)).check(matches(withText(STUDENT_NAME)));
        onView(withId(R.id.tvStudentId)).check(matches(isDisplayed()));
        onView(withId(R.id.tvClass)).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════
    // #5 — Reports card → ProgressReport
    // ═══════════════════════════════════════════════════════════
    @Test
    public void cardReports_click_navigatesToProgressReport() {
        loginAndLaunch(STUDENT_ID);

        onView(withId(R.id.cardReports)).perform(scrollTo(),click());
        sleep(8000);

        onView(withId(R.id.cardReports)).check(doesNotExist());
    }

    // ═══════════════════════════════════════════════════════════
    // #6 — Quizzes card → QuizReport
    // ═══════════════════════════════════════════════════════════
    @Test
    public void cardQuizzes_click_navigatesToQuizReport() {
        loginAndLaunch(STUDENT_ID);

        onView(withId(R.id.cardQuizzes)).perform(scrollTo(),click());
        sleep(8000);

        onView(withId(R.id.cardQuizzes)).check(doesNotExist());
    }

    // ═══════════════════════════════════════════════════════════
    // #7 — Assignments card → AssignmentReport
    // ═══════════════════════════════════════════════════════════
    @Test
    public void cardAssignments_click_navigatesToAssignmentReport() {
        loginAndLaunch(STUDENT_ID);

        onView(withId(R.id.cardAssignments)).perform(scrollTo(),click());
        sleep(10000);

        onView(withId(R.id.cardAssignments)).check(doesNotExist());
    }

    // ═══════════════════════════════════════════════════════════
    // #8 — Upcoming schedule cards (Live Class/Quiz/Assignment) dikhein
    // ═══════════════════════════════════════════════════════════
    @Test
    public void upcomingScheduleCards_areDisplayed() {
        loginAndLaunch(STUDENT_ID);

        scenario.onActivity(activity -> {
            android.widget.LinearLayout classes = activity.findViewById(R.id.containerUpcomingClasses);
            android.widget.LinearLayout quizzes = activity.findViewById(R.id.containerUpcomingQuizzes);
            android.widget.LinearLayout assignments = activity.findViewById(R.id.containerUpcomingAssignments);

            org.junit.Assert.assertTrue("Live Class card not found", classes.getChildCount() > 0);
            org.junit.Assert.assertTrue("Quiz card not found", quizzes.getChildCount() > 0);
            org.junit.Assert.assertTrue("Assignment card not found", assignments.getChildCount() > 0);
        });
    }
}