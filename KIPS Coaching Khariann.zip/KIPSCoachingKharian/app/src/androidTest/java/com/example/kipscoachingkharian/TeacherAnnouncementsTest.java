package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.action.ViewActions.swipeLeft;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.test.espresso.PerformException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.espresso.util.HumanReadables;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Teacher Announcements Test — Teacher sirf announcements SEARCH, VIEW,
 * aur SWIPE-TO-DELETE (dismiss) kar sakta hai — CREATE nahi kar sakta
 * (yeh sirf Admin kar sakta hai). Is liye yeh test sirf inhi 3 cheezon
 * ko cover karta hai:
 *   1. View  — announcements list load ho rahi hai
 *   2. Search — kisi term se search kar ke list filter hoti hai
 *   3. Delete — pehle announcement ko swipe kar ke dismiss karna, aur
 *      verify karna ke wo list se hat gaya
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daal dein.
 */
@RunWith(AndroidJUnit4.class)
public class TeacherAnnouncementsTest {

    // ── Yahan apni test-teacher ki details daalein ─────────────────────────
    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    // Container (dynamically-added items wali LinearLayout) ke pehle child
    // ke andar diye gaye TextView ka text nikaalta hai.
    public static ViewAction readFirstChildTextWithId(final int id, final String[] outValue) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(ViewGroup.class);
            }

            @Override
            public String getDescription() {
                return "Read text of a TextView inside the first child of a container.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                ViewGroup container = (ViewGroup) view;
                if (container.getChildCount() == 0) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException("Container khali hai"))
                            .build();
                }
                View firstChild = container.getChildAt(0);
                View target = firstChild.findViewById(id);
                if (target instanceof TextView) {
                    outValue[0] = ((TextView) target).getText().toString();
                }
            }
        };
    }

    // Container ke pehle child ko swipe (left) kar ke dismiss/delete karta
    // hai — Espresso ki built-in swipeLeft() action ko us specific child
    // par manually invoke karte hain.
    public static ViewAction swipeFirstChildLeft() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(ViewGroup.class);
            }

            @Override
            public String getDescription() {
                return "Swipe left on the first child of a container.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                ViewGroup container = (ViewGroup) view;
                if (container.getChildCount() == 0) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException("Container khali hai, swipe nahi ho sakta"))
                            .build();
                }
                View firstChild = container.getChildAt(0);
                swipeLeft().perform(uiController, firstChild);
            }
        };
    }

    // Espresso ki 90%-visibility check ko bypass kar ke DIRECT click karta
    // hai — bottom nav ke buttons is device par kabhi kabhi "not 90%
    // visible" ka false-positive dete hain jabke woh visually theek hote
    // hain.
    public static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility check.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    // Login ke baad Dashboard load hone ka smart wait
    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(1000);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    @Test
    public void searchAndDeleteAnnouncement() throws InterruptedException {

        // ── Step 1: Login ──────────────────────────────────────────────────
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(25);

        // ── Step 2: Bottom nav se "Announcement" tab dabayen ─────────────────
        androidx.test.espresso.Espresso.closeSoftKeyboard();
        Thread.sleep(500);
        onView(withId(R.id.nav_bottom_Announcment)).perform(forceClick());
        Thread.sleep(2500); // Announcements list load hone ka wait

        // ── Step 3 (VIEW): List load ho rahi hai, verify karein ──────────────
        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));

        // ── Step 4 (SEARCH): Pehle announcement ka title capture karein, phir
        //                     us title se search kar ke confirm karein ke
        //                     wahi result aata hai ─────────────────────────
        String[] firstTitle = new String[1];
        onView(withId(R.id.containerAnnouncements))
                .perform(readFirstChildTextWithId(R.id.tvItemTitle, firstTitle));

        if (firstTitle[0] != null && !firstTitle[0].isEmpty()) {
            String searchTerm = firstTitle[0].length() > 4
                    ? firstTitle[0].substring(0, 4) : firstTitle[0];
            onView(withId(R.id.etSearchAnnouncements))
                    .perform(replaceText(searchTerm), closeSoftKeyboard());
            Thread.sleep(1000);

            onView(withId(R.id.containerAnnouncements))
                    .check(matches(hasDescendant(
                            ViewMatchers.withText(org.hamcrest.Matchers.containsString(searchTerm)))));

            // Search clear kar dein taake agla step poori list par ho
            onView(withId(R.id.etSearchAnnouncements)).perform(
                    androidx.test.espresso.action.ViewActions.clearText(), closeSoftKeyboard());
            Thread.sleep(1000);
        }

        // Delete se pehle total items count capture karein (title se check
        // karna reliable nahi tha kyunke "📝 Quiz Submitted" jaisa generic
        // title kai alag announcements par repeat ho sakta hai)
        int[] countBefore = new int[1];
        onView(withId(R.id.containerAnnouncements)).perform(readChildCount(countBefore));

        // ── Step 5 (DELETE): Pehle announcement ko swipe kar ke dismiss karein
        onView(withId(R.id.containerAnnouncements)).perform(swipeFirstChildLeft());
        Thread.sleep(1500); // Dismiss animation + list update ka wait

        // ── Step 6: Verify — item count 1 kam hona chahiye ───────────────────
        int[] countAfter = new int[1];
        onView(withId(R.id.containerAnnouncements)).perform(readChildCount(countAfter));

        org.junit.Assert.assertEquals(
                "Delete ke baad announcement count 1 kam hona chahiye tha!",
                countBefore[0] - 1, countAfter[0]);
    }

    // Container ke bachon (children) ki total ginti nikaalta hai.
    public static ViewAction readChildCount(final int[] outCount) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(ViewGroup.class);
            }

            @Override
            public String getDescription() {
                return "Read child count of a container.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                outCount[0] = ((ViewGroup) view).getChildCount();
            }
        };
    }

    private static Matcher<View> withText_exact(String text) {
        return ViewMatchers.withText(text);
    }
}