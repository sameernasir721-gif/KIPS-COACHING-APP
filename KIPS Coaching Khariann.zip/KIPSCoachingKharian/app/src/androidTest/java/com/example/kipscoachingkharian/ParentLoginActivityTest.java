package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.doesNotExist;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static com.example.kipscoachingkharian.EspressoMatchers.hasTextInputLayoutErrorText;
import static org.hamcrest.Matchers.not;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;

import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.ViewAction;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.ParentLoginActivity;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ParentLoginActivityTest {

    private ActivityScenario<ParentLoginActivity> scenario;

    @Before
    public void setup() {
        Context ctx = ApplicationProvider.getApplicationContext();
        SharedPreferences prefs = ctx.getSharedPreferences("kips_prefs", Context.MODE_PRIVATE);
        prefs.edit().putBoolean("parent_email_verified_done", true).apply();

        Intent intent = new Intent(ctx, ParentLoginActivity.class);
        scenario = ActivityScenario.launch(intent);
    }

    // ═══════════════════════════════════════════════════════════
    // VISIBILITY / TAB TESTS
    // ═══════════════════════════════════════════════════════════

    @Test
    public void loginForm_isVisibleWhenAlreadyVerified() {
        onView(withId(R.id.tilLoginStudentId)).check(matches(isDisplayed()));
        onView(withId(R.id.btnParentLogin)).check(matches(isDisplayed()));
        onView(withId(R.id.btnEmailVerified)).check(matches(not(isDisplayed())));
    }

    @Test
    public void tabRegister_switchesToRegisterLayout() {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.layoutRegister)).check(matches(isDisplayed()));
        onView(withId(R.id.layoutLogin)).check(matches(not(isDisplayed())));
    }

    @Test
    public void tabLogin_switchesBackToLoginLayout() {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.tabLogin)).perform(click());
        onView(withId(R.id.layoutLogin)).check(matches(isDisplayed()));
        onView(withId(R.id.layoutRegister)).check(matches(not(isDisplayed())));
    }

    @Test
    public void login_emptyFields_showsAllValidationErrors() {
        onView(withId(R.id.btnParentLogin)).perform(click());

        onView(withId(R.id.tilLoginEmail)).check(matches(hasTextInputLayoutErrorText("Please enter email")));
        onView(withId(R.id.tilLoginStudentId)).check(matches(hasTextInputLayoutErrorText("Please enter Student ID")));
        onView(withId(R.id.tilLoginPassword)).check(matches(hasTextInputLayoutErrorText("Please enter your password")));
    }

    @Test
    public void login_invalidEmailFormat_showsError() {
        fillLoginFields("notanemail", "student001", "SomePass1!");
        onView(withId(R.id.btnParentLogin)).perform(click());
        onView(withId(R.id.tilLoginEmail)).check(matches(hasTextInputLayoutErrorText("Enter valid email")));
    }

    @Test
    public void login_invalidStudentIdFormat_showsError() {
        fillLoginFields("parent@test.com", "STU-001", "SomePass1!");
        onView(withId(R.id.btnParentLogin)).perform(click());
        onView(withId(R.id.tilLoginStudentId))
                .check(matches(hasTextInputLayoutErrorText("Invalid format. Example: student001")));
    }

    @Test
    public void login_typingAfterError_clearsErrorText() {
        onView(withId(R.id.btnParentLogin)).perform(click());
        onView(withId(R.id.etLoginEmail)).perform(typeText("a"));
        onView(withId(R.id.tilLoginEmail)).check(matches(hasTextInputLayoutErrorText(null)));
    }

    @Test
    public void login_validCredentials_navigatesToParentDashboard() throws InterruptedException {
        fillLoginFields("ama319709@gmail.com", "student048", "Student048@");
        onView(withId(R.id.btnParentLogin)).perform(click());

        Thread.sleep(8000); // Firebase auth + database calls wait
        onView(withId(R.id.btnParentLogin)).check(doesNotExist());
    }

    @Test
    public void login_wrongPassword_showsInvalidCredentialsError() throws InterruptedException {
        fillLoginFields("ama319709@gmail.com", "student048", "WrongPassword1!");
        onView(withId(R.id.btnParentLogin)).perform(click());

        Thread.sleep(15000);

        onView(withId(R.id.tilLoginPassword))
                .check(matches(hasTextInputLayoutErrorText("Invalid email or password")));
    }
    @Test
    public void loginPasswordToggle_iconClick_doesNotCrash() {
        onView(withId(R.id.etLoginPassword)).perform(typeText("MyPass123!"), closeSoftKeyboard());

        // TextInputLayout ke end icon pe click (built-in Espresso action)
        onView(withId(R.id.tilLoginPassword)).perform(new ViewAction() {
            @Override
            public org.hamcrest.Matcher<View> getConstraints() {
                return org.hamcrest.Matchers.any(View.class);
            }
            @Override
            public String getDescription() {
                return "Click TextInputLayout end icon";
            }
            @Override
            public void perform(androidx.test.espresso.UiController uiController, View view) {
                com.google.android.material.textfield.TextInputLayout til =
                        (com.google.android.material.textfield.TextInputLayout) view;
                View endIcon = til.findViewById(com.google.android.material.R.id.text_input_end_icon);
                endIcon.performClick();
            }
        });
        onView(withId(R.id.etLoginPassword)).check(matches(isDisplayed()));
    }
    @Test
    public void register_studentIdNotFound_showsError() throws InterruptedException {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.etRegName)).perform(typeText("Test Parent"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(typeText("03001112222"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(typeText("newtestparent1@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etRegStudentId)).perform(typeText("student999"), closeSoftKeyboard()); // exist nahi karti
        onView(withId(R.id.etRegPassword)).perform(typeText("NewPass1!@"), closeSoftKeyboard());
        onView(withId(R.id.btnParentRegister)).perform(click());

        Thread.sleep(8000);

        onView(withId(R.id.tilRegStudentId))
                .check(matches(hasTextInputLayoutErrorText("Student ID 'student999' not found in records")));
    }
    @Test
    public void register_studentIdAlreadyLinkedToParent_showsError() throws InterruptedException {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.etRegName)).perform(typeText("Another Parent"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(typeText("03003334444"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(typeText("raiazaslam063@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etRegStudentId)).perform(typeText("student048"), closeSoftKeyboard()); // already linked
        onView(withId(R.id.etRegPassword)).perform(typeText("AnotherPass1!"), closeSoftKeyboard());
        onView(withId(R.id.btnParentRegister)).perform(click());

        Thread.sleep(8000);

        onView(withId(R.id.tilRegStudentId))
                .check(matches(hasTextInputLayoutErrorText("This Student ID is already linked with another parent account")));
    }
    @Test
    public void register_passwordAlreadyInUse_showsError() throws InterruptedException {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.etRegName)).perform(typeText("Password Test Parent"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(typeText("03005556666"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(typeText("raiazaslam063@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etRegStudentId)).perform(typeText("student064"), closeSoftKeyboard());
        onView(withId(R.id.etRegPassword)).perform(typeText("Student048@"), closeSoftKeyboard()); // already used password
        onView(withId(R.id.btnParentRegister)).perform(click());

        Thread.sleep(8000);

        onView(withId(R.id.tilRegPassword))
                .check(matches(hasTextInputLayoutErrorText("This password is already in use — please choose a different password")));
    }
    @Test
    public void register_emailAlreadyInUse_showsError() throws InterruptedException {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.etRegName)).perform(typeText("Duplicate Email Parent"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(typeText("03009990000"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(typeText("ama319709@gmail.com"), closeSoftKeyboard()); // already used
        onView(withId(R.id.etRegStudentId)).perform(typeText("student064"), closeSoftKeyboard());
        onView(withId(R.id.etRegPassword)).perform(typeText("YetAnotherPass1!"), closeSoftKeyboard());
        onView(withId(R.id.btnParentRegister)).perform(click());

        Thread.sleep(15000);

        onView(withId(R.id.tilRegEmail))
                .check(matches(hasTextInputLayoutErrorText("This email is already registered")));
    }

    @Test
    public void register_validNewParent_registersSuccessfully() throws InterruptedException {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.etRegName)).perform(typeText("Naima"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(typeText("03007778888"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(typeText("raiazaslam063@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etRegStudentId)).perform(typeText("student064"), closeSoftKeyboard());
        onView(withId(R.id.etRegPassword)).perform(typeText("Student064@"), closeSoftKeyboard());
        onView(withId(R.id.btnParentRegister)).perform(click());

        Thread.sleep(10000);
        onView(withId(R.id.layoutLogin)).check(matches(isDisplayed()));
    }
    @Test
    public void login_unverifiedEmail_blocksLoginAndShowsMessage() throws InterruptedException {
        fillLoginFields("raiazaslam063@gmail.com", "student064", "Student064@");
        onView(withId(R.id.btnParentLogin)).perform(click());

        Thread.sleep(8000);
        onView(withId(R.id.btnParentLogin)).check(matches(isDisplayed()));
    }
    @Test
    public void login_pendingStatus_showsApprovalPendingAndStaysOnLogin() throws InterruptedException {
        fillLoginFields("raiazaslam063@gmail.com", "student064", "Student064@");
        onView(withId(R.id.btnParentLogin)).perform(click());
        Thread.sleep(8000);
        onView(withId(R.id.btnParentLogin)).check(matches(isDisplayed()));
    }

    @Test
    public void login_studentIdMismatch_showsErrorAndStaysOnLogin() throws InterruptedException {
        fillLoginFields("ama319709@gmail.com", "student999", "Student048@"); // sahi email/pass, galat ID
        onView(withId(R.id.btnParentLogin)).perform(click());

        Thread.sleep(8000);

        onView(withId(R.id.btnParentLogin)).check(matches(isDisplayed()));
    }

    @Test
    public void login_accountDoesNotExist_showsInvalidCredentials() throws InterruptedException {
        fillLoginFields("doesnotexist12345@gmail.com", "student001", "SomePass1!");
        onView(withId(R.id.btnParentLogin)).perform(click());

        Thread.sleep(8000);

        onView(withId(R.id.tilLoginPassword))
                .check(matches(hasTextInputLayoutErrorText("Invalid email or password")));
    }
    @Ignore
    @Test
    public void forgotPassword_validEmail_sendsResetLink() throws InterruptedException {
        onView(withId(R.id.etLoginEmail)).perform(typeText("ama319709@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.tvForgotPassword)).perform(click());

        Thread.sleep(8000); // Firebase ko email bhejne ka time do
        onView(withId(R.id.tvForgotPassword)).check(matches(isDisplayed()));
    }
    private void fillLoginFields(String email, String studentId, String password) {
        onView(withId(R.id.etLoginEmail)).perform(typeText(email), closeSoftKeyboard());
        onView(withId(R.id.etLoginStudentId)).perform(typeText(studentId), closeSoftKeyboard());
        onView(withId(R.id.etLoginPassword)).perform(typeText(password), closeSoftKeyboard());
    }

    @Test
    public void forgotPassword_emptyEmail_showsError() {
        onView(withId(R.id.tvForgotPassword)).perform(click());
        onView(withId(R.id.tilLoginEmail))
                .check(matches(hasTextInputLayoutErrorText("Enter your email for reset link")));
    }

    @Test
    public void forgotPassword_invalidEmail_showsError() {
        onView(withId(R.id.etLoginEmail)).perform(typeText("bademail"), closeSoftKeyboard());
        onView(withId(R.id.tvForgotPassword)).perform(click());
        onView(withId(R.id.tilLoginEmail))
                .check(matches(hasTextInputLayoutErrorText("Enter a valid email address")));
    }

    @Test
    public void register_emptyFields_showsAllValidationErrors() {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.btnParentRegister)).perform(click());

        onView(withId(R.id.tilRegName)).check(matches(hasTextInputLayoutErrorText("Please enter your name")));
        onView(withId(R.id.tilRegPhone)).check(matches(hasTextInputLayoutErrorText("Please enter phone number")));
        onView(withId(R.id.tilRegEmail)).check(matches(hasTextInputLayoutErrorText("Please enter your email")));
        onView(withId(R.id.tilRegStudentId))
                .check(matches(hasTextInputLayoutErrorText("Please enter Student Registration ID")));
        onView(withId(R.id.tilRegPassword)).check(matches(hasTextInputLayoutErrorText("Please enter password")));
    }

    @Test
    public void register_invalidName_showsError() {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.etRegName)).perform(typeText("A1"), closeSoftKeyboard());
        fillRegisterRest("03001234567", "parent@test.com", "student001", "Strong1!@");
        onView(withId(R.id.btnParentRegister)).perform(click());

        onView(withId(R.id.tilRegName))
                .check(matches(hasTextInputLayoutErrorText("Only alphabets allowed, min 3 characters")));
    }

    @Test
    public void register_invalidPhone_showsError() {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.etRegName)).perform(typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(typeText("12345"), closeSoftKeyboard());
        fillRegisterRest2("parent@test.com", "student001", "Strong1!@");
        onView(withId(R.id.btnParentRegister)).perform(click());

        onView(withId(R.id.tilRegPhone))
                .check(matches(hasTextInputLayoutErrorText("Write 11-digit number (03XXXXXXXXX)")));
    }

    @Test
    public void register_invalidEmail_showsError() {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.etRegName)).perform(typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(typeText("03001234567"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(typeText("bademail"), closeSoftKeyboard());
        onView(withId(R.id.etRegStudentId)).perform(typeText("student001"), closeSoftKeyboard());
        onView(withId(R.id.etRegPassword)).perform(typeText("Strong1!@"), closeSoftKeyboard());
        onView(withId(R.id.btnParentRegister)).perform(click());

        onView(withId(R.id.tilRegEmail)).check(matches(hasTextInputLayoutErrorText("Enter valid email")));
    }

    @Test
    public void register_invalidStudentIdFormat_showsError() {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.etRegName)).perform(typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(typeText("03001234567"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(typeText("parent@test.com"), closeSoftKeyboard());
        onView(withId(R.id.etRegStudentId)).perform(typeText("STU-1"), closeSoftKeyboard());
        onView(withId(R.id.etRegPassword)).perform(typeText("Strong1!@"), closeSoftKeyboard());
        onView(withId(R.id.btnParentRegister)).perform(click());

        onView(withId(R.id.tilRegStudentId))
                .check(matches(hasTextInputLayoutErrorText("Invalid format. Example: student001")));
    }

    @Test
    public void register_weakPassword_showsError() {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.etRegName)).perform(typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(typeText("03001234567"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(typeText("parent@test.com"), closeSoftKeyboard());
        onView(withId(R.id.etRegStudentId)).perform(typeText("student001"), closeSoftKeyboard());
        onView(withId(R.id.etRegPassword)).perform(typeText("weak"), closeSoftKeyboard());
        onView(withId(R.id.btnParentRegister)).perform(click());

        onView(withId(R.id.tilRegPassword))
                .check(matches(hasTextInputLayoutErrorText(
                        "Min 8 chars with capital, small letter, digit & special symbol")));
    }

    private void fillRegisterRest(String phone, String email, String studentId, String password) {
        onView(withId(R.id.etRegPhone)).perform(typeText(phone), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(typeText(email), closeSoftKeyboard());
        onView(withId(R.id.etRegStudentId)).perform(typeText(studentId), closeSoftKeyboard());
        onView(withId(R.id.etRegPassword)).perform(typeText(password), closeSoftKeyboard());
    }

    private void fillRegisterRest2(String email, String studentId, String password) {
        onView(withId(R.id.etRegEmail)).perform(typeText(email), closeSoftKeyboard());
        onView(withId(R.id.etRegStudentId)).perform(typeText(studentId), closeSoftKeyboard());
        onView(withId(R.id.etRegPassword)).perform(typeText(password), closeSoftKeyboard());
    }
}