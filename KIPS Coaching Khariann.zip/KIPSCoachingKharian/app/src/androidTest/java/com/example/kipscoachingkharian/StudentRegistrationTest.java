package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;
import androidx.test.uiautomator.Until;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;
import com.google.android.material.textfield.TextInputLayout;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isEnabled;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertTrue;

/**
 * Student Registration Test — StudentLoginActivity ke "Register" tab ka
 * poora flow test karta hai.
 *
 * NOTE — yeh test-file assume karti hai ke StudentLoginActivity.java mein
 * REGISTRATION_DEADLINE ko ek FUTURE date par extend kiya ja chuka hai
 * (abhi "2027-12-31 23:59" set hai), taake isRegistrationOpen() hamesha
 * true return kare aur actual field-validation + Firebase registration
 * test ho sakein.
 *
 * Poora "Register" tab flow cover karta hai:
 *   1) Login \u2194 Register tab switching.
 *   2) Subject checkboxes select karne par fee calculation.
 *   3) Empty-fields validation errors.
 *   4) Invalid name error.
 *   5) Non-Gmail email error.
 *   6) Invalid phone-number error.
 *   7) Weak-password error.
 *   8) Koi subject select na karne par button/screen state (validation
 *      block hona) verify hota hai.
 *   9) Sahi data ke sath successful registration — Firebase par naya
 *      account banta hai, aur app khud Login-view par wapis aata hai
 *      (isko UI-signal ke tor par verify kiya jata hai).
 *
 * NOTE — "Toast" (jaise "Choose at least one subject", "Registered!"
 * wagera) is Tecno/HiOS device par accessibility-tree se detect nahi
 * ho pate (OEM apna custom pop-up-style Toast render karta hai jo
 * standard Android accessibility APIs se expose nahi hota) — manual
 * testing se confirm ho chuka hai ke Toast asal mein sahi dikhta hai,
 * sirf automation isay "dekh" nahi sakta. Is liye aise cases mein
 * Toast detect karne ke bajaye, StudentLoginActivity ke asal code-path
 * se koi reliable, OEM-independent UI-state signal (button-enabled,
 * layoutLogin visible wagera) use kiya gaya hai.
 *
 * IMPORTANT — TEST 9 (validRegistration_showsSuccessToast) HAR RUN PAR
 * Firebase mein ek NAYA account banata hai (timestamp-based unique email
 * use karke, taake "email already in use" error na aaye). Agar aap
 * baar-baar yeh test nahi chalana chahtay (Firebase "Users" node mein
 * "Pending" students jama hote rahenge), to is method ko comment kar
 * dein ya @Ignore laga dein.
 *
 * IMPORTANT — jab asal session live ho jaye, REGISTRATION_DEADLINE ko
 * dobara sahi (real) date par set karna na bhoolein — warna production
 * mein registration hamesha khuli rahegi. Us waqt "registration closed"
 * scenario ke liye alag se test likha ja sakta hai (Toast-detection ka
 * OEM-limitation is scenario mein bhi laagu hoga, kyunke registerStudent()
 * sirf Toast dikha kar return karta hai — koi aur observable UI-signal
 * nahi deta).
 */
@RunWith(AndroidJUnit4.class)
public class StudentRegistrationTest {

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 1 — Login ↔ Register tab switching
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void tabToggle_switchesBetweenLoginAndRegister() {
        // Default: Login tab open hota hai
        onView(withId(R.id.layoutLogin)).check(matches(isDisplayed()));

        // Register tab par jao
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.layoutRegister)).check(matches(isDisplayed()));

        // Wapas Login tab par
        onView(withId(R.id.tabLogin)).perform(click());
        onView(withId(R.id.layoutLogin)).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 2 — Subject checkboxes select karne par fee calculation
    // (yeh submit se pehle hi UI-level calculation hai, deadline se
    // koi taluq nahi)
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void feeCalculation_updatesWhenSubjectsToggled() {
        openRegisterTab();

        // Math select karo -> Rs 3000
        onView(withId(R.id.cbRegMath)).perform(scrollTo(), click());
        onView(withId(R.id.tvRegTotalFee)).check(matches(withText("Total Fee: Rs 3000")));

        // Physics bhi select karo -> Rs 6000
        onView(withId(R.id.cbRegPhysics)).perform(scrollTo(), click());
        onView(withId(R.id.tvRegTotalFee)).check(matches(withText("Total Fee: Rs 6000")));

        // Urdu select karo (extra subject, Rs 2500) -> Rs 8500
        onView(withId(R.id.cbRegUrdu)).perform(scrollTo(), click());
        onView(withId(R.id.tvRegTotalFee)).check(matches(withText("Total Fee: Rs 8500")));

        // Math deselect karo -> Rs 5500
        onView(withId(R.id.cbRegMath)).perform(scrollTo(), click());
        onView(withId(R.id.tvRegTotalFee)).check(matches(withText("Total Fee: Rs 5500")));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 3 — Empty fields ki validation errors
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void emptyFields_showValidationErrors() {
        openRegisterTab();

        // Sab fields khaali chhor kar seedha submit karo
        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        onView(withId(R.id.tilRegName))
                .check(matches(hasTextInputLayoutErrorText("Please enter your name")));
        onView(withId(R.id.tilRegEmail))
                .check(matches(hasTextInputLayoutErrorText("Please enter your email")));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 4 — Invalid name (numbers/symbols) error
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void invalidName_showsError() {
        openRegisterTab();

        onView(withId(R.id.etRegName)).perform(scrollTo(), typeText("Ali123"), closeSoftKeyboard());
        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        onView(withId(R.id.tilRegName))
                .check(matches(hasTextInputLayoutErrorText("Only alphabets allowed")));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 5 — Non-Gmail email error
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void nonGmailEmail_showsError() {
        openRegisterTab();

        onView(withId(R.id.etRegName)).perform(scrollTo(), typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(scrollTo(), typeText("alikhan@yahoo.com"), closeSoftKeyboard());
        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        onView(withId(R.id.tilRegEmail))
                .check(matches(hasTextInputLayoutErrorText("Only Gmail address allowed (e.g. name@gmail.com)")));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 6 — Invalid phone number error (11-digit format nahi)
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void invalidPhone_showsError() {
        openRegisterTab();

        onView(withId(R.id.etRegName)).perform(scrollTo(), typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(scrollTo(), typeText("alikhan@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(scrollTo(), typeText("12345"), closeSoftKeyboard());
        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        onView(withId(R.id.tilRegPhone))
                .check(matches(hasTextInputLayoutErrorText("Write 11-digits number")));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 7 — Weak password error (8 se kam ya symbol nahi)
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void weakPassword_showsError() throws InterruptedException {
        openRegisterTab();

        onView(withId(R.id.etRegName)).perform(scrollTo(), typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(scrollTo(), typeText("alikhan@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(scrollTo(), typeText("03001234567"), closeSoftKeyboard());
        selectClass("10");
        onView(withId(R.id.etRegPassword)).perform(scrollTo(), typeText("weakpass"), closeSoftKeyboard());
        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        onView(withId(R.id.tilRegPassword))
                .check(matches(hasTextInputLayoutErrorText(
                        "Password must be atleast 8 characters including special symbol")));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 8 — Koi subject select na karne par button/screen state
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void noSubjectSelected_showsToast() throws InterruptedException {
        openRegisterTab();

        onView(withId(R.id.etRegName)).perform(scrollTo(), typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(scrollTo(), typeText("alikhan@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(scrollTo(), typeText("03001234567"), closeSoftKeyboard());
        selectClass("10");

        // DEBUG CHECK: confirm karo class dropdown se "10" waqai select ho
        // chuki hai — agar ye assertion khud fail ho, to iska matlab
        // selectClass() popup-timing ki wajah se fail ho raha hai (asal
        // masla), na ke Toast-detection.
        onView(withId(R.id.etRegClass)).check(matches(withText("10")));

        onView(withId(R.id.etRegPassword)).perform(scrollTo(), typeText("Passw0rd!"), closeSoftKeyboard());

        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        // NOTE: is device par (Tecno/HiOS — Transsion OEM) Toast Android
        // ke standard accessibility-tree ke through expose hi nahi hota
        // (custom pop-up style render karte hain), is liye UiAutomator
        // (aur Espresso) kisi bhi polling-speed par ise "dekh" nahi sakte
        // — chahe user ko wo screen par visually nazar aaye. Manual test
        // se confirm ho chuka hai ke Toast asal mein dikhta hai, sirf
        // automation is device par detect nahi kar sakta.
        //
        // Is liye yahan Toast detect karne ke bajaye, StudentLoginActivity
        // ke asal code-path se ek reliable UI-state check kiya ja raha
        // hai: "Choose at least one subject" Toast dikhne ke turant baad
        // registerStudent() seedha `return` kar deta hai — btnStudentRegister
        // ko DISABLE karna aur Firebase call, dono is check ke BAAD aate
        // hain. Matlab agar subject-check trigger hui hai, to button
        // ENABLED hi rahega aur screen Register tab par hi rahegi (koi
        // navigation/Firebase-submission nahi hua) — ye OEM se bilkul
        // independent, deterministic signal hai.
        onView(withId(R.id.btnStudentRegister))
                .check(matches(isEnabled()))
                .check(matches(isDisplayed()));
        onView(withId(R.id.layoutRegister)).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 9 — Poora sahi data ke sath registration (real Firebase account
    // banega — dekhein file ke top wala IMPORTANT note)
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void validRegistration_showsSuccessToast() throws InterruptedException {
        openRegisterTab();

        // Har run par unique email (taake "email already in use" na aaye)
        String uniqueEmail = "kipstest" + System.currentTimeMillis() + "@gmail.com";

        onView(withId(R.id.etRegName)).perform(scrollTo(), typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(scrollTo(), typeText(uniqueEmail), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(scrollTo(), typeText("03001234567"), closeSoftKeyboard());
        selectClass("10");
        onView(withId(R.id.etRegPassword)).perform(scrollTo(), typeText("Passw0rd!"), closeSoftKeyboard());
        onView(withId(R.id.cbRegMath)).perform(scrollTo(), click());
        onView(withId(R.id.cbRegEnglish)).perform(scrollTo(), click());

        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        // NOTE: is device par Toast ("Registered! Verification link
        // sent...") accessibility-tree se detect nahi ho pata (OEM
        // limitation — dekhein noSubjectSelected_showsToast ka comment).
        // Is liye StudentLoginActivity ke asal success-path se ek
        // reliable, OEM-independent UI-signal use kar rahe hain:
        // registration + Firebase-write + verification-email — teeno
        // successful hone ke baad code khud showLoginView() call karta
        // hai, jo layoutLogin ko VISIBLE aur layoutRegister ko GONE kar
        // deta hai. Chunke ye poora flow Firebase se async network calls
        // (createUser + database write + email-send) par depend karta
        // hai jinka waqt network-speed ke hisab se badal sakta hai, fixed
        // Thread.sleep() ke bajaye yahan poll kiya ja raha hai.
        waitUntilLoginViewShown(15000);

        onView(withId(R.id.layoutLogin)).check(matches(isDisplayed()));
    }

    /**
     * Poll karta hai jab tak "layoutLogin" VISIBLE na ho jaye (matlab
     * registration ka poora Firebase-flow successful complete ho chuka
     * hai aur app khud Login-view par wapis aa gaya hai), ya timeout ho
     * jaye.
     */
    private void waitUntilLoginViewShown(long timeoutMillis) throws InterruptedException {
        long deadline = System.currentTimeMillis() + timeoutMillis;
        while (System.currentTimeMillis() < deadline) {
            try {
                onView(withId(R.id.layoutLogin)).check(matches(isDisplayed()));
                return; // mil gaya — layoutLogin visible ho chuka hai
            } catch (Throwable notYetVisible) {
                Thread.sleep(300);
            }
        }
        // Aakhri koshish — agar ab bhi visible nahi hai to yehi exception
        // throw hone dein taake asal failure-reason (assertion) test-report
        // mein saaf dikhe.
        onView(withId(R.id.layoutLogin)).check(matches(isDisplayed()));
    }

    // ── Register tab kholne ka shared helper ─────────────────────────────────
    private void openRegisterTab() {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.layoutRegister)).check(matches(isDisplayed()));
    }

    // ── Class dropdown (Exposed Dropdown Menu) se class select karne ka helper ─
    // NOTE: etRegClass ka inputType=0 hai (sirf dropdown-select field hai,
    // typeText() accept nahi karta — "has-input-connection=false" error deta
    // hai). Is liye click() se popup kholna zaroori hai. Pehli koshish mein
    // fixed Thread.sleep(800) use hua tha jo popup ke slow/fast khulne ki
    // wajah se flaky tha (race condition — kabhi popup time par nahi khulta
    // tha). Ab UiAutomator ka poll-based wait use kiya hai (fixed time ka
    // andaza lagane ke bajaye jab tak popup-item asal mein screen par na aa
    // jaye, tab tak wait karta hai) — ye Toast-detection wale approach jaisa
    // hi hai aur zyada reliable hai.
    private void selectClass(String className) {
        onView(withId(R.id.etRegClass)).perform(scrollTo(), click());

        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        boolean popupItemFound = device.wait(
                Until.hasObject(By.text(className)), 5000);
        assertTrue("Class dropdown se \"" + className + "\" wala option 5 second mein nahi mila — popup nahi khula ya bohot slow hai",
                popupItemFound);

        UiObject2 item = device.findObject(By.text(className));
        assertTrue("Popup mein \"" + className + "\" wala item mila to sahi, lekin click ke liye null nikla",
                item != null);
        item.click();

        // Popup band hone aur field mein value set hone ka thora wait
        device.waitForIdle(1000);
    }

    /**
     * TextInputLayout (til...) ka error-text match karne ke liye custom
     * matcher. Espresso ka built-in hasErrorText() sirf plain EditText par
     * kaam karta hai — hamari fields TextInputLayout ke andar hain aur
     * error TextInputLayout.setError() se set hota hai, is liye
     * hasErrorText() "doesn't match the selected view" de kar fail ho
     * jata tha. Ab onView(withId(R.id.tilRegName)) ke sath yeh matcher
     * use karo, TextInputEditText ke sath nahi.
     */
    private static Matcher<View> hasTextInputLayoutErrorText(final String expectedError) {
        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("TextInputLayout with error text: " + expectedError);
            }

            @Override
            protected boolean matchesSafely(View view) {
                if (!(view instanceof TextInputLayout)) {
                    return false;
                }
                CharSequence error = ((TextInputLayout) view).getError();
                return error != null && expectedError.contentEquals(error);
            }
        };
    }
}