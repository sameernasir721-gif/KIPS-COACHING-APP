package com.example.kipscoachingkharian;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

/**
 * Class Schedule Flow Test — Login karne ke baad Dashboard se
 * "Class Schedule" card (cardClassSchedule) kholta hai, aur verify
 * karta hai ke screen crash ke bina load ho jaati hai — chahe koi
 * timetable PDF admin ki taraf se upload ho ya na ho.
 * IMPORTANT — ClassScheduleActivity.java mein pehle "tvTimetableStatus"
 * ek dusri layout se galat bind ho raha tha (dead code, "no timetable"
 * message student ko kabhi nahi dikhta tha). Ye fix ho chuka hai —
 * status TextView ab activity_class_schedule.xml mein maujood hai aur
 * sahi tarah bind hoti hai.
 * NOTE: "VIEW" aur "DOWNLOAD" buttons is test mein click NAHI kiye
 * jaate — VIEW asal PDF viewer app (external intent) open kar deta
 * hai, aur DOWNLOAD asal DownloadManager se file download start kar
 * deta hai. Sirf inki visibility verify ki gayi hai.
 * IMPORTANT: Neeche apni asal test-student ki details daalein.
 */
@RunWith(AndroidJUnit4.class)
public class ClassScheduleFlowTest {

    // ── Yahan apni test-student ki details daalein ─────────────────────────
    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void openClassSchedule_directFromDashboard_timetableLoads() throws InterruptedException {

        // ── Step 1-6: Poora Login Flow ──────────────────────────────────────
        onView(withId(R.id.etStudentUsername))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));

        // Dashboard ke activity-transition animation ko settle hone ka
        // thora waqt dein — warna "cardClassSchedule" par click Espresso
        // ke 90%-visible-area constraint ki wajah se fail ho sakta hai.
        Thread.sleep(600);

        // ── Step 7: Dashboard se "Class Schedule" card dabayen (direct) ──────
        onView(withId(R.id.cardClassSchedule)).perform(click());

        // Class Schedule screen load hone ka wait (Firebase se Users +
        // Announcements fetch hoti hai)
        Thread.sleep(3000);

        // ── Step 8: Header/student-info section verify karein ────────────────
        onView(withId(R.id.tvStudentInfo)).check(matches(isDisplayed()));

        // ── Step 9: Timetable section verify karein — "layoutPdfActions"
        // ki visibility se pata chalta hai timetable upload hui hai ya nahi.
        // Dono soorat mein screen crash nahi honi chahiye. ────────────────
        boolean pdfActionsVisible = isViewDisplayed(R.id.layoutPdfActions);

        if (pdfActionsVisible) {
            // Timetable mojood hai — VIEW/DOWNLOAD buttons visible hone
            // chahiye (click nahi karte — file-level NOTE dekhein)
            onView(withId(R.id.btnViewTimetablePdf)).check(matches(isDisplayed()));
            onView(withId(R.id.btnShareTimetablePdf)).check(matches(isDisplayed()));
        } else {
            // Koi timetable mojood nahi — status message ab visible hona
            // chahiye ("No timetable has been uploaded yet.")
            onView(withId(R.id.tvTimetableStatus)).check(matches(isDisplayed()));
        }
    }

    /**
     * Helper — check karta hai ke di gayi ID wala view is waqt VISIBLE hai
     * ya nahi (GONE/hidden ho to false return karega).
     */
    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }
}
