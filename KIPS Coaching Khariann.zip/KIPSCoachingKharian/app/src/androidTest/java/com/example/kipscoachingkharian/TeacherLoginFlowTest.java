package com.example.kipscoachingkharian;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

/**
 * Teacher Login Flow — StudentLoginFlowTest jaisa hi, lekin Teacher
 * ke liye. Teacher login mein "I've Verified" wala step nahi hota
 * (yeh sirf Student side pe hai) — seedha email + password se login
 * ho jata hai.
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daal dein.
 */
@RunWith(AndroidJUnit4.class)
public class TeacherLoginFlowTest {

    // ── Yahan apni test-teacher ki details daalein ──────────────────────────
    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    @Test
    public void fullLoginFlow_navigatesToDashboard() throws InterruptedException {

        // Step 1 — Login screen par hain yeh confirm karein
        onView(withId(R.id.etTeacherId))
                .check(matches(isDisplayed()));

        // Step 2 — Email type karein
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        // Step 3 — Password type karein
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        // Step 4 — Login button dabayen
        onView(withId(R.id.btnTeacherLogin))
                .perform(click());

        // Step 5 — Login + Dashboard-load ke liye wait
        Thread.sleep(10000);

        // Step 6 — Verify karein ke Dashboard khul chuki hai
        onView(withId(R.id.tvTeacherName))
                .check(matches(isDisplayed()));
    }
}