package com.example.kipscoachingkharian;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertTrue;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

/**
 * Study Material Flow Test — Login karne ke baad Dashboard se "Study
 * Material" card kholta hai (bina kisi subject-filter ke, direct), aur
 * verify karta hai ke poori material-list (sab subjects) load ho gayi
 * hai. Phir Search-box test karta hai.
 *
 * IMPORTANT: Neeche apni asal test-student ki details daalein.
 */
@RunWith(AndroidJUnit4.class)
public class StudyMaterialFlowTest {

    // ── Yahan apni test-student ki details daalein ─────────────────────────
    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void openStudyMaterial_directFromDashboard_searchWorks() throws InterruptedException {

        // ── Step 1-6: Poora Login Flow ──────────────────────────────────────
        onView(withId(R.id.etStudentUsername))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));

        // ── Step 7: Dashboard se "Study Material" card dabayen (direct) ─────
        onView(withId(R.id.cardStudyMaterial)).perform(click());

        // Study Material screen load hone ka wait (Firebase se
        // SharedStudyMaterials fetch hoti hai — is dafa BINA kisi
        // subject-filter ke, sab subjects ki material aani chahiye)
        Thread.sleep(3000);

        // ── Step 8: Verify karein ke list screen khul gayi hai ──────────────
        onView(withId(R.id.rvStudyMaterial))
                .check(matches(isDisplayed()));

        // ── Step 9: Subject-filter chips dikh rahe hain yeh confirm karein ──
        // (NOTE: chipAll/chipPdf/chipImage type-filters is layout-version
        // mein maujood nahi hain, isliye unhe test nahi kiya ja raha —
        // sirf subject-chips container test kiya ja raha hai)
        onView(withId(R.id.containerSubjectChips))
                .check(matches(isDisplayed()));

        // ── Step 10: Search-box mein kuch type karke search test karein ─────
        onView(withId(R.id.etSearch))
                .perform(typeText("chapter"), closeSoftKeyboard());

        Thread.sleep(1000);

        // ── Step 11: Screen abhi bhi stable honi chahiye (crash na ho
        // search use karne par). NOTE: agar "chapter" se koi material
        // match nahi karta to app jaan-boojh kar rvStudyMaterial ko GONE
        // kar deta hai aur layoutEmpty dikhata hai (StudyMaterialActivity
        // ke updateEmptyState() ka intended behavior) — isliye yahan
        // strict isDisplayed() check nahi, balke sirf ye verify kar rahe
        // hain ke ek in-hierarchy state (list ya empty-view) exist karti
        // hai, matlab app crash nahi hua.
        boolean listVisible = isViewDisplayed(R.id.rvStudyMaterial);
        boolean emptyVisible = isViewDisplayed(R.id.layoutEmpty);
        assertTrue("Na to list na hi empty-state dikh rahi — screen crash/broken lagti hai",
                listVisible || emptyVisible);
    }

    /**
     * Helper — check karta hai ke di gayi ID wala view is waqt VISIBLE hai
     * ya nahi (GONE/hidden ho to false return karega).
     */
    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }
}