package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.doesNotExist;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import android.content.Context;
import android.content.Intent;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;

import com.example.kipscoachingkharian.dashboard.ParentFeeActivity;

import org.junit.After;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ParentFeeActivityTest {

    private ActivityScenario<ParentFeeActivity> scenario;

    private static final String STUDENT_ID = "student048";
    private static final String STUDENT_NAME = "Haleema";

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    // Har 200ms mein poll karta hai — Toast reliably pakadne ke liye
    private UiObject2 pollForText(UiDevice device, String text, long timeoutMs) {
        UiObject2 obj = null;
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            obj = device.findObject(By.textContains(text));
            if (obj != null) break;
            try { Thread.sleep(200); } catch (InterruptedException ignored) {}
        }
        return obj;
    }

    private void launch(String studentId) {
        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentFeeActivity.class);
        if (studentId != null) intent.putExtra("STUDENT_ID", studentId);
        scenario = ActivityScenario.launch(intent);
        sleep(6000); // Firebase se child + fee data load hone ka time
    }

    @After
    public void tearDown() {
        if (scenario != null) {
            scenario.close();
        }
    }

    // ═══════════════════════════════════════════════════════════
    // #1 — Student ID missing → error Toast
    // ═══════════════════════════════════════════════════════════
    @Ignore
    @Test
    public void missingStudentId_showsErrorToast() {
        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());

        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentFeeActivity.class);
        scenario = ActivityScenario.launch(intent);

        UiObject2 toast = pollForText(device, "Student ID not provided", 10000);
        assertNotNull("Error Toast not found", toast);
    }

    // ═══════════════════════════════════════════════════════════
    // #2 — Back button
    // ═══════════════════════════════════════════════════════════
    @Test
    public void backButton_click_finishesActivity() {
        launch(STUDENT_ID);

        onView(withId(R.id.ivBack)).perform(click());
        sleep(1000);

        assertEquals(Lifecycle.State.DESTROYED, scenario.getState());
    }

    // ═══════════════════════════════════════════════════════════
    // #3 — Home tab click → Dashboard, ye Activity band ho
    // ═══════════════════════════════════════════════════════════
    @Test
    public void homeTab_click_navigatesToDashboard() {
        launch(STUDENT_ID);

        onView(withId(R.id.llHomeTab)).perform(click());
        sleep(1000);

        assertEquals(Lifecycle.State.DESTROYED, scenario.getState());
    }

    // ═══════════════════════════════════════════════════════════
    // #4 — Profile tab click → Profile khule
    // ═══════════════════════════════════════════════════════════
    @Test
    public void profileTab_click_navigatesToProfile() {
        launch(STUDENT_ID);

        onView(withId(R.id.llProfileTab)).perform(click());
        sleep(2000);

        onView(withId(R.id.tvChildName)).check(doesNotExist());
    }

    // ═══════════════════════════════════════════════════════════
    // #5 — Real data se Name/Info load ho
    // ═══════════════════════════════════════════════════════════
    @Test
    public void validStudent_showsChildNameAndInfo() {
        launch(STUDENT_ID);

        onView(withId(R.id.tvChildName)).check(matches(withText(STUDENT_NAME)));
        onView(withId(R.id.tvChildInfo)).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════
    // #6 — Fee history render ho
    // ═══════════════════════════════════════════════════════════
    @Test
    public void validStudent_showsFeeHistory() {
        launch(STUDENT_ID);

        scenario.onActivity(activity -> {
            android.widget.LinearLayout container = activity.findViewById(R.id.feeContainer);
            org.junit.Assert.assertTrue("Fee history render nahi hui",
                    container.getChildCount() > 0);
        });
    }

    // ═══════════════════════════════════════════════════════════
    // #7 — Data load hone se pehle Pay Now click → Loading Toast
    // ═══════════════════════════════════════════════════════════
    @Ignore
    @Test
    public void payNowButton_beforeDataLoads_showsLoadingToast() {
        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());

        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentFeeActivity.class);
        intent.putExtra("STUDENT_ID", STUDENT_ID);
        scenario = ActivityScenario.launch(intent);

        // Turant click karo, Firebase fetch complete hone se pehle
        onView(withId(R.id.btnPayNow)).perform(click());

        UiObject2 toast = pollForText(device, "Fee data is Loading", 8000);
        assertNotNull("Loading Toast not found", toast);
    }

    // ═══════════════════════════════════════════════════════════
    // #8 — Due amount pending ho to Pay Now → PaymentActivity
    // ═══════════════════════════════════════════════════════════
    @Ignore
    @Test
    public void payNowButton_withDuesPending_navigatesToPayment() {
        launch(STUDENT_ID);

        onView(withId(R.id.btnPayNow)).perform(click());
        sleep(2000);

        onView(withId(R.id.tvChildName)).check(doesNotExist());
    }

    // ═══════════════════════════════════════════════════════════
    // #9 — View Challan button → ParentFeeChallanActivity
    // ═══════════════════════════════════════════════════════════
    @Test
    public void viewChallanButton_navigatesToChallanActivity() {
        launch(STUDENT_ID);

        onView(withId(R.id.btnViewChallan)).perform(click());
        sleep(2000);

        onView(withId(R.id.tvChildName)).check(doesNotExist());
    }
}