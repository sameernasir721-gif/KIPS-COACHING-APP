package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isDialog;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

/**
 * Profile Section — Full "View Only" Test.
 *
 * Yeh test Profile section ke HAR item ko khol kar verify karta hai ke
 * screen sahi khulti hai — lekin KUCH BHI CHANGE NAHI KARTA (na koi
 * field edit hoti hai, na koi setting change hoti hai, na asal logout
 * hota hai). Sirf navigation + display verify hota hai, phir wapas aa
 * jate hain.
 *
 * Cover kiya gaya:
 *   1. My Profile      — screen khulti hai, fields (Name/Email/Phone/
 *                         Subject) visible hain — "Edit" button ko
 *                         CHOOO nahi karte
 *   2. Notifications    — Announcements screen khulti hai (view only)
 *   3. Settings         — Font Size / Theme / Privacy — teeno dialogs
 *                         khol kar sirf verify karte hain, koi option
 *                         select NAHI karte
 *   4. Help             — FAQ screen khulti hai
 *   5. Logout           — dialog khulta hai, "Cancel" dabate hain
 *                         (asal logout NAHI hota)
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daal dein.
 */
@RunWith(AndroidJUnit4.class)
public class TeacherProfileSettingsTest {

    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    public static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility check.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(500);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    // Profile menu ke item par click, destination verify, wapas aana.
    private void openItemAndBack(int itemId, int destinationVerifyId, int waitMs)
            throws InterruptedException {
        onView(withId(itemId)).perform(click());
        Thread.sleep(waitMs);
        onView(withId(destinationVerifyId)).check(matches(isDisplayed()));
        Espresso.pressBack();
        Thread.sleep(1200);
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
    }

    // Settings ke andar ek dialog-based item khol kar verify, dismiss karna
    // (koi option select nahi karte).
    private void openDialogItemAndDismiss(int itemId, String dialogTitle) throws InterruptedException {
        onView(withId(itemId)).perform(click());
        Thread.sleep(700);
        onView(withText(dialogTitle)).inRoot(isDialog()).check(matches(isDisplayed()));
        Espresso.pressBack();
        Thread.sleep(500);
    }

    @Test
    public void viewAllProfileSectionItems() throws InterruptedException {

        // ── Login ─────────────────────────────────────────────────────────
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());
        waitForDashboard(20);

        // ── Bottom nav se "Profile" tab kholein ──────────────────────────────
        Espresso.closeSoftKeyboard();
        onView(withId(R.id.nav_bottom_profile)).perform(forceClick());
        Thread.sleep(1500);
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));

        // ═══════════════ 1. MY PROFILE (view only — Edit ko touch nahi karte) ═
        System.out.println("➡️ My Profile khol rahe hain (view only)...");
        onView(withId(R.id.item_my_profile)).perform(click());
        Thread.sleep(1500);
        onView(withId(R.id.etName)).check(matches(isDisplayed()));
        onView(withId(R.id.etEmail)).check(matches(isDisplayed()));
        onView(withId(R.id.etPhone)).check(matches(isDisplayed()));
        onView(withId(R.id.etSubject)).check(matches(isDisplayed()));
        Espresso.pressBack();
        Thread.sleep(1200);
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));

        // ═══════════════ 2. NOTIFICATIONS ═══════════════
        System.out.println("➡️ Notifications khol rahe hain...");
        openItemAndBack(R.id.item_notifications, R.id.containerAnnouncements, 1500);

        // ═══════════════ 3. SETTINGS — Font Size / Theme / Privacy ═══════════
        System.out.println("➡️ Settings khol rahe hain...");
        onView(withId(R.id.item_settings)).perform(click());
        Thread.sleep(1500);
        onView(withId(R.id.itemFontSize)).check(matches(isDisplayed()));

        System.out.println("➡️ Font Size dialog check kar rahe hain...");
        openDialogItemAndDismiss(R.id.itemFontSize, "Font Size");

        System.out.println("➡️ Theme dialog check kar rahe hain...");
        openDialogItemAndDismiss(R.id.itemTheme, "Theme");

        System.out.println("➡️ Privacy dialog check kar rahe hain...");
        openDialogItemAndDismiss(R.id.itemPrivacy, "Privacy");

        Espresso.pressBack(); // ProfileMenuActivity par wapas
        Thread.sleep(1200);
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));

        // ═══════════════ 4. HELP ═══════════════
        System.out.println("➡️ Help khol rahe hain...");
        openItemAndBack(R.id.item_help, R.id.layoutFaqContainer, 1500);

        // ═══════════════ 5. LOGOUT (dialog verify only, Cancel dabate hain) ══
        System.out.println("➡️ Logout dialog check kar rahe hain...");
        onView(withId(R.id.item_logout)).perform(click());
        Thread.sleep(700);
        onView(withText("Cancel")).inRoot(isDialog()).perform(click());
        Thread.sleep(500);

        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
        System.out.println("✅ Poora Profile section (view-only) test pass ho gaya!");
    }
}