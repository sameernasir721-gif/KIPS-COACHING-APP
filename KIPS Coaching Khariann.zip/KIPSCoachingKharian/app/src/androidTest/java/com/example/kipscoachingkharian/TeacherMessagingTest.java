package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.Matchers.containsString;

import android.Manifest;
import android.view.View;

import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.GrantPermissionRule;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Messaging Test — Teacher login karke Message (bottom nav) kholta hai,
 * "+" (fabNewChat) dabata hai, pehle parent ko select karta hai, ek
 * unique message type kar ke Send karta hai, aur verify karta hai ke
 * message chat mein nazar aa raha hai.
 *
 * ZAROORI SHART (test data): Kam az kam EK parent/student maujood ho
 * jinke sath teacher chat start kar sake (ParentPickerActivity ki list
 * khali nahi honi chahiye).
 *
 * FIX: "POST_NOTIFICATIONS" permission GrantPermissionRule se pre-grant
 * kar dete hain, taake Android ka "Allow notifications?" system popup
 * login ke turant baad na aaye — yeh popup screen ke bottom nav ko dhak
 * kar clicks fail kara raha tha. (Android 12 aur us se purane par yeh
 * permission exist hi nahi karti, GrantPermissionRule khud handle kar
 * leta hai.)
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daal dein.
 */
@RunWith(AndroidJUnit4.class)
public class TeacherMessagingTest {

    // ── Yahan apni test-teacher ki details daalein ─────────────────────────
    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    @Rule
    public GrantPermissionRule permissionRule =
            GrantPermissionRule.grant(Manifest.permission.POST_NOTIFICATIONS);

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    // Espresso ki 90%-visibility check ko bypass kar ke DIRECT click karta
    // hai — jab hum confirm kar chuke hon ke view visually theek hai lekin
    // Espresso ka strict visibility heuristic (kabhi kabhi animation/inset
    // ki wajah se) galat fail de raha ho.
    public static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility check.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    // Login ke baad Dashboard load hone ka smart wait
    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(1000);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    @Test
    public void sendMessage_verifyInChat() throws InterruptedException {

        String uniqueMessage = "Test message "
                + new SimpleDateFormat("dd-MMM HH:mm:ss", Locale.getDefault())
                .format(Calendar.getInstance().getTime());

        // ── Step 1: Login ──────────────────────────────────────────────────
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(25);

        // ── Step 2: Bottom nav se "Message" tab dabayen ──────────────────────
        androidx.test.espresso.Espresso.closeSoftKeyboard();
        Thread.sleep(500);
        onView(withId(R.id.nav_bottom_Message)).perform(forceClick());
        Thread.sleep(2000); // Conversations list load hone ka wait

        // ── Step 3: "+" (New Chat) button dabayen ────────────────────────────
        onView(withId(R.id.fabNewChat)).perform(click());
        Thread.sleep(2000); // Parent picker list load hone ka wait

        // ── Step 4: Search karein (list sirf type karne ke baad load hoti hai) ─
        onView(withId(R.id.etSearch)).perform(typeText("a"), closeSoftKeyboard());
        Thread.sleep(1500); // Search results load hone ka wait

        // ── Step 5: Pehle parent ko select karein ────────────────────────────
        onView(withId(R.id.rvParents)).perform(
                RecyclerViewActions.actionOnItemAtPosition(0, click()));
        Thread.sleep(2000); // Chat screen load hone ka wait

        // ── Step 6: Message likhein ────────────────────────────────────────
        onView(withId(R.id.etMessage))
                .perform(typeText(uniqueMessage), closeSoftKeyboard());

        // ── Step 7: Send button dabayen ───────────────────────────────────────
        onView(withId(R.id.btnSend)).perform(click());

        Thread.sleep(3000); // Firebase par message save hone ka wait

        // ── Step 8: Verify — message chat mein nazar aana chahiye ────────────
        onView(withId(R.id.rvMessages))
                .check(matches(hasDescendant(withText_containsString(uniqueMessage))));
    }

    // Helper: withText(containsString(...)) likhne ka chota tareeqa
    private static Matcher<View> withText_containsString(String text) {
        return ViewMatchers.withText(containsString(text));
    }
}