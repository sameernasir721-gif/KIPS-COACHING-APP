package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.assertion.ViewAssertions.doesNotExist;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertEquals;

import android.content.Context;
import android.content.Intent;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.dashboard.ParentProfileActivity;
import com.google.firebase.auth.FirebaseAuth;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ParentProfileActivityTest {

    private ActivityScenario<ParentProfileActivity> scenario;

    private static final String TEST_EMAIL = "ama319709@gmail.com";
    private static final String TEST_PASSWORD = "Student048#";
    private static final String STUDENT_ID = "student048";

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    private void loginAndLaunch() {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(TEST_EMAIL, TEST_PASSWORD);
        sleep(5000);

        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentProfileActivity.class);
        intent.putExtra("STUDENT_ID", STUDENT_ID);
        scenario = ActivityScenario.launch(intent);

        sleep(5000); // Firebase se profile load hone ka time
    }

    @After
    public void tearDown() {
        if (scenario != null) {
            scenario.close();
        }
    }

    // ═══════════════════════════════════════════════════════════
    // #1 — Profile Firebase se load ho
    // ═══════════════════════════════════════════════════════════
    @Test
    public void profileLoadsFromFirebase_showsNameAndRole() {
        loginAndLaunch();

        onView(withId(R.id.tv_name)).check(matches(withText("Ahad Ali")));
        onView(withId(R.id.tv_role)).check(matches(withText("Parent")));
    }

    // ═══════════════════════════════════════════════════════════
    // #2 — My Profile click
    // ═══════════════════════════════════════════════════════════
    @Test
    public void myProfileClick_navigatesToInfoDetails() {
        loginAndLaunch();

        onView(withId(R.id.item_my_profile)).perform(scrollTo(), click());
        sleep(2000);

        onView(withId(R.id.item_my_profile)).check(doesNotExist());
    }

    // ═══════════════════════════════════════════════════════════
    // #3 — Settings click
    // ═══════════════════════════════════════════════════════════
    @Test
    public void settingsClick_navigatesToSettings() {
        loginAndLaunch();

        onView(withId(R.id.item_settings)).perform(scrollTo(), click());
        sleep(2000);

        onView(withId(R.id.item_settings)).check(doesNotExist());
    }

    // ═══════════════════════════════════════════════════════════
    // #4 — Help click
    // ═══════════════════════════════════════════════════════════
    @Test
    public void helpClick_navigatesToHelp() {
        loginAndLaunch();

        onView(withId(R.id.item_help)).perform(scrollTo(), click());
        sleep(2000);

        onView(withId(R.id.item_help)).check(doesNotExist());
    }

    // ═══════════════════════════════════════════════════════════
    // #5 — Notifications click → Announcements
    // ═══════════════════════════════════════════════════════════
    @Test
    public void notificationsClick_navigatesToAnnouncements() {
        loginAndLaunch();

        onView(withId(R.id.item_notifications)).perform(scrollTo(), click());
        sleep(2000);

        onView(withId(R.id.item_notifications)).check(doesNotExist());
    }

    // ═══════════════════════════════════════════════════════════
    // #6 — Logout click → confirmation dialog
    // ═══════════════════════════════════════════════════════════
    @Test
    public void logoutClick_showsConfirmationDialog() {
        loginAndLaunch();

        onView(withId(R.id.item_logout)).perform(scrollTo(), click());
        sleep(1000);

        onView(withText("Logout")).check(matches(isDisplayed()));
        onView(withText("Are you sure you want to log out?")).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════
    // #7 — "No" dabane se logout na ho
    // ═══════════════════════════════════════════════════════════
    @Test
    public void logoutDialog_no_dismissesWithoutLoggingOut() {
        loginAndLaunch();

        onView(withId(R.id.item_logout)).perform(scrollTo(), click());
        sleep(1000);
        onView(withText("No")).perform(click());
        sleep(1000);

        // Activity abhi bhi zinda honi chahiye, current user bhi login hi rahega
        onView(withId(R.id.item_logout)).check(matches(isDisplayed()));
        org.junit.Assert.assertNotNull(FirebaseAuth.getInstance().getCurrentUser());
    }

    // ═══════════════════════════════════════════════════════════
    // #8 — "Yes, Logout" → sign-out + Login screen

    @Test
    public void logoutDialog_yesLogout_navigatesToLoginAndSignsOut() {
        loginAndLaunch();

        onView(withId(R.id.item_logout)).perform(scrollTo(), click());
        sleep(1000);
        onView(withText("Yes, Logout")).perform(click());
        sleep(2000);

        org.junit.Assert.assertNull(FirebaseAuth.getInstance().getCurrentUser());
        assertEquals(Lifecycle.State.DESTROYED, scenario.getState());
    }
}