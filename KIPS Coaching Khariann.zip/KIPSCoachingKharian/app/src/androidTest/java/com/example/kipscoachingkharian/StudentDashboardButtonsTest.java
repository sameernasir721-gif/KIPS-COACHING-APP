package com.example.kipscoachingkharian;

import android.view.View;
import android.view.ViewGroup;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.Espresso.pressBack;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

/**
 * Student Dashboard Buttons Test — StudentDashboardActivity ke saare
 * clickable elements test karta hai:
 *   1) 8 grid cards (Subjects, Class Schedule, Study Material, Quizzes,
 *      Assignments, Progress Report, Fees, Announcements) — har card
 *      apni correct target Activity par navigate karta hai ya nahi.
 *   2) Bottom-nav "Feedback" aur "Profile" tabs.
 *   3) Menu icon (ivMenu) — navigation drawer open karta hai.
 *   4) "Upcoming Schedule" section ke 3 dynamic cards — Live Class,
 *      Upcoming Quiz, Assignment — chahe data ho ya na ho ("No Upcoming
 *      Class" / "No Upcoming Quiz" / "No Upcoming Assignment" state mein
 *      bhi), click hamesha sahi Activity kholta hai.
 *
 * IMPORTANT — poori dashboard screen ek ScrollView ke andar hai (grid
 * cards aur upcoming-schedule section neeche ki taraf hain), is liye
 * har jagah scrollTo() use kiya gaya hai.
 *
 * IMPORTANT — grid cards aur bottomNav ke items par Espresso ka normal
 * click() "<90% visible" wala PerformException de sakta hai (jaisa
 * FeedbackFlowTest mein dekha gaya — layout/system-nav-bar occlusion
 * ke wajah se, keyboard ka masla nahi). Isliye forceClick() custom
 * action use kiya hai jo seedha view.performClick() call karta hai
 * (StudentProgressTest.java jaisa hi established pattern).
 *
 * IMPORTANT — Upcoming Schedule ke cards (Live Class/Quiz/Assignment)
 * programmatically bante hain, koi fixed resource-id nahi hota. Unka
 * click listener hamesha container ke pehle (aur sirf) child CardView
 * par lagta hai — chahe data ho ("Live Class" + subject) ya na ho
 * ("No Upcoming Class"). Isliye clickFirstChildOf() custom action se
 * container ke andar ka pehla child dhoond kar click karte hain — yeh
 * dynamic text content se independent, reliable tareeqa hai.
 *
 * IMPORTANT: Neeche apni asal test-student ki details daalein.
 */
@RunWith(AndroidJUnit4.class)
public class StudentDashboardButtonsTest {

    // ── Yahan apni test-student ki details daalein ─────────────────────────
    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 1 — 8 grid cards, ek hi flow mein (koi card dashboard finish()
    // nahi karta, is liye pressBack() se wapas dashboard par aa jaate hain)
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void gridCards_eachNavigatesToCorrectScreen() throws InterruptedException {
        login();

        // Subjects
        clickDashboardCard(R.id.cardSubjects);
        onView(withId(R.id.toggleLayout)).check(matches(isDisplayed()));
        backToDashboard();

        // Class Schedule
        clickDashboardCard(R.id.cardClassSchedule);
        onView(withId(R.id.tvStudentInfo))
                .check(matches(isDisplayed()));
        backToDashboard();

        // Study Material
        clickDashboardCard(R.id.cardStudyMaterial);
        onView(withId(R.id.rvStudyMaterial)).check(matches(isDisplayed()));
        backToDashboard();

        // Quizzes
        clickDashboardCard(R.id.cardQuizzes);
        onView(withId(R.id.layoutQuizCards)).check(matches(isDisplayed()));
        backToDashboard();

        // Assignments
        clickDashboardCard(R.id.cardAssignments);
        onView(withId(R.id.rvAssignments)).check(matches(isDisplayed()));
        backToDashboard();

        // Progress Report
        clickDashboardCard(R.id.cardReports);
        onView(withId(R.id.chipProgress)).check(matches(isDisplayed()));
        backToDashboard();

        // Fees
        clickDashboardCard(R.id.cardFees);
        onView(withId(R.id.feeContainer)).check(matches(isDisplayed()));
        backToDashboard();

        // Announcements
        clickDashboardCard(R.id.cardAnnouncements);
        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));
        backToDashboard();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 2 — Menu icon (drawer)
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void menuIcon_opensNavigationDrawer() throws InterruptedException {
        login();

        onView(withId(R.id.ivMenu)).perform(forceClick());
        Thread.sleep(500); // Drawer-open animation ka wait

        onView(withId(R.id.navigationView)).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 3 — Bottom-nav "Feedback" tab (yeh dashboard ko finish() karta
    // hai, is liye alag test — koi back-navigation dependency nahi)
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void bottomNav_feedback_navigatesToFeedbackScreen() throws InterruptedException {
        login();

        onView(withId(R.id.nav_bottom_feedback)).perform(forceClick());
        Thread.sleep(2500); // FeedbackActivity load + Firebase fetch ka wait

        onView(withId(R.id.layoutSubmitFeedback)).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 4 — Bottom-nav "Profile" tab
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void bottomNav_profile_navigatesToProfileScreen() throws InterruptedException {
        login();

        onView(withId(R.id.nav_bottom_profile)).perform(forceClick());
        Thread.sleep(2000); // ProfileActivity load ka wait

        onView(withId(R.id.tv_name)).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 5 — Bottom-nav "Home" tab (already dashboard par hain — crash
    // ke bina reselect hona chahiye, screen change nahi honi chahiye)
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void bottomNav_home_staysOnDashboard() throws InterruptedException {
        login();

        onView(withId(R.id.nav_bottom_home)).perform(forceClick());
        Thread.sleep(500);

        onView(withId(R.id.tvStudentName)).check(matches(isDisplayed()));
        onView(withId(R.id.bottomNav)).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 6 — "Upcoming Schedule" ke 3 dynamic cards (Live Class, Quiz,
    // Assignment). Yeh cards dashboard finish() nahi karte, is liye ek hi
    // flow mein sab test karke pressBack() se wapas aate hain.
    // ═══════════════════════════════════════════════════════════════════════
    @Test
    public void upcomingScheduleCards_eachNavigatesToCorrectScreen() throws InterruptedException {
        login();
        // Firebase se upcoming-schedule (classes/quizzes/assignments) load
        // hone ka extra wait — cards dynamically bante hain
        Thread.sleep(2000);

        // Live Class card → AttendanceActivity
        onView(withId(R.id.containerUpcomingClasses))
                .perform(scrollTo(), clickFirstChildOf());
        Thread.sleep(1500);
        onView(withId(R.id.containerHistory)).check(matches(isDisplayed()));
        backToDashboard();
        Thread.sleep(500);

        // Upcoming Quiz card → QuizActivity
        onView(withId(R.id.containerUpcomingQuizzes))
                .perform(scrollTo(), clickFirstChildOf());
        Thread.sleep(1500);
        onView(withId(R.id.layoutQuizCards)).check(matches(isDisplayed()));
        backToDashboard();
        Thread.sleep(500);

        // Assignment card → AssignmentActivity
        onView(withId(R.id.containerUpcomingAssignments))
                .perform(scrollTo(), clickFirstChildOf());
        Thread.sleep(1500);
        onView(withId(R.id.rvAssignments)).check(matches(isDisplayed()));
    }

    // ── Shared login helper ──────────────────────────────────────────────────
    private void login() throws InterruptedException {
        onView(withId(R.id.etStudentUsername))
                .perform(replaceText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(replaceText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(replaceText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));
    }

    // ── Dashboard grid card par scroll + reliable click ──────────────────────
    private void clickDashboardCard(int cardId) throws InterruptedException {
        onView(withId(cardId)).perform(scrollTo(), forceClick());
        Thread.sleep(1500); // Target activity load hone ka wait
    }

    // ── Target activity se wapas dashboard par aane ka helper ────────────────
    private void backToDashboard() throws InterruptedException {
        pressBack();
        Thread.sleep(1000);
        onView(withId(R.id.tvStudentName)).check(matches(isDisplayed()));
    }

    /**
     * Helper — check karta hai ke di gayi ID wala view is waqt VISIBLE hai
     * ya nahi (GONE/hidden ho to false return karega).
     */
    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }

    /**
     * Custom ViewAction — Espresso ki visibility/coverage constraints
     * (jaise "<90% visible") bypass karke seedha view par performClick()
     * call karta hai. StudentProgressTest.java ke clickChildViewWithId()
     * jaisa hi tareeqa.
     */
    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility constraints.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    /**
     * Custom ViewAction — diye gaye container (LinearLayout) ke andar jo
     * bhi pehla child view ho (dynamically add hua CardView — Live
     * Class/Quiz/Assignment card), usay dhoond kar click karta hai. Yeh
     * card ke andar ke text (jo data available hai ya nahi uske hisaab
     * se badalta rehta hai) par depend nahi karta, is liye reliable hai.
     */
    private static ViewAction clickFirstChildOf() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(ViewGroup.class);
            }

            @Override
            public String getDescription() {
                return "Click the first child view inside this container.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                ViewGroup group = (ViewGroup) view;
                if (group.getChildCount() > 0) {
                    group.getChildAt(0).performClick();
                }
                uiController.loopMainThreadUntilIdle();
            }
        };
    }
}