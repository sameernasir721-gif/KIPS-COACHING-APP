package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.assertEquals;

import android.content.Context;
import android.content.Intent;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.dashboard.ParentAttendanceActivity;
import com.google.firebase.auth.FirebaseAuth;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ParentAttendanceActivityTest {

    private ActivityScenario<ParentAttendanceActivity> scenario;

    private static final String TEST_EMAIL = "ama319709@gmail.com";
    private static final String TEST_PASSWORD = "Student048@";

    private static final String STUDENT_UID = "xltikub9engV0nknj3On6oBHEYh1";
    private static final String KNOWN_CLASS_TEXT = "Mathematics";

    @After
    public void tearDown() {
        if (scenario != null) {
            scenario.close();
        }
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    private void loginAndLaunch(String studentUidExtra) {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(TEST_EMAIL, TEST_PASSWORD);
        sleep(5000);

        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentAttendanceActivity.class);
        if (studentUidExtra != null) {
            intent.putExtra(ParentAttendanceActivity.EXTRA_STUDENT_UID, studentUidExtra);
        }
        scenario = ActivityScenario.launch(intent);

        sleep(6000); // Firebase se student info + class history load hone ka time
    }

    // ═══════════════════════════════════════════════════════════
    // #1 — Student UID na diya jaye to empty-message
    // ═══════════════════════════════════════════════════════════
    @Test
    public void noStudentUid_showsEmptyMessage() {
        loginAndLaunch(null);

        onView(withId(R.id.tvHistoryEmpty)).check(matches(isDisplayed()));
        onView(withId(R.id.tvHistoryEmpty)).check(matches(withText("Student information not available.")));
    }

    // ═══════════════════════════════════════════════════════════
    // #2 — Back button click → Activity finish ho
    // ═══════════════════════════════════════════════════════════
    @Test
    public void backButton_click_finishesActivity() {
        loginAndLaunch(null);

        onView(withId(R.id.btnBack)).perform(click());
        sleep(1000);

        assertEquals(Lifecycle.State.DESTROYED, scenario.getState());
    }

    // ═══════════════════════════════════════════════════════════
    // #3 — Progress bar shuru mein dikhe, baad mein chupa ho
    // ═══════════════════════════════════════════════════════════
    @Test
    public void progressBar_hiddenAfterLoad() {
        loginAndLaunch(STUDENT_UID);

        onView(withId(R.id.progressLoading)).check(matches(
                org.hamcrest.CoreMatchers.not(androidx.test.espresso.matcher.ViewMatchers.isDisplayed())));
    }
        // ═══════════════════════════════════════════════════════════
        // #4 — Real student ke sath class history card dikhe
        // ═══════════════════════════════════════════════════════════

    @Test
    public void validStudentWithClasses_showsHistoryCard() {
        loginAndLaunch("xltikub9engV0nknj3On6oBHEYh1");

        onView(withId(R.id.tvHistoryEmpty)).check(matches(
                org.hamcrest.CoreMatchers.not(isDisplayed())));

        onView(withText(containsString("Mathematics"))).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════
    // #5 — containerHistory mein kam se kam 1 child view ho
    // ═══════════════════════════════════════════════════════════
    @Test
    public void validStudentWithClasses_containerHasChildren() {
        loginAndLaunch(STUDENT_UID);

        scenario.onActivity(activity -> {
            android.widget.LinearLayout container = activity.findViewById(R.id.containerHistory);
            org.junit.Assert.assertTrue("Container mein koi history card nahi hai",
                    container.getChildCount() > 0);
        });
    }
}