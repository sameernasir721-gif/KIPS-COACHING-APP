package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;

import android.content.Context;
import android.content.Intent;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.dashboard.ParentHelpActivity;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ParentHelpActivityTest {

    private ActivityScenario<ParentHelpActivity> scenario;

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    private void launch() {
        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentHelpActivity.class);
        scenario = ActivityScenario.launch(intent);
        sleep(1000);
    }

    @After
    public void tearDown() {
        if (scenario != null) {
            scenario.close();
        }
    }

    // ═══════════════════════════════════════════════════════════
    // #1 — Back button
    // ═══════════════════════════════════════════════════════════
    @Test
    public void backButton_click_finishesActivity() {
        launch();

        onView(withId(R.id.btnBack)).perform(click());
        sleep(1000);

        assertEquals(Lifecycle.State.DESTROYED, scenario.getState());
    }

    // ═══════════════════════════════════════════════════════════


    @Test
    public void allFaqQuestions_areVisible() {
        launch();

        onView(withText("How can I see my child's marks?")).check(matches(isDisplayed()));
        onView(withText("Where can I check fee records?")).check(matches(isDisplayed()));
        onView(withText("How do I view new announcements?")).check(matches(isDisplayed()));
        onView(withText("How do I view my child's assignments and quizzes?"))
                .perform(scrollTo()).check(matches(isDisplayed()));
        onView(withText("How do I update my contact information?"))
                .perform(scrollTo()).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════
    // #3 — Answers by default chupe hon
    // ═══════════════════════════════════════════════════════════
    @Test
    public void faqAnswer_hiddenByDefault() {
        launch();

        onView(withText("Open the 'Student Progress' card from your dashboard. You can view marks for quizzes and assignments here."))
                .check(matches(not(isDisplayed())));
    }

    // ═══════════════════════════════════════════════════════════
    // #4 — Question click → answer dikhe
    // ═══════════════════════════════════════════════════════════
    @Test
    public void clickingQuestion_showsAnswer() {
        launch();

        onView(withText("How can I see my child's marks?")).perform(click());
        sleep(500);

        onView(withText("Open the 'Student Progress' card from your dashboard. You can view marks for quizzes and assignments here."))
                .check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════
    // #5 — Dobara click → answer chupe
    // ═══════════════════════════════════════════════════════════
    @Test
    public void clickingQuestionAgain_hidesAnswer() {
        launch();

        onView(withText("How can I see my child's marks?")).perform(click());
        sleep(500);
        onView(withText("How can I see my child's marks?")).perform(click());
        sleep(500);

        onView(withText("Open the 'Student Progress' card from your dashboard. You can view marks for quizzes and assignments here."))
                .check(matches(not(isDisplayed())));
    }
}