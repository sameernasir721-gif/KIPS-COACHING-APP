package com.example.kipscoachingkharian;

import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.TimePicker;

import androidx.test.espresso.contrib.PickerActions;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isPlatformPopup;
import static androidx.test.espresso.matcher.ViewMatchers.hasSibling;
import static androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withHint;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.equalTo;

/**
 * Create Quiz Test — Teacher login karke Quizzes screen kholta hai,
 * "Create" dabata hai, poora quiz form (Title, Subject, Class, Question
 * Type, Time Limit, Start/End Date+Time, Description) fill karta hai,
 * ek MCQ question (4 options + correct answer) add karta hai, aur
 * "Share Quiz" dabakar quiz ko us class ke students ko bhejta hai.
 * Aakhir mein wapas Quizzes list par aane ka verify karta hai.
 *
 * NOTE: Questions is screen par DYNAMICALLY (Java code se, bina fixed
 * resource-id ke) add hote hain, isliye humein unhe unke HINT TEXT se
 * (jaise "Enter question 1", "Option A") pakadna padta hai — resource
 * id se nahi.
 *
 * FIX: Form ek ScrollView ke andar hai, is liye niche wale fields
 * (End Date/Time, Description, Add Question, Share Quiz waghera) click
 * karne se pehle scrollTo() perform karte hain, taake element pehle
 * screen par 90%+ visible ho jaye (warna Espresso "not 90% visible"
 * PerformException deta hai).
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daal dein (wahi
 * jo TeacherLoginFlowTest mein use ki thi).
 */
@RunWith(AndroidJUnit4.class)
public class CreateQuizTest {

    // ── Yahan apni test-teacher ki details daalein ─────────────────────────
    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    // ── Quiz ke liye subject/class (dropdown se exact match hone chahiye)
    private static final String SUBJECT = "Mathematics";
    private static final String GRADE   = "10A";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    @Test
    public void createQuiz_shareWithClass_verifyInList() throws InterruptedException {

        // Unique title taake purane quizzes se confuse na ho
        String uniqueTitle = "Test Quiz "
                + new SimpleDateFormat("dd-MMM HH:mm:ss", Locale.getDefault())
                .format(Calendar.getInstance().getTime());

        // ── Step 1-4: Poora Login Flow ────────────────────────────────────
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        onView(withId(R.id.btnTeacherLogin)).perform(click());

        // Dashboard load hone ka wait
        Thread.sleep(10000);

        onView(withId(R.id.tvTeacherName))
                .check(matches(isDisplayed()));

        // ── Step 5: Dashboard se "Quizzes" card dabayen ─────────────────────
        onView(withId(R.id.cardQuizzes)).perform(scrollTo(), click());
        Thread.sleep(3000);

        // ── Step 6: "Create" button dabayen (naya quiz banane ke liye) ──────
        onView(withId(R.id.btnCreate)).perform(scrollTo(), click());
        Thread.sleep(2000);

        // ── Step 7: Quiz Title bharein ───────────────────────────────────────
        onView(withId(R.id.etQuizTitle))
                .perform(scrollTo(), typeText(uniqueTitle), closeSoftKeyboard());

        // ── Step 8: Subject dropdown se select karein ───────────────────────
        onView(withId(R.id.spinnerSubject)).perform(scrollTo(), click());
        onView(withText(SUBJECT)).inRoot(isPlatformPopup()).perform(click());

        // ── Step 9: Class dropdown se select karein ─────────────────────────
        onView(withId(R.id.spinnerClass)).perform(scrollTo(), click());
        onView(withText(GRADE)).inRoot(isPlatformPopup()).perform(click());

        // ── Step 10: Question Type dropdown se "MCQs" select karein ─────────
        onView(withId(R.id.spinnerQuestionType)).perform(scrollTo(), click());
        onView(withText("MCQs")).inRoot(isPlatformPopup()).perform(click());

        // ── Step 11: Time Limit bharein ──────────────────────────────────────
        onView(withId(R.id.etTimeLimit))
                .perform(scrollTo(), typeText("15"), closeSoftKeyboard());

        // ── Step 12: Start Date select karein (aaj ki date accept karte hain) ─
        onView(withId(R.id.tvStartDate)).perform(scrollTo(), click());
        Thread.sleep(500);
        onView(withId(android.R.id.button1)).perform(click()); // OK

        // ── Step 13: Start Time select karein (default time accept karte hain)
        onView(withId(R.id.tvStartTime)).perform(scrollTo(), click());
        Thread.sleep(500);
        onView(withId(android.R.id.button1)).perform(click()); // OK

        // ── Step 14: End Date select karein (1 hafta aage) ──────────────────
        onView(withId(R.id.tvEndDate)).perform(scrollTo(), click());
        Thread.sleep(500);
        Calendar endCal = Calendar.getInstance();
        endCal.add(Calendar.DAY_OF_MONTH, 7);
        onView(withClassName(equalTo(DatePicker.class.getName()))).perform(
                PickerActions.setDate(
                        endCal.get(Calendar.YEAR),
                        endCal.get(Calendar.MONTH) + 1, // PickerActions 1-based month leta hai
                        endCal.get(Calendar.DAY_OF_MONTH)));
        onView(withId(android.R.id.button1)).perform(click()); // OK

        // ── Step 15: End Time select karein (default time accept karte hain) ─
        onView(withId(R.id.tvEndTime)).perform(scrollTo(), click());
        Thread.sleep(500);
        onView(withId(android.R.id.button1)).perform(click()); // OK

        // ── Step 16: Description bharein ─────────────────────────────────────
        onView(withId(R.id.etQuizDescription))
                .perform(scrollTo(), typeText("Yeh ek automated Espresso test se banaya gaya quiz hai."),
                        closeSoftKeyboard());

        // ── Step 17: "+ Add Question" dabayen (naya question card add hoga) ──
        onView(withId(R.id.btnAddQuestion)).perform(scrollTo(), click());
        Thread.sleep(500);

        // ── Step 18: Question text bharein (hint se pakda hai, id nahi hai) ──
        onView(withHint("Enter question 1"))
                .perform(scrollTo(), typeText("2 + 2 kitne hote hain?"), closeSoftKeyboard());

        // ── Step 19: 4 options bharein (A/B/C/D) ─────────────────────────────
        onView(withHint("Option A")).perform(scrollTo(), typeText("3"), closeSoftKeyboard());
        onView(withHint("Option B")).perform(scrollTo(), typeText("4"), closeSoftKeyboard());
        onView(withHint("Option C")).perform(scrollTo(), typeText("5"), closeSoftKeyboard());
        onView(withHint("Option D")).perform(scrollTo(), typeText("6"), closeSoftKeyboard());

        // ── Step 20: Sahi jawab (Option B = "4") ka radio button select karein
        onView(allOf(isAssignableFrom(RadioButton.class), hasSibling(withHint("Option B"))))
                .perform(scrollTo(), click());

        // ── Step 21: "Share Quiz" button dabayen ─────────────────────────────
        // NOTE: btnShareQuiz screen ke fixed bottom bar mein hai (ScrollView
        // ke bahar), is liye scrollTo() nahi lagana — yeh hamesha visible
        // rehta hai, seedha click() kaafi hai.
        onView(withId(R.id.btnShareQuiz)).perform(click());

        // Firebase par save + share hone ka wait
        Thread.sleep(6000);

        // ── Step 22: Wapas Quizzes list par aane ka verify karein ────────────
        onView(withId(R.id.btnCreate))
                .check(matches(isDisplayed()));
    }
}