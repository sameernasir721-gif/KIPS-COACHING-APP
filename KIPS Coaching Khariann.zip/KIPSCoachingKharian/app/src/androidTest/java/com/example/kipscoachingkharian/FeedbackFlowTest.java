package com.example.kipscoachingkharian;

import android.view.View;
import android.widget.RatingBar;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

/**
 * Feedback Flow Test
 *
 * Test 1:
 * Login ke baad Feedback screen open karta hai aur
 * Submit Feedback / All Feedback tabs ke darmiyan switching verify karta hai.
 *
 * Test 2:
 * Rating + name + feedback fill karke submit karta hai.
 * Submit ke baad All Feedback tab automatically open hona
 * aur feedback list visible hona verify karta hai.
 */
@RunWith(AndroidJUnit4.class)
public class FeedbackFlowTest {

    // ─────────────────────────────────────────────────────────────
    // TEST STUDENT DETAILS
    // ─────────────────────────────────────────────────────────────

    private static final String TEST_EMAIL =
            "haleemaiftikhar718@gmail.com";

    private static final String TEST_STUDENT_ID =
            "student048";

    private static final String TEST_PASSWORD =
            "haleemay67?";

    private static final String FEEDBACK_TEXT =
            "Automated test feedback - please ignore "
                    + System.currentTimeMillis();


    // ─────────────────────────────────────────────────────────────
    // ACTIVITY RULE
    // ─────────────────────────────────────────────────────────────

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);


    // ─────────────────────────────────────────────────────────────
    // TEST 1
    // SUBMIT FEEDBACK ↔ ALL FEEDBACK TAB SWITCHING
    // ─────────────────────────────────────────────────────────────

    @Test
    public void feedbackTabs_switchBetweenSubmitAndAll()
            throws InterruptedException {

        // Login
        login();

        // Open Feedback screen
        openFeedbackScreen();

        // Default mein Submit Feedback tab visible hona chahiye
        onView(withId(R.id.layoutSubmitFeedback))
                .check(matches(isDisplayed()));


        // ─────────────────────────────────────────────────────────
        // ALL FEEDBACK TAB
        // ─────────────────────────────────────────────────────────

        onView(withId(R.id.tabAll))
                .perform(scrollTo(), click());

        Thread.sleep(500);

        // All Feedback layout visible hona chahiye
        onView(withId(R.id.layoutAllFeedback))
                .check(matches(isDisplayed()));

        // Feedback RecyclerView visible hona chahiye
        onView(withId(R.id.rvFeedbacks))
                .check(matches(isDisplayed()));

        // Overall rating visible hona chahiye
        onView(withId(R.id.tvOverallRatingDigit))
                .check(matches(isDisplayed()));


        // ─────────────────────────────────────────────────────────
        // WAPAS SUBMIT FEEDBACK TAB
        // ─────────────────────────────────────────────────────────

        onView(withId(R.id.tabSubmit))
                .perform(scrollTo(), click());

        Thread.sleep(500);

        // Submit Feedback layout visible hona chahiye
        onView(withId(R.id.layoutSubmitFeedback))
                .check(matches(isDisplayed()));
    }


    // ─────────────────────────────────────────────────────────────
    // TEST 2
    // SUBMIT FEEDBACK
    // ─────────────────────────────────────────────────────────────

    @Test
    public void submitFeedback_showsSuccessToastAndSwitchesToAllTab()
            throws InterruptedException {

        // Login
        login();

        // Feedback screen open
        openFeedbackScreen();

        // Submit Feedback tab visible hona chahiye
        onView(withId(R.id.layoutSubmitFeedback))
                .check(matches(isDisplayed()));


        // ─────────────────────────────────────────────────────────
        // SELECT 5 STAR RATING
        // ─────────────────────────────────────────────────────────

        onView(withId(R.id.ratingBarFeedback))
                .perform(
                        scrollTo(),
                        setRating(5f)
                );


        // ─────────────────────────────────────────────────────────
        // ENTER NAME
        // ─────────────────────────────────────────────────────────

        onView(withId(R.id.editName))
                .perform(
                        scrollTo(),
                        clearText(),
                        typeText("Test Student"),
                        closeSoftKeyboard()
                );


        // ─────────────────────────────────────────────────────────
        // ENTER FEEDBACK
        // ─────────────────────────────────────────────────────────

        onView(withId(R.id.editFeedback))
                .perform(
                        scrollTo(),
                        replaceText(FEEDBACK_TEXT),
                        closeSoftKeyboard()
                );


        // ─────────────────────────────────────────────────────────
        // SUBMIT BUTTON
        // ─────────────────────────────────────────────────────────

        onView(withId(R.id.btnSubmit))
                .perform(
                        scrollTo(),
                        click()
                );


        // ─────────────────────────────────────────────────────────
        // WAIT FOR FIREBASE + UI UPDATE
        // ─────────────────────────────────────────────────────────

        Thread.sleep(2000);


        // ─────────────────────────────────────────────────────────
        // AFTER SUCCESS:
        // FeedbackActivity ke andar showAllTab() call hota hai.
        // Is liye All Feedback tab visible hona chahiye.
        // ─────────────────────────────────────────────────────────

        onView(withId(R.id.layoutAllFeedback))
                .check(matches(isDisplayed()));


        // Feedback list visible honi chahiye
        onView(withId(R.id.rvFeedbacks))
                .check(matches(isDisplayed()));
    }


    // ─────────────────────────────────────────────────────────────
    // LOGIN HELPER
    // ─────────────────────────────────────────────────────────────

    private void login() throws InterruptedException {

        // Email
        onView(withId(R.id.etStudentUsername))
                .perform(
                        typeText(TEST_EMAIL),
                        closeSoftKeyboard()
                );


        // Password
        onView(withId(R.id.etStudentPassword))
                .perform(
                        typeText(TEST_PASSWORD),
                        closeSoftKeyboard()
                );


        // Agar email verification button visible hai
        if (isViewDisplayed(R.id.btnEmailVerified)) {

            onView(withId(R.id.btnEmailVerified))
                    .perform(click());

            Thread.sleep(4000);
        }


        // Student ID
        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(
                        typeText(TEST_STUDENT_ID),
                        closeSoftKeyboard()
                );


        // Login button
        onView(withId(R.id.btnStudentLogin))
                .perform(click());


        // Dashboard load hone ka wait
        Thread.sleep(5000);


        // Student dashboard ka name visible hona chahiye
        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));
    }


    // ─────────────────────────────────────────────────────────────
    // OPEN FEEDBACK SCREEN
    // ─────────────────────────────────────────────────────────────

    private void openFeedbackScreen()
            throws InterruptedException {

        /*
         * Bottom navigation ka Feedback item.
         *
         * Normal click() ke bajaye forceClick() use kiya gaya hai
         * kyunki pehle Espresso "<90% visible" error de raha tha.
         */

        onView(withId(R.id.nav_bottom_feedback))
                .perform(forceClick());


        // FeedbackActivity load hone ka wait
        Thread.sleep(2500);
    }


    // ─────────────────────────────────────────────────────────────
    // FORCE CLICK
    // ─────────────────────────────────────────────────────────────

    private static ViewAction forceClick() {

        return new ViewAction() {

            @Override
            public Matcher<View> getConstraints() {

                return isAssignableFrom(View.class);
            }


            @Override
            public String getDescription() {

                return "Force click on a view, bypassing visibility constraints.";
            }


            @Override
            public void perform(
                    UiController uiController,
                    View view) {

                view.performClick();

                uiController.loopMainThreadUntilIdle();
            }
        };
    }


    // ─────────────────────────────────────────────────────────────
    // CHECK VIEW DISPLAYED
    // ─────────────────────────────────────────────────────────────

    private boolean isViewDisplayed(int viewId) {

        try {

            onView(withId(viewId))
                    .check(matches(isDisplayed()));

            return true;

        } catch (NoMatchingViewException | AssertionError e) {

            return false;
        }
    }


    // ─────────────────────────────────────────────────────────────
    // SET RATING
    // ─────────────────────────────────────────────────────────────

    private static ViewAction setRating(final float rating) {

        return new ViewAction() {

            @Override
            public Matcher<View> getConstraints() {

                return isAssignableFrom(
                        RatingBar.class
                );
            }


            @Override
            public String getDescription() {

                return "Set the rating of a RatingBar.";
            }


            @Override
            public void perform(
                    UiController uiController,
                    View view) {

                ((RatingBar) view).setRating(rating);

                uiController.loopMainThreadUntilIdle();
            }
        };
    }
}