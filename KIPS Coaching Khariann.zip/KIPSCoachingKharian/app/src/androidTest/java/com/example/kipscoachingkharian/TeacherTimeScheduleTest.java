package com.example.kipscoachingkharian;

import android.os.Environment;

import androidx.test.espresso.Espresso;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

/**
 * Time Schedule Test — Teacher login karke Time Schedule screen kholta
 * hai, phir dono actions ASAL MEIN (real) perform karta hai:
 *   1. "View" — button dabata hai, jo ASAL PDF viewer/browser app
 *      khol deta hai. Us external app se wapas aane ke liye UiDevice
 *      ka back button use karte hain — Espresso.pressBack() nahi,
 *      kyunke woh is jagah "AppNotIdleException" de kar 60 second tak
 *      HANG ho jata hai (external app khulne ke baad app ke internal
 *      delayed/background tasks ki wajah se Espresso "idle" hone ka
 *      wait karta reh jata hai). UiDevice ka back button seedha OS
 *      level par kaam karta hai, is masle ko bypass kar deta hai.
 *   2. "Share" (asal mein Download) — button dabata hai, aur ASAL
 *      download hone ka wait karta hai, phir verify karta hai ke file
 *      waqai Downloads folder mein maujood hai.
 *
 * ZAROORI SETUP: uiautomator dependency chahiye
 * (androidTestImplementation("androidx.test.uiautomator:uiautomator:2.3.0"))
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daal dein.
 */
@RunWith(AndroidJUnit4.class)
public class TeacherTimeScheduleTest {

    // ── Yahan apni test-teacher ki details daalein ─────────────────────────
    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    // Login ke baad Dashboard load hone ka smart wait
    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(500);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    // Downloads folder mein "KIPS_Timetable_" se shuru hone wali files ginta hai
    private int countTimetableFiles(File dir) {
        if (dir == null || !dir.exists()) return 0;
        File[] files = dir.listFiles((d, name) ->
                name.startsWith("KIPS_Timetable_") && name.endsWith(".pdf"));
        return files == null ? 0 : files.length;
    }

    @Test
    public void viewAndDownloadTimetablePdf() throws InterruptedException {

        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());

        // ── Step 1: Login ──────────────────────────────────────────────────
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(20);

        // ── Step 2: Dashboard se "Time Schedule" card dabayen (retry ke sath) ─
        boolean onCorrectScreen = false;
        for (int attempt = 1; attempt <= 3 && !onCorrectScreen; attempt++) {
            onView(withId(R.id.TimeSchedule)).perform(scrollTo(), click());
            Thread.sleep(2500);
            try {
                onView(withId(R.id.layoutPdfActions)).check(matches(isDisplayed()));
                onCorrectScreen = true;
            } catch (Exception e) {
                System.out.println("⚠️ Attempt " + attempt + ": Time Schedule screen nahi khuli, " +
                        "UiDevice back dabaa kar dobara try kar rahe hain...");
                device.pressBack();
                Thread.sleep(1500);
            }
        }
        org.junit.Assert.assertTrue("3 koshishon ke baad bhi Time Schedule screen nahi khuli!",
                onCorrectScreen);

        // ═══════════════ VIEW BUTTON — ASAL app khulti hai ═══════════════
        System.out.println("➡️ 'View' button dabate hain (asal PDF viewer/browser khulegi)...");
        onView(withId(R.id.btnViewTimetablePdf)).perform(click());
        Thread.sleep(4000); // External app khulne ka wait

        System.out.println("➡️ UiDevice back se wapas app mein aa rahe hain...");
        device.pressBack(); // Espresso.pressBack() ki jagah — hang nahi hota
        Thread.sleep(2000);

        // Wapas Time Schedule screen par confirm karte hain
        onView(withId(R.id.layoutPdfActions)).check(matches(isDisplayed()));
        System.out.println("✅ 'View' se PDF khuli aur wapas app mein aa gaye.");

        // ═══════════════ SHARE (DOWNLOAD) BUTTON — ASAL download ═══════════
        System.out.println("➡️ 'Share' (Download) button dabate hain...");

        File downloadsDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS);
        int filesBefore = countTimetableFiles(downloadsDir);

        onView(withId(R.id.btnShareTimetablePdf)).perform(click());

        // Download ka wait (DownloadManager background mein kaam karta hai)
        boolean downloaded = false;
        for (int i = 0; i < 20; i++) {
            Thread.sleep(1000);
            int filesNow = countTimetableFiles(downloadsDir);
            if (filesNow > filesBefore) {
                downloaded = true;
                break;
            }
        }

        if (downloaded) {
            System.out.println("✅ PDF Downloads folder mein successfully download ho gayi!");
        } else {
            System.out.println("⚠️ 20 second mein download confirm nahi hui.");
        }

        org.junit.Assert.assertTrue(
                "Timetable PDF Downloads folder mein download nahi hui!", downloaded);

        System.out.println("✅ Time Schedule (View + Download) test pass ho gaya!");
    }
}