package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isEnabled;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import android.content.Context;
import android.content.Intent;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;

import com.example.kipscoachingkharian.dashboard.ParentFeeChallanActivity;

import org.junit.After;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ParentFeeChallanActivityTest {

    private ActivityScenario<ParentFeeChallanActivity> scenario;

    private static final String CHILD_UID = "xltikub9engV0nknj3On6oBHEYh1"; // student048
    private static final String FEE_MONTH = "July 2026";

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    private void launch(String childUid, String feeMonth) {
        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentFeeChallanActivity.class);
        if (childUid != null) intent.putExtra("child_uid", childUid);
        if (feeMonth != null) intent.putExtra("fee_month", feeMonth);
        scenario = ActivityScenario.launch(intent);
        sleep(6000);
    }

    // Har 200ms mein poll karta hai, jab tak text mil jaye ya timeout ho jaye
    private UiObject2 pollForText(UiDevice device, String text, long timeoutMs) {
        UiObject2 obj = null;
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            obj = device.findObject(By.textContains(text));
            if (obj != null) break;
            try { Thread.sleep(200); } catch (InterruptedException ignored) {}
        }
        return obj;
    }

    @After
    public void tearDown() {
        if (scenario != null) {
            scenario.close();
        }
    }

    // ═══════════════════════════════════════════════════════════
    // #1 — Back button
    // ═══════════════════════════════════════════════════════════
    @Test
    public void backButton_click_finishesActivity() {
        launch(CHILD_UID, FEE_MONTH);

        onView(withId(R.id.ivBack)).perform(click());
        sleep(1000);

        assertEquals(Lifecycle.State.DESTROYED, scenario.getState());
    }

    // ═══════════════════════════════════════════════════════════
    // #2 — child_uid missing → error Toast
    // ═══════════════════════════════════════════════════════════
   @Ignore
    @Test
    public void missingChildUid_showsErrorToast() {
        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());

        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentFeeChallanActivity.class);
        intent.putExtra("fee_month", FEE_MONTH);
        scenario = ActivityScenario.launch(intent);

        UiObject2 toast = pollForText(device, "Challan data not available", 10000);

        assertNotNull("Error Toast not found", toast);
    }

    // ═══════════════════════════════════════════════════════════
    // #3 — fee_month missing → error Toast
    // ═══════════════════════════════════════════════════════════
    @Ignore
    @Test
    public void missingFeeMonth_showsErrorToast() {
        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());

        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentFeeChallanActivity.class);
        intent.putExtra("child_uid", CHILD_UID);
        scenario = ActivityScenario.launch(intent);

        UiObject2 toast = pollForText(device, "Challan data not available", 10000);

        assertNotNull("Error Toast not found", toast);
    }

    // ═══════════════════════════════════════════════════════════
    // #4 — Download button initially disabled
    // ═══════════════════════════════════════════════════════════
    @Test
    public void downloadButton_disabledUntilChallanLoads() {
        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentFeeChallanActivity.class);
        intent.putExtra("child_uid", CHILD_UID);
        intent.putExtra("fee_month", FEE_MONTH);
        scenario = ActivityScenario.launch(intent);

        onView(withId(R.id.btnDownloadChallan)).check(matches(not(isEnabled())));
    }

    // ═══════════════════════════════════════════════════════════
    // #5 — Valid challan load ho, button enable ho jaye
    // ═══════════════════════════════════════════════════════════
    @Test
    public void validChallan_loadsAndEnablesDownloadButton() {
        launch(CHILD_UID, FEE_MONTH);

        onView(withId(R.id.challanProgress)).check(matches(not(isDisplayed())));
        onView(withId(R.id.btnDownloadChallan)).check(matches(isEnabled()));
        onView(withId(R.id.webChallan)).check(matches(isDisplayed()));
    }

    // ═══════════════════════════════════════════════════════════
    // #6 — Is month ka koi challan na ho → error Toast
    // ═══════════════════════════════════════════════════════════
    @Ignore
    @Test
    public void noChallanFound_showsErrorToast() {
        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());

        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentFeeChallanActivity.class);
        intent.putExtra("child_uid", CHILD_UID);
        intent.putExtra("fee_month", "May 2026");
        scenario = ActivityScenario.launch(intent);

        UiObject2 toast = pollForText(device, "No challan found for this month", 3000);

        assertNotNull("Error Toast nahi mila", toast);
    }
}