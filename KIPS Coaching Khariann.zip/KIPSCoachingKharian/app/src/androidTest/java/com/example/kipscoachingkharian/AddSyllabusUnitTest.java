package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isDialog;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withHint;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.containsString;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Add Syllabus Unit Test — Teacher login karke Syllabus screen kholta
 * hai, "+ Add Unit" dabata hai, Unit Order, Unit Title, aur Chapters
 * bhar kar "Add" dabata hai, aur verify karta hai ke naya unit list
 * mein nazar aa raha hai.
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daal dein.
 */
@RunWith(AndroidJUnit4.class)
public class AddSyllabusUnitTest {

    // ── Yahan apni test-teacher ki details daalein ─────────────────────────
    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    // Login ke baad Dashboard load hone ka smart wait
    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(1000);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    @Test
    public void addSyllabusUnit_verifyInList() throws InterruptedException {

        // Unique title taake purani units se confuse na ho
        String uniqueTitle = "Test Unit "
                + new SimpleDateFormat("dd-MMM HH:mm:ss", Locale.getDefault())
                .format(Calendar.getInstance().getTime());

        // ── Step 1: Login ──────────────────────────────────────────────────
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(25);

        // ── Step 2: Dashboard se "Syllabus" card dabayen ─────────────────────
        onView(withId(R.id.Syllabus)).perform(scrollTo(), click());
        Thread.sleep(2500); // Syllabus screen + units list load hone ka wait

        // ── Step 3: "+ Add Unit" button dabayen ──────────────────────────────
        onView(withId(R.id.btnAddUnit)).perform(click());
        Thread.sleep(1000); // Dialog open hone ka wait

        // ── Step 4: Unit Order bharein ────────────────────────────────────────
        onView(withHint("1")).inRoot(isDialog())
                .perform(typeText("1"), closeSoftKeyboard());

        // ── Step 5: Unit Title bharein ────────────────────────────────────────
        onView(withHint("e.g. Unit 1: Introduction")).inRoot(isDialog())
                .perform(typeText(uniqueTitle), closeSoftKeyboard());

        // ── Step 6: Chapters bharein (ek per line) ───────────────────────────
        onView(withHint("Chapter 1: Introduction\nChapter 2: Types")).inRoot(isDialog())
                .perform(typeText("Chapter 1: Basics\nChapter 2: Advanced Concepts"),
                        closeSoftKeyboard());

        // ── Step 7: "Add" button dabayen ──────────────────────────────────────
        onView(withText("Add")).inRoot(isDialog()).perform(click());

        Thread.sleep(3000); // Firebase par save hone ka wait

        // ── Step 8: Verify — naya unit list mein nazar aana chahiye ──────────
        onView(withId(R.id.rvUnits))
                .check(matches(hasDescendant(withText(containsString(uniqueTitle)))));
    }
}
