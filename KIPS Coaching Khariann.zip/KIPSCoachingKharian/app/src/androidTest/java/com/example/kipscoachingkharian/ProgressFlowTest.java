package com.example.kipscoachingkharian;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertTrue;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

/**
 * Progress Report Flow Test — Login karne ke baad Dashboard se
 * "Progress Report" card (cardReports) kholta hai, verify karta hai ke
 * screen crash na ho, Search-box test karta hai, aur Progress/Report
 * tab-toggle (chipProgress / chipReport) test karta hai.
 *
 * NOTE: Jaisa StudyMaterialFlowTest mein tha, waise hi yahan bhi
 * "rvProgress hamesha VISIBLE hogi" wala assumption nahi banaya —
 * ProgressActivity ka apna intended behavior hai: agar student ke
 * paas koi shared progress report na ho (ya search se kuch match na
 * ho) to rvProgress GONE ho kar layoutEmpty VISIBLE ho jata hai
 * (dekhein loadProgressReports() aur filterReports() in
 * ProgressActivity.java). Is liye hum "list ya empty-state, dono me
 * se koi ek dikh rahi ho" ye check karte hain — matlab crash nahi hua.
 *
 * IMPORTANT: Neeche apni asal test-student ki details daalein.
 */
@RunWith(AndroidJUnit4.class)
public class ProgressFlowTest {

    // ── Yahan apni test-student ki details daalein ─────────────────────────
    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void openProgressReport_directFromDashboard_searchAndTabsWork() throws InterruptedException {

        // ── Step 1-6: Poora Login Flow ──────────────────────────────────────
        onView(withId(R.id.etStudentUsername))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));

        // ── Step 7: Dashboard se "Progress Report" card dabayen ──────────────
        onView(withId(R.id.cardReports)).perform(click());

        // Progress screen load hone ka wait (Firebase se SharedProgress
        // fetch hoti hai)
        Thread.sleep(3000);

        // ── Step 8: Verify karein ke screen crash nahi hui — list ya
        // empty-state mein se koi ek dikh rahi honi chahiye ──────────────────
        assertListOrEmptyDisplayed();

        // ── Step 9: Search-box mein kuch type karke search test karein ───────
        onView(withId(R.id.etSearch))
                .perform(typeText("math"), closeSoftKeyboard());

        Thread.sleep(1000);

        // ── Step 10: Search ke baad bhi screen stable honi chahiye ───────────
        assertListOrEmptyDisplayed();

        // ── Step 11: "Report" tab par switch karein aur uske sections
        // check karein (Bar/Pie/Trend charts wala section) ───────────────────
        onView(withId(R.id.chipReport)).perform(click());
        Thread.sleep(1500); // charts render hone ka wait

        onView(withId(R.id.layoutReportSection)).check(matches(isDisplayed()));

        // ── Step 12: Wapis "Progress" tab par switch karein aur verify
        // karein ke progress-list section dobara dikhne lagi hai ─────────────
        onView(withId(R.id.chipProgress)).perform(click());
        Thread.sleep(500);

        onView(withId(R.id.layoutProgressSection)).check(matches(isDisplayed()));
    }

    /**
     * rvProgress aur layoutEmpty mein se kam az kam ek visible honi
     * chahiye — dono ek sath GONE hona iska matlab screen broken/crash
     * hai.
     */
    private void assertListOrEmptyDisplayed() {
        boolean listVisible = isViewDisplayed(R.id.rvProgress);
        boolean emptyVisible = isViewDisplayed(R.id.layoutEmpty);
        assertTrue("Na to progress list na hi empty-state dikh rahi — screen crash/broken lagti hai",
                listVisible || emptyVisible);
    }

    /**
     * Helper — check karta hai ke di gayi ID wala view is waqt VISIBLE hai
     * ya nahi (GONE/hidden ho to false return karega).
     */
    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }
}
