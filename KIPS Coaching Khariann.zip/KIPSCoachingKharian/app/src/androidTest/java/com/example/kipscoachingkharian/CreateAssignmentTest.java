package com.example.kipscoachingkharian;

import android.widget.DatePicker;

import androidx.test.espresso.contrib.PickerActions;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isPlatformPopup;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.equalTo;

/**
 * Create Assignment Test — Teacher login karke Assignments screen kholta
 * hai, "Create New" dabata hai, poora assignment form (Title, Subject,
 * Grade, Marks, Due Date/Time, Description) fill karta hai, aur
 * "Share Assignment" dabakar assignment ko us class ke students ko
 * bhejta hai. Aakhir mein wapas Assignments list par aane ka aur naya
 * assignment list mein dikhne ka verify karta hai.
 *
 * NOTE: App ka logic Subject + Grade (class) select karne par khud
 * us class + subject ke saare matching students ko assignment share
 * kar deta hai — isliye alag se student select karne ki zaroorat nahi.
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daal dein (wahi
 * jo TeacherLoginFlowTest mein use ki thi).
 */
@RunWith(AndroidJUnit4.class)
public class CreateAssignmentTest {

    // ── Yahan apni test-teacher ki details daalein ─────────────────────────
    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    // ── Assignment ke liye subject/grade (dropdown se exact match hone chahiye)
    private static final String SUBJECT = "Mathematics";
    private static final String GRADE   = "10A";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    @Test
    public void createAssignment_shareWithClass_verifyInList() throws InterruptedException {

        // Unique title taake purane assignments se confuse na ho
        String uniqueTitle = "Test Assignment "
                + new SimpleDateFormat("dd-MMM HH:mm:ss", Locale.getDefault())
                .format(Calendar.getInstance().getTime());

        // ── Step 1-4: Poora Login Flow ────────────────────────────────────
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        onView(withId(R.id.btnTeacherLogin)).perform(click());

        // Dashboard load hone ka wait
        Thread.sleep(10000);

        onView(withId(R.id.tvTeacherName))
                .check(matches(isDisplayed()));

        // ── Step 5: Dashboard se "Assignments" card dabayen ─────────────────
        onView(withId(R.id.cardAssignments)).perform(click());
        Thread.sleep(3000);

        onView(withId(R.id.rvAssignments))
                .check(matches(isDisplayed()));

        // ── Step 6: "Create New" button dabayen (naya assignment banane ke liye)
        onView(withId(R.id.btnCreateNew)).perform(click());
        Thread.sleep(2000);

        // ── Step 7: Assignment Title bharein ────────────────────────────────
        onView(withId(R.id.etTitle))
                .perform(typeText(uniqueTitle), closeSoftKeyboard());

        // ── Step 8: Subject dropdown se select karein ───────────────────────
        onView(withId(R.id.spinnerSubject)).perform(click());
        onView(withText(SUBJECT)).inRoot(isPlatformPopup()).perform(click());

        // ── Step 9: Grade/Class dropdown se select karein ───────────────────
        onView(withId(R.id.spinnerGrade)).perform(click());
        onView(withText(GRADE)).inRoot(isPlatformPopup()).perform(click());

        // ── Step 10: Total Marks bharein ─────────────────────────────────────
        onView(withId(R.id.etMarks))
                .perform(typeText("50"), closeSoftKeyboard());

        // ── Step 11: Due Date select karein (Date Picker mein aaj ki date
        //             default hoti hai, hum ek hafta aage set kar rahe hain) ──
        onView(withId(R.id.tvDueDate)).perform(click());
        Thread.sleep(500);
        Calendar dueCal = Calendar.getInstance();
        dueCal.add(Calendar.DAY_OF_MONTH, 7);
        onView(withClassName(equalTo(DatePicker.class.getName()))).perform(
                PickerActions.setDate(
                        dueCal.get(Calendar.YEAR),
                        dueCal.get(Calendar.MONTH) + 1, // PickerActions 1-based month leta hai
                        dueCal.get(Calendar.DAY_OF_MONTH)));
        onView(withId(android.R.id.button1)).perform(click()); // OK

        // ── Step 12: Due Time select karein (default time accept karte hain) ─
        onView(withId(R.id.tvDueTime)).perform(click());
        Thread.sleep(500);
        onView(withId(android.R.id.button1)).perform(click()); // OK

        // ── Step 13: Description bharein ─────────────────────────────────────
        onView(withId(R.id.etDescription))
                .perform(typeText("Yeh ek automated Espresso test se banaya gaya assignment hai."),
                        closeSoftKeyboard());

        // ── Step 14: "Share Assignment" button dabayen ───────────────────────
        onView(withId(R.id.btnCreateAssignment)).perform(click());

        // Firebase par save + share hone ka wait
        Thread.sleep(6000);

        // ── Step 15: Wapas Assignments list par aane ka verify karein ────────
        onView(withId(R.id.rvAssignments))
                .check(matches(isDisplayed()));
    }
}