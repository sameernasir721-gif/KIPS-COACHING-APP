package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.any;

/**
 * Assignment Flow Test — Login karne ke baad Dashboard se Assignments
 * screen kholta hai, pehle assignment card ka "View" button dabata hai,
 * aur detail-dialog khulne ka verify karta hai.
 *
 * IMPORTANT: Neeche apni asal test-student ki details daal dein (wahi
 * jo StudentLoginFlowTest mein use ki thi). Yeh test tabhi kaam karega
 * jab test-student ke paas kam se kam 1 shared assignment ho.
 */
@RunWith(AndroidJUnit4.class)
public class AssignmentFlowTest {

    // ── Yahan apni test-student ki details daalein ─────────────────────────
    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void openAssignments_viewFirstAssignment() throws InterruptedException {

        // ── Step 1-6: Poora Login Flow (StudentLoginFlowTest jaisa hi) ──────
        onView(withId(R.id.etStudentUsername))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());

        // Dashboard load hone ka wait
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));

        // ── Step 7: Dashboard se "Assignments" card dabayen ─────────────────
        onView(withId(R.id.cardAssignments)).perform(click());

        // Assignment list load hone ka wait (Firebase se real data aata hai)
        Thread.sleep(3000);

        // ── Step 8: RecyclerView dikh rahi hai yeh confirm karein ───────────
        onView(withId(R.id.rvAssignments))
                .check(matches(isDisplayed()));

        // ── Step 9: Pehle assignment-card ka "View" button dabayen ──────────
        onView(withId(R.id.rvAssignments))
                .perform(RecyclerViewActions.actionOnItemAtPosition(0, clickChildViewWithId(R.id.btnView)));

        Thread.sleep(1000);

        // ── Step 10: Detail-dialog khul chuka hai yeh verify karein ─────────
        onView(withId(R.id.tvDialogTitle))
                .check(matches(isDisplayed()));
    }

    /**
     * Helper — check karta hai ke di gayi ID wala view is waqt VISIBLE hai
     * ya nahi (GONE/hidden ho to false return karega).
     */
    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }

    /**
     * Custom action — RecyclerView ke andar kisi specific item ke andar
     * chhupe hue child-view (jaise btnView, btnSubmit) ko click karta hai.
     * Espresso ka RecyclerViewActions sirf poori row par click support
     * karta hai, isliye row ke andar ka specific button click karne ke
     * liye yeh helper zaroori hai.
     */
    public static ViewAction clickChildViewWithId(final int id) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return any(View.class);
            }

            @Override
            public String getDescription() {
                return "Click on a child view with specified id.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View v = view.findViewById(id);
                if (v != null) {
                    v.performClick();
                }
            }
        };
    }
}
