package com.example.kipscoachingkharian;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

/**
 * Subjects Flow Test — Login karne ke baad Dashboard se "Subjects" card
 * kholta hai, pehle enrolled-subject card ko dabata hai, aur verify karta
 * hai ke Study Material screen sahi tarah khul gayi hai (subject-filter
 * ke sath).
 *
 * IMPORTANT: Neeche apni asal test-student ki details daalein. Yeh test
 * tabhi kaam karega jab test-student ke paas kam se kam 1 enrolled
 * subject ho (jo tabhi hota hai jab Admin ne registration ke waqt
 * subjects assign kiye hon).
 */
@RunWith(AndroidJUnit4.class)
public class SubjectsFlowTest {

    // ── Yahan apni test-student ki details daalein ─────────────────────────
    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void openSubjects_clickFirstSubject_opensStudyMaterial() throws InterruptedException {

        // ── Step 1-6: Poora Login Flow ──────────────────────────────────────
        onView(withId(R.id.etStudentUsername))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));

        // ── Step 7: Dashboard se "Subjects" card dabayen ────────────────────
        onView(withId(R.id.cardSubjects)).perform(click());

        // Subjects screen load hone ka wait (Firebase se enrolledSubjects
        // fetch hoti hai, phir cards populate hote hain)
        Thread.sleep(3000);

        // ── Step 8: Pehla subject-card (cardSubject1) dikh raha hai ─────────
        // check karein (yeh sirf tab visible hota hai jab kam se kam 1
        // subject enrolled ho — displaySubjects() method isay VISIBLE karta
        // hai)
        onView(withId(R.id.cardSubject1))
                .check(matches(isDisplayed()));

        // ── Step 9: Pehle subject-card ko dabayen ───────────────────────────
        onView(withId(R.id.cardSubject1))
                .perform(click());

        // Study Material screen load hone ka wait (Firebase se
        // SharedStudyMaterials fetch hoti hai)
        Thread.sleep(3000);

        // ── Step 10: Verify karein ke Study Material screen khul gayi hai ───
        onView(withId(R.id.rvStudyMaterial))
                .check(matches(isDisplayed()));
    }

    /**
     * Helper — check karta hai ke di gayi ID wala view is waqt VISIBLE hai
     * ya nahi (GONE/hidden ho to false return karega).
     */
    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }
}
