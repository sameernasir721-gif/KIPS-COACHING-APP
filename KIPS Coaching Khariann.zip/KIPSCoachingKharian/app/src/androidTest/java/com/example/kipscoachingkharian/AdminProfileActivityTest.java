// LOCATION: app/src/androidTest/java/com/example/kipscoachingkharian/dashboard/AdminProfileActivityTest.java
package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.RootMatchers.withDecorView;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertTrue;

import android.view.WindowManager;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.intent.Intents;
import androidx.test.espresso.matcher.RootMatchers;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.example.kipscoachingkharian.dashboard.AdminDashboardActivity;
import com.example.kipscoachingkharian.dashboard.AdminProfileActivity;
import com.google.firebase.auth.FirebaseAuth;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * AdminProfileActivity apne onCreate() me FirebaseAuth.getCurrentUser() == null
 * check karta hai — signed-in nahi ho to seedha LoginSelectionActivity bhej
 * deta hai. Isliye @Before me pehle admin account se sign-in karte hain.
 *
 * JAAN-BOOJH KAR SHAMIL NAHI KIYA (real data/session ko safe rakhne ke liye):
 *   - "Edit Profile" ko VALID name/phone ke sath save karna — ye real
 *     Firebase Database record ko update kar dega.
 *   - "Change Password" ko sahi purane password ke sath complete karna —
 *     ye aapka REAL admin password badal dega. Sirf validation checks
 *     (jo network call se pehle hi return ho jate hain) test kiye hain.
 *
 * Logout test SAFE hai — sirf local FirebaseAuth session sign-out hoti hai,
 * koi remote data change nahi hoti.
 */
@RunWith(AndroidJUnit4.class)
public class AdminProfileActivityTest {

    private static final String TEST_ADMIN_EMAIL = "raimanasir260@gmail.com";
    private static final String TEST_ADMIN_PASSWORD = "#kipsadmin";

    private ActivityScenario<AdminProfileActivity> scenario;

    @Before
    public void signInAndLaunch() throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        FirebaseAuth.getInstance()
                .signInWithEmailAndPassword(TEST_ADMIN_EMAIL, TEST_ADMIN_PASSWORD)
                .addOnCompleteListener(task -> latch.countDown());

        boolean completed = latch.await(15, TimeUnit.SECONDS);
        assertTrue("Firebase sign-in timeout — internet check karein", completed);
        assertTrue("Sign-in fail ho gaya", FirebaseAuth.getInstance().getCurrentUser() != null);

        Intents.init();
        scenario = ActivityScenario.launch(AdminProfileActivity.class);

        // Firebase se admin profile fields (name/role) load hone ka wait
        try { Thread.sleep(3000); } catch (InterruptedException ignored) {}
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
        Intents.release();
        // Agar test ke andar logout na hua ho to yahan safai kar dein
        FirebaseAuth.getInstance().signOut();
    }

    // ── Toast matcher helper ────────────────────────────────────────────────
    private static Matcher<androidx.test.espresso.Root> isToast() {
        return new TypeSafeMatcher<androidx.test.espresso.Root>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("is toast");
            }

            @Override
            public boolean matchesSafely(androidx.test.espresso.Root root) {
                int type = root.getWindowLayoutParams().get().type;
                if (type == WindowManager.LayoutParams.TYPE_TOAST) {
                    return true;
                }
                return false;
            }
        };
    }

    // 1) Screen open hote hi zaroori elements dikhne chahiye
    @Test
    public void screen_elementsAreVisible() {
        onView(withId(R.id.tv_name)).check(matches(isDisplayed()));
        onView(withId(R.id.tv_role)).check(matches(isDisplayed()));
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
        onView(withId(R.id.item_settings)).check(matches(isDisplayed()));
        onView(withId(R.id.item_help)).check(matches(isDisplayed()));
        onView(withId(R.id.item_logout)).check(matches(isDisplayed()));
        onView(withId(R.id.bottomNav)).check(matches(isDisplayed()));
    }

    // 2) "My Profile" par tap karne se credentials dialog khulta hai
    @Test
    public void myProfile_opensCredentialsDialog() {
        onView(withId(R.id.item_my_profile)).perform(click());
        onView(withText("👤  Admin Profile")).check(matches(isDisplayed()));
        onView(withText("✏️ Edit Profile")).check(matches(isDisplayed()));
    }

    // 3) Credentials dialog se "Edit Profile" par tap karne se Edit dialog khulta hai
    @Test
    public void editProfileButton_opensEditDialog() {
        onView(withId(R.id.item_my_profile)).perform(click());
        onView(withText("✏️ Edit Profile")).perform(click());
        onView(withText("Name")).check(matches(isDisplayed()));
        onView(withText("Phone")).check(matches(isDisplayed()));
    }

    // 4) Edit Profile me naam khaali chor kar Save karne par warning Toast
    @Test
    public void editProfile_emptyName_showsWarningToast() {
        onView(withId(R.id.item_my_profile)).perform(click());
        onView(withText("✏️ Edit Profile")).perform(click());

        // Name field pehle se admin ke asli naam se filled hoti hai — usko khaali karein
        onView(withHintCompat("Full Name")).perform(clearText(), closeSoftKeyboard());
        onView(withText("Save")).perform(click());

        onView(withText("Naam zaroor likhein"))
                .inRoot(isToast())
                .check(matches(isDisplayed()));
    }

    // 5) "Settings" par tap karne se Change Password dialog khulta hai
    @Test
    public void settings_opensChangePasswordDialog() {
        onView(withId(R.id.item_settings)).perform(click());
        onView(withText("🔑 Change Password")).check(matches(isDisplayed()));
    }

    // 6) Purana password khaali chor kar Update karne par warning
    @Test
    public void changePassword_emptyOldPassword_showsWarningToast() {
        onView(withId(R.id.item_settings)).perform(click());
        onView(withText("Update")).perform(click());

        onView(withText("Purana password likhein"))
                .inRoot(isToast())
                .check(matches(isDisplayed()));
    }

    // 7) Naya password 6 characters se chota ho to warning
    @Test
    public void changePassword_shortNewPassword_showsWarningToast() {
        onView(withId(R.id.item_settings)).perform(click());

        onView(withText("Purana password")).check(matches(isDisplayed()));
        // Old password field me kuch bhi likh dein (validation aage badhne ke liye)
        onView(withHintCompat("Purana password")).perform(replaceText("dummyOldPass"), closeSoftKeyboard());
        onView(withHintCompat("Naya password (min 6)")).perform(replaceText("123"), closeSoftKeyboard());
        onView(withHintCompat("Naya password confirm")).perform(replaceText("123"), closeSoftKeyboard());

        onView(withText("Update")).perform(click());

        onView(withText("Password kam az kam 6 characters ka ho"))
                .inRoot(isToast())
                .check(matches(isDisplayed()));
    }

    // 8) Naya password aur confirm match na karein to warning
    @Test
    public void changePassword_mismatchedConfirm_showsWarningToast() {
        onView(withId(R.id.item_settings)).perform(click());

        onView(withHintCompat("Purana password")).perform(replaceText("dummyOldPass"), closeSoftKeyboard());
        onView(withHintCompat("Naya password (min 6)")).perform(replaceText("newPass123"), closeSoftKeyboard());
        onView(withHintCompat("Naya password confirm")).perform(replaceText("different123"), closeSoftKeyboard());

        onView(withText("Update")).perform(click());

        onView(withText("Password match nahi kiya"))
                .inRoot(isToast())
                .check(matches(isDisplayed()));
    }

    // 9) "Help" par tap karne se About dialog khulta hai
    @Test
    public void help_opensAboutDialog() {
        onView(withId(R.id.item_help)).perform(click());
        onView(withText("About App")).check(matches(isDisplayed()));
        onView(withText("KIPS Coaching Kharian\nVersion: 1.0\nStatus: Running"))
                .check(matches(isDisplayed()));
    }

    // 10) Bottom nav ka "Home" tab AdminDashboardActivity par le jana chahiye
    @Test
    public void bottomNavHome_opensAdminDashboard() {
        onView(withId(R.id.nav_home)).perform(click());
        intended(hasComponent(AdminDashboardActivity.class.getName()));
    }

    // 11) Logout dialog "No" dabane se dialog band ho jata hai, session wahi rehta hai
    @Test
    public void logoutDialog_tappingNo_staysLoggedIn() {
        onView(withId(R.id.item_logout)).perform(click());
        onView(withText("Kya aap logout karna chahte hain?")).check(matches(isDisplayed()));
        onView(withText("No")).perform(click());

        // Dialog band ho gaya, hum abhi bhi profile screen par hain
        onView(withId(R.id.tv_name)).check(matches(isDisplayed()));
        assertTrue("User signed-out ho gaya jab ke 'No' dabaya tha",
                FirebaseAuth.getInstance().getCurrentUser() != null);
    }

    // 12) Logout dialog "Yes" dabane se sign-out ho kar LoginSelectionActivity khulti hai
    @Test
    public void logoutDialog_tappingYes_signsOutAndNavigatesToLogin() {
        onView(withId(R.id.item_logout)).perform(click());
        onView(withText("Yes")).perform(click());

        intended(hasComponent(LoginSelectionActivity.class.getName()));
        assertTrue("Sign-out nahi hua", FirebaseAuth.getInstance().getCurrentUser() == null);
    }

    /**
     * Helper: dynamically banaye gaye EditText ko uske hint text se dhoondhta hai,
     * kyunke inn fields ki koi static ID nahi hai.
     */
    private static Matcher<android.view.View> withHintCompat(String hint) {
        return new TypeSafeMatcher<android.view.View>() {
            @Override
            protected boolean matchesSafely(android.view.View item) {
                if (!(item instanceof android.widget.EditText)) return false;
                CharSequence h = ((android.widget.EditText) item).getHint();
                return h != null && h.toString().equals(hint);
            }
            @Override
            public void describeTo(Description description) {
                description.appendText("with hint: " + hint);
            }
        };
    }
}
