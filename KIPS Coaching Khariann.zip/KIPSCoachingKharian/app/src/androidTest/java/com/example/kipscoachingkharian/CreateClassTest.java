package com.example.kipscoachingkharian;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isPlatformPopup;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

/**
 * Create New Class Test — Teacher login karke Dashboard se "Create
 * Classes" kholta hai, "+ Create New Class" dabata hai, poora form
 * (Class Name, Subject, Grade, Date, Time, Duration, Description) fill
 * karta hai, "Create Class" dabata hai, aur wapas list par aakar verify
 * karta hai ke naya class list mein nazar aa raha hai.
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daal dein.
 */
@RunWith(AndroidJUnit4.class)
public class CreateClassTest {

    // ── Yahan apni test-teacher ki details daalein ─────────────────────────
    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    private static final String SUBJECT = "Mathematics";
    private static final String GRADE   = "10A";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    // Login ke baad Dashboard load hone ka smart wait (fixed sleep ki jagah)
    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(1000);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    @Test
    public void createNewClass_verifyInList() throws InterruptedException {

        // Unique class name taake purani classes se confuse na ho
        String uniqueClassName = "Test Class "
                + new SimpleDateFormat("dd-MMM HH:mm:ss", Locale.getDefault())
                .format(Calendar.getInstance().getTime());

        // ── Step 1: Login ──────────────────────────────────────────────────
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(25);

        // ── Step 2: Dashboard se "Create Classes" card dabayen ───────────────
        onView(withId(R.id.cardCreateClasses)).perform(click());
        Thread.sleep(2000); // Class list screen load hone ka wait

        // ── Step 3: "+ Create New Class" button dabayen ──────────────────────
        onView(withId(R.id.btnCreateClass)).perform(click());
        Thread.sleep(1500); // Form screen load hone ka wait

        // ── Step 4: Class Name bharein ────────────────────────────────────────
        onView(withId(R.id.etClassName))
                .perform(typeText(uniqueClassName), closeSoftKeyboard());

        // ── Step 5: Subject dropdown se select karein ────────────────────────
        onView(withId(R.id.etSubject)).perform(click());
        onView(withText(SUBJECT)).inRoot(isPlatformPopup()).perform(click());

        // ── Step 6: Grade dropdown se select karein ──────────────────────────
        onView(withId(R.id.spinnerGrade)).perform(click());
        onView(withText(GRADE)).inRoot(isPlatformPopup()).perform(click());

        // ── Step 7: Date select karein (aaj ki date accept karte hain) ───────
        onView(withId(R.id.etClassDate)).perform(click());
        Thread.sleep(500);
        onView(withId(android.R.id.button1)).perform(click()); // OK

        // ── Step 8: Time select karein (default time accept karte hain) ─────
        onView(withId(R.id.etClassTime)).perform(click());
        Thread.sleep(500);
        onView(withId(android.R.id.button1)).perform(click()); // OK

        // ── Step 9: Duration bharein (optional) ──────────────────────────────
        onView(withId(R.id.etClassDuration))
                .perform(typeText("45"), closeSoftKeyboard());

        // ── Step 10: Description bharein (optional) ──────────────────────────
        onView(withId(R.id.etDescription))
                .perform(typeText("Yeh ek automated Espresso test se banaya gaya class hai."),
                        closeSoftKeyboard());

        // ── Step 11: "Create Class" button dabayen ───────────────────────────
        onView(withId(R.id.btnCreateClass)).perform(click());

        // Firebase par save + notification jaane ka wait (form khud finish()
        // ho kar wapas list screen par le aata hai)
        Thread.sleep(5000);

        // ── Step 12: Verify — naya class list mein nazar aana chahiye ────────
        onView(withId(R.id.containerClassHistory))
                .check(matches(hasDescendant(withText(
                        org.hamcrest.Matchers.containsString(uniqueClassName)))));
    }
}
