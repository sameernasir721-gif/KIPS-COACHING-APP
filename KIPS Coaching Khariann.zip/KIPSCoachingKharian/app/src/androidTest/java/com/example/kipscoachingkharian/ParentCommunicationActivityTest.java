
package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.dashboard.ParentCommunicationActivity;
import com.example.kipscoachingkharian.dashboard.ParentProfileActivity;
import com.example.kipscoachingkharian.dashboard.TeacherPickerActivity;
import com.google.firebase.auth.FirebaseAuth;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class ParentCommunicationActivityTest {

    // TODO: replace with a real parent test account's credentials
    private static final String TEST_EMAIL =
            "ama319709@gmail.com";

    private static final String TEST_STUDENT_ID =
            "student048";

    private static final String TEST_PASSWORD =
            "Student048#";
    private ActivityScenario<ParentCommunicationActivity> scenario;

    @Before
    public void signInAndLaunch() throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        FirebaseAuth.getInstance()
                .signInWithEmailAndPassword(TEST_EMAIL, TEST_PASSWORD)
                .addOnCompleteListener(task -> latch.countDown());

        boolean completed = latch.await(15, TimeUnit.SECONDS);
        assertTrue("Firebase sign-in timeout — check internet/credentials", completed);
        assertTrue("Sign-in failed", FirebaseAuth.getInstance().getCurrentUser() != null);

        Intents.init();
        scenario = ActivityScenario.launch(ParentCommunicationActivity.class);
        // Wait for the Firebase "ConversationIndex" listener to load
        try { Thread.sleep(3000); } catch (InterruptedException ignored) {}
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
        Intents.release();
        FirebaseAuth.getInstance().signOut();
    }

    // 1) Core screen elements should be visible
    @Test
    public void screen_elementsAreVisible() {
        onView(withId(R.id.etSearch)).check(matches(isDisplayed()));
        onView(withId(R.id.rvConversations)).check(matches(isDisplayed()));
        onView(withId(R.id.fabNewChat)).check(matches(isDisplayed()));
        onView(withId(R.id.llHomeTab)).check(matches(isDisplayed()));
        onView(withId(R.id.llProfileTab)).check(matches(isDisplayed()));
    }

    @Ignore
    @Test
    public void backIcon_finishesActivity() {
        onView(withId(R.id.ivBack)).perform(click());
        assertTrue("Activity should be DESTROYED after tapping back",
                scenario.getState() == Lifecycle.State.DESTROYED);
    }

    // 3) "New Chat" FAB should open TeacherPickerActivity
    @Test
    public void fabNewChat_opensTeacherPickerActivity() {
        onView(withId(R.id.fabNewChat)).perform(click());
        intended(hasComponent(TeacherPickerActivity.class.getName()));
    }

    // 4) Bottom "Home" tab should finish this activity (returns to dashboard)
    @Test
    public void homeTab_finishesActivity() {
        onView(withId(R.id.llHomeTab)).perform(click());
        assertTrue("Activity should be DESTROYED after tapping Home tab",
                scenario.getState() == Lifecycle.State.DESTROYED);
    }

    // 5) Bottom "Profile" tab should open ParentProfileActivity
    @Test
    public void profileTab_opensParentProfileActivity() {
        onView(withId(R.id.llProfileTab)).perform(click());
        intended(hasComponent(ParentProfileActivity.class.getName()));
    }

    // 6) Search field should accept text input without crashing
    @Test
    public void searchField_acceptsTextInput() {
        onView(withId(R.id.etSearch)).perform(typeText("Ali"), closeSoftKeyboard());
        onView(withId(R.id.etSearch)).check(matches(withText("Ali")));
    }

    // 7) After data loads, either the conversation list or the empty-state
    //    text should be shown — but not both stuck in a loading state
    @Test
    public void afterLoad_progressBarIsHidden() {
        onView(withId(R.id.progressBar)).check((view, noViewFoundException) -> {
            if (noViewFoundException != null) throw noViewFoundException;
            assertTrue("progressBar should be hidden once conversations have loaded",
                    view.getVisibility() != android.view.View.VISIBLE);
        });
    }
}