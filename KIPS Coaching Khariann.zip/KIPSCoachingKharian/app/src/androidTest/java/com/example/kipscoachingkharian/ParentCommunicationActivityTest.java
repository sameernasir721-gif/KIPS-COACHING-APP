package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.containsString;

import android.view.View;

import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;
import androidx.test.uiautomator.Until;

import com.example.kipscoachingkharian.auth.ParentLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

@RunWith(AndroidJUnit4.class)
public class ParentCommunicationActivityTest {


    private static final String TEST_EMAIL =
            "ama319709@gmail.com";

    private static final String TEST_STUDENT_ID =
            "student048";

    private static final String TEST_PASSWORD =
            "Student048#";

    @Rule
    public ActivityScenarioRule<ParentLoginActivity> activityRule =
            new ActivityScenarioRule<>(ParentLoginActivity.class);



    @Test
    public void communicationFlow_listSearchAndSendMessage() throws InterruptedException {

        // ── Step 1: Login (sirf ek baar) ─────────────────────────────────
        login();
        openCommunicationScreen();


        // ── Step 2: Conversation list crash ke bina load honi chahiye ────
        onView(withId(R.id.rvConversations))
                .check(matches(isDisplayed()));

        onView(withId(R.id.etSearch))
                .check(matches(isDisplayed()));


        // ── Step 3: Search filter — koi match na ho to empty-state dikhe ──
        onView(withId(R.id.etSearch))
                .perform(typeText("zzz_no_such_teacher"), closeSoftKeyboard());

        Thread.sleep(500);

        onView(withId(R.id.tvEmpty))
                .check(matches(isDisplayed()));

        // Search box saaf karo taake agla step (New Chat) fresh state se shuru ho
        onView(withId(R.id.etSearch))
                .perform(androidx.test.espresso.action.ViewActions.clearText(),
                        closeSoftKeyboard());

        Thread.sleep(500);


        // ── Step 4: "+" (New Chat) -> pehla teacher select karo ──────────
        String uniqueMessage = "Parent test message "
                + new SimpleDateFormat("dd-MMM HH:mm:ss", Locale.getDefault())
                .format(Calendar.getInstance().getTime());

        onView(withId(R.id.fabNewChat))
                .perform(click());

        Thread.sleep(2000); // Teacher picker list load hone ka wait

        onView(withId(R.id.etSearch))
                .perform(typeText("a"), closeSoftKeyboard());

        Thread.sleep(1500);

        onView(withId(R.id.rvParents))
                .perform(RecyclerViewActions.actionOnItemAtPosition(0, click()));

        Thread.sleep(2000); // ChatActivity load hone ka wait


        // ── Step 5: Message bhejo aur verify karo ─────────────────────────
        onView(withId(R.id.etMessage))
                .perform(typeText(uniqueMessage), closeSoftKeyboard());

        onView(withId(R.id.btnSend))
                .perform(click());

        Thread.sleep(3000); // Firebase par message save hone ka wait

        onView(withId(R.id.rvMessages))
                .check(matches(hasDescendant(withText(containsString(uniqueMessage)))));
    }


    // ─────────────────────────────────────────────────────────────
    // LOGIN HELPER
    // ─────────────────────────────────────────────────────────────

    private void login() throws InterruptedException {

        onView(withId(R.id.etLoginEmail))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etLoginPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        // ✅ FIX: tilLoginStudentId sirf tab VISIBLE hoti hai jab
        // checkEmailVerification() Firebase se confirm kar chuka ho ke
        // account asal mein verified hai (fUser.isEmailVerified()) — agar
        // account verify nahi hai to "I've verified" button sirf email
        // dobara bhej deta hai aur field kabhi VISIBLE hi nahi hoti. Fixed
        // 4-second sleep is timing ko reliably cover nahi karta (async
        // Firebase call kabhi zyada waqt le sakta hai), is liye field
        // VISIBLE hone tak poll karo, phir hi type karo.
        waitForViewThenType(R.id.etLoginStudentId, TEST_STUDENT_ID, 15);

        onView(withId(R.id.btnParentLogin))
                .perform(click());

        Thread.sleep(5000);

        allowNotificationPermissionIfShown();

        onView(withId(R.id.cardFeedback))
                .check(matches(isDisplayed()));
    }


    // ─────────────────────────────────────────────────────────────
    // WAIT FOR A FIELD TO BECOME VISIBLE, THEN TYPE INTO IT
    // ─────────────────────────────────────────────────────────────

    private void waitForViewThenType(int viewId, String text, int maxSeconds)
            throws InterruptedException {

        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(viewId)).check(matches(isDisplayed()));
                onView(withId(viewId)).perform(
                        androidx.test.espresso.action.ViewActions.scrollTo(),
                        typeText(text), closeSoftKeyboard());
                return;
            } catch (Throwable e) {
                // Espresso ki visibility-check failure Error hierarchy se
                // aati hai, Exception se nahi — Throwable pakadna zaroori hai
                // warna loop pehli hi nakaam koshish par crash ho jayega.
                Thread.sleep(1000);
            }
        }

        // Aakhri koshish — agar ab bhi na mile to asal error clearly throw ho
        onView(withId(viewId))
                .check(matches(isDisplayed()))
                .perform(androidx.test.espresso.action.ViewActions.scrollTo(),
                        typeText(text), closeSoftKeyboard());
    }


    // ─────────────────────────────────────────────────────────────
    // OPEN COMMUNICATION SCREEN
    // ─────────────────────────────────────────────────────────────

    private void openCommunicationScreen() throws InterruptedException {

        onView(withId(R.id.cardCommunication))
                .perform(forceClick());

        Thread.sleep(2500);
    }


    // ─────────────────────────────────────────────────────────────
    // ALLOW NOTIFICATION PERMISSION DIALOG (agar dikhe to)
    // ─────────────────────────────────────────────────────────────

    private void allowNotificationPermissionIfShown() {
        try {
            UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());

            String[] possibleLabels = {
                    "Allow", "ALLOW", "While using the app",
                    "Allow only while using the app", "OK"
            };

            for (String label : possibleLabels) {
                UiObject2 button = device.wait(Until.findObject(By.text(label)), 3000);
                if (button != null) {
                    button.click();
                    break;
                }
            }
        } catch (Exception e) {
            // Dialog aaya hi nahi, ya already resolve ho chuka — ignore karo.
        }
    }


    // ─────────────────────────────────────────────────────────────
    // FORCE CLICK
    // ─────────────────────────────────────────────────────────────

    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility constraints.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }


    // ─────────────────────────────────────────────────────────────
    // CHECK VIEW DISPLAYED
    // ─────────────────────────────────────────────────────────────

    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (Throwable e) {
            // Espresso ki failure "AssertionFailedWithCauseError" (aur
            // NoMatchingViewException) Error/Throwable hierarchy se aate
            // hain, Exception se nahi — is liye sirf "catch (Exception e)"
            // inhe miss kar deta tha aur crash upar propagate ho jaata tha.
            return false;
        }
    }
}