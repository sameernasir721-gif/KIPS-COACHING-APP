package com.example.kipscoachingkharian;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ParentProfileLogicTest {

    // ═══════════════════════════════════════════════════════════
    // Logout confirmation logic
    // (as in the dialog: "Yes, Logout" or "No")
    // ═══════════════════════════════════════════════════════════
    private boolean shouldSignOut(String userChoice) {
        return "Yes, Logout".equals(userChoice);
    }

    @Test
    public void logoutChoice_yesLogout_signsOut() {
        assertTrue(shouldSignOut("Yes, Logout"));
    }

    @Test
    public void logoutChoice_no_doesNotSignOut() {
        assertFalse(shouldSignOut("No"));
    }

    @Test
    public void logoutChoice_unrecognizedInput_doesNotSignOut() {
        assertFalse(shouldSignOut("Maybe"));
    }

    // ═══════════════════════════════════════════════════════════
    // Name fallback logic (when Firebase doesn't return a name)
    // (as in: name != null ? name : "Parent")
    // ═══════════════════════════════════════════════════════════
    private String getDisplayName(String firebaseName) {
        return (firebaseName != null && !firebaseName.trim().isEmpty()) ? firebaseName : "Parent";
    }

    @Test
    public void displayName_validNameFromFirebase_returnsSameName() {
        assertEquals("Ahad Ali", getDisplayName("Ahad Ali"));
    }

    @Test
    public void displayName_nullFromFirebase_returnsDefaultParent() {
        assertEquals("Parent", getDisplayName(null));
    }

    @Test
    public void displayName_emptyFromFirebase_returnsDefaultParent() {
        assertEquals("Parent", getDisplayName(""));
    }

    // ═══════════════════════════════════════════════════════════
    // Role-based label logic
    // ═══════════════════════════════════════════════════════════
    private String getRoleLabel(String role) {
        if (role == null) return "Unknown";
        switch (role) {
            case "Parent": return "Parent";
            case "Teacher": return "Teacher";
            case "Student": return "Student";
            case "Admin": return "Administrator";
            default: return "Unknown";
        }
    }

    @Test
    public void roleLabel_parent_returnsParent() {
        assertEquals("Parent", getRoleLabel("Parent"));
    }

    @Test
    public void roleLabel_admin_returnsAdministrator() {
        assertEquals("Administrator", getRoleLabel("Admin"));
    }

    @Test
    public void roleLabel_nullRole_returnsUnknown() {
        assertEquals("Unknown", getRoleLabel(null));
    }

    @Test
    public void roleLabel_unrecognizedRole_returnsUnknown() {
        assertEquals("Unknown", getRoleLabel("SuperUser"));
    }

    // ═══════════════════════════════════════════════════════════
    // Notification navigation eligibility
    // (as in: registrationId != null → open Announcements)
    // ═══════════════════════════════════════════════════════════
    private boolean canNavigateToNotifications(String registrationId) {
        return registrationId != null && !registrationId.trim().isEmpty();
    }

    @Test
    public void notifications_validRegistrationId_canNavigate() {
        assertTrue(canNavigateToNotifications("student048"));
    }

    @Test
    public void notifications_nullRegistrationId_cannotNavigate() {
        assertFalse(canNavigateToNotifications(null));
    }
}