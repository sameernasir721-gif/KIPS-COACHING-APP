package com.example.kipscoachingkharian;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ParentHelpFaqToggleTest {

    // ParentHelpActivity mein FAQ answer ki visibility toggle
    // (isExpanded = !isExpanded)
    private boolean toggleExpanded(boolean currentState) {
        return !currentState;
    }


    // Toggle state logic

    @Test
    public void toggle_fromCollapsed_becomesExpanded() {
        assertTrue(toggleExpanded(false));
    }

    @Test
    public void toggle_fromExpanded_becomesCollapsed() {
        assertFalse(toggleExpanded(true));
    }

    @Test
    public void toggle_twiceInARow_returnsToOriginalState() {
        boolean state = false;
        state = toggleExpanded(state);
        state = toggleExpanded(state);
        assertFalse(state);
    }


    // Visibility mapping (expanded → VISIBLE, collapsed → GONE)

    private String getVisibilityState(boolean isExpanded) {
        return isExpanded ? "VISIBLE" : "GONE";
    }

    @Test
    public void visibility_whenExpanded_isVisible() {
        assertEquals("VISIBLE", getVisibilityState(true));
    }

    @Test
    public void visibility_whenCollapsed_isGone() {
        assertEquals("GONE", getVisibilityState(false));
    }


    private int getArrowRotation(boolean isExpanded) {
        return isExpanded ? 180 : 0;
    }

    @Test
    public void arrowRotation_whenExpanded_is180Degrees() {
        assertEquals(180, getArrowRotation(true));
    }

    @Test
    public void arrowRotation_whenCollapsed_is0Degrees() {
        assertEquals(0, getArrowRotation(false));
    }



    private int getNewlyExpandedIndex(int clickedIndex, int currentlyExpandedIndex) {

        return (clickedIndex == currentlyExpandedIndex) ? -1 : clickedIndex;
    }

    @Test
    public void accordion_clickingSameItem_collapsesIt() {
        assertEquals(-1, getNewlyExpandedIndex(2, 2));
    }

    @Test
    public void accordion_clickingDifferentItem_expandsNewOne() {
        assertEquals(3, getNewlyExpandedIndex(3, 2));
    }

    @Test
    public void accordion_noItemExpandedYet_expandsClickedOne() {
        assertEquals(0, getNewlyExpandedIndex(0, -1));
    }
}