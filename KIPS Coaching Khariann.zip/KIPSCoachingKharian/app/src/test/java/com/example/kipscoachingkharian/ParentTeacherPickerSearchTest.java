package com.example.kipscoachingkharian;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ParentTeacherPickerSearchTest {

    // Same logic used in TeacherPickerActivity for filtering teacher names
    // (teacherName.toLowerCase().contains(query.toLowerCase()))
    private boolean matchesSearch(String teacherName, String query) {
        return teacherName.toLowerCase().contains(query.toLowerCase());
    }

    // ═══════════════════════════════════════════════════════════
    // Search matching logic
    // ═══════════════════════════════════════════════════════════
    @Test
    public void search_exactNameMatch_returnsTrue() {
        assertTrue(matchesSearch("Tanzila Shaheen", "Tanzila Shaheen"));
    }

    @Test
    public void search_partialNameMatch_returnsTrue() {
        assertTrue(matchesSearch("Tanzila Shaheen", "Tanz"));
    }

    @Test
    public void search_caseInsensitiveMatch_returnsTrue() {
        assertTrue(matchesSearch("Tanzila Shaheen", "SHAHEEN"));
    }

    @Test
    public void search_lastNameOnly_returnsTrue() {
        assertTrue(matchesSearch("Waleed Choudhary", "Choudhary"));
    }

    @Test
    public void search_noMatch_returnsFalse() {
        assertFalse(matchesSearch("Tanzila Shaheen", "zzz_no_such_teacher"));
    }

    @Test
    public void search_emptyQuery_matchesEverything() {
        assertTrue(matchesSearch("Tanzila Shaheen", ""));
    }

    @Test
    public void search_middleOfName_returnsTrue() {
        assertTrue(matchesSearch("Ghulam Fatima", "am Fat"));
    }

    // ═══════════════════════════════════════════════════════════
    // "No results found" empty-state logic
    // (jaisa: filteredList.isEmpty() → show tvEmpty)
    // ═══════════════════════════════════════════════════════════
    private boolean shouldShowEmptyState(int filteredResultCount) {
        return filteredResultCount == 0;
    }

    @Test
    public void emptyState_zeroResults_shouldShow() {
        assertTrue(shouldShowEmptyState(0));
    }

    @Test
    public void emptyState_someResults_shouldNotShow() {
        assertFalse(shouldShowEmptyState(3));
    }

    // ═══════════════════════════════════════════════════════════
    // Role filter logic (only "Teacher" role shown in picker)
    // ═══════════════════════════════════════════════════════════
    private boolean isEligibleForPicker(String role) {
        return "Teacher".equalsIgnoreCase(role);
    }

    @Test
    public void roleFilter_teacherRole_isEligible() {
        assertTrue(isEligibleForPicker("Teacher"));
    }

    @Test
    public void roleFilter_parentRole_isNotEligible() {
        assertFalse(isEligibleForPicker("Parent"));
    }

    @Test
    public void roleFilter_caseInsensitive_isEligible() {
        assertTrue(isEligibleForPicker("TEACHER"));
    }
}