package com.example.kipscoachingkharian;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ParentFeeChallanLogicTest {

    // ═══════════════════════════════════════════════════════════
    // Required intent extras check
    // (as in: if (childUid == null || feeMonth == null) show error Toast)
    // ═══════════════════════════════════════════════════════════
    private boolean hasRequiredChallanData(String childUid, String feeMonth) {
        return childUid != null && !childUid.trim().isEmpty()
                && feeMonth != null && !feeMonth.trim().isEmpty();
    }

    @Test
    public void challanData_bothExtrasProvided_returnsTrue() {
        assertTrue(hasRequiredChallanData("xltikub9engV0nknj3On6oBHEYh1", "July_2026"));
    }

    @Test
    public void challanData_missingChildUid_returnsFalse() {
        assertFalse(hasRequiredChallanData(null, "July_2026"));
    }

    @Test
    public void challanData_missingFeeMonth_returnsFalse() {
        assertFalse(hasRequiredChallanData("xltikub9engV0nknj3On6oBHEYh1", null));
    }

    @Test
    public void challanData_bothMissing_returnsFalse() {
        assertFalse(hasRequiredChallanData(null, null));
    }

    // ═══════════════════════════════════════════════════════════
    // Download button enable logic
    // (as in: button enabled only after challan HTML successfully loads)
    // ═══════════════════════════════════════════════════════════
    private boolean shouldEnableDownloadButton(boolean challanLoaded, boolean hasError) {
        return challanLoaded && !hasError;
    }

    @Test
    public void downloadButton_challanLoadedNoError_isEnabled() {
        assertTrue(shouldEnableDownloadButton(true, false));
    }

    @Test
    public void downloadButton_challanNotYetLoaded_isDisabled() {
        assertFalse(shouldEnableDownloadButton(false, false));
    }

    @Test
    public void downloadButton_loadErrorOccurred_isDisabled() {
        assertFalse(shouldEnableDownloadButton(true, true));
    }

    // ═══════════════════════════════════════════════════════════
    // Challan-not-found detection
    // (as in: Fees/<uid>/<monthKey> node does not exist)
    // ═══════════════════════════════════════════════════════════
    private boolean isChallanMissing(boolean nodeExistsInFirebase) {
        return !nodeExistsInFirebase;
    }

    @Test
    public void challanMissing_nodeDoesNotExist_returnsTrue() {
        assertTrue(isChallanMissing(false));
    }

    @Test
    public void challanMissing_nodeExists_returnsFalse() {
        assertFalse(isChallanMissing(true));
    }
}