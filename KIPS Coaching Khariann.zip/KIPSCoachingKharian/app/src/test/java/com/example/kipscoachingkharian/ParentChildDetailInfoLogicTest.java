package com.example.kipscoachingkharian;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ParentChildDetailInfoLogicTest {

    // ═══════════════════════════════════════════════════════════
    // STUDENT_ID intent extra presence check
    // (as in: if (studentId == null) show "Student ID not provided")
    // ═══════════════════════════════════════════════════════════
    private boolean hasValidStudentId(String studentId) {
        return studentId != null && !studentId.trim().isEmpty();
    }

    @Test
    public void studentId_provided_returnsTrue() {
        assertTrue(hasValidStudentId("student048"));
    }

    @Test
    public void studentId_null_returnsFalse() {
        assertFalse(hasValidStudentId(null));
    }

    @Test
    public void studentId_empty_returnsFalse() {
        assertFalse(hasValidStudentId(""));
    }

    // ═══════════════════════════════════════════════════════════
    // Upcoming schedule fallback logic
    // (as in: if no upcoming class found, show "No Upcoming Class" card)
    // ═══════════════════════════════════════════════════════════
    private String getUpcomingLabel(int upcomingCount, String itemType) {
        return upcomingCount > 0 ? itemType + " scheduled" : "No Upcoming " + itemType;
    }

    @Test
    public void upcomingSchedule_hasItems_showsScheduledLabel() {
        org.junit.Assert.assertEquals("Class scheduled", getUpcomingLabel(2, "Class"));
    }

    @Test
    public void upcomingSchedule_noItems_showsFallbackLabel() {
        org.junit.Assert.assertEquals("No Upcoming Class", getUpcomingLabel(0, "Class"));
    }

    @Test
    public void upcomingSchedule_noQuizItems_showsFallbackLabel() {
        org.junit.Assert.assertEquals("No Upcoming Quiz", getUpcomingLabel(0, "Quiz"));
    }

    // ═══════════════════════════════════════════════════════════
    // Card-navigation eligibility based on linked student
    // (as in: cards should only navigate once linkedStudentUid is set)
    // ═══════════════════════════════════════════════════════════
    private boolean canNavigateFromCard(String linkedStudentUid) {
        return linkedStudentUid != null && !linkedStudentUid.trim().isEmpty();
    }

    @Test
    public void cardNavigation_studentLinked_canNavigate() {
        assertTrue(canNavigateFromCard("xltikub9engV0nknj3On6oBHEYh1"));
    }

    @Test
    public void cardNavigation_studentNotYetLinked_cannotNavigate() {
        assertFalse(canNavigateFromCard(null));
    }
}