package com.example.kipscoachingkharian;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ParentClassStatusTest {

    // ParentAttendanceActivity  class status determine
    // (currentTime se compare Live / Upcoming / Ended)
    private String getClassStatus(long classStartMillis, long durationMinutes, long currentTimeMillis) {
        long classEndMillis = classStartMillis + (durationMinutes * 60 * 1000);

        if (currentTimeMillis < classStartMillis) {
            return "Upcoming";
        } else if (currentTimeMillis >= classStartMillis && currentTimeMillis <= classEndMillis) {
            return "Live";
        } else {
            return "Ended";
        }
    }


    // Class status determination

    @Test
    public void classStatus_currentTimeBeforeStart_returnsUpcoming() {
        long classStart = 100000L;
        long currentTime = 50000L;
        assertEquals("Upcoming", getClassStatus(classStart, 45, currentTime));
    }

    @Test
    public void classStatus_currentTimeDuringClass_returnsLive() {
        long classStart = 100000L;
        long duration = 45; // minutes
        long currentTime = classStart + (10 * 60 * 1000); // 10 min baad
        assertEquals("Live", getClassStatus(classStart, duration, currentTime));
    }

    @Test
    public void classStatus_currentTimeAfterEnd_returnsEnded() {
        long classStart = 100000L;
        long duration = 45;
        long currentTime = classStart + (60 * 60 * 1000); // 60 min baad (class 45 min ki thi)
        assertEquals("Ended", getClassStatus(classStart, duration, currentTime));
    }

    @Test
    public void classStatus_exactlyAtStartTime_returnsLive() {
        long classStart = 100000L;
        assertEquals("Live", getClassStatus(classStart, 45, classStart));
    }

    @Test
    public void classStatus_exactlyAtEndTime_returnsLive() {
        long classStart = 100000L;
        long duration = 45;
        long classEnd = classStart + (duration * 60 * 1000);
        assertEquals("Live", getClassStatus(classStart, duration, classEnd));
    }

    @Test
    public void classStatus_oneMillisecondAfterEnd_returnsEnded() {
        long classStart = 100000L;
        long duration = 45;
        long classEnd = classStart + (duration * 60 * 1000);
        assertEquals("Ended", getClassStatus(classStart, duration, classEnd + 1));
    }

    // ═══════════════════════════════════════════════════════════
    // "Join button visible only for live class" logic
    // ═══════════════════════════════════════════════════════════
    private boolean shouldShowJoinButton(String status) {
        return "Live".equals(status);
    }

    @Test
    public void joinButton_liveClass_isVisible() {
        org.junit.Assert.assertTrue(shouldShowJoinButton("Live"));
    }

    @Test
    public void joinButton_upcomingClass_isHidden() {
        org.junit.Assert.assertFalse(shouldShowJoinButton("Upcoming"));
    }

    @Test
    public void joinButton_endedClass_isHidden() {
        org.junit.Assert.assertFalse(shouldShowJoinButton("Ended"));
    }
}