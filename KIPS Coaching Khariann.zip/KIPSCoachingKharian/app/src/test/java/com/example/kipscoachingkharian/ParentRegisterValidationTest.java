package com.example.kipscoachingkharian;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.regex.Pattern;

public class ParentRegisterValidationTest {

    private static final Pattern NAME_PATTERN = Pattern.compile("^[A-Za-z ]{3,}$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^03[0-9]{9}$");
    private static final Pattern STUDENT_ID_PATTERN = Pattern.compile("^student[0-9]{1,10}$");

    // ═══════════════════════════════════════════════════════════
    // Name validation
    // ═══════════════════════════════════════════════════════════
    @Test
    public void name_validAlphabets_returnsTrue() {
        assertTrue(NAME_PATTERN.matcher("Ali Khan").matches());
    }

    @Test
    public void name_containsDigits_returnsFalse() {
        assertFalse(NAME_PATTERN.matcher("Ali123").matches());
    }

    @Test
    public void name_tooShort_returnsFalse() {
        assertFalse(NAME_PATTERN.matcher("A1").matches());
    }

    @Test
    public void name_empty_returnsFalse() {
        assertFalse(NAME_PATTERN.matcher("").matches());
    }

    @Test
    public void name_singleWord_valid_returnsTrue() {
        assertTrue(NAME_PATTERN.matcher("Ahad").matches());
    }

    // ═══════════════════════════════════════════════════════════
    // Phone number validation (03XXXXXXXXX — 11 digits)
    // ═══════════════════════════════════════════════════════════
    @Test
    public void phone_validFormat_returnsTrue() {
        assertTrue(PHONE_PATTERN.matcher("03001234567").matches());
    }

    @Test
    public void phone_tooShort_returnsFalse() {
        assertFalse(PHONE_PATTERN.matcher("12345").matches());
    }

    @Test
    public void phone_wrongPrefix_returnsFalse() {
        assertFalse(PHONE_PATTERN.matcher("13001234567").matches());
    }

    @Test
    public void phone_containsLetters_returnsFalse() {
        assertFalse(PHONE_PATTERN.matcher("0300abc4567").matches());
    }

    @Test
    public void phone_empty_returnsFalse() {
        assertFalse(PHONE_PATTERN.matcher("").matches());
    }

    @Test
    public void phone_tooLong_returnsFalse() {
        assertFalse(PHONE_PATTERN.matcher("030012345678").matches());
    }

    // ═══════════════════════════════════════════════════════════
    // Student ID format (register flow mein bhi same pattern)
    // ═══════════════════════════════════════════════════════════
    @Test
    public void registerStudentId_validFormat_returnsTrue() {
        assertTrue(STUDENT_ID_PATTERN.matcher("student001").matches());
    }

    @Test
    public void registerStudentId_invalidFormat_returnsFalse() {
        assertFalse(STUDENT_ID_PATTERN.matcher("STU-1").matches());
    }

    // ═══════════════════════════════════════════════════════════
    // Duplicate-linkage logic (jaisa: dbId.equalsIgnoreCase(inputId))
    // ═══════════════════════════════════════════════════════════
    @Test
    public void studentId_matchesDbRecord_caseInsensitive_returnsTrue() {
        String dbId = "student048";
        String inputId = "STUDENT048";
        assertTrue(dbId.equalsIgnoreCase(inputId));
    }

    @Test
    public void studentId_doesNotMatchDbRecord_returnsFalse() {
        String dbId = "student048";
        String inputId = "student999";
        assertFalse(dbId.equalsIgnoreCase(inputId));
    }
}