package com.example.kipscoachingkharian;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ParentCommunicationLogicTest {

    // ═══════════════════════════════════════════════════════════
    // Unread message indicator logic
    // (as in: dotCommunication is shown when unreadCount > 0)
    // ═══════════════════════════════════════════════════════════
    private boolean shouldShowUnreadDot(int unreadCount) {
        return unreadCount > 0;
    }

    @Test
    public void unreadDot_hasUnreadMessages_shouldShow() {
        assertTrue(shouldShowUnreadDot(3));
    }

    @Test
    public void unreadDot_noUnreadMessages_shouldNotShow() {
        assertFalse(shouldShowUnreadDot(0));
    }

    @Test
    public void unreadDot_exactlyOneUnread_shouldShow() {
        assertTrue(shouldShowUnreadDot(1));
    }

    // ═══════════════════════════════════════════════════════════
    // Chat participant eligibility (only Teacher role selectable)
    // ═══════════════════════════════════════════════════════════
    private boolean isValidChatPartner(String role) {
        return "Teacher".equalsIgnoreCase(role);
    }

    @Test
    public void chatPartner_teacherRole_isValid() {
        assertTrue(isValidChatPartner("Teacher"));
    }

    @Test
    public void chatPartner_studentRole_isNotValid() {
        assertFalse(isValidChatPartner("Student"));
    }

    @Test
    public void chatPartner_caseInsensitive_isValid() {
        assertTrue(isValidChatPartner("TEACHER"));
    }

    // ═══════════════════════════════════════════════════════════
    // Message-empty check (prevent sending blank messages)
    // ═══════════════════════════════════════════════════════════
    private boolean isSendableMessage(String messageText) {
        return messageText != null && !messageText.trim().isEmpty();
    }

    @Test
    public void message_withText_isSendable() {
        assertTrue(isSendableMessage("Hello, how is my child doing?"));
    }

    @Test
    public void message_empty_isNotSendable() {
        assertFalse(isSendableMessage(""));
    }

    @Test
    public void message_onlyWhitespace_isNotSendable() {
        assertFalse(isSendableMessage("   "));
    }

    @Test
    public void message_null_isNotSendable() {
        assertFalse(isSendableMessage(null));
    }
}