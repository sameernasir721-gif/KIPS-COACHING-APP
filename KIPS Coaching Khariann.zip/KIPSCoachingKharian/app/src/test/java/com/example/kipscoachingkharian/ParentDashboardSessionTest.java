package com.example.kipscoachingkharian;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ParentDashboardSessionTest {

    // Same logic jo ParentDashboardActivity.isValidSession() mein use hoti hai
    // (registrationId != null && !registrationId.trim().isEmpty())
    private boolean isValidSession(String registrationId) {
        return registrationId != null && !registrationId.trim().isEmpty();
    }

    // ═══════════════════════════════════════════════════════════
    // Session validity checks
    // ═══════════════════════════════════════════════════════════
    @Test
    public void session_validRegistrationId_returnsTrue() {
        assertTrue(isValidSession("student048"));
    }

    @Test
    public void session_nullRegistrationId_returnsFalse() {
        assertFalse(isValidSession(null));
    }

    @Test
    public void session_emptyRegistrationId_returnsFalse() {
        assertFalse(isValidSession(""));
    }

    @Test
    public void session_onlyWhitespace_returnsFalse() {
        assertFalse(isValidSession("   "));
    }

    @Test
    public void session_registrationIdWithSpaces_returnsTrue() {
        assertTrue(isValidSession("  student048  "));
    }

    // ═══════════════════════════════════════════════════════════
    // Role + Student ID match logic (checkStatus() ke andar)
    // (role.equalsIgnoreCase("Parent") && dbId.equalsIgnoreCase(inputId))
    // ═══════════════════════════════════════════════════════════
    private boolean isValidParentAccount(String role, String dbId, String inputId) {
        return "Parent".equalsIgnoreCase(role) && dbId != null && dbId.equalsIgnoreCase(inputId);
    }

    @Test
    public void parentAccount_correctRoleAndMatchingId_returnsTrue() {
        assertTrue(isValidParentAccount("Parent", "student048", "student048"));
    }

    @Test
    public void parentAccount_wrongRole_returnsFalse() {
        assertFalse(isValidParentAccount("Teacher", "student048", "student048"));
    }

    @Test
    public void parentAccount_mismatchedStudentId_returnsFalse() {
        assertFalse(isValidParentAccount("Parent", "student048", "student999"));
    }

    @Test
    public void parentAccount_caseInsensitiveRole_returnsTrue() {
        assertTrue(isValidParentAccount("PARENT", "student048", "student048"));
    }

    @Test
    public void parentAccount_nullDbId_returnsFalse() {
        assertFalse(isValidParentAccount("Parent", null, "student048"));
    }
}
// ════════════════════