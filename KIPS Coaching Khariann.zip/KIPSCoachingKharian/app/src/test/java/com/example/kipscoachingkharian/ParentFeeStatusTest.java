package com.example.kipscoachingkharian;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ParentFeeStatusTest {


    // Fee status check logic
    // ( "Paid".equalsIgnoreCase(status))

    private boolean isPaid(String status) {
        return "Paid".equalsIgnoreCase(status);
    }

    @Test
    public void feeStatus_paid_returnsTrue() {
        assertTrue(isPaid("Paid"));
    }

    @Test
    public void feeStatus_unpaid_returnsFalse() {
        assertFalse(isPaid("Unpaid"));
    }

    @Test
    public void feeStatus_caseInsensitive_returnsTrue() {
        assertTrue(isPaid("PAID"));
    }

    @Test
    public void feeStatus_null_returnsFalse() {
        assertFalse(isPaid(null));
    }

    @Test
    public void feeStatus_pending_returnsFalse() {
        assertFalse(isPaid("Pending"));
    }


    // Due amount calculation
    // (totalFee - amountPaid = dueAmount)

    private double calculateDue(double totalFee, double amountPaid) {
        return totalFee - amountPaid;
    }

    @Test
    public void dueAmount_noPaymentMade_equalsFullFee() {
        assertEquals(5000.0, calculateDue(5000.0, 0.0), 0.01);
    }

    @Test
    public void dueAmount_fullyPaid_equalsZero() {
        assertEquals(0.0, calculateDue(5000.0, 5000.0), 0.01);
    }

    @Test
    public void dueAmount_partiallyPaid_returnsRemainder() {
        assertEquals(2000.0, calculateDue(5000.0, 3000.0), 0.01);
    }

    // "Has pending dues" check
    // (dueAmount > 0)

    private boolean hasPendingDues(double dueAmount) {
        return dueAmount > 0;
    }

    @Test
    public void pendingDues_positiveAmount_returnsTrue() {
        assertTrue(hasPendingDues(2000.0));
    }

    @Test
    public void pendingDues_zeroAmount_returnsFalse() {
        assertFalse(hasPendingDues(0.0));
    }

    @Test
    public void pendingDues_negativeAmount_returnsFalse() {
        // overpaid case — koi due nahi
        assertFalse(hasPendingDues(-500.0));
    }


    // Fee month key existence check
    // ( Fees/<uid>/<monthKey> node finding)

    private boolean challanExists(String requestedMonth, String[] availableMonths) {
        for (String month : availableMonths) {
            if (month.equalsIgnoreCase(requestedMonth)) return true;
        }
        return false;
    }

    @Test
    public void challan_existingMonth_returnsTrue() {
        String[] months = {"July_2026", "August_2026"};
        assertTrue(challanExists("July_2026", months));
    }

    @Test
    public void challan_nonExistingMonth_returnsFalse() {
        String[] months = {"July_2026", "August_2026"};
        assertFalse(challanExists("December_2026", months));
    }
}