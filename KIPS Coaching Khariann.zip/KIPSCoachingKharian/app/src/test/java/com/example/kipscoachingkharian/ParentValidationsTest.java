package com.example.kipscoachingkharian;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.regex.Pattern;

public class ParentValidationsTest {

    // Same patterns jo ParentLoginActivity mein use hote hain
    private static final Pattern STUDENT_ID_PATTERN = Pattern.compile("^student[0-9]{1,10}$");
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PASSWORD_PATTERN = Pattern.compile(
            "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$");

    // ═══════════════════════════════════════════════════════════
    // Email validation
    // ═══════════════════════════════════════════════════════════
    @Test
    public void email_validFormat_returnsTrue() {
        assertTrue(EMAIL_PATTERN.matcher("parent@test.com").matches());
    }

    @Test
    public void email_missingAtSymbol_returnsFalse() {
        assertFalse(EMAIL_PATTERN.matcher("notanemail").matches());
    }

    @Test
    public void email_missingDomain_returnsFalse() {
        assertFalse(EMAIL_PATTERN.matcher("parent@").matches());
    }

    @Test
    public void email_empty_returnsFalse() {
        assertFalse(EMAIL_PATTERN.matcher("").matches());
    }

    // ═══════════════════════════════════════════════════════════
    // Student ID validation
    // ═══════════════════════════════════════════════════════════
    @Test
    public void studentId_validFormat_returnsTrue() {
        assertTrue(STUDENT_ID_PATTERN.matcher("student048").matches());
    }

    @Test
    public void studentId_wrongPrefix_returnsFalse() {
        assertFalse(STUDENT_ID_PATTERN.matcher("STU-048").matches());
    }

    @Test
    public void studentId_missingNumber_returnsFalse() {
        assertFalse(STUDENT_ID_PATTERN.matcher("student").matches());
    }

    @Test
    public void studentId_empty_returnsFalse() {
        assertFalse(STUDENT_ID_PATTERN.matcher("").matches());
    }

    // ═══════════════════════════════════════════════════════════
    // Password strength validation
    // ═══════════════════════════════════════════════════════════
    @Test
    public void password_strong_returnsTrue() {
        assertTrue(PASSWORD_PATTERN.matcher("Student048@").matches());
    }

    @Test
    public void password_tooShort_returnsFalse() {
        assertFalse(PASSWORD_PATTERN.matcher("Ab1@").matches());
    }

    @Test
    public void password_noUppercase_returnsFalse() {
        assertFalse(PASSWORD_PATTERN.matcher("student048@").matches());
    }

    @Test
    public void password_noSpecialChar_returnsFalse() {
        assertFalse(PASSWORD_PATTERN.matcher("Student048").matches());
    }

    @Test
    public void password_noDigit_returnsFalse() {
        assertFalse(PASSWORD_PATTERN.matcher("Student@Abc").matches());
    }

    @Test
    public void password_containsSpace_returnsFalse() {
        assertFalse(PASSWORD_PATTERN.matcher("Student 048@").matches());
    }
}