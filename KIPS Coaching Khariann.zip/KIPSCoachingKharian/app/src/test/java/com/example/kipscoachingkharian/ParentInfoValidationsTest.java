package com.example.kipscoachingkharian;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.regex.Pattern;

public class ParentInfoValidationsTest {

    // Same pattern jo ParentInfoDetailsActivity.isStrongPassword() mein use hota hai
    private static final Pattern STRONG_PASSWORD_PATTERN = Pattern.compile(
            "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$");

    // ═══════════════════════════════════════════════════════════
    // Strong password checks
    // ═══════════════════════════════════════════════════════════
    @Test
    public void newPassword_strong_returnsTrue() {
        assertTrue(STRONG_PASSWORD_PATTERN.matcher("Student048#").matches());
    }

    @Test
    public void newPassword_weak_tooShort_returnsFalse() {
        assertFalse(STRONG_PASSWORD_PATTERN.matcher("Ab1@").matches());
    }

    @Test
    public void newPassword_weak_allLowercase_returnsFalse() {
        assertFalse(STRONG_PASSWORD_PATTERN.matcher("weakpass123@").matches());
    }

    @Test
    public void newPassword_weak_noSpecialSymbol_returnsFalse() {
        assertFalse(STRONG_PASSWORD_PATTERN.matcher("Password123").matches());
    }

    @Test
    public void newPassword_weak_noDigit_returnsFalse() {
        assertFalse(STRONG_PASSWORD_PATTERN.matcher("Password@abc").matches());
    }

    @Test
    public void newPassword_weak_plainWord_returnsFalse() {
        assertFalse(STRONG_PASSWORD_PATTERN.matcher("weak").matches());
    }

    @Test
    public void newPassword_weak_containsSpace_returnsFalse() {
        assertFalse(STRONG_PASSWORD_PATTERN.matcher("Pass word1@").matches());
    }

    // ═══════════════════════════════════════════════════════════
    // Old-password / current-password matching logic
    // (jaisa validateAndUpdate() mein: inputOldPass.equals(actualStoredPassword))
    // ═══════════════════════════════════════════════════════════
    @Test
    public void oldPassword_matchesStoredPassword_returnsTrue() {
        String actualStoredPassword = "Student048@";
        String inputOldPass = "Student048@";
        assertTrue(inputOldPass.equals(actualStoredPassword));
    }

    @Test
    public void oldPassword_doesNotMatchStoredPassword_returnsFalse() {
        String actualStoredPassword = "Student048@";
        String inputOldPass = "WrongPassword1!";
        assertFalse(inputOldPass.equals(actualStoredPassword));
    }

    @Test
    public void oldPassword_empty_returnsFalse() {
        String inputOldPass = "";
        assertTrue(inputOldPass.isEmpty());
    }

    // ═══════════════════════════════════════════════════════════
    // New-password / confirm-password matching logic
    // (jaisa: !newPass.equals(confirmPass))
    // ═══════════════════════════════════════════════════════════
    @Test
    public void newPassword_matchesConfirmPassword_returnsTrue() {
        String newPass = "Student048#";
        String confirmPass = "Student048#";
        assertTrue(newPass.equals(confirmPass));
    }

    @Test
    public void newPassword_doesNotMatchConfirmPassword_returnsFalse() {
        String newPass = "Student048#";
        String confirmPass = "Different123!";
        assertFalse(newPass.equals(confirmPass));
    }

    @Test
    public void confirmPassword_empty_returnsFalse() {
        String confirmPass = "";
        assertTrue(confirmPass.isEmpty());
    }
}
