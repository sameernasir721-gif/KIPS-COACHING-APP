package com.example.kipscoachingkharian;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ParentSettingMappingTest {

    // Same mapping  ParentSettingActivity font size index ko text mein convert
    private String getFontSizeLabel(int index) {
        switch (index) {
            case 0: return "Small";
            case 1: return "Medium";
            case 2: return "Large";
            default: return "Medium";
        }
    }


    // Font size mapping

    @Test
    public void fontSize_indexZero_returnsSmall() {
        assertEquals("Small", getFontSizeLabel(0));
    }

    @Test
    public void fontSize_indexOne_returnsMedium() {
        assertEquals("Medium", getFontSizeLabel(1));
    }

    @Test
    public void fontSize_indexTwo_returnsLarge() {
        assertEquals("Large", getFontSizeLabel(2));
    }

    @Test
    public void fontSize_invalidIndex_returnsDefaultMedium() {
        assertEquals("Medium", getFontSizeLabel(99));
    }


    // Theme mapping

    private String getThemeLabel(int index) {
        switch (index) {
            case 0: return "White";
            case 1: return "Black";
            default: return "White";
        }
    }

    @Test
    public void theme_indexZero_returnsWhite() {
        assertEquals("White", getThemeLabel(0));
    }

    @Test
    public void theme_indexOne_returnsBlack() {
        assertEquals("Black", getThemeLabel(1));
    }

    @Test
    public void theme_invalidIndex_returnsDefaultWhite() {
        assertEquals("White", getThemeLabel(50));
    }


    // Default values SharedPreferences empty
    // ( prefs.getInt("parent_font_size", 1))

    private int getSavedValueOrDefault(Integer savedValue, int defaultValue) {
        return savedValue != null ? savedValue : defaultValue;
    }

    @Test
    public void savedFontSize_notSet_returnsDefault() {
        assertEquals(1, getSavedValueOrDefault(null, 1)); // 1 = Medium
    }

    @Test
    public void savedFontSize_previouslySet_returnsSavedValue() {
        assertEquals(0, getSavedValueOrDefault(0, 1)); // Small was saved
    }

    @Test
    public void savedTheme_notSet_returnsDefaultWhite() {
        assertEquals(0, getSavedValueOrDefault(null, 0)); // 0 = White
    }
}