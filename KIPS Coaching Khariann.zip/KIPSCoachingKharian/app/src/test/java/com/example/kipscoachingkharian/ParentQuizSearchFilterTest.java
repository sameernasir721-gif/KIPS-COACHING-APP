package com.example.kipscoachingkharian;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ParentQuizSearchFilterTest {


    private boolean matchesSearch(String title, String query) {
        return title.toLowerCase().contains(query.toLowerCase());
    }

    // Search matching logic

    @Test
    public void search_exactMatch_returnsTrue() {
        assertTrue(matchesSearch("chapter 3", "chapter 3"));
    }

    @Test
    public void search_partialMatch_returnsTrue() {
        assertTrue(matchesSearch("chapter 3", "chap"));
    }

    @Test
    public void search_caseInsensitive_returnsTrue() {
        assertTrue(matchesSearch("Chapter 3", "CHAPTER"));
    }

    @Test
    public void search_noMatch_returnsFalse() {
        assertFalse(matchesSearch("chapter 3", "zzz_no_such_quiz"));
    }

    @Test
    public void search_emptyQuery_matchesEverything() {
        assertTrue(matchesSearch("chapter 3", ""));
    }

    @Test
    public void search_matchesMiddleOfString_returnsTrue() {
        assertTrue(matchesSearch("Mathematics chapter 9", "chapter"));
    }

    @Test
    public void search_extraSpaces_stillNoMatch() {
        assertFalse(matchesSearch("chapter 3", "chapter 5"));
    }


    private boolean matchesSubjectFilter(String quizSubject, String selectedFilter) {
        return selectedFilter.equals("All") || quizSubject.equals(selectedFilter);
    }

    @Test
    public void subjectFilter_allSelected_matchesAnySubject() {
        assertTrue(matchesSubjectFilter("Mathematics", "All"));
        assertTrue(matchesSubjectFilter("Physics", "All"));
    }

    @Test
    public void subjectFilter_specificSubject_matchesSameSubject() {
        assertTrue(matchesSubjectFilter("Mathematics", "Mathematics"));
    }

    @Test
    public void subjectFilter_specificSubject_doesNotMatchDifferentSubject() {
        assertFalse(matchesSubjectFilter("Physics", "Mathematics"));
    }
}