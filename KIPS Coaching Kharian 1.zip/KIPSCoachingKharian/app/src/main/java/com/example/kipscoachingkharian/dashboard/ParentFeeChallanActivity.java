package com.example.kipscoachingkharian.dashboard;

import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * Parent side — child ka fee challan (admin jaise format mein) view + print/save-PDF.
 * Data Fees/{childUid}/{monthKey} se aata hai (jo admin ne generate kiya).
 * Print ke liye Android ka built-in PrintManager (koi external library nahi) —
 * user system dialog se "Save as PDF" bhi kar sakta hai.
 */
public class ParentFeeChallanActivity extends AppCompatActivity {

    private WebView webChallan;
    private ProgressBar challanProgress;
    private MaterialButton btnDownloadChallan;
    private ImageView ivBack;

    private String childUid, monthKey, childName = "Student";
    private boolean challanReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_fee_challan);

        webChallan         = findViewById(R.id.webChallan);
        challanProgress    = findViewById(R.id.challanProgress);
        btnDownloadChallan = findViewById(R.id.btnDownloadChallan);
        ivBack             = findViewById(R.id.ivBack);

        if (ivBack != null) ivBack.setOnClickListener(v -> finish());

        childUid = getIntent().getStringExtra("child_uid");
        String month = getIntent().getStringExtra("fee_month");
        monthKey = (month != null) ? month.trim().replace(" ", "_") : "";

        if (btnDownloadChallan != null) {
            btnDownloadChallan.setEnabled(false);
            btnDownloadChallan.setOnClickListener(v -> printChallan());
        }

        if (childUid == null || childUid.isEmpty() || monthKey.isEmpty()) {
            Toast.makeText(this, "Challan data not available", Toast.LENGTH_LONG).show();
            return;
        }
        loadChallan();
    }

    private void loadChallan() {
        if (challanProgress != null) challanProgress.setVisibility(View.VISIBLE);

        FirebaseDatabase.getInstance().getReference("Fees")
                .child(childUid).child(monthKey)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snap) {
                        if (challanProgress != null) challanProgress.setVisibility(View.GONE);
                        if (!snap.exists()) {
                            Toast.makeText(ParentFeeChallanActivity.this,
                                    "Is month ka challan nahi mila", Toast.LENGTH_LONG).show();
                            return;
                        }
                        String html = buildChallanHtml(snap);
                        if (webChallan != null) {
                            webChallan.setWebViewClient(new WebViewClient() {
                                @Override public void onPageFinished(WebView view, String url) {
                                    challanReady = true;
                                    if (btnDownloadChallan != null) btnDownloadChallan.setEnabled(true);
                                }
                            });
                            webChallan.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {
                        if (challanProgress != null) challanProgress.setVisibility(View.GONE);
                        Toast.makeText(ParentFeeChallanActivity.this,
                                "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private String val(DataSnapshot snap, String key, String def) {
        Object o = snap.child(key).getValue();
        return o != null ? o.toString() : def;
    }

    private String buildChallanHtml(DataSnapshot snap) {
        childName          = val(snap, "studentName", "Student");
        String className   = val(snap, "className", "-");
        String month       = val(snap, "month", monthKey.replace("_", " "));
        String dueDate     = val(snap, "dueDate", "-");
        String baseFee     = val(snap, "baseFee", "0");
        String lateFine    = val(snap, "lateFine", "0");
        String amount      = val(snap, "amount", "0");
        String status      = val(snap, "status", "Unpaid");
        String perSubject  = val(snap, "feePerSubject", "");
        String totalSubs   = val(snap, "totalSubjects", "");

        boolean paid = "Paid".equalsIgnoreCase(status);
        String statusColor = paid ? "#2E7D32" : "#C62828";

        // Subjects list (naam) — feePerSubject ek single value hai (map nahi)
        StringBuilder subjList = new StringBuilder();
        DataSnapshot subjectsSnap = snap.child("subjects");
        int subjCount = 0;
        if (subjectsSnap.exists()) {
            for (DataSnapshot s : subjectsSnap.getChildren()) {
                String sub = s.getValue() != null ? s.getValue().toString() : null;
                if (sub == null || sub.isEmpty()) continue;
                if (subjList.length() > 0) subjList.append(", ");
                subjList.append(escape(sub));
                subjCount++;
            }
        }
        if (totalSubs.isEmpty() && subjCount > 0) totalSubs = String.valueOf(subjCount);

        // Fee breakdown rows — sab stored (sahi) values se
        StringBuilder rows = new StringBuilder();
        if (!perSubject.isEmpty()) {
            rows.append("<tr><td>Fee per subject</td><td style='text-align:right'>Rs ")
                    .append(escape(perSubject)).append("</td></tr>");
        }
        if (!totalSubs.isEmpty()) {
            rows.append("<tr><td>Number of subjects</td><td style='text-align:right'>")
                    .append(escape(totalSubs)).append("</td></tr>");
        }
        rows.append("<tr><td>Tuition Fee</td><td style='text-align:right'>Rs ")
                .append(escape(baseFee)).append("</td></tr>");
        long fineL = parseLong(lateFine);
        if (fineL > 0) {
            rows.append("<tr><td>Late Fine</td><td style='text-align:right;color:#C62828'>Rs ")
                    .append(escape(lateFine)).append("</td></tr>");
        }

        return "<!DOCTYPE html><html><head><meta name='viewport' "
                + "content='width=device-width, initial-scale=1'>"
                + "<style>"
                + "body{font-family:sans-serif;color:#222;margin:0;padding:18px;}"
                + ".hd{text-align:center;border-bottom:2px solid #D50000;padding-bottom:10px;margin-bottom:14px;}"
                + ".hd h2{margin:0;color:#D50000;}"
                + ".hd p{margin:2px 0;font-size:12px;color:#666;}"
                + ".info{font-size:14px;margin:4px 0;}"
                + ".info b{display:inline-block;width:110px;color:#555;}"
                + "table{width:100%;border-collapse:collapse;margin-top:12px;font-size:14px;}"
                + "th,td{border:1px solid #ddd;padding:8px;}"
                + "th{background:#F8E8EA;color:#D50000;text-align:left;}"
                + ".total{font-size:18px;font-weight:bold;margin-top:14px;text-align:right;color:#D50000;}"
                + ".status{display:inline-block;margin-top:10px;padding:5px 14px;border-radius:6px;"
                + "color:#fff;font-weight:bold;background:" + statusColor + ";}"
                + "</style></head><body>"
                + "<div class='hd'><h2>KIPS Coaching Kharian</h2><p>Fee Challan</p></div>"
                + "<p class='info'><b>Student:</b> " + escape(childName) + "</p>"
                + "<p class='info'><b>Class:</b> " + escape(className) + "</p>"
                + "<p class='info'><b>Month:</b> " + escape(month) + "</p>"
                + "<p class='info'><b>Due Date:</b> " + escape(dueDate) + "</p>"
                + (subjList.length() > 0
                ? "<p class='info'><b>Subjects:</b> " + subjList + "</p>" : "")
                + "<table><tr><th>Description</th><th style='text-align:right'>Amount</th></tr>"
                + rows + "</table>"
                + "<p class='total'>Total Payable: Rs " + escape(amount) + "</p>"
                + "<span class='status'>" + escape(status) + "</span>"
                + "</body></html>";
    }

    private void printChallan() {
        if (!challanReady || webChallan == null) {
            Toast.makeText(this, "Challan load ho raha hai...", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
            if (printManager == null) {
                Toast.makeText(this, "Print service available nahi", Toast.LENGTH_SHORT).show();
                return;
            }
            String jobName = "FeeChallan_" + childName.replace(" ", "_") + "_" + monthKey;
            PrintDocumentAdapter adapter = webChallan.createPrintDocumentAdapter(jobName);
            printManager.print(jobName, adapter, new PrintAttributes.Builder().build());
            // System dialog khulega — wahan se "Save as PDF" bhi ho sakta hai
        } catch (Exception e) {
            Toast.makeText(this, "Print error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private long parseLong(String s) {
        if (s == null || s.trim().isEmpty()) return 0;
        try { return Long.parseLong(s.trim()); }
        catch (NumberFormatException e) { return 0; }
    }
}