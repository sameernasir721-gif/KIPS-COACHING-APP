package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ParentPickerActivity extends AppCompatActivity {

    private RecyclerView rvParents;
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private EditText etSearch;

    private ParentPickerAdapter adapter;
    private final List<UserItem> allParents  = new ArrayList<>();
    private final List<UserItem> filteredList = new ArrayList<>();

    private String myName, myRole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_picker);

        myName = getIntent().getStringExtra("MY_NAME");
        myRole = getIntent().getStringExtra("MY_ROLE");

        rvParents   = findViewById(R.id.rvParents);
        progressBar = findViewById(R.id.progressBar);
        tvEmpty     = findViewById(R.id.tvEmpty);
        etSearch    = findViewById(R.id.etSearch);

        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        adapter = new ParentPickerAdapter(filteredList, user -> {
            Intent intent = new Intent(ParentPickerActivity.this, ChatActivity.class);
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_ID,   user.uid);
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_NAME, user.name);
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_ROLE, "Parent");
            intent.putExtra(ChatActivity.EXTRA_MY_NAME,       myName);
            intent.putExtra(ChatActivity.EXTRA_MY_ROLE,       myRole);
            startActivity(intent);
        });

        rvParents.setLayoutManager(new LinearLayoutManager(this));
        rvParents.setAdapter(adapter);

        // Load data but keep display empty initially
        loadParents();

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
            @Override public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                filter(s.toString());
            }
            @Override public void afterTextChanged(Editable e) {}
        });
    }

    private void loadParents() {
        progressBar.setVisibility(View.VISIBLE);

        // Show guidance text initially
        tvEmpty.setText("Type a name to search for a parent");
        tvEmpty.setVisibility(View.VISIBLE);

        FirebaseDatabase.getInstance().getReference("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        allParents.clear();
                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String role = ds.child("role").getValue(String.class);

                            if (role != null && role.equalsIgnoreCase("Parent")) {
                                String name  = ds.child("name").getValue(String.class);
                                String phone = ds.child("phone").getValue(String.class);
                                // Student ID = parent node ka registrationId (linked student)
                                String regId = ds.child("registrationId").getValue(String.class);
                                String studentId = (regId != null && !regId.isEmpty())
                                        ? ("Student ID: " + regId)
                                        : "No Student ID";

                                allParents.add(new UserItem(
                                        ds.getKey(),
                                        name  != null ? name  : "Unknown",
                                        phone != null ? phone : "",
                                        studentId
                                ));
                            }
                        }
                        progressBar.setVisibility(View.GONE);
                        // filteredList stays empty until user types
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(ParentPickerActivity.this, "Error loading data", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void filter(String query) {
        filteredList.clear();
        String searchKey = query.toLowerCase().trim();

        // ONLY search if the user has typed something
        if (!searchKey.isEmpty()) {
            for (UserItem u : allParents) {
                if (u.name.toLowerCase().contains(searchKey)) {
                    filteredList.add(u);
                }
            }
        }

        adapter.notifyDataSetChanged();

        // Update Visibility Logic
        if (searchKey.isEmpty()) {
            tvEmpty.setText("Type a name to search for a parent");
            tvEmpty.setVisibility(View.VISIBLE);
        } else if (filteredList.isEmpty()) {
            tvEmpty.setText("No parents found with that name");
            tvEmpty.setVisibility(View.VISIBLE);
        } else {
            tvEmpty.setVisibility(View.GONE);
        }
    }

    static class UserItem {
        String uid, name, phone, studentId;

        // 4-arg: ParentPicker (studentId ke saath)
        UserItem(String uid, String name, String phone, String studentId) {
            this.uid = uid; this.name = name; this.phone = phone; this.studentId = studentId;
        }

        // 3-arg: TeacherPicker (purana use — studentId khali, phone field subject hold karti hai)
        UserItem(String uid, String name, String phone) {
            this(uid, name, phone, "");
        }
    }

    static class ParentPickerAdapter extends RecyclerView.Adapter<ParentPickerAdapter.VH> {
        interface OnPickListener { void onPick(UserItem user); }
        private final List<UserItem> list;
        private final OnPickListener listener;

        ParentPickerAdapter(List<UserItem> list, OnPickListener listener) {
            this.list = list; this.listener = listener;
        }

        @NonNull @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_parent_pick_row, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int pos) {
            UserItem u = list.get(pos);
            h.tvName.setText(u.name);
            h.tvPhone.setText(u.studentId);   // name ke neeche Student ID
            if (u.name != null && !u.name.isEmpty()) {
                h.tvAvatar.setText(String.valueOf(u.name.charAt(0)).toUpperCase());
            }
            h.itemView.setOnClickListener(v -> listener.onPick(u));
        }

        @Override public int getItemCount() { return list.size(); }

        static class VH extends RecyclerView.ViewHolder {
            TextView tvAvatar, tvName, tvPhone;
            VH(@NonNull View v) {
                super(v);
                tvAvatar = v.findViewById(R.id.tvPickAvatar);
                tvName   = v.findViewById(R.id.tvPickName);
                tvPhone  = v.findViewById(R.id.tvPickPhone);
            }
        }
    }
}