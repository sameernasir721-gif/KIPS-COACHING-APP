package com.example.kipscoachingkharian.dashboard;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CommunicationActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private BottomNavigationView bottomNav;
    private RecyclerView rvConversations;
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private FloatingActionButton fabNewChat;
    private EditText etSearch;

    private ConversationAdapter conversationAdapter;
    private final List<Conversation> conversationList = new ArrayList<>();
    private final List<Conversation> filteredList = new ArrayList<>();

    private String myUid, myName;
    private DatabaseReference indexRef;

    // ── Notifications: parent side jaisa per-conversation popup ──
    private static final String TEACHER_CHANNEL_ID = "teacher_chat_channel";
    private final java.util.Map<String, Integer> knownUnreadMap = new java.util.HashMap<>();
    private boolean firstLoad = true;   // app khulte hi purane unread pe spam na ho

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_communication);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) { finish(); return; }
        myUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        initViews();
        loadMyName();
        setupBottomNav();
        loadConversations();
        createNotificationChannel(); // Channel initialize karein
    }

    private void initViews() {
        drawerLayout    = findViewById(R.id.drawerLayout);
        navigationView  = findViewById(R.id.navigationView);
        bottomNav       = findViewById(R.id.bottomNav);
        rvConversations = findViewById(R.id.rvConversations);
        progressBar     = findViewById(R.id.progressBar);
        tvEmpty         = findViewById(R.id.tvEmpty);
        fabNewChat      = findViewById(R.id.fabNewChat);
        etSearch        = findViewById(R.id.etSearch);

        navigationView.setNavigationItemSelectedListener(this);

        ImageView ivMenu = findViewById(R.id.ivMenu);
        if (ivMenu != null) ivMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
            @Override public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                filter(s.toString());
            }
            @Override public void afterTextChanged(Editable e) {}
        });

        conversationAdapter = new ConversationAdapter(this, filteredList, conv -> {
            Intent intent = new Intent(CommunicationActivity.this, ChatActivity.class);
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_ID,   conv.getOtherUserId());
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_NAME, conv.getOtherUserName());
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_ROLE, conv.getOtherUserRole());
            intent.putExtra(ChatActivity.EXTRA_MY_NAME,       myName);
            intent.putExtra(ChatActivity.EXTRA_MY_ROLE,       "Teacher");
            startActivity(intent);
        });
        rvConversations.setLayoutManager(new LinearLayoutManager(this));
        rvConversations.setAdapter(conversationAdapter);

        fabNewChat.setOnClickListener(v -> {
            Intent intent = new Intent(CommunicationActivity.this, ParentPickerActivity.class);
            intent.putExtra("MY_NAME", myName);
            intent.putExtra("MY_ROLE", "Teacher");
            startActivity(intent);
        });
    }

    private void loadMyName() {
        FirebaseDatabase.getInstance().getReference("Users").child(myUid)
                .child("name").get()
                .addOnSuccessListener(snap -> {
                    myName = snap.exists() && snap.getValue(String.class) != null
                            ? snap.getValue(String.class) : "Teacher";
                });
    }

    private void loadConversations() {
        indexRef = FirebaseDatabase.getInstance()
                .getReference("ConversationIndex").child(myUid);

        progressBar.setVisibility(View.VISIBLE);

        indexRef.orderByChild("lastTimestamp").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                conversationList.clear();

                for (DataSnapshot ds : snapshot.getChildren()) {
                    Conversation conv = ds.getValue(Conversation.class);
                    if (conv == null) continue;

                    // ── Per-conversation notification trigger ──
                    int newUnread = conv.getUnreadCount();
                    String convId = conv.getConversationId() != null
                            ? conv.getConversationId() : ds.getKey();
                    int prevUnread = knownUnreadMap.containsKey(convId)
                            ? knownUnreadMap.get(convId) : 0;

                    // unread badha = parent ne naya message bheja → popup
                    // firstLoad pe notify na karo (sirf map seed karo)
                    if (!firstLoad && newUnread > prevUnread) {
                        showChatNotification(conv);
                    }
                    knownUnreadMap.put(convId, newUnread);

                    conversationList.add(0, conv);
                }
                firstLoad = false;

                filter(etSearch.getText().toString());
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
            }
        });
    }

    // --- Notification Logic ---
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    TEACHER_CHANNEL_ID, "Parent Messages",
                    NotificationManager.IMPORTANCE_HIGH);   // HIGH = heads-up popup
            channel.setDescription("Messages from Parents");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void showChatNotification(Conversation conv) {
        String sender  = conv.getOtherUserName() != null ? conv.getOtherUserName() : "Parent";
        String message = conv.getLastMessage()   != null ? conv.getLastMessage()   : "New message";

        // Tap par usi parent ke saath chat khule
        Intent openChat = new Intent(this, ChatActivity.class);
        openChat.putExtra(ChatActivity.EXTRA_RECEIVER_ID,   conv.getOtherUserId());
        openChat.putExtra(ChatActivity.EXTRA_RECEIVER_NAME, conv.getOtherUserName());
        openChat.putExtra(ChatActivity.EXTRA_RECEIVER_ROLE, conv.getOtherUserRole());
        openChat.putExtra(ChatActivity.EXTRA_MY_NAME,       myName);
        openChat.putExtra(ChatActivity.EXTRA_MY_ROLE,       "Teacher");
        openChat.putExtra(ChatActivity.EXTRA_OTHER_DETAIL,  conv.getOtherUserDetail());
        openChat.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        String convId = conv.getConversationId() != null
                ? conv.getConversationId() : conv.getOtherUserId();
        int notifId = convId != null ? convId.hashCode() : 1;

        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, notifId, openChat,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this, TEACHER_CHANNEL_ID)
                        .setSmallIcon(R.drawable.app_logo)
                        .setContentTitle("Message from " + sender)
                        .setContentText(message)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                        .setPriority(NotificationCompat.PRIORITY_HIGH)   // heads-up
                        .setAutoCancel(true)
                        .setContentIntent(pendingIntent);

        NotificationManager manager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(notifId, builder.build());
    }

    private void filter(String query) {
        filteredList.clear();
        for (Conversation conv : conversationList) {
            if (conv.getOtherUserName().toLowerCase().contains(query.toLowerCase().trim())) {
                filteredList.add(conv);
            }
        }
        conversationAdapter.notifyDataSetChanged();

        if (filteredList.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText(query.isEmpty() ? "No conversations yet." : "No results found.");
        } else {
            tvEmpty.setVisibility(View.GONE);
        }
    }

    private void setupBottomNav() {
        bottomNav.setSelectedItemId(R.id.nav_bottom_Message);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                Intent i = new Intent(this, TeacherDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i); finish(); return true;
            } else if (id == R.id.nav_bottom_Message) {
                return true;
            } else if (id == R.id.nav_bottom_Announcment) {
                startActivity(new Intent(this, TeacherAnnouncementsActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileMenuActivity.class));
                finish(); return true;
            }
            return false;
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_change_password) {
            Toast.makeText(this, "Change Password", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_logout) {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(this, LoginSelectionActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent); finishAffinity();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}