package com.example.kipscoachingkharian.dashboard;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class TeacherDashboardActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private TextView tvTeacherName, tvTeacherID;
    private ImageView ivNotification;

    // Layouts
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private BottomNavigationView bottomNav;

    // Cards
    private CardView cardStudents, cardCreateClasses, cardStudyMaterial, cardQuizzes;
    private CardView cardAssignments, cardStudentProgress, cardSyllabus, cardTimeSchedule;

    // Today at a Glance
    private TextView tvSeeAll;
    private TextView tvGlanceClasses, tvGlanceAssignments, tvGlanceSubmissions, tvGlanceQuizzes;
    private MaterialCardView cardGlanceClasses, cardGlanceAssignments, cardGlanceSubmissions, cardGlanceQuizzes;

    private String teacherUid;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_dashboard);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, LoginSelectionActivity.class));
            finish();
            return;
        }
        teacherUid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        dbRef = FirebaseDatabase.getInstance().getReference();

        // --- Init Views ---
        tvTeacherName  = findViewById(R.id.tvTeacherName);
        tvTeacherID    = findViewById(R.id.tvTeacherID);
        drawerLayout   = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);
        bottomNav      = findViewById(R.id.bottomNav);

        ImageView ivMenu = findViewById(R.id.ivMenu);
        ivMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
        navigationView.setNavigationItemSelectedListener(this);

        // --- Init Cards ---
        cardStudents        = findViewById(R.id.cardStudent);
        cardCreateClasses   = findViewById(R.id.cardCreateClasses);
        cardStudyMaterial   = findViewById(R.id.cardStudyMaterial);
        cardQuizzes         = findViewById(R.id.cardQuizzes);
        cardAssignments     = findViewById(R.id.cardAssignments);
        cardStudentProgress = findViewById(R.id.cardPerformance);
        cardSyllabus        = findViewById(R.id.Syllabus);
        cardTimeSchedule    = findViewById(R.id.TimeSchedule);

        // --- Today at a Glance ---
        tvSeeAll             = findViewById(R.id.tvSeeAll);
        tvGlanceClasses      = findViewById(R.id.tvGlanceClasses);
        tvGlanceAssignments  = findViewById(R.id.tvGlanceAssignments);
        tvGlanceSubmissions  = findViewById(R.id.tvGlanceSubmissions);
        tvGlanceQuizzes      = findViewById(R.id.tvGlanceQuizzes);
        cardGlanceClasses    = findViewById(R.id.cardGlanceClasses);
        cardGlanceAssignments= findViewById(R.id.cardGlanceAssignments);
        cardGlanceSubmissions= findViewById(R.id.cardGlanceSubmissions);
        cardGlanceQuizzes    = findViewById(R.id.cardGlanceQuizzes);

        // --- Load Data ---
        fetchTeacherDetails();
        loadTodayAtAGlance();


        // --- Bottom Navigation ---
        bottomNav.setSelectedItemId(R.id.nav_bottom_home);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                return true;
            } else if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class));
                return true;
            } else if (id == R.id.nav_bottom_Announcment) {
                startActivity(new Intent(this, TeacherAnnouncementsActivity.class));
                return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileMenuActivity.class));
                return true;
            }
            return false;
        });

        // --- Setup Card Clicks ---
        setupCardClicks();

        // --- Search Bar ---
        EditText etSearch = findViewById(R.id.etSearch);
        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
                @Override public void afterTextChanged(Editable s) {
                    filterCards(s.toString().trim().toLowerCase());
                }
            });
        }

        requestNotificationPermissionIfNeeded();
    }

    // ── Android 13+ par popup notifications dikhane ke liye permission zaroori hai ──
    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
    }

    // ── Search filter — cards show/hide based on query ────────────────────────
    private void filterCards(String query) {
        String[] labels = {
                "students",
                "create classes",
                "study material",
                "quizzes",
                "assignments",
                "student progress",
                "syllabus",
                "time schedule",
        };

        CardView[] cards = {
                cardStudents, cardCreateClasses, cardStudyMaterial, cardQuizzes,
                cardAssignments, cardStudentProgress, cardSyllabus, cardTimeSchedule
        };

        if (query.isEmpty()) {
            for (CardView c : cards) if (c != null) c.setVisibility(android.view.View.VISIBLE);
            return;
        }

        for (int i = 0; i < cards.length; i++) {
            if (cards[i] == null) continue;
            boolean match = labels[i].contains(query) || query.contains(labels[i]);
            cards[i].setVisibility(match ? android.view.View.VISIBLE : android.view.View.GONE);
        }
    }

    // ── Main grid card clicks ─────────────────────────────────────────────────
    private void setupCardClicks() {
        cardStudents.setOnClickListener(v ->
                startActivity(new Intent(this, StudentListActivity.class)));

        cardCreateClasses.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherCreateClassActivity.class)));

        cardStudyMaterial.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherStudyMaterialActivity.class)));

        cardQuizzes.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherQuizzesActivity.class)));

        cardAssignments.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherAssignmentActivity.class)));

        cardStudentProgress.setOnClickListener(v ->
                startActivity(new Intent(this, StudentProgressActivity.class)));

        cardSyllabus.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherSyllabusActivity.class)));

        cardTimeSchedule.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherTimeScheduleActivity.class)));
    }

    // ── Today at a Glance — Firebase se real data ─────────────────────────────
    private void loadTodayAtAGlance() {
        // Aaj ki date — "d/M/yyyy" format (Classes mein isi format se save hoti hai)
        String todayFormatted = new SimpleDateFormat("d/M/yyyy", Locale.getDefault()).format(new Date());
        // Assignment/Quiz dueDate format "dd/MM/yyyy" bhi check karo
        String todayFull = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());

        // 4 parallel checks
        loadClassesToday(todayFormatted, todayFull);
        loadAssignmentsDueToday(todayFormatted, todayFull);
        loadSubmissionsPending();
        loadActiveQuizzesToday(todayFormatted, todayFull);

        // See All — Full page Today at a Glance screen
        tvSeeAll.setOnClickListener(v ->
                startActivity(new Intent(this, TodayAtAGlanceActivity.class)));

        // Classes Today row
        cardGlanceClasses.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherCreateClassActivity.class)));

        // Assignments Due Today row
        cardGlanceAssignments.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherAssignmentActivity.class)));

        // Submissions to Check row — AllSubmissionsActivity direct
        cardGlanceSubmissions.setOnClickListener(v ->
                startActivity(new Intent(this, AllSubmissionsActivity.class)));

        // Active Quizzes row
        cardGlanceQuizzes.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherQuizzesActivity.class)));
    }

    // ── 1. Aaj ki Classes ─────────────────────────────────────────────────────
    private void loadClassesToday(String todayShort, String todayFull) {
        dbRef.child("Classes").child(teacherUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        int count = 0;
                        for (DataSnapshot cls : snapshot.getChildren()) {
                            String date = cls.child("date").getValue(String.class);
                            if (date != null &&
                                    (date.equals(todayShort) || date.equals(todayFull))) {
                                count++;
                            }
                        }
                        final int total = count;
                        if (tvGlanceClasses != null) {
                            tvGlanceClasses.setText(total == 0
                                    ? "Classes Today — None scheduled"
                                    : "Classes Today — " + total + (total == 1 ? " class" : " classes"));
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (tvGlanceClasses != null)
                            tvGlanceClasses.setText("Classes Today — Error loading");
                    }
                });
    }

    // ── 2. Aaj deadline wali Assignments ──────────────────────────────────────
    private void loadAssignmentsDueToday(String todayShort, String todayFull) {
        dbRef.child("Assignments").child(teacherUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        int count = 0;
                        for (DataSnapshot asgn : snapshot.getChildren()) {
                            String dueDate = asgn.child("dueDate").getValue(String.class);
                            if (dueDate != null &&
                                    (dueDate.equals(todayShort) || dueDate.equals(todayFull))) {
                                count++;
                            }
                        }
                        final int total = count;
                        if (tvGlanceAssignments != null) {
                            tvGlanceAssignments.setText(total == 0
                                    ? "Assignments Due Today — None"
                                    : "Assignments Due Today — " + total);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (tvGlanceAssignments != null)
                            tvGlanceAssignments.setText("Assignments Due Today — Error");
                    }
                });
    }

    // ── 3. Submissions jo abhi check nahi hue (grade/marks nahi laga) ─────────
    private void loadSubmissionsPending() {
        // Pehle teacher ki sari assignments lao, phir har assignment ki submissions check karo
        dbRef.child("Assignments").child(teacherUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                            if (tvGlanceSubmissions != null)
                                tvGlanceSubmissions.setText("Submissions to Check — None");
                            return;
                        }

                        int totalAssignments = (int) snapshot.getChildrenCount();
                        AtomicInteger remaining = new AtomicInteger(totalAssignments);
                        AtomicInteger pendingCount = new AtomicInteger(0);

                        for (DataSnapshot asgn : snapshot.getChildren()) {
                            String assignmentKey = asgn.getKey();
                            if (assignmentKey == null) {
                                if (remaining.decrementAndGet() == 0) updateSubmissionsText(pendingCount.get());
                                continue;
                            }

                            dbRef.child("Submissions").child(assignmentKey)
                                    .addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot subSnap) {
                                            for (DataSnapshot sub : subSnap.getChildren()) {
                                                // "grade" ya "marks" field nahi hai = unchecked
                                                Object grade  = sub.child("grade").getValue();
                                                Object marks  = sub.child("marks").getValue();
                                                Object checked = sub.child("checked").getValue();
                                                if (grade == null && marks == null && !Boolean.TRUE.equals(checked)) {
                                                    pendingCount.incrementAndGet();
                                                }
                                            }
                                            if (remaining.decrementAndGet() == 0)
                                                updateSubmissionsText(pendingCount.get());
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {
                                            if (remaining.decrementAndGet() == 0)
                                                updateSubmissionsText(pendingCount.get());
                                        }
                                    });
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (tvGlanceSubmissions != null)
                            tvGlanceSubmissions.setText("Submissions to Check — Error");
                    }
                });
    }

    private void updateSubmissionsText(int count) {
        runOnUiThread(() -> {
            if (tvGlanceSubmissions != null) {
                tvGlanceSubmissions.setText(count == 0
                        ? "Submissions to Check — All done ✓"
                        : "Submissions to Check — " + count + " pending");
            }
        });
    }

    // ── 4. Active Quizzes (jo aaj bhi chalein) ────────────────────────────────
    private void loadActiveQuizzesToday(String todayShort, String todayFull) {
        dbRef.child("Quizzes").child(teacherUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        int active = 0;
                        int attemptsTotal = 0;

                        for (DataSnapshot quiz : snapshot.getChildren()) {
                            String status  = quiz.child("status").getValue(String.class);
                            String endDate = quiz.child("endDate").getValue(String.class);

                            if ("active".equalsIgnoreCase(status)) {
                                // Deadline aaj ya baad mein = still running
                                if (endDate == null || endDate.isEmpty()
                                        || endDate.equals(todayShort)
                                        || endDate.equals(todayFull)
                                        || !isDateBefore(endDate, todayFull)) {
                                    active++;
                                }
                            }
                        }

                        final int totalActive = active;
                        if (tvGlanceQuizzes != null) {
                            tvGlanceQuizzes.setText(totalActive == 0
                                    ? "Active Quizzes — None running"
                                    : "Active Quizzes — " + totalActive + " running");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (tvGlanceQuizzes != null)
                            tvGlanceQuizzes.setText("Active Quizzes — Error");
                    }
                });
    }

    /**
     * Check karo kya dateStr (dd/MM/yyyy) today se pehle hai
     * Returns true agar date already past ho gayi
     */
    private boolean isDateBefore(String dateStr, String todayStr) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date d     = sdf.parse(dateStr);
            Date today = sdf.parse(todayStr);
            if (d == null || today == null) return false;
            return d.before(today);
        } catch (Exception e) {
            return false;
        }
    }

    // ── Drawer ────────────────────────────────────────────────────────────────
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_change_password) {
            showChangePasswordDialog();
        } else if (id == R.id.nav_logout) {
            showLogoutDialog();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ── Logout ────────────────────────────────────────────────────────────────
    private void showLogoutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Do you want to logout?")
                .setPositiveButton("Yes, Logout", (dialog, which) -> {
                    FirebaseAuth.getInstance().signOut();
                    Intent intent = new Intent(this, LoginSelectionActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finishAffinity();
                })
                .setNegativeButton("Cancel", null)
                .setIcon(R.drawable.ic_power)
                .show();
    }

    // ── Change Password ──────────────────────────────────────────────────────
    private void showChangePasswordDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 30, 50, 10);

        final EditText etOldPass = new EditText(this);
        etOldPass.setHint("Current Password");
        etOldPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        layout.addView(etOldPass);

        final EditText etNewPass = new EditText(this);
        etNewPass.setHint("New Password (min 6 chars)");
        etNewPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        layout.addView(etNewPass);

        final EditText etConfirmPass = new EditText(this);
        etConfirmPass.setHint("Confirm New Password");
        etConfirmPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        layout.addView(etConfirmPass);

        new AlertDialog.Builder(this)
                .setTitle("Change Password")
                .setView(layout)
                .setPositiveButton("Update", (dialog, which) -> {
                    String oldPass     = etOldPass.getText().toString().trim();
                    String newPass     = etNewPass.getText().toString().trim();
                    String confirmPass = etConfirmPass.getText().toString().trim();

                    if (newPass.length() < 6) {
                        showToast("Password must be at least 6 characters");
                        return;
                    }
                    if (!newPass.equals(confirmPass)) {
                        showToast("Passwords do not match");
                        return;
                    }

                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                    if (user == null || user.getEmail() == null) return;

                    AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(), oldPass);

                    user.reauthenticate(credential).addOnCompleteListener(reauthTask -> {
                        if (reauthTask.isSuccessful()) {
                            user.updatePassword(newPass).addOnCompleteListener(updateTask -> {
                                if (updateTask.isSuccessful()) {
                                    FirebaseDatabase.getInstance().getReference("Users")
                                            .child(user.getUid())
                                            .child("password")
                                            .setValue(newPass);
                                    Toast.makeText(this, "Password updated successfully!", Toast.LENGTH_LONG).show();
                                } else {
                                    Toast.makeText(this, "Update failed: " + updateTask.getException().getMessage(), Toast.LENGTH_LONG).show();
                                }
                            });
                        } else {
                            showToast("Incorrect current password!");
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Teacher name/ID Firebase se load ─────────────────────────────────────
    private void fetchTeacherDetails() {
        dbRef.child("Users").child(teacherUid).get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        String name      = snapshot.child("name").getValue(String.class);
                        String teacherId = snapshot.child("teacherId").getValue(String.class);
                        String subject   = snapshot.child("subject").getValue(String.class);

                        tvTeacherName.setText(name != null ? name : "Teacher");
                        String details = teacherId != null ? "ID: " + teacherId : "";
                        if (subject != null)
                            details += (details.isEmpty() ? "" : " | ") + "Subject: " + subject;
                        tvTeacherID.setText(details);
                    }
                });
    }
}