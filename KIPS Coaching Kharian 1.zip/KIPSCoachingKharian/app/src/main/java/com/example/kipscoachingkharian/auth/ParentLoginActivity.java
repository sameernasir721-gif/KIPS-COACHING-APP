package com.example.kipscoachingkharian.auth;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.ParentDashboardActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class ParentLoginActivity extends AppCompatActivity {

    private TextView tabLogin, tabRegister, tvForgotPassword;
    private LinearLayout layoutLogin, layoutRegister;
    private MaterialButton btnParentLogin, btnParentRegister;

    // Login fields
    private TextInputLayout tilLoginEmail, tilLoginStudentId, tilLoginPassword;
    private TextInputEditText etLoginEmail, etLoginRegistrationId, etLoginPassword;

    // Register fields
    private TextInputLayout tilRegName, tilRegPhone, tilRegEmail, tilRegStudentId, tilRegPassword;
    private TextInputEditText etRegName, etRegPhone, etRegEmail, etRegregistrationId, etRegPassword;

    // Password visibility state
    private boolean isLoginPassVisible = false;
    private boolean isRegPassVisible   = false;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_login);

        mAuth     = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        initViews();
        setupTabs();

        btnParentRegister.setOnClickListener(v -> validateAndRegister());
        btnParentLogin.setOnClickListener(v -> validateAndLogin());
        tvForgotPassword.setOnClickListener(v -> sendPasswordResetEmail());
    }

    // ─────────────────────────────────────────────────────────────
    // INIT
    // ─────────────────────────────────────────────────────────────
    private void initViews() {
        tabLogin    = findViewById(R.id.tabLogin);
        tabRegister = findViewById(R.id.tabRegister);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);
        layoutLogin    = findViewById(R.id.layoutLogin);
        layoutRegister = findViewById(R.id.layoutRegister);
        btnParentLogin    = findViewById(R.id.btnParentLogin);
        btnParentRegister = findViewById(R.id.btnParentRegister);

        // Login TILs
        tilLoginEmail     = findViewById(R.id.tilLoginEmail);
        tilLoginStudentId = findViewById(R.id.tilLoginStudentId);
        tilLoginPassword  = findViewById(R.id.tilLoginPassword);

        etLoginEmail          = findViewById(R.id.etLoginEmail);
        etLoginRegistrationId = findViewById(R.id.etLoginStudentId);
        etLoginPassword       = findViewById(R.id.etLoginPassword);

        // Register TILs
        tilRegName      = findViewById(R.id.tilRegName);
        tilRegPhone     = findViewById(R.id.tilRegPhone);
        tilRegEmail     = findViewById(R.id.tilRegEmail);
        tilRegStudentId = findViewById(R.id.tilRegStudentId);
        tilRegPassword  = findViewById(R.id.tilRegPassword);

        etRegName           = findViewById(R.id.etRegName);
        etRegPhone          = findViewById(R.id.etRegPhone);
        etRegEmail          = findViewById(R.id.etRegEmail);
        etRegregistrationId = findViewById(R.id.etRegStudentId);
        etRegPassword       = findViewById(R.id.etRegPassword);

        // Password eye toggle — same as StudentLoginActivity
        setupPasswordToggle(tilLoginPassword, etLoginPassword, true);
        setupPasswordToggle(tilRegPassword,   etRegPassword,   false);

        // Type karte hi error clear ho
        clearErrorOnEdit(tilLoginEmail,     etLoginEmail);
        clearErrorOnEdit(tilLoginStudentId, etLoginRegistrationId);
        clearErrorOnEdit(tilLoginPassword,  etLoginPassword);
        clearErrorOnEdit(tilRegName,        etRegName);
        clearErrorOnEdit(tilRegPhone,       etRegPhone);
        clearErrorOnEdit(tilRegEmail,       etRegEmail);
        clearErrorOnEdit(tilRegStudentId,   etRegregistrationId);
        clearErrorOnEdit(tilRegPassword,    etRegPassword);
    }

    // ─────────────────────────────────────────────────────────────
    // PASSWORD TOGGLE — same pattern as StudentLoginActivity
    // ─────────────────────────────────────────────────────────────
    private void setupPasswordToggle(TextInputLayout til, TextInputEditText et, boolean isLoginField) {
        if (til == null || et == null) return;
        til.setEndIconDrawable(R.drawable.ic_eye_slash);
        et.setTransformationMethod(PasswordTransformationMethod.getInstance());

        til.setEndIconOnClickListener(v -> {
            boolean currentlyVisible = isLoginField ? isLoginPassVisible : isRegPassVisible;
            boolean makeVisible = !currentlyVisible;

            if (makeVisible) {
                et.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                til.setEndIconDrawable(R.drawable.ic_eye_open);
            } else {
                et.setTransformationMethod(PasswordTransformationMethod.getInstance());
                til.setEndIconDrawable(R.drawable.ic_eye_slash);
            }
            if (et.getText() != null) et.setSelection(et.getText().length());

            if (isLoginField) isLoginPassVisible = makeVisible;
            else              isRegPassVisible   = makeVisible;
        });
    }

    // ─────────────────────────────────────────────────────────────
    // FORGOT / RESET PASSWORD
    // ─────────────────────────────────────────────────────────────
    private void sendPasswordResetEmail() {
        String email = etLoginEmail.getText().toString().trim();
        tilLoginEmail.setError(null);

        if (email.isEmpty()) {
            tilLoginEmail.setError("Enter your email for reset link");
            return;
        }
        if (!isValidEmail(email)) {
            tilLoginEmail.setError("Enter a valid email address");
            return;
        }

        tvForgotPassword.setEnabled(false);
        mAuth.sendPasswordResetEmail(email).addOnCompleteListener(task -> {
            tvForgotPassword.setEnabled(true);
            if (task.isSuccessful()) {
                Toast.makeText(this, "Password reset link sent to " + email, Toast.LENGTH_LONG).show();
            } else {
                String msg = task.getException() != null ? task.getException().getMessage() : "Try again";
                Toast.makeText(this, "Failed: " + msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ─────────────────────────────────────────────────────────────
    // REGISTER — VALIDATION
    // ─────────────────────────────────────────────────────────────
    private void validateAndRegister() {
        tilRegName.setError(null);
        tilRegPhone.setError(null);
        tilRegEmail.setError(null);
        tilRegStudentId.setError(null);
        tilRegPassword.setError(null);

        String name  = etRegName.getText().toString().trim();
        String phone = etRegPhone.getText().toString().trim();
        String email = etRegEmail.getText().toString().trim();
        String regId = etRegregistrationId.getText().toString().trim();
        String pass  = etRegPassword.getText().toString().trim();

        boolean hasError = false;

        if (name.isEmpty()) {
            tilRegName.setError("Please enter your name");
            hasError = true;
        } else if (!isValidName(name)) {
            tilRegName.setError("Only alphabets allowed, min 3 characters");
            hasError = true;
        }

        if (phone.isEmpty()) {
            tilRegPhone.setError("Please enter phone number");
            hasError = true;
        } else if (!isValidPhone(phone)) {
            tilRegPhone.setError("Write 11-digit number (03XXXXXXXXX)");
            hasError = true;
        }

        if (email.isEmpty()) {
            tilRegEmail.setError("Please enter your email");
            hasError = true;
        } else if (!isValidEmail(email)) {
            tilRegEmail.setError("Enter valid email");
            hasError = true;
        }

        if (regId.isEmpty()) {
            tilRegStudentId.setError("Please enter Student Registration ID");
            hasError = true;
        } else if (!isValidStudentId(regId)) {
            tilRegStudentId.setError("Only letters and digits allowed");
            hasError = true;
        }

        if (pass.isEmpty()) {
            tilRegPassword.setError("Please enter password");
            hasError = true;
        } else if (!isValidPassword(pass)) {
            tilRegPassword.setError("Password must be at least 8 characters including special symbol");
            hasError = true;
        }

        if (hasError) return;

        // All fields valid — verify Student ID exists in Firebase with role=Student
        btnParentRegister.setEnabled(false);
        mDatabase.child("Users").orderByChild("registrationId").equalTo(regId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            // Check that matched record belongs to a Student, not any other role
                            boolean isStudentFound = false;
                            for (DataSnapshot child : snapshot.getChildren()) {
                                String role = child.child("role").getValue(String.class);
                                if ("Student".equalsIgnoreCase(role)) {
                                    isStudentFound = true;
                                    break;
                                }
                            }
                            if (isStudentFound) {
                                performFirebaseRegistration(name, phone, email, regId, pass);
                            } else {
                                btnParentRegister.setEnabled(true);
                                tilRegStudentId.setError("This ID does not belong to a registered Student");
                            }
                        } else {
                            btnParentRegister.setEnabled(true);
                            tilRegStudentId.setError("Student ID '" + regId + "' not found in records");
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        btnParentRegister.setEnabled(true);
                        Toast.makeText(ParentLoginActivity.this,
                                "Database Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void performFirebaseRegistration(String name, String phone,
                                             String email, String regId, String password) {
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
            if (task.isSuccessful() && mAuth.getCurrentUser() != null) {
                String uid = mAuth.getCurrentUser().getUid();

                Map<String, Object> data = new HashMap<>();
                data.put("name",           name);
                data.put("email",          email);
                data.put("phone",          phone);
                data.put("registrationId", regId);
                data.put("role",           "Parent");
                data.put("status",         "Pending");
                data.put("createdAt",      System.currentTimeMillis()); // System Reports daily chart ke liye

                mDatabase.child("Users").child(uid).setValue(data).addOnCompleteListener(t -> {
                    mAuth.signOut();
                    btnParentRegister.setEnabled(true);
                    Toast.makeText(this,
                            "Registration Successful! Waiting for Admin Approval.",
                            Toast.LENGTH_LONG).show();
                    showLoginView();
                });
            } else {
                btnParentRegister.setEnabled(true);
                String errMsg = task.getException() != null
                        ? task.getException().getMessage() : "Registration failed";
                if (errMsg != null && errMsg.contains("email address is already in use")) {
                    tilRegEmail.setError("This email is already registered");
                } else {
                    Toast.makeText(this, "Error: " + errMsg, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // ─────────────────────────────────────────────────────────────
    // LOGIN — VALIDATION
    // ─────────────────────────────────────────────────────────────
    private void validateAndLogin() {
        tilLoginEmail.setError(null);
        tilLoginStudentId.setError(null);
        tilLoginPassword.setError(null);

        String email    = etLoginEmail.getText().toString().trim();
        String inputId  = etLoginRegistrationId.getText().toString().trim();
        String password = etLoginPassword.getText().toString().trim();

        boolean hasError = false;

        if (email.isEmpty()) {
            tilLoginEmail.setError("Please enter email");
            hasError = true;
        } else if (!isValidEmail(email)) {
            tilLoginEmail.setError("Enter valid email");
            hasError = true;
        }

        if (inputId.isEmpty()) {
            tilLoginStudentId.setError("Please enter Student ID");
            hasError = true;
        } else if (!isValidStudentId(inputId)) {
            tilLoginStudentId.setError("Only letters and digits allowed");
            hasError = true;
        }

        if (password.isEmpty()) {
            tilLoginPassword.setError("Please enter your password");
            hasError = true;
        }

        if (hasError) return;

        btnParentLogin.setEnabled(false);
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                FirebaseUser user = mAuth.getCurrentUser();
                if (user != null) checkStatus(user.getUid(), inputId);
            } else {
                btnParentLogin.setEnabled(true);
                tilLoginPassword.setError("Invalid email or password");
            }
        });
    }

    private void checkStatus(String uid, String inputId) {
        mDatabase.child("Users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            String dbId   = snapshot.child("registrationId").getValue(String.class);
                            String status = snapshot.child("status").getValue(String.class);
                            String role   = snapshot.child("role").getValue(String.class);

                            if ("Parent".equalsIgnoreCase(role) && dbId != null
                                    && dbId.equalsIgnoreCase(inputId)) {
                                if ("Approved".equalsIgnoreCase(status)) {
                                    Intent intent = new Intent(ParentLoginActivity.this,
                                            ParentDashboardActivity.class);
                                    intent.putExtra("REGISTRATION_ID", dbId);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    handleError("Your account is pending approval from Admin.");
                                }
                            } else {
                                handleError("Invalid Parent Account or Student ID mismatch.");
                            }
                        } else {
                            handleError("Parent account not found.");
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        btnParentLogin.setEnabled(true);
                    }
                });
    }

    private void handleError(String msg) {
        mAuth.signOut();
        btnParentLogin.setEnabled(true);
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    // ─────────────────────────────────────────────────────────────
    // VALIDATION HELPERS — same as StudentLoginActivity
    // ─────────────────────────────────────────────────────────────
    private boolean isValidEmail(String email) {
        return !email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private boolean isValidName(String name) {
        return name.matches("^[A-Za-z ]{3,40}$");
    }

    private boolean isValidPhone(String phone) {
        return phone.matches("^03[0-9]{9}$");
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 8) return false;
        return password.matches(".*[^A-Za-z0-9].*");
    }

    private boolean isValidStudentId(String id) {

        if (id.length() < 3) return false;
        return id.matches("^[A-Za-z0-9][A-Za-z0-9]{2,29}$");
    }

    private void clearErrorOnEdit(TextInputLayout layout, TextInputEditText input) {
        if (layout == null || input == null) return;
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                layout.setError(null);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    // ─────────────────────────────────────────────────────────────
    // TABS
    // ─────────────────────────────────────────────────────────────
    private void setupTabs() {
        showLoginView(); // default
        tabLogin.setOnClickListener(v -> showLoginView());
        tabRegister.setOnClickListener(v -> showRegisterView());
    }

    private void showLoginView() {
        layoutLogin.setVisibility(View.VISIBLE);
        layoutRegister.setVisibility(View.GONE);
        tabLogin.setBackgroundResource(R.drawable.toggle_bg);
        tabLogin.setTextColor(Color.parseColor("#B71C1C"));
        tabRegister.setBackground(null);
        tabRegister.setTextColor(Color.WHITE);
    }

    private void showRegisterView() {
        layoutLogin.setVisibility(View.GONE);
        layoutRegister.setVisibility(View.VISIBLE);
        tabRegister.setBackgroundResource(R.drawable.toggle_bg);
        tabRegister.setTextColor(Color.parseColor("#B71C1C"));
        tabLogin.setBackground(null);
        tabLogin.setTextColor(Color.WHITE);
    }
}