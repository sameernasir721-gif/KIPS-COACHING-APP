package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class ManageParentRequestsActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private LinearLayout containerRequests;
    private TextView tvLoading;
    private TextView tvPendingCount, tvApprovedCount, tvRejectedCount, tvTotalCount;

    private String currentFilter = "Pending";
    private ValueEventListener activeListener = null; // ✅ duplicate listener se bachne ke liye

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_parents_requests);

        mDatabase         = FirebaseDatabase.getInstance().getReference();
        containerRequests = findViewById(R.id.containerParentRequests);
        tvLoading         = findViewById(R.id.tvParentLoading);
        tvPendingCount    = findViewById(R.id.tvParentPendingCount);
        tvApprovedCount   = findViewById(R.id.tvParentApprovedCount);
        tvRejectedCount   = findViewById(R.id.tvParentRejectedCount);
        tvTotalCount      = findViewById(R.id.tvParentTotalCount);

        // Summary card clicks — filter switch karo
        if (tvPendingCount  != null) tvPendingCount.setOnClickListener(v  -> switchFilter("Pending"));
        if (tvApprovedCount != null) tvApprovedCount.setOnClickListener(v -> switchFilter("Approved"));
        if (tvRejectedCount != null) tvRejectedCount.setOnClickListener(v -> switchFilter("Rejected"));
        if (tvTotalCount    != null) tvTotalCount.setOnClickListener(v    -> switchFilter("All"));

        loadParentRequests();
    }

    private void switchFilter(String filter) {
        currentFilter = filter;
        loadParentRequests();
    }

    // ── Firebase load — addListenerForSingleValueEvent use karo ──────────────
    // addValueEventListener ki jagah SingleValueEvent — duplicate cards nahi aayenge
    private void loadParentRequests() {
        if (tvLoading != null) tvLoading.setVisibility(View.VISIBLE);
        containerRequests.removeAllViews();

        mDatabase.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                containerRequests.removeAllViews();
                if (tvLoading != null) tvLoading.setVisibility(View.GONE);

                int pending = 0, approved = 0, rejected = 0;
                boolean anyMatch = false;

                for (DataSnapshot userSnap : snapshot.getChildren()) {
                    String role = userSnap.child("role").getValue(String.class);
                    if (role == null || !"Parent".equalsIgnoreCase(role)) continue;

                    String status = userSnap.child("status").getValue(String.class);
                    if (status == null) status = "Pending";

                    switch (status.toLowerCase()) {
                        case "pending":  pending++;  break;
                        case "approved": approved++; break;
                        case "rejected": rejected++; break;
                    }

                    boolean matches = currentFilter.equalsIgnoreCase("All")
                            || currentFilter.equalsIgnoreCase(status);

                    if (matches) {
                        anyMatch = true;

                        String uid    = userSnap.getKey(); // key — naam ya uid jo bhi ho
                        String name   = userSnap.child("name").getValue(String.class);
                        String email  = userSnap.child("email").getValue(String.class);
                        String reason = userSnap.child("rejectionReason").getValue(String.class);

                        String regId = userSnap.child("registrationId").getValue(String.class);
                        if (regId == null) regId = userSnap.child("studentId").getValue(String.class);
                        if (regId == null) regId = userSnap.child("childId").getValue(String.class);

                        Object phoneObj = userSnap.child("phone").getValue();
                        if (phoneObj == null) phoneObj = userSnap.child("phoneNumber").getValue();
                        String phone = phoneObj != null ? String.valueOf(phoneObj).trim() : "-";

                        createRequestCard(uid, name, email, regId, phone, status, reason);
                    }
                }

                updateSummary(pending, approved, rejected, pending + approved + rejected);
                if (!anyMatch) showEmptyState();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (tvLoading != null) tvLoading.setVisibility(View.GONE);
                Toast.makeText(ManageParentRequestsActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateSummary(int pending, int approved, int rejected, int total) {
        if (tvPendingCount  != null) tvPendingCount.setText(String.valueOf(pending));
        if (tvApprovedCount != null) tvApprovedCount.setText(String.valueOf(approved));
        if (tvRejectedCount != null) tvRejectedCount.setText(String.valueOf(rejected));
        if (tvTotalCount    != null) tvTotalCount.setText(String.valueOf(total));
    }

    // ── Request Card ──────────────────────────────────────────────────────────
    private void createRequestCard(String uid, String name, String email,
                                   String regId, String phone,
                                   String status, String rejectionReason) {

        // Card background — status ke hisaab se colour
        int cardBg;
        switch (status.toLowerCase()) {
            case "approved": cardBg = 0xFFF1FFF1; break;
            case "rejected": cardBg = 0xFFFFF1F1; break;
            default:         cardBg = 0xFFFFFFFF; break;
        }

        androidx.cardview.widget.CardView card = new androidx.cardview.widget.CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(cp);
        card.setRadius(dp(12));
        card.setCardElevation(dp(4));
        card.setCardBackgroundColor(cardBg);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(16), dp(16), dp(16), dp(16));

        // Info text
        TextView tvInfo = new TextView(this);
        tvInfo.setText(
                "👤 Name:   " + (name  != null ? name  : "-")
                        + "\n🏷️ Role:   Parent"
                        + "\n📧 Email:  " + (email != null ? email : "-")
                        + "\n🆔 Reg ID: " + (regId != null ? regId : "N/A")
                        + "\n📞 Phone:  " + phone);
        tvInfo.setTextSize(14f);
        tvInfo.setTextColor(0xFF333333);
        tvInfo.setLineSpacing(dp(3), 1f);
        tvInfo.setPadding(0, 0, 0, dp(10));
        inner.addView(tvInfo);

        // Status badge
        TextView tvStatus = new TextView(this);
        tvStatus.setText(getStatusEmoji(status) + " " + status);
        tvStatus.setTextSize(13f);
        tvStatus.setTypeface(null, android.graphics.Typeface.BOLD);
        tvStatus.setTextColor(getStatusColor(status));
        tvStatus.setPadding(dp(10), dp(6), dp(10), dp(6));
        tvStatus.setBackgroundColor(getStatusBgColor(status));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.bottomMargin = dp(10);
        tvStatus.setLayoutParams(sp);
        inner.addView(tvStatus);

        // ── Rejected: tap to see reason ──────────────────────────────────────
        if ("Rejected".equalsIgnoreCase(status)) {
            TextView tvBanner = new TextView(this);
            tvBanner.setText("❌ Tap card to see rejection reason");
            tvBanner.setTextSize(12f);
            tvBanner.setTextColor(0xFFB71C1C);
            tvBanner.setTypeface(null, android.graphics.Typeface.BOLD);
            tvBanner.setPadding(dp(10), dp(8), dp(10), dp(8));
            tvBanner.setBackgroundColor(0xFFFFEBEE);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
            bp.bottomMargin = dp(6);
            tvBanner.setLayoutParams(bp);
            inner.addView(tvBanner);

            // ✅ Card aur banner dono tap se dialog
            tvBanner.setOnClickListener(v -> showRejectionReasonDialog(name, rejectionReason));
            card.setOnClickListener(v    -> showRejectionReasonDialog(name, rejectionReason));
        }

        // ── Pending: Approve + Reject buttons ────────────────────────────────
        if ("Pending".equalsIgnoreCase(status)) {
            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(-1, -2);
            brp.topMargin = dp(4);
            btnRow.setLayoutParams(brp);

            Button btnApprove = new Button(this);
            btnApprove.setText("✅ Approve");
            btnApprove.setBackgroundColor(0xFF388E3C);
            btnApprove.setTextColor(0xFFFFFFFF);
            LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, -2, 1f);
            p1.setMarginEnd(dp(8));
            btnApprove.setLayoutParams(p1);
            btnApprove.setOnClickListener(v -> handleApproval(uid, name, email));

            Button btnReject = new Button(this);
            btnReject.setText("❌ Reject");
            btnReject.setBackgroundColor(0xFFB71C1C);
            btnReject.setTextColor(0xFFFFFFFF);
            btnReject.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
            btnReject.setOnClickListener(v -> handleRejection(uid, name, email));

            btnRow.addView(btnApprove);
            btnRow.addView(btnReject);
            inner.addView(btnRow);
        }

        card.addView(inner);
        containerRequests.addView(card);
    }

    // ── Rejection reason dialog ───────────────────────────────────────────────
    private void showRejectionReasonDialog(String name, String reason) {
        String displayReason = (reason != null && !reason.trim().isEmpty())
                ? reason : "No reason provided.";

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(20), dp(24), dp(16));

        TextView tvTitle = new TextView(this);
        tvTitle.setText("❌  Request Rejected");
        tvTitle.setTextSize(17f);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(0xFFB71C1C);
        tvTitle.setPadding(0, 0, 0, dp(8));
        layout.addView(tvTitle);

        TextView tvName = new TextView(this);
        tvName.setText("Parent: " + (name != null ? name : "-"));
        tvName.setTextSize(14f);
        tvName.setTextColor(0xFF555555);
        tvName.setPadding(0, 0, 0, dp(12));
        layout.addView(tvName);

        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        divider.setBackgroundColor(0xFFEEEEEE);
        layout.addView(divider);

        TextView tvLabel = new TextView(this);
        tvLabel.setText("Reason for Rejection:");
        tvLabel.setTextSize(13f);
        tvLabel.setTextColor(0xFF888888);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-1, -2);
        llp.topMargin = dp(12); llp.bottomMargin = dp(6);
        tvLabel.setLayoutParams(llp);
        layout.addView(tvLabel);

        TextView tvReason = new TextView(this);
        tvReason.setText(displayReason);
        tvReason.setTextSize(15f);
        tvReason.setTextColor(0xFFB71C1C);
        tvReason.setTypeface(null, android.graphics.Typeface.BOLD);
        tvReason.setPadding(dp(14), dp(12), dp(14), dp(12));
        tvReason.setBackgroundColor(0xFFFFEBEE);
        tvReason.setLineSpacing(dp(3), 1f);
        layout.addView(tvReason);

        new AlertDialog.Builder(this)
                .setView(layout)
                .setPositiveButton("OK", null)
                .show();
    }

    // ── Approve ───────────────────────────────────────────────────────────────
    private void handleApproval(String uid, String name, String email) {
        mDatabase.child("Users").child(uid).child("status").setValue("Approved")
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "✅ " + name + " Approved!", Toast.LENGTH_SHORT).show();
                    sendEmail(email,
                            "Account Approved - KIPS Coaching Kharian",
                            "Dear " + name + ",\n\nYour Parent Account has been APPROVED. You can now login.\n\nRegards,\nAdmin Team");
                    loadParentRequests(); // ✅ Refresh
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    // ── Reject ────────────────────────────────────────────────────────────────
    private void handleRejection(String uid, String name, String email) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(16), dp(24), dp(8));

        EditText input = new EditText(this);
        input.setHint("Enter reason for rejection...");
        input.setMinLines(2);
        layout.addView(input);

        new AlertDialog.Builder(this)
                .setTitle("Rejection Reason")
                .setView(layout)
                .setPositiveButton("Reject & Notify", (dialog, which) -> {
                    String reason = input.getText().toString().trim();
                    if (reason.isEmpty()) reason = "No reason provided.";
                    final String finalReason = reason;

                    Map<String, Object> rejectMap = new HashMap<>();
                    rejectMap.put("status", "Rejected");
                    rejectMap.put("rejectionReason", finalReason);

                    mDatabase.child("Users").child(uid).updateChildren(rejectMap)
                            .addOnSuccessListener(unused -> {
                                Toast.makeText(this, "❌ " + name + " Rejected.", Toast.LENGTH_SHORT).show();
                                sendEmail(email,
                                        "Account Request Rejected - KIPS Coaching Kharian",
                                        "Dear " + name + ",\n\nYour request has been rejected.\nReason: "
                                                + finalReason + "\n\nPlease contact the office for details.");
                                loadParentRequests(); // ✅ Refresh
                            })
                            .addOnFailureListener(e ->
                                    Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Email ─────────────────────────────────────────────────────────────────
    private void sendEmail(String to, String subject, String body) {
        if (to == null || to.isEmpty()) return;
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL,   new String[]{to});
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT,    body);
        try {
            startActivity(Intent.createChooser(intent, "Choose Email App:"));
        } catch (Exception e) {
            Toast.makeText(this, "No email app found.", Toast.LENGTH_SHORT).show();
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private void showEmptyState() {
        TextView tv = new TextView(this);
        tv.setText("No " + currentFilter.toLowerCase() + " parent requests.");
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(60), 0, 0);
        containerRequests.addView(tv);
    }

    private String getStatusEmoji(String status) {
        if (status == null) return "⏳";
        switch (status.toLowerCase()) {
            case "approved": return "✅";
            case "rejected": return "❌";
            default:         return "⏳";
        }
    }

    private int getStatusColor(String status) {
        if (status == null) return 0xFFE65100;
        switch (status.toLowerCase()) {
            case "approved": return 0xFF2E7D32;
            case "rejected": return 0xFFB71C1C;
            default:         return 0xFFE65100;
        }
    }

    private int getStatusBgColor(String status) {
        if (status == null) return 0xFFFFF3E0;
        switch (status.toLowerCase()) {
            case "approved": return 0xFFE8F5E9;
            case "rejected": return 0xFFFFEBEE;
            default:         return 0xFFFFF3E0;
        }
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}