// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "8.2.0" apply false
    id("com.android.library") version "8.2.0" apply false

    // Add this line for Google Services
    id("com.google.gms.google-services") version "4.4.1" apply false
}