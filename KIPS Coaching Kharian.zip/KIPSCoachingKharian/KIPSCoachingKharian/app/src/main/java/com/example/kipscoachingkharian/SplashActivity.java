package com.example.kipscoachingkharian;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Hide Status Bar for Full Screen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);

        // 1. Initialize Animations
        Animation topAnim = AnimationUtils.loadAnimation(this, R.anim.top_animation);
        Animation bottomAnim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation);

        // 2. Find Views using the NEW IDs from your XML
        ImageView logo = findViewById(R.id.ivLogoSplash);
        TextView mainTitle = findViewById(R.id.tvMainTitle);
        TextView subTitle = findViewById(R.id.tvSubTitle);

        // 3. Set Animations
        // Logo comes from top
        if (logo != null) {
            logo.setAnimation(topAnim);
        }

        // Text comes from bottom
        if (mainTitle != null) {
            mainTitle.setAnimation(bottomAnim);
        }
        if (subTitle != null) {
            subTitle.setAnimation(bottomAnim);
        }

        // 4. Move to Next Screen after 3 Seconds
        int SPLASH_TIME_OUT = 3000;
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Intent i = new Intent(SplashActivity.this, LoginSelectionActivity.class);
            startActivity(i);
            // Add a smooth fade transition
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, SPLASH_TIME_OUT);
    }
}