package com.example.kipscoachingkharian;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TeacherLoginActivity extends AppCompatActivity {

    EditText etTeacherId, etTeacherPassword;
    Button btnTeacherLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_login);

        etTeacherId = findViewById(R.id.etTeacherId);
        etTeacherPassword = findViewById(R.id.etTeacherPassword);
        btnTeacherLogin = findViewById(R.id.btnTeacherLogin);

        btnTeacherLogin.setOnClickListener(v -> {

            String id = etTeacherId.getText().toString();
            String password = etTeacherPassword.getText().toString();

            if (id.isEmpty() || password.isEmpty()) {
                Toast.makeText(TeacherLoginActivity.this, "Please enter ID and password", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(TeacherLoginActivity.this, "Teacher Login: Processing...", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

