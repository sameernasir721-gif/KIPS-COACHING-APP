package com.example.kipscoachingkharian;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AdminLoginActivity extends AppCompatActivity {

    private TextView tabLogin, tabRegister;
    private LinearLayout layoutLogin, layoutRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        tabLogin = findViewById(R.id.tabLogin);
        tabRegister = findViewById(R.id.tabRegister);
        layoutLogin = findViewById(R.id.layoutLogin);
        layoutRegister = findViewById(R.id.layoutRegister);

        showLoginView();
        tabLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLoginView();
            }
        });

        tabRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRegisterView();
            }
        });
    }

    private void showLoginView() {
        layoutLogin.setVisibility(View.VISIBLE);
        layoutRegister.setVisibility(View.GONE);

        // Styles update: Login active, Register inactive
        tabLogin.setBackgroundResource(R.drawable.toggle_bg);
        tabLogin.setTextColor(Color.parseColor("#B71C1C"));

        tabRegister.setBackground(null);

        tabRegister.setTextColor(Color.parseColor("#FFFFFF"));
    }

    private void showRegisterView() {
        layoutLogin.setVisibility(View.GONE);
        layoutRegister.setVisibility(View.VISIBLE);

        // Styles update: Register active, Login inactive
        tabRegister.setBackgroundResource(R.drawable.toggle_bg);
        tabRegister.setTextColor(Color.parseColor("#B71C1C"));

        tabLogin.setBackground(null);
        tabLogin.setTextColor(Color.parseColor("#FFFFFF"));
    }
}
