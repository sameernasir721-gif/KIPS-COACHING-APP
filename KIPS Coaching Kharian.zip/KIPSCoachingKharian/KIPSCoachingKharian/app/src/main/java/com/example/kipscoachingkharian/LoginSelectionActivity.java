package com.example.kipscoachingkharian;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;
import android.content.Intent;
import android.os.Bundle; // Added missing import

public class LoginSelectionActivity extends AppCompatActivity {

    MaterialCardView cardAdmin, cardTeacher, cardStudent, cardParent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_selection);

        cardAdmin = findViewById(R.id.cardAdmin);
        cardTeacher = findViewById(R.id.cardTeacher);
        cardStudent = findViewById(R.id.cardStudent);
        cardParent = findViewById(R.id.cardParent);

        cardAdmin.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, AdminLoginActivity.class)));

        cardTeacher.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, TeacherLoginActivity.class)));

        cardStudent.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, StudentLoginActivity.class)));

        cardParent.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, ParentLoginActivity.class)));
    }

    // Fixed: Moved outside of onCreate and corrected syntax
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Exit Application")
                .setMessage("Are you sure you want to exit KIPS Coaching Kharian?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    super.onBackPressed();
                    finishAffinity();
                })
                .setNegativeButton("No", null)
                .show();
    }
}