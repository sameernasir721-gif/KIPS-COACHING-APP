// LOCATION: app/src/test/java/com/example/kipscoachingkharian/ParentRegisterValidationTest.java
package com.example.kipscoachingkharian;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.regex.Pattern;

public class ParentRegisterValidationTest {

    // ✅ FIX: Added the "40" upper bound to match ParentLoginActivity.isValidName()
    // EXACTLY: return name.matches("^[A-Za-z ]{3,40}$");
    // The old pattern ("^[A-Za-z ]{3,}$") had no upper limit, so a 41+
    // character name would incorrectly PASS this test while the real app
    // REJECTS it.
    private static final Pattern NAME_PATTERN = Pattern.compile("^[A-Za-z ]{3,40}$");

    // This one was already correct — matches ParentLoginActivity.isValidPhone()
    // EXACTLY: return phone.matches("^03[0-9]{9}$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^03[0-9]{9}$");

    // ⚠️ NOTE: STUDENT_ID_PATTERN tests were REMOVED from this file.
    // A search of the real codebase found NO place where a regex like
    // "^student[0-9]{1,10}$" is actually enforced on the registration
    // student-ID field (etRegStudentId) — the app reads the value but does
    // not validate its format. Keeping tests for a rule the app doesn't
    // actually apply would give false confidence, so they've been dropped.
    // If you DO want this format enforced, the fix belongs in
    // ParentLoginActivity's registration flow first, then a test can be
    // added here to match it.

    // ═══════════════════════════════════════════════════════════
    // Name validation
    // ═══════════════════════════════════════════════════════════
    @Test
    public void name_validAlphabets_returnsTrue() {
        assertTrue(NAME_PATTERN.matcher("Ali Khan").matches());
    }

    @Test
    public void name_containsDigits_returnsFalse() {
        assertFalse(NAME_PATTERN.matcher("Ali123").matches());
    }

    @Test
    public void name_tooShort_returnsFalse() {
        assertFalse(NAME_PATTERN.matcher("A1").matches());
    }

    @Test
    public void name_empty_returnsFalse() {
        assertFalse(NAME_PATTERN.matcher("").matches());
    }

    @Test
    public void name_singleWord_valid_returnsTrue() {
        assertTrue(NAME_PATTERN.matcher("Ahad").matches());
    }

    // ✅ NEW: boundary tests for the 40-character upper limit that was
    // missing from the original pattern.
    @Test
    public void name_exactly40Characters_returnsTrue() {
        String name40 = "A".repeat(40); // 40 letters, no spaces
        assertTrue(NAME_PATTERN.matcher(name40).matches());
    }

    @Test
    public void name_41Characters_returnsFalse() {
        String name41 = "A".repeat(41);
        assertFalse(NAME_PATTERN.matcher(name41).matches());
    }

    // ═══════════════════════════════════════════════════════════
    // Phone number validation (03XXXXXXXXX — 11 digits)
    // ═══════════════════════════════════════════════════════════
    @Test
    public void phone_validFormat_returnsTrue() {
        assertTrue(PHONE_PATTERN.matcher("03001234567").matches());
    }

    @Test
    public void phone_tooShort_returnsFalse() {
        assertFalse(PHONE_PATTERN.matcher("12345").matches());
    }

    @Test
    public void phone_wrongPrefix_returnsFalse() {
        assertFalse(PHONE_PATTERN.matcher("13001234567").matches());
    }

    @Test
    public void phone_containsLetters_returnsFalse() {
        assertFalse(PHONE_PATTERN.matcher("0300abc4567").matches());
    }

    @Test
    public void phone_empty_returnsFalse() {
        assertFalse(PHONE_PATTERN.matcher("").matches());
    }

    @Test
    public void phone_tooLong_returnsFalse() {
        assertFalse(PHONE_PATTERN.matcher("030012345678").matches());
    }

    // ═══════════════════════════════════════════════════════════
    // Duplicate-linkage logic (as in: dbId.equalsIgnoreCase(inputId))
    // This logic genuinely exists in ParentDashboardActivity's checkStatus()
    // ═══════════════════════════════════════════════════════════
    @Test
    public void studentId_matchesDbRecord_caseInsensitive_returnsTrue() {
        String dbId = "student048";
        String inputId = "STUDENT048";
        assertTrue(dbId.equalsIgnoreCase(inputId));
    }

    @Test
    public void studentId_doesNotMatchDbRecord_returnsFalse() {
        String dbId = "student048";
        String inputId = "student999";
        assertFalse(dbId.equalsIgnoreCase(inputId));
    }
}