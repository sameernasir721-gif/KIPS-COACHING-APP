// LOCATION: app/src/test/java/com/example/kipscoachingkharian/ParentClassStatusTest.java
package com.example.kipscoachingkharian;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ParentClassStatusTest {

    // ✅ FIX: Ye ab ParentAttendanceActivity.addHistoryRow() ke ASLI logic
    // se match karta hai:
    //   long windowStart = rec.sortMillis - (10 * 60 * 1000);  // 10-min early join
    //   long windowEnd   = rec.sortMillis + (durationMinutes * 60 * 1000);
    //   boolean isLive = nowMillis >= windowStart && nowMillis <= windowEnd;
    //   boolean isPast = nowMillis > windowEnd;
    //
    // Pehle test me ye 10-minute "early join" window shamil nahi tha —
    // matlab test 9:55 AM (10 AM ki class ke liye) ko "Upcoming" expect
    // karta tha, jab ke asli app usay "🟢 Live" dikhati hai.
    private String getClassStatus(long classStartMillis, long durationMinutes, long currentTimeMillis) {
        long windowStart = classStartMillis - (10 * 60 * 1000); // 10 min early-join buffer
        long windowEnd   = classStartMillis + (durationMinutes * 60 * 1000);

        if (currentTimeMillis < windowStart) {
            return "Upcoming";
        } else if (currentTimeMillis >= windowStart && currentTimeMillis <= windowEnd) {
            return "Live";
        } else {
            return "Ended";
        }
    }

    @Test
    public void classStatus_beforeEarlyJoinWindow_returnsUpcoming() {
        long classStart = 1_000_000_000L;
        long duration    = 60; // minutes
        long now         = classStart - (15 * 60 * 1000); // 15 min before start — still Upcoming
        assertEquals("Upcoming", getClassStatus(classStart, duration, now));
    }

    // ✅ NEW: covers the 10-minute early-join window that the previous
    // version of this test did not account for.
    @Test
    public void classStatus_withinEarlyJoinWindow_returnsLive() {
        long classStart = 1_000_000_000L;
        long duration    = 60;
        long now         = classStart - (5 * 60 * 1000); // 5 min before start — within 10-min buffer
        assertEquals("Live", getClassStatus(classStart, duration, now));
    }

    @Test
    public void classStatus_exactlyAtStartTime_returnsLive() {
        long classStart = 1_000_000_000L;
        long duration    = 60;
        assertEquals("Live", getClassStatus(classStart, duration, classStart));
    }

    @Test
    public void classStatus_duringClass_returnsLive() {
        long classStart = 1_000_000_000L;
        long duration    = 60;
        long now         = classStart + (30 * 60 * 1000); // 30 min into a 60-min class
        assertEquals("Live", getClassStatus(classStart, duration, now));
    }

    @Test
    public void classStatus_afterClassEnds_returnsEnded() {
        long classStart = 1_000_000_000L;
        long duration    = 60;
        long now         = classStart + (61 * 60 * 1000); // 1 min after class ends
        assertEquals("Ended", getClassStatus(classStart, duration, now));
    }
}