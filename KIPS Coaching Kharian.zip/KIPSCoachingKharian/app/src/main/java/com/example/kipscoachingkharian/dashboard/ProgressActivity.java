package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.components.Legend;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

public class ProgressActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private BottomNavigationView bottomNav;

    private RecyclerView rvProgress;
    private LinearLayout layoutEmpty, layoutLoading;
    private LinearLayout layoutProgressSection, layoutReportSection;
    private TextView tvOverallPercent, tvStudentName, tvHeaderSubtitle;
    private EditText etSearch;
    private TextView chipProgress, chipReport;
    private BarChart barChart;
    private PieChart pieChart;
    private LineChart lineChartTrend;
    private TextView chipMonthly, chipYearly, tvTrendEmpty;
    private Spinner spinnerSubject;
    private View cardSearch;

    // Daily Progress (combined, all subjects) — simple line chart
    private LineChart lineChart;
    private TextView tvNoHistory;

    private boolean showMonthlyTrend = true; // true = Monthly, false = Yearly

    // Har entry ek quiz/assignment attempt ka percentage + uska date hota hai
    static class ScoreEntry {
        long timestamp;
        double percent;
    }
    private final List<ScoreEntry> allScoreEntries = new ArrayList<>();

    private String studentUid;
    private final List<ProgressItem> progressList = new ArrayList<>(); // Original List
    private final List<ProgressItem> filteredList = new ArrayList<>(); // List for Search
    private ProgressAdapter adapter;

    static class ProgressItem {
        String subject, className;
        int classAttended, classTotal, attendancePct;
        int assignMarks, assignTotal;
        int quizMarks, quizTotal;
        int avgPercent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) { finish(); return; }
        studentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Views initialization
        drawerLayout         = findViewById(R.id.drawerLayout);
        navigationView       = findViewById(R.id.navigationView);
        bottomNav            = findViewById(R.id.bottomNav);
        rvProgress           = findViewById(R.id.rvProgress);
        layoutEmpty          = findViewById(R.id.layoutEmpty);
        layoutLoading        = findViewById(R.id.layoutLoading);
        tvOverallPercent     = findViewById(R.id.tvOverallPercent);
        tvStudentName        = findViewById(R.id.tvStudentName);
        tvHeaderSubtitle     = findViewById(R.id.tvHeaderSubtitle);
        etSearch             = findViewById(R.id.etSearch);
        cardSearch           = findViewById(R.id.cardSearch);
        chipProgress         = findViewById(R.id.chipProgress);
        chipReport           = findViewById(R.id.chipReport);
        layoutProgressSection = findViewById(R.id.layoutProgressSection);
        layoutReportSection  = findViewById(R.id.layoutReportSection);
        barChart             = findViewById(R.id.barChart);
        pieChart             = findViewById(R.id.pieChart);
        spinnerSubject       = findViewById(R.id.spinnerSubject);
        lineChartTrend       = findViewById(R.id.lineChartTrend);
        chipMonthly          = findViewById(R.id.chipMonthly);
        chipYearly           = findViewById(R.id.chipYearly);
        tvTrendEmpty         = findViewById(R.id.tvTrendEmpty);
        lineChart            = findViewById(R.id.lineChart);
        tvNoHistory          = findViewById(R.id.tvNoHistory);

        // RecyclerView Setup with filteredList
        adapter = new ProgressAdapter(filteredList);
        rvProgress.setLayoutManager(new LinearLayoutManager(this));
        rvProgress.setAdapter(adapter);
        rvProgress.setNestedScrollingEnabled(false);

        // Search logic
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterReports(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Tab toggle logic
        chipProgress.setOnClickListener(v -> {
            layoutProgressSection.setVisibility(View.VISIBLE);
            layoutReportSection.setVisibility(View.GONE);
            cardSearch.setVisibility(View.VISIBLE);
            chipProgress.setBackgroundResource(R.drawable.bg_tab_selected);
            chipProgress.setTextColor(0xFFFFFFFF);
            chipReport.setBackgroundResource(R.drawable.bg_tab_unselected);
            chipReport.setTextColor(0xFFB71C1C);
        });

        chipReport.setOnClickListener(v -> {
            layoutProgressSection.setVisibility(View.GONE);
            layoutReportSection.setVisibility(View.VISIBLE);
            cardSearch.setVisibility(View.GONE);
            chipReport.setBackgroundResource(R.drawable.bg_tab_selected);
            chipReport.setTextColor(0xFFFFFFFF);
            chipProgress.setBackgroundResource(R.drawable.bg_tab_unselected);
            chipProgress.setTextColor(0xFFB71C1C);
            setupBarChart();
            setupPieChart();
            loadTrendData();
        });

        // Monthly / Yearly toggle for trend chart
        chipMonthly.setOnClickListener(v -> {
            showMonthlyTrend = true;
            chipMonthly.setBackgroundResource(R.drawable.bg_tab_selected);
            chipMonthly.setTextColor(0xFFFFFFFF);
            chipYearly.setBackgroundResource(R.drawable.bg_tab_unselected);
            chipYearly.setTextColor(0xFFB71C1C);
            drawTrendChart();
        });

        chipYearly.setOnClickListener(v -> {
            showMonthlyTrend = false;
            chipYearly.setBackgroundResource(R.drawable.bg_tab_selected);
            chipYearly.setTextColor(0xFFFFFFFF);
            chipMonthly.setBackgroundResource(R.drawable.bg_tab_unselected);
            chipMonthly.setTextColor(0xFFB71C1C);
            drawTrendChart();
        });

        findViewById(R.id.ivMenu).setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        setupBottomNav();
        setupDrawerNav();
        loadStudentInfo();
        loadProgressReports();
    }

    // ── Filter Method ────────────────────────────────────────────────────────
    private void filterReports(String query) {
        filteredList.clear();
        if (query.isEmpty()) {
            filteredList.addAll(progressList);
        } else {
            String lowerCaseQuery = query.toLowerCase().trim();
            for (ProgressItem item : progressList) {
                if (item.subject.toLowerCase().contains(lowerCaseQuery) ||
                        item.className.toLowerCase().contains(lowerCaseQuery)) {
                    filteredList.add(item);
                }
            }
        }
        adapter.notifyDataSetChanged();

        // Show empty state if no results found during search
        if (filteredList.isEmpty()) {
            layoutEmpty.setVisibility(View.VISIBLE);
        } else {
            layoutEmpty.setVisibility(View.GONE);
        }
    }

    private void loadStudentInfo() {
        FirebaseDatabase.getInstance().getReference("Users").child(studentUid).get()
                .addOnSuccessListener(snap -> {
                    if (snap.exists()) {
                        String name  = snap.child("name").getValue(String.class);
                        String grade = snap.child("className").getValue(String.class);
                        String infoText = (grade != null && !grade.isEmpty()) ? "Grade: " + grade : "Grade: --";
                        tvHeaderSubtitle.setText(infoText);
                        if (name != null) tvStudentName.setText(name);
                    }
                });
    }

    private void loadProgressReports() {
        layoutLoading.setVisibility(View.VISIBLE);
        layoutEmpty.setVisibility(View.GONE);
        rvProgress.setVisibility(View.GONE);

        FirebaseDatabase.getInstance().getReference("SharedProgress").child(studentUid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        progressList.clear();
                        for (DataSnapshot teacherSnap : snapshot.getChildren()) {
                            ProgressItem item = new ProgressItem();
                            item.subject        = getStringValue(teacherSnap, "subject");
                            item.className      = getStringValue(teacherSnap, "className");
                            item.classAttended  = getIntValue(teacherSnap, "classAttended");
                            item.classTotal     = getIntValue(teacherSnap, "classTotal");
                            item.attendancePct  = getIntValue(teacherSnap, "attendancePct");
                            item.assignMarks    = getIntValue(teacherSnap, "assignMarks");
                            item.assignTotal    = getIntValue(teacherSnap, "assignTotal");
                            item.quizMarks      = getIntValue(teacherSnap, "quizMarks");
                            item.quizTotal      = getIntValue(teacherSnap, "quizTotal");
                            item.avgPercent     = getIntValue(teacherSnap, "avgPercent");
                            progressList.add(item);
                        }

                        layoutLoading.setVisibility(View.GONE);
                        // Default search set karein
                        filterReports(etSearch.getText().toString());

                        if (!progressList.isEmpty()) {
                            rvProgress.setVisibility(View.VISIBLE);
                            updateOverall();
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        layoutLoading.setVisibility(View.GONE);
                    }
                });
    }

    private void updateOverall() {
        int totalObt = 0, totalMax = 0;
        for (ProgressItem p : progressList) {
            totalObt += p.assignMarks + p.quizMarks;
            totalMax += p.assignTotal + p.quizTotal;
        }
        int overall = totalMax == 0 ? 0 : (int)((totalObt * 100.0) / totalMax);
        tvOverallPercent.setText(overall + "%");
    }

    private String getStringValue(DataSnapshot snap, String key) {
        String v = snap.child(key).getValue(String.class);
        return v != null ? v : "--";
    }

    private int getIntValue(DataSnapshot snap, String key) {
        Object v = snap.child(key).getValue();
        if (v == null) return 0;
        if (v instanceof Long) return ((Long) v).intValue();
        if (v instanceof Integer) return (Integer) v;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return 0; }
    }

    // ── Bar Chart ────────────────────────────────────────────────────────────
    private void setupBarChart() {
        if (progressList.isEmpty()) return;

        ArrayList<BarEntry> entries = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        for (int i = 0; i < progressList.size(); i++) {
            ProgressItem p = progressList.get(i);
            entries.add(new BarEntry(i, p.avgPercent));
            String[] words = p.subject.trim().split("\\s+");
            StringBuilder lbl = new StringBuilder();
            for (int w = 0; w < Math.min(3, words.length); w++) {
                if (w > 0) lbl.append(" ");
                lbl.append(words[w]);
            }
            labels.add(lbl.toString());
        }

        BarDataSet dataSet = new BarDataSet(entries, "Avg %");
        dataSet.setColors(
                0xFF90CAF9,  // light blue
                0xFFA5D6A7,  // light green
                0xFFFFCC80,  // light orange
                0xFFCE93D8,  // light purple
                0xFFEF9A9A,  // light red
                0xFF80DEEA,  // light cyan
                0xFFFFF176   // light yellow
        );
        dataSet.setValueTextColor(0xFF424242);
        dataSet.setValueTextSize(11f);

        BarData data = new BarData(dataSet);
        data.setBarWidth(0.6f);

        barChart.setData(data);
        barChart.getDescription().setEnabled(false);
        barChart.setFitBars(true);
        barChart.getLegend().setEnabled(false);
        barChart.getAxisRight().setEnabled(false);
        barChart.getAxisLeft().setAxisMinimum(0f);
        barChart.getAxisLeft().setAxisMaximum(100f);
        barChart.getAxisLeft().setDrawGridLines(false);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setDrawGridLines(false);
        xAxis.setTextSize(10f);
        xAxis.setLabelCount(labels.size());

        barChart.animateY(800);
        barChart.invalidate();
    }

    // ── Pie Chart ─────────────────────────────────────────────────────────────
    private void setupPieChart() {
        if (progressList.isEmpty()) return;

        // Spinner subjects populate karo
        ArrayList<String> subjectNames = new ArrayList<>();
        for (ProgressItem p : progressList) {
            subjectNames.add(p.subject);
        }

        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, subjectNames);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSubject.setAdapter(spinnerAdapter);

        // Pehle subject ka chart default show karo
        drawPieForSubject(progressList.get(0));

        // Spinner change listener
        spinnerSubject.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                drawPieForSubject(progressList.get(position));
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void drawPieForSubject(ProgressItem p) {
        ArrayList<PieEntry> entries = new ArrayList<>();
        if (p.assignTotal  > 0) entries.add(new PieEntry(p.assignMarks,   "Assignments (" + p.assignMarks  + "/" + p.assignTotal  + ")"));
        if (p.quizTotal    > 0) entries.add(new PieEntry(p.quizMarks,     "Quizzes ("     + p.quizMarks    + "/" + p.quizTotal    + ")"));
        if (p.classTotal   > 0) entries.add(new PieEntry(p.classAttended, "Classes ("     + p.classAttended + "/" + p.classTotal  + ")"));

        if (entries.isEmpty()) {
            pieChart.clear();
            pieChart.setNoDataText("No data for this subject");
            pieChart.invalidate();
            return;
        }

        PieDataSet dataSet = new PieDataSet(entries, "");
        dataSet.setColors(
                0xFF90CAF9,  // light blue  - Assignments
                0xFFA5D6A7,  // light green - Quizzes
                0xFFFFCC80   // light orange - Classes
        );
        dataSet.setValueTextColor(0xFF424242);
        dataSet.setValueTextSize(12f);
        dataSet.setSliceSpace(3f);
        dataSet.setYValuePosition(PieDataSet.ValuePosition.INSIDE_SLICE);

        PieData pieData = new PieData(dataSet);
        pieData.setValueFormatter(new PercentFormatter(pieChart));

        pieChart.setData(pieData);
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleRadius(42f);
        pieChart.setHoleColor(Color.WHITE);
        pieChart.setCenterText(p.subject);
        pieChart.setCenterTextSize(12f);
        pieChart.setCenterTextColor(0xFF1A1A2E);
        pieChart.setDrawEntryLabels(false);
        pieChart.getLegend().setEnabled(true);
        pieChart.getLegend().setTextSize(13f);
        pieChart.getLegend().setWordWrapEnabled(true);
        pieChart.getLegend().setXEntrySpace(12f);
        pieChart.getLegend().setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        pieChart.getLegend().setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        pieChart.getLegend().setOrientation(Legend.LegendOrientation.HORIZONTAL);
        pieChart.getLegend().setDrawInside(false);
        pieChart.animateY(700);
        pieChart.invalidate();
    }

    // ── Daily Progress (combined, all subjects) ─────────────────────────────
    /**
     * allScoreEntries (jo loadTrendData()/loadAssignmentTrendData() se bharta
     * hai) ko DIN-wise group karke daily average % line chart mein dikhata hai.
     * Yeh Monthly/Yearly trend se pehle, "Daily Progress" card mein dikhega.
     */
    private void drawDailyProgressChart() {
        if (lineChart == null) return;

        if (allScoreEntries.isEmpty()) {
            lineChart.clear();
            lineChart.setVisibility(View.GONE);
            if (tvNoHistory != null) tvNoHistory.setVisibility(View.VISIBLE);
            return;
        }

        SimpleDateFormat dayKeyFormat   = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat dayLabelFormat = new SimpleDateFormat("dd MMM", Locale.getDefault());

        Map<String, List<Double>> grouped = new TreeMap<>();
        Map<String, String> dayLabels = new LinkedHashMap<>();

        for (ScoreEntry entry : allScoreEntries) {
            String key = dayKeyFormat.format(new java.util.Date(entry.timestamp));
            grouped.computeIfAbsent(key, k -> new ArrayList<>()).add(entry.percent);
            dayLabels.put(key, dayLabelFormat.format(new java.util.Date(entry.timestamp)));
        }

        if (grouped.isEmpty()) {
            lineChart.clear();
            lineChart.setVisibility(View.GONE);
            if (tvNoHistory != null) tvNoHistory.setVisibility(View.VISIBLE);
            return;
        }

        lineChart.setVisibility(View.VISIBLE);
        if (tvNoHistory != null) tvNoHistory.setVisibility(View.GONE);

        ArrayList<Entry> entries = new ArrayList<>();
        ArrayList<String> xLabels = new ArrayList<>();
        int index = 0;
        for (Map.Entry<String, List<Double>> g : grouped.entrySet()) {
            double sum = 0;
            for (double p : g.getValue()) sum += p;
            double avg = sum / g.getValue().size();
            entries.add(new Entry(index, (float) avg));
            xLabels.add(dayLabels.get(g.getKey()));
            index++;
        }

        LineDataSet dataSet = new LineDataSet(entries, "Daily Average %");
        dataSet.setColor(0xFF2E7D32);
        dataSet.setCircleColor(0xFF2E7D32);
        dataSet.setCircleRadius(4f);
        dataSet.setCircleHoleRadius(2f);
        dataSet.setDrawCircleHole(true);
        dataSet.setCircleHoleColor(Color.WHITE);
        dataSet.setLineWidth(2.5f);

        // Point ke upar sirf % dikhao, date X-axis pe rahegi
        dataSet.setDrawValues(true);
        dataSet.setValueTextSize(10f);
        dataSet.setValueTextColor(0xFF1B5E20);
        dataSet.setValueFormatter(new com.github.mikephil.charting.formatter.ValueFormatter() {
            @Override
            public String getPointLabel(com.github.mikephil.charting.data.Entry entry) {
                return Math.round(entry.getY()) + "%";
            }
        });
        dataSet.setDrawFilled(true);
        dataSet.setFillColor(0xFFA5D6A7);
        dataSet.setFillAlpha(80);
        dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        dataSet.setHighlightEnabled(true);
        dataSet.setHighlightLineWidth(1.5f);
        dataSet.setHighLightColor(0xFF2E7D32);
        dataSet.setDrawHorizontalHighlightIndicator(false); // sirf vertical line

        LineData lineData = new LineData(dataSet);
        lineData.setHighlightEnabled(true);
        lineChart.setData(lineData);
        lineChart.setExtraTopOffset(24f);
        lineChart.setExtraBottomOffset(28f);
        lineChart.setExtraLeftOffset(8f);
        lineChart.setExtraRightOffset(20f);
        lineChart.setNoDataText("No progress history yet");

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xLabels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setDrawGridLines(false);
        xAxis.setDrawLabels(true);
        xAxis.setTextSize(10f);
        xAxis.setTextColor(0xFF616161);
        xAxis.setAxisLineColor(0xFFBDBDBD);
        xAxis.setAvoidFirstLastClipping(true);
        xAxis.setLabelRotationAngle(0f);
        xAxis.setLabelCount(xLabels.size(), false);

        lineChart.getAxisLeft().setAxisMinimum(0f);
        lineChart.getAxisLeft().setAxisMaximum(100f);
        lineChart.getAxisLeft().setGranularity(20f);
        lineChart.getAxisLeft().setLabelCount(6, true);
        lineChart.getAxisLeft().setDrawGridLines(true);
        lineChart.getAxisLeft().setGridColor(0xFFEEEEEE);
        lineChart.getAxisLeft().setGridLineWidth(0.7f);
        lineChart.getAxisLeft().setTextSize(11f);
        lineChart.getAxisLeft().setTextColor(0xFF616161);
        lineChart.getAxisLeft().setAxisLineColor(0xFFBDBDBD);
        lineChart.getAxisLeft().setValueFormatter(new com.github.mikephil.charting.formatter.ValueFormatter() {
            @Override public String getFormattedValue(float value) {
                return (int) value + "%";
            }
        });
        lineChart.getAxisRight().setEnabled(false);
        lineChart.getDescription().setEnabled(false);
        lineChart.getLegend().setEnabled(true);
        lineChart.getLegend().setTextSize(12f);
        lineChart.getLegend().setTextColor(0xFF424242);
        lineChart.getLegend().setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        lineChart.getLegend().setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        lineChart.getLegend().setForm(Legend.LegendForm.LINE);

        // Scrollable chart — har point ko proper spacing do
        lineChart.setTouchEnabled(true);
        lineChart.setDragEnabled(true);
        lineChart.setScaleEnabled(false);
        lineChart.setPinchZoom(false);

        // Pehle zoom reset karo
        lineChart.fitScreen();

        // Visible window mein sirf 5 points — spacing achhi rahegi
        float visiblePoints = Math.min(5f, xLabels.size());
        lineChart.setVisibleXRangeMaximum(visiblePoints);
        lineChart.setVisibleXRangeMinimum(visiblePoints);

        // Shuruaat se dikhao (left side)
        lineChart.moveViewToX(0);

        // Touch par date + percentage dikhane wala marker

        final ArrayList<String> xLabelsRef = xLabels;
        com.github.mikephil.charting.components.MarkerView mv =
                new com.github.mikephil.charting.components.MarkerView(ProgressActivity.this, R.layout.marker_chart) {
                    private android.widget.TextView tvDate;
                    private android.widget.TextView tvPercent;

                    @Override
                    public void refreshContent(com.github.mikephil.charting.data.Entry e,
                                               com.github.mikephil.charting.highlight.Highlight highlight) {
                        if (tvDate == null)    tvDate    = findViewById(R.id.tvMarkerDate);
                        if (tvPercent == null) tvPercent = findViewById(R.id.tvMarkerPercent);

                        int idx = (int) e.getX();
                        String date = (idx >= 0 && idx < xLabelsRef.size()) ? xLabelsRef.get(idx) : "";
                        tvDate.setText(date);
                        tvPercent.setText(Math.round(e.getY()) + "%");
                        super.refreshContent(e, highlight);
                    }

                    @Override
                    public com.github.mikephil.charting.utils.MPPointF getOffset() {
                        return new com.github.mikephil.charting.utils.MPPointF(
                                -(getWidth() / 2f), -getHeight() - 10f);
                    }
                };
        lineChart.setMarkerView(mv);

        lineChart.animateX(900);
        lineChart.invalidate();
    }

    // ── Monthly / Yearly Progress Trend ─────────────────────────────────────
    /**
     * Quiz attempts aur assignment submissions dono se data jama karo
     * (subject ki tafseel zaroori nahi — overall combined trend chahiye).
     * Har attempt/submission ka percentage + date (timestamp) save karte hain.
     */
    private void loadTrendData() {
        allScoreEntries.clear();

        FirebaseDatabase.getInstance().getReference("QuizAttempts")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot quizAttemptsSnap) {
                        for (DataSnapshot quizSnap : quizAttemptsSnap.getChildren()) {
                            DataSnapshot myAttempt = quizSnap.child(studentUid);
                            if (!myAttempt.exists()) continue;

                            Long score     = myAttempt.child("score").getValue(Long.class);
                            Long mcqTotal  = myAttempt.child("mcqTotal").getValue(Long.class);
                            Long shortTot  = myAttempt.child("shortTotal").getValue(Long.class);
                            Long timestamp = myAttempt.child("timestamp").getValue(Long.class);

                            int obtained = score != null ? score.intValue() : 0;
                            int total = (mcqTotal != null ? mcqTotal.intValue() : 0)
                                    + (shortTot != null ? shortTot.intValue() : 0);

                            if (total > 0 && timestamp != null) {
                                ScoreEntry e = new ScoreEntry();
                                e.timestamp = timestamp;
                                e.percent   = (obtained * 100.0) / total;
                                allScoreEntries.add(e);
                            }
                        }
                        loadAssignmentTrendData();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        loadAssignmentTrendData();
                    }
                });
    }

    private void loadAssignmentTrendData() {
        FirebaseDatabase.getInstance().getReference("Submissions")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot submissionsSnap) {
                        for (DataSnapshot assignSnap : submissionsSnap.getChildren()) {
                            DataSnapshot mySub = assignSnap.child(studentUid);
                            if (!mySub.exists()) continue;

                            String obtainedStr = mySub.child("obtainedMarks").getValue(String.class);
                            Long submittedAt   = mySub.child("submittedAt").getValue(Long.class);

                            if (obtainedStr == null || obtainedStr.trim().isEmpty()
                                    || submittedAt == null) continue;

                            // Total marks asal assignment se chahiye — Assignments node se lo
                            String teacherId = mySub.child("teacherId").getValue(String.class);
                            String assignmentId = assignSnap.getKey();

                            double obtained;
                            try { obtained = Double.parseDouble(obtainedStr.trim()); }
                            catch (NumberFormatException ex) { continue; }

                            if (teacherId == null || assignmentId == null) continue;

                            FirebaseDatabase.getInstance().getReference("Assignments")
                                    .child(teacherId).child(assignmentId).child("marks")
                                    .get().addOnSuccessListener(marksSnap -> {
                                        String totalStr = marksSnap.getValue(String.class);
                                        if (totalStr == null || totalStr.trim().isEmpty()) return;
                                        double total;
                                        try { total = Double.parseDouble(totalStr.trim()); }
                                        catch (NumberFormatException ex) { return; }
                                        if (total <= 0) return;

                                        ScoreEntry e = new ScoreEntry();
                                        e.timestamp = submittedAt;
                                        e.percent   = (obtained * 100.0) / total;
                                        allScoreEntries.add(e);

                                        drawTrendChart();
                                        drawDailyProgressChart();
                                    });
                        }
                        // Quiz-only data ke liye bhi ek dafa draw kar do (assignment lookups async hain)
                        drawTrendChart();
                        drawDailyProgressChart();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        drawTrendChart();
                        drawDailyProgressChart();
                    }
                });
    }

    /**
     * allScoreEntries ko month-wise ya year-wise group karo, har group ka
     * average percent nikalo, aur Line Chart mein dikhao (chronological order).
     */
    private void drawTrendChart() {
        if (allScoreEntries.isEmpty()) {
            lineChartTrend.clear();
            lineChartTrend.setVisibility(View.GONE);
            tvTrendEmpty.setVisibility(View.VISIBLE);
            return;
        }

        // key format: Monthly -> "yyyy-MM", Yearly -> "yyyy"
        SimpleDateFormat keyFormat = new SimpleDateFormat(
                showMonthlyTrend ? "yyyy-MM" : "yyyy", Locale.getDefault());
        SimpleDateFormat labelFormat = new SimpleDateFormat(
                showMonthlyTrend ? "MMM yy" : "yyyy", Locale.getDefault());

        Map<String, List<Double>> grouped = new TreeMap<>();
        Map<String, String> labels = new LinkedHashMap<>();

        for (ScoreEntry entry : allScoreEntries) {
            String key = keyFormat.format(new java.util.Date(entry.timestamp));
            grouped.computeIfAbsent(key, k -> new ArrayList<>()).add(entry.percent);
            labels.put(key, labelFormat.format(new java.util.Date(entry.timestamp)));
        }

        if (grouped.size() < 1) {
            lineChartTrend.clear();
            lineChartTrend.setVisibility(View.GONE);
            tvTrendEmpty.setVisibility(View.VISIBLE);
            return;
        }

        lineChartTrend.setVisibility(View.VISIBLE);
        tvTrendEmpty.setVisibility(View.GONE);

        ArrayList<Entry> entries = new ArrayList<>();
        ArrayList<String> xLabels = new ArrayList<>();
        int index = 0;
        for (Map.Entry<String, List<Double>> g : grouped.entrySet()) {
            double sum = 0;
            for (double p : g.getValue()) sum += p;
            double avg = sum / g.getValue().size();
            entries.add(new Entry(index, (float) avg));
            xLabels.add(labels.get(g.getKey()));
            index++;
        }

        LineDataSet dataSet = new LineDataSet(entries, "Average Progress %");
        dataSet.setColor(0xFFB71C1C);
        dataSet.setCircleColor(0xFFB71C1C);
        dataSet.setCircleRadius(4.5f);
        dataSet.setLineWidth(2.5f);
        dataSet.setValueTextSize(10f);
        dataSet.setValueTextColor(0xFF424242);
        dataSet.setDrawFilled(true);
        dataSet.setFillColor(0xFFFFCDD2);
        dataSet.setFillAlpha(80);
        dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);

        LineData lineData = new LineData(dataSet);
        lineChartTrend.setData(lineData);

        XAxis xAxis = lineChartTrend.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xLabels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setDrawGridLines(false);
        xAxis.setTextSize(10f);
        xAxis.setAvoidFirstLastClipping(true);
        if (xLabels.size() > 6) {
            xAxis.setLabelRotationAngle(-45f);
            xAxis.setLabelCount(6, false);
        } else {
            xAxis.setLabelRotationAngle(0f);
            xAxis.setLabelCount(xLabels.size(), false);
        }
        lineChartTrend.setExtraBottomOffset(14f);

        lineChartTrend.getAxisLeft().setAxisMinimum(0f);
        lineChartTrend.getAxisLeft().setAxisMaximum(100f);
        lineChartTrend.getAxisLeft().setDrawGridLines(true);
        lineChartTrend.getAxisRight().setEnabled(false);
        lineChartTrend.getDescription().setEnabled(false);
        lineChartTrend.getLegend().setEnabled(true);
        lineChartTrend.setTouchEnabled(true);
        lineChartTrend.setPinchZoom(true);

        lineChartTrend.animateX(800);
        lineChartTrend.invalidate();
    }

    private void setupBottomNav() {
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) { finish(); return true; }
            if (id == R.id.nav_bottom_feedback) { startActivity(new Intent(this, FeedbackActivity.class)); return true; }
            if (id == R.id.nav_bottom_profile) { startActivity(new Intent(this, ProfileActivity.class)); return true; }
            return false;
        });
    }

    private void setupDrawerNav() {
        navigationView.setNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_logout) {
                FirebaseAuth.getInstance().signOut();
                Intent i = new Intent(this, LoginSelectionActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                finishAffinity();
            }
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });
    }

    // ── RecyclerView Adapter ──────────────────────────────────────────────────
    class ProgressAdapter extends RecyclerView.Adapter<ProgressAdapter.VH> {
        private List<ProgressItem> mList;
        ProgressAdapter(List<ProgressItem> list) { this.mList = list; }

        class VH extends RecyclerView.ViewHolder {
            TextView tvSubject, tvClass, tvClassVal, tvAssignVal, tvQuizVal, tvAvgVal;
            ProgressBar progressBar;
            ImageView ivSubject;
            VH(View v) {
                super(v);
                tvSubject   = v.findViewById(R.id.tvSubject);
                tvClass     = v.findViewById(R.id.tvClass);
                tvClassVal  = v.findViewById(R.id.tvClassVal);
                tvAssignVal = v.findViewById(R.id.tvAssignVal);
                tvQuizVal   = v.findViewById(R.id.tvQuizVal);
                tvAvgVal    = v.findViewById(R.id.tvAvgVal);
                progressBar = v.findViewById(R.id.progressBar);
                ivSubject   = v.findViewById(R.id.ivSubject);
            }
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_progress_report, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int pos) {
            ProgressItem p = mList.get(pos);
            h.tvSubject.setText(p.subject);
            h.tvClass.setText("Class: " + p.className);
            h.tvClassVal.setText(p.classAttended + "/" + p.classTotal + "\n(" + p.attendancePct + "%)");
            h.tvAssignVal.setText(p.assignMarks + "/" + p.assignTotal);
            h.tvQuizVal.setText(p.quizMarks + "/" + p.quizTotal);
            h.tvAvgVal.setText(p.avgPercent + "%");
            h.progressBar.setProgress(p.avgPercent);
            int color = (p.avgPercent >= 75) ? 0xFF388E3C : (p.avgPercent >= 50 ? 0xFFFF8F00 : 0xFFD32F2F);
            h.progressBar.getProgressDrawable().setColorFilter(color, android.graphics.PorterDuff.Mode.SRC_IN);

            // Subject image
            String subjectLower = p.subject.toLowerCase();
            int imgRes;
            if      (subjectLower.contains("math"))      imgRes = R.drawable.ic_mathematics;
            else if (subjectLower.contains("english"))   imgRes = R.drawable.ic_english;
            else if (subjectLower.contains("physics"))   imgRes = R.drawable.ic_physics;
            else if (subjectLower.contains("chemistry")) imgRes = R.drawable.ic_chemistry;
            else if (subjectLower.contains("biology"))   imgRes = R.drawable.ic_biology;
            else if (subjectLower.contains("computer"))  imgRes = R.drawable.ic_computer;
            else if (subjectLower.contains("urdu"))      imgRes = R.drawable.ic_urdu;
            else if (subjectLower.contains("islamiyat")) imgRes = R.drawable.ic_islamiyat;
            else if (subjectLower.contains("pak"))       imgRes = R.drawable.ic_pakstudy;
            else                                         imgRes = R.drawable.ic_studentpr;
            h.ivSubject.setImageResource(imgRes);
        }
        @Override public int getItemCount() { return mList.size(); }
    }
}