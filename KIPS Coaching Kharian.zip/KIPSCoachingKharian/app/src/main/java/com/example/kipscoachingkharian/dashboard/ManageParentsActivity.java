package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.HashMap;
import java.util.Map;

public class ManageParentsActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private LinearLayout containerParents;
    private TextView tvCount, tvLoading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_parents);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        containerParents = findViewById(R.id.containerParentsList);
        tvCount = findViewById(R.id.tvTotalParentsCount);
        tvLoading = findViewById(R.id.tvParentsLoading);

        loadParentsData();
    }

    private void loadParentsData() {
        mDatabase.child("Users").orderByChild("role").equalTo("Parent")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        containerParents.removeAllViews();
                        tvLoading.setVisibility(View.GONE);

                        long parentCount = snapshot.getChildrenCount();
                        tvCount.setText(String.valueOf(parentCount));

                        if (parentCount == 0) {
                            showEmptyState("No parents registered yet.");
                            return;
                        }

                        for (DataSnapshot parentSnap : snapshot.getChildren()) {
                            String parentId = parentSnap.getKey();
                            String name      = parentSnap.child("name").getValue(String.class);
                            String email     = parentSnap.child("email").getValue(String.class);
                            String role      = parentSnap.child("role").getValue(String.class);

                            // Pehle registrationId check karein, phir studentId/childId as fallback
                            String regId = parentSnap.child("registrationId").getValue(String.class);
                            if (regId == null) regId = parentSnap.child("studentId").getValue(String.class);
                            if (regId == null) regId = parentSnap.child("childId").getValue(String.class);

                            Object phoneObj = parentSnap.child("phone").getValue();
                            if (phoneObj == null) phoneObj = parentSnap.child("phoneNumber").getValue();
                            String phone = phoneObj != null ? String.valueOf(phoneObj).trim() : "-";

                            // Null safety
                            name  = (name == null) ? "-" : name;
                            email = (email == null) ? "-" : email;
                            role  = (role == null) ? "Parent" : role;
                            regId = (regId == null) ? "N/A" : regId;

                            createModernParentRow(parentId, name, email, phone, role, regId);
                        }
                    }

                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    private void createModernParentRow(String parentId, String name, String email, String phone, String role, String regId) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setBackgroundColor(0xFFFFFFFF);
        card.setPadding(30, 30, 30, 30);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, 20);
        card.setLayoutParams(lp);
        card.setElevation(4f);

        LinearLayout dataLayout = new LinearLayout(this);
        dataLayout.setOrientation(LinearLayout.VERTICAL);
        dataLayout.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));

        TextView tvName = new TextView(this);
        tvName.setText(name);
        tvName.setTextSize(17);
        tvName.setTextColor(0xFF212121);
        tvName.setTypeface(null, android.graphics.Typeface.BOLD);
        dataLayout.addView(tvName);

        TextView tvDetails = new TextView(this);
        // Student ID ki jagah Registration ID label update kar diya gaya hai
        String subDetails = "Email:      " + email
                + "\nPhone:      " + phone
                + "\nRole:       " + role
                + "\nReg ID:     " + regId;
        tvDetails.setText(subDetails);
        tvDetails.setTextSize(14);
        tvDetails.setTextColor(0xFF555555);
        tvDetails.setLineSpacing(6, 1);
        tvDetails.setPadding(0, 8, 0, 0);
        dataLayout.addView(tvDetails);

        card.addView(dataLayout);

        TextView tvMenu = new TextView(this);
        tvMenu.setText("⋮");
        tvMenu.setTextSize(26);
        tvMenu.setPadding(20, 0, 20, 0);
        tvMenu.setTextColor(Color.GRAY);
        tvMenu.setOnClickListener(v -> showActionPopup(v, parentId, name, email));
        card.addView(tvMenu);

        containerParents.addView(card);
    }

    private void showActionPopup(View anchor, String uid, String name, String email) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add("Approve Request");
        popup.getMenu().add("Reject Request");
        popup.getMenu().add("Delete Record");

        popup.setOnMenuItemClickListener(item -> {
            if (item.getTitle().equals("Approve Request")) {
                handleApproval(uid, name, email);
            } else if (item.getTitle().equals("Reject Request")) {
                handleRejection(uid, name, email);
            } else if (item.getTitle().equals("Delete Record")) {
                mDatabase.child("Users").child(uid).removeValue();
            }
            return true;
        });
        popup.show();
    }

    private void handleApproval(String uid, String name, String email) {
        mDatabase.child("Users").child(uid).child("status").setValue("Approved")
                .addOnCompleteListener(task -> {
                    Toast.makeText(this, name + " Approved", Toast.LENGTH_SHORT).show();
                    String subject = "Account Approved - KIPS Coaching Kharian";
                    String message = "Dear " + name + ",\n\nYour parental account request has been APPROVED. You can now login to monitor your child's progress.\n\nRegards,\nAdmin Team";
                    sendEmail(email, subject, message);
                });
    }

    private void handleRejection(String uid, String name, String email) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Reason for Rejection");
        final EditText input = new EditText(this);
        input.setHint("Write reason here...");
        builder.setView(input);

        builder.setPositiveButton("Reject & Mail", (dialog, which) -> {
            String reason = input.getText().toString().trim();
            mDatabase.child("Users").child(uid).child("status").setValue("Rejected");
            String subject = "Account Request Update - KIPS Coaching Kharian";
            String message = "Dear " + name + ",\n\nUnfortunately, your request has been REJECTED.\nReason: " + reason + "\n\nPlease contact admin for more info.";
            sendEmail(email, subject, message);
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void sendEmail(String to, String subject, String body) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, body);
        try {
            startActivity(Intent.createChooser(intent, "Send Confirmation Email..."));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "No email app found.", Toast.LENGTH_SHORT).show();
        }
    }

    private void showEmptyState(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, 50, 0, 0);
        containerParents.addView(tv);
    }
}