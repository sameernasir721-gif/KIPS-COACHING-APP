package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.StudentLoginActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileActivity extends AppCompatActivity {

    // Header views
    private TextView tvName, tvRole;
    private ImageView ivAvatar;

    // Menu items
    private LinearLayout itemMyProfile, itemNotifications, itemSettings, itemHelp, itemLogout;

    private BottomNavigationView bottomNav;
    private View notificationBadge;

    // Firebase
    private FirebaseAuth mAuth;
    private DatabaseReference userRef;

    // Student data
    private String studentName    = "";
    private String studentEmail   = "";
    private String studentPhone   = "";
    private String studentClass   = "";
    private String fatherName     = "";
    private String registrationId = "";

    private static final String PREFS_NAME    = "kips_prefs";
    private static final String KEY_LAST_SEEN = "last_seen_announcement_time";
    private static final String KEY_FONT_SIZE = "student_font_size";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser == null) {
            goToLogin();
            return;
        }

        userRef = FirebaseDatabase.getInstance()
                .getReference("Users")
                .child(currentUser.getUid());

        initViews();
        loadUserProfile();
        checkNewAnnouncements();
        setClickListeners();
        setupBottomNav();
    }

    // ── Views init ────────────────────────────────────────────────────────────
    private void initViews() {
        tvName            = findViewById(R.id.tv_name);
        tvRole            = findViewById(R.id.tv_role);
        ivAvatar          = findViewById(R.id.iv_avatar);
        itemMyProfile     = findViewById(R.id.item_my_profile);
        itemNotifications = findViewById(R.id.item_notifications);
        itemSettings      = findViewById(R.id.item_settings);
        itemHelp          = findViewById(R.id.item_help);
        itemLogout        = findViewById(R.id.item_logout);
        bottomNav         = findViewById(R.id.bottomNav);
        notificationBadge = findViewById(R.id.notification_badge);
    }

    // ── Firebase se data load karo ────────────────────────────────────────────
    private void loadUserProfile() {
        userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    studentName    = getStr(snapshot, "name");
                    studentEmail   = getStr(snapshot, "email");
                    studentPhone   = getStr(snapshot, "phone");
                    studentClass   = getStr(snapshot, "className");
                    fatherName     = getStr(snapshot, "fatherName");
                    registrationId = getStr(snapshot, "registrationId");

                    tvName.setText(studentName.isEmpty() ? "Student" : studentName);
                    String role = getStr(snapshot, "role");
                    tvRole.setText(role.isEmpty() ? "Student" : role);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ProfileActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String getStr(DataSnapshot snap, String key) {
        String val = snap.child(key).getValue(String.class);
        return val != null ? val : "";
    }

    // ── Click Listeners ───────────────────────────────────────────────────────
    private void setClickListeners() {

        // 1. MY PROFILE — StudentProfileInfoActivity kholo
        itemMyProfile.setOnClickListener(v ->
                startActivity(new Intent(this, StudentProfileInfoActivity.class)));

        // 2. NOTIFICATIONS — AnnouncementsActivity kholo + badge hatao
        itemNotifications.setOnClickListener(v -> {
            if (notificationBadge != null) notificationBadge.setVisibility(View.GONE);
            saveLastSeenTime();
            startActivity(new Intent(this, AnnouncementsActivity.class));
        });

        // 3. SETTINGS — StudentSettingActivity kholo (Teacher jaisa dedicated page)
        itemSettings.setOnClickListener(v ->
                startActivity(new Intent(this, StudentSettingActivity.class)));

        // 4. HELP — StudentHelpActivity kholo (Teacher jaisa dedicated page)
        itemHelp.setOnClickListener(v ->
                startActivity(new Intent(this, StudentHelpActivity.class)));

        // 5. LOGOUT
        itemLogout.setOnClickListener(v -> showLogoutDialog());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CHECK NEW ANNOUNCEMENTS + NOTIFICATIONS — badge show/hide
    // ─────────────────────────────────────────────────────────────────────────
    private void checkNewAnnouncements() {
        long lastSeen = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getLong(KEY_LAST_SEEN, 0);

        FirebaseUser currentUser = mAuth.getCurrentUser();
        String uid = (currentUser != null) ? currentUser.getUid() : null;

        int totalChecks = (uid != null) ? 3 : 1;
        java.util.concurrent.atomic.AtomicInteger pending =
                new java.util.concurrent.atomic.AtomicInteger(totalChecks);
        boolean[] hasNew = {false};

        // ── Check 1: Announcements/Students ──────────────────────────────────
        FirebaseDatabase.getInstance().getReference("Announcements").child("Students")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot child : snapshot.getChildren()) {
                            Long ts = child.child("timestamp").getValue(Long.class);
                            if (ts != null && ts > lastSeen) {
                                hasNew[0] = true;
                                break;
                            }
                        }
                        if (pending.decrementAndGet() == 0) updateBadgeVisibility(hasNew[0]);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (pending.decrementAndGet() == 0) updateBadgeVisibility(hasNew[0]);
                    }
                });

        if (uid == null) return;

        // ── Check 2: Notifications/{uid} ─────────────────────────────────────
        FirebaseDatabase.getInstance().getReference("Notifications").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot child : snapshot.getChildren()) {
                            Boolean read = child.child("read").getValue(Boolean.class);
                            Long ts      = child.child("timestamp").getValue(Long.class);
                            if (!Boolean.TRUE.equals(read)) { hasNew[0] = true; break; }
                            if (ts != null && ts > lastSeen)  { hasNew[0] = true; break; }
                        }
                        if (pending.decrementAndGet() == 0) updateBadgeVisibility(hasNew[0]);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (pending.decrementAndGet() == 0) updateBadgeVisibility(hasNew[0]);
                    }
                });

        // ── Check 3: SharedAssignments/{uid} ─────────────────────────────────
        FirebaseDatabase.getInstance().getReference("SharedAssignments").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot child : snapshot.getChildren()) {
                            Long ts = child.child("sharedAt").getValue(Long.class);
                            if (ts != null && ts > lastSeen) { hasNew[0] = true; break; }
                        }
                        if (pending.decrementAndGet() == 0) updateBadgeVisibility(hasNew[0]);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (pending.decrementAndGet() == 0) updateBadgeVisibility(hasNew[0]);
                    }
                });
    }

    private void updateBadgeVisibility(boolean hasNew) {
        if (notificationBadge != null) {
            notificationBadge.setVisibility(hasNew ? View.VISIBLE : View.GONE);
        }
    }

    private void saveLastSeenTime() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putLong(KEY_LAST_SEEN, System.currentTimeMillis())
                .apply();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LOGOUT DIALOG
    // ─────────────────────────────────────────────────────────────────────────
    private void showLogoutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Do you want to logout?")
                .setPositiveButton("Yes, Logout", (dialog, which) -> {
                    mAuth.signOut();
                    goToLogin();
                })
                .setNegativeButton("Cancel", null)
                .setIcon(R.drawable.ic_power)
                .show();
    }

    // ── Bottom Navigation ─────────────────────────────────────────────────────
    private void setupBottomNav() {
        bottomNav.setSelectedItemId(R.id.nav_bottom_profile);

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_bottom_home) {
                Intent intent = new Intent(this, StudentDashboardActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
                return true;

            } else if (id == R.id.nav_bottom_feedback) {
                startActivity(new Intent(this, FeedbackActivity.class));
                finish();
                return true;

            } else if (id == R.id.nav_bottom_profile) {
                return true;
            }
            return false;
        });
    }

    // ── Font Scale ─────────────────────────────────────────────────────────────
    @Override
    protected void attachBaseContext(android.content.Context newBase) {
        android.content.SharedPreferences prefs =
                newBase.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int size = prefs.getInt(KEY_FONT_SIZE, 1);
        float scale;
        switch (size) {
            case 0: scale = 0.85f; break;
            case 2: scale = 1.15f; break;
            default: scale = 1.0f;
        }
        android.content.res.Configuration config = new android.content.res.Configuration();
        config.fontScale = scale;
        android.content.Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }

    private void goToLogin() {
        Intent intent = new Intent(this, StudentLoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}