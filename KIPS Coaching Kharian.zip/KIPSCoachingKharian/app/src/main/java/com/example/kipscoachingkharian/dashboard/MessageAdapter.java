package com.example.kipscoachingkharian.dashboard;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.kipscoachingkharian.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_SENT     = 1;
    private static final int TYPE_RECEIVED = 2;

    private final Context       context;
    private final List<Message> messages;
    private final String        currentUserId;   // = myUid from ChatActivity

    private boolean             selectionMode    = false;
    private final List<Message> selectedMessages = new ArrayList<>();

    // ── Callback interface ────────────────────────────────────────
    // Long press hone par ChatActivity ko batao: kaun sa message tha
    // ChatActivity apna showDeleteDialog() khud dikhayega
    public interface OnMessageLongPressListener {
        void onLongPress(Message msg);
    }
    private OnMessageLongPressListener longPressListener;

    public void setOnMessageLongPressListener(OnMessageLongPressListener l) {
        this.longPressListener = l;
    }

    // ── Attachment tap callback ───────────────────────────────────
    // Image/PDF pe tap hone par ChatActivity ko batao → woh file open karega
    public interface OnAttachmentClickListener {
        void onAttachmentClick(Message msg);
    }
    private OnAttachmentClickListener attachmentClickListener;

    public void setOnAttachmentClickListener(OnAttachmentClickListener l) {
        this.attachmentClickListener = l;
    }

    // ─────────────────────────────────────────────────────────────

    public MessageAdapter(Context context, List<Message> messages, String currentUserId) {
        this.context       = context;
        this.messages      = messages;
        this.currentUserId = currentUserId;
    }

    // ── Selection mode ────────────────────────────────────────────

    public void setSelectionMode(boolean on) {
        selectionMode = on;
        selectedMessages.clear();
        notifyDataSetChanged();
    }

    public boolean       isSelectionMode()      { return selectionMode; }
    public List<Message> getSelectedMessages()  { return new ArrayList<>(selectedMessages); }

    // ── ViewType ──────────────────────────────────────────────────

    @Override
    public int getItemViewType(int pos) {
        String senderId = messages.get(pos).getSenderId();
        // senderId == currentUserId → mera message (right/sent bubble)
        // warna → doosre ka message (left/received bubble)
        return (senderId != null && senderId.equals(currentUserId))
                ? TYPE_SENT : TYPE_RECEIVED;
    }

    // ── Create ViewHolder ─────────────────────────────────────────

    @NonNull @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inf = LayoutInflater.from(context);
        if (viewType == TYPE_SENT)
            return new SentVH(inf.inflate(R.layout.item_message_sent, parent, false));
        else
            return new ReceivedVH(inf.inflate(R.layout.item_message_received, parent, false));
    }

    // ── Bind ──────────────────────────────────────────────────────

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int pos) {
        Message msg         = messages.get(pos);
        boolean delEveryone = msg.isDeletedForEveryone();
        boolean selected    = selectedMessages.contains(msg);

        // Selection highlight
        holder.itemView.setBackgroundColor(
                selected ? Color.parseColor("#D1E4FF") : Color.TRANSPARENT);

        String time = msg.getTimestamp() > 0
                ? new SimpleDateFormat("hh:mm a", Locale.getDefault())
                .format(new Date(msg.getTimestamp()))
                : "";

        // ── SENT bubble ───────────────────────────────────────────
        if (holder instanceof SentVH) {
            SentVH sh = (SentVH) holder;
            sh.tvTime.setText(time);

            if (delEveryone) {
                // Placeholder: maine delete kiya → "You deleted this message"
                sh.ivImage.setVisibility(View.GONE);
                sh.cardPdf.setVisibility(View.GONE);
                sh.tvMessage.setVisibility(View.VISIBLE);
                sh.tvMessage.setText("You deleted this message");
                sh.tvMessage.setTextColor(Color.parseColor("#9E9E9E"));
                sh.tvMessage.setTypeface(null, Typeface.ITALIC);
                sh.ivTick.setVisibility(View.GONE);
            } else {
                if (msg.isImage()) {
                    // Image attachment
                    sh.tvMessage.setVisibility(View.GONE);
                    sh.cardPdf.setVisibility(View.GONE);
                    sh.ivImage.setVisibility(View.VISIBLE);
                    loadImage(sh.ivImage, msg.getFileUrl());
                    bindAttachmentTouch(sh.ivImage, msg, pos, holder);
                } else if (msg.isPdf()) {
                    // PDF attachment
                    sh.tvMessage.setVisibility(View.GONE);
                    sh.ivImage.setVisibility(View.GONE);
                    sh.cardPdf.setVisibility(View.VISIBLE);
                    sh.tvPdfName.setText(safeFileName(msg.getFileName()));
                    sh.tvPdfSize.setText(msg.getFileSize() != null ? msg.getFileSize() : "");
                    bindAttachmentTouch(sh.cardPdf, msg, pos, holder);
                } else {
                    // Plain text
                    sh.ivImage.setVisibility(View.GONE);
                    sh.cardPdf.setVisibility(View.GONE);
                    sh.tvMessage.setVisibility(View.VISIBLE);
                    sh.tvMessage.setText(msg.getText());
                    sh.tvMessage.setTextColor(Color.parseColor("#212121"));
                    sh.tvMessage.setTypeface(null, Typeface.NORMAL);
                }
                sh.ivTick.setVisibility(View.VISIBLE);
                // Read ticks
                if (msg.isRead()) {
                    sh.ivTick.setImageResource(R.drawable.ic_done_all);
                    sh.ivTick.setColorFilter(Color.parseColor("#34B7F1")); // blue double tick
                } else {
                    sh.ivTick.setImageResource(R.drawable.ic_done);
                    sh.ivTick.setColorFilter(Color.GRAY); // grey single tick
                }
            }
        }

        // ── RECEIVED bubble ───────────────────────────────────────
        else if (holder instanceof ReceivedVH) {
            ReceivedVH rh = (ReceivedVH) holder;
            rh.tvTime.setText(time);

            if (delEveryone) {
                rh.tvSenderName.setVisibility(View.GONE);
                rh.ivImage.setVisibility(View.GONE);
                rh.cardPdf.setVisibility(View.GONE);
                rh.tvMessage.setVisibility(View.VISIBLE);
                rh.tvMessage.setText("This message was deleted");
                rh.tvMessage.setTextColor(Color.parseColor("#9E9E9E"));
                rh.tvMessage.setTypeface(null, Typeface.ITALIC);
            } else {
                rh.tvSenderName.setVisibility(View.VISIBLE);
                rh.tvSenderName.setText(msg.getSenderName());

                if (msg.isImage()) {
                    rh.tvMessage.setVisibility(View.GONE);
                    rh.cardPdf.setVisibility(View.GONE);
                    rh.ivImage.setVisibility(View.VISIBLE);
                    loadImage(rh.ivImage, msg.getFileUrl());
                    bindAttachmentTouch(rh.ivImage, msg, pos, holder);
                } else if (msg.isPdf()) {
                    rh.tvMessage.setVisibility(View.GONE);
                    rh.ivImage.setVisibility(View.GONE);
                    rh.cardPdf.setVisibility(View.VISIBLE);
                    rh.tvPdfName.setText(safeFileName(msg.getFileName()));
                    rh.tvPdfSize.setText(msg.getFileSize() != null ? msg.getFileSize() : "");
                    bindAttachmentTouch(rh.cardPdf, msg, pos, holder);
                } else {
                    rh.ivImage.setVisibility(View.GONE);
                    rh.cardPdf.setVisibility(View.GONE);
                    rh.tvMessage.setVisibility(View.VISIBLE);
                    rh.tvMessage.setText(msg.getText());
                    rh.tvMessage.setTextColor(Color.parseColor("#212121"));
                    rh.tvMessage.setTypeface(null, Typeface.NORMAL);
                }
            }
        }

        // ── Long press handler ────────────────────────────────────
        // Deleted ("This message was deleted") messages bhi select ho sakte hain
        // (taake user apni side se inko hata sake)
        holder.itemView.setOnLongClickListener(v -> {
            if (!selectionMode) {
                // Pehli baar long press → selection mode on karo
                selectionMode = true;
                selectedMessages.clear();
                selectedMessages.add(msg);
                notifyDataSetChanged(); // saare items refresh (highlight ke liye)
            } else {
                // Pehle se selection mode → is message ko toggle karo
                if (selectedMessages.contains(msg)) selectedMessages.remove(msg);
                else selectedMessages.add(msg);
                notifyItemChanged(pos);
            }

            // ChatActivity ko batao — woh delete dialog dikhayega
            if (longPressListener != null) longPressListener.onLongPress(msg);
            return true;
        });

        // ── Single tap handler ────────────────────────────────────
        // Selection mode mein → tap se toggle
        holder.itemView.setOnClickListener(v -> {
            if (!selectionMode) return;
            if (selectedMessages.contains(msg)) selectedMessages.remove(msg);
            else selectedMessages.add(msg);
            notifyItemChanged(pos);
        });
    }

    @Override
    public int getItemCount() { return messages.size(); }

    // ── Attachment helpers ────────────────────────────────────────

    /** Image ko URL se load karo (Glide caching + recycling handle karta hai) */
    private void loadImage(ImageView iv, String url) {
        Glide.with(context)
                .load(url)
                .placeholder(R.drawable.ic_image)
                .error(R.drawable.ic_image)
                .into(iv);
    }

    /** File name null/empty ho to fallback */
    private String safeFileName(String name) {
        return (name == null || name.trim().isEmpty()) ? "PDF document" : name;
    }

    /**
     * Image/PDF view pe touch bind karo:
     *  - tap   → handleAttachmentTap (selection mode mein toggle, warna open)
     *  - long  → itemView ka long press (select/delete flow chale)
     */
    private void bindAttachmentTouch(View v, Message msg, int pos,
                                     RecyclerView.ViewHolder holder) {
        v.setOnClickListener(x -> handleAttachmentTap(msg, pos));
        v.setOnLongClickListener(x -> holder.itemView.performLongClick());
    }

    /** Attachment pe tap: selection mode mein selection toggle, warna file open */
    private void handleAttachmentTap(Message msg, int pos) {
        if (selectionMode) {
            if (selectedMessages.contains(msg)) selectedMessages.remove(msg);
            else selectedMessages.add(msg);
            notifyItemChanged(pos);
        } else if (attachmentClickListener != null) {
            attachmentClickListener.onAttachmentClick(msg);
        }
    }

    // ── ViewHolders ───────────────────────────────────────────────

    static class SentVH extends RecyclerView.ViewHolder {
        TextView  tvMessage, tvTime, tvPdfName, tvPdfSize;
        ImageView ivTick, ivImage;
        View      cardPdf;
        SentVH(View v) {
            super(v);
            tvMessage = v.findViewById(R.id.tvMessageSent);
            tvTime    = v.findViewById(R.id.tvTimeSent);
            ivTick    = v.findViewById(R.id.ivTick);
            ivImage   = v.findViewById(R.id.ivImageSent);
            cardPdf   = v.findViewById(R.id.cardPdfSent);
            tvPdfName = v.findViewById(R.id.tvPdfNameSent);
            tvPdfSize = v.findViewById(R.id.tvPdfSizeSent);
        }
    }

    static class ReceivedVH extends RecyclerView.ViewHolder {
        TextView  tvSenderName, tvMessage, tvTime, tvPdfName, tvPdfSize;
        ImageView ivImage;
        View      cardPdf;
        ReceivedVH(View v) {
            super(v);
            tvSenderName = v.findViewById(R.id.tvSenderName);
            tvMessage    = v.findViewById(R.id.tvMessageReceived);
            tvTime       = v.findViewById(R.id.tvTimeReceived);
            ivImage      = v.findViewById(R.id.ivImageReceived);
            cardPdf      = v.findViewById(R.id.cardPdfReceived);
            tvPdfName    = v.findViewById(R.id.tvPdfNameReceived);
            tvPdfSize    = v.findViewById(R.id.tvPdfSizeReceived);
        }
    }
}