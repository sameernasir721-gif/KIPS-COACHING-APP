package com.example.kipscoachingkharian.dashboard;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;



public class ChangeFeeStructureActivity extends AppCompatActivity {

    private EditText etPerSubjectFee, etSpecialSubjectFee;
    private EditText etRegDeadline;

    // ── Test-only hook ───────────────────────────────────────────────────
    // Some OEMs (Tecno/HiOS, etc.) render their own custom Toast which is not
    // exposed through the standard Android accessibility tree, so
    // Espresso/UiAutomator cannot "see" it — even though it is actually
    // visible to the user on screen. Therefore, alongside every Toast, we also
    // set the same message in this small, GONE (invisible, no effect on the UI)
    // TextView — tests can find it by its tag ("test_status_message") and
    // check it reliably, independent of the OEM. Real users never see it, and
    // the normal Toast keeps showing exactly as before.
    private TextView tvTestStatus;

    private static final String DEADLINE_FORMAT = "yyyy-MM-dd HH:mm";

    private final DatabaseReference configRef =
            FirebaseDatabase.getInstance().getReference("payment_config");
    private final DatabaseReference regConfigRef =
            FirebaseDatabase.getInstance().getReference("registration_config");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ── Root Layout ───────────────────────────────────────────────────
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF4F6FA);

        // ── Toolbar ───────────────────────────────────────────────────────
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setBackgroundColor(0xFFC62828);
        toolbar.setPadding(dp(16), dp(14), dp(16), dp(14));

        ImageView ivBack = new ImageView(this);
        ivBack.setImageResource(android.R.drawable.ic_menu_revert);
        ivBack.setColorFilter(0xFFFFFFFF);
        ivBack.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(dp(24), dp(24));
        bLp.setMarginEnd(dp(14));
        ivBack.setLayoutParams(bLp);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Change Fee Structure");
        tvTitle.setTextSize(18f);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);

        toolbar.addView(ivBack);
        toolbar.addView(tvTitle);

        // ── ScrollView + Container ────────────────────────────────────────
        ScrollView sv = new ScrollView(this);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(16), dp(24), dp(16), dp(24));

        TextView tvSection = new TextView(this);
        tvSection.setText("Update fee amounts (Rs.) used for challan generation");
        tvSection.setTextSize(13f);
        tvSection.setTextColor(0xFF888888);
        tvSection.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.setMargins(0, 0, 0, dp(16));
        tvSection.setLayoutParams(slp);
        container.addView(tvSection);

        // ── Card: Regular subject fee ─────────────────────────────────────
        CardView cardRegular = makeCard();
        LinearLayout innerRegular = (LinearLayout) cardRegular.getChildAt(0);

        TextView tvRegularLabel = new TextView(this);
        tvRegularLabel.setText("📘  Regular Subject Fee");
        tvRegularLabel.setTextSize(16f);
        tvRegularLabel.setTypeface(null, Typeface.BOLD);
        tvRegularLabel.setTextColor(0xFF1565C0);
        innerRegular.addView(tvRegularLabel);

        TextView tvRegularHint = new TextView(this);
        tvRegularHint.setText("Applies to all normal subjects, per subject.");
        tvRegularHint.setTextSize(12f);
        tvRegularHint.setTextColor(0xFF888888);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        hintLp.topMargin = dp(4);
        hintLp.bottomMargin = dp(12);
        tvRegularHint.setLayoutParams(hintLp);
        innerRegular.addView(tvRegularHint);

        etPerSubjectFee = makeAmountInput("e.g. 3000");
        innerRegular.addView(etPerSubjectFee);
        container.addView(cardRegular);

        // ── Card: Special subject fee ─────────────────────────────────────
        CardView cardSpecial = makeCard();
        LinearLayout innerSpecial = (LinearLayout) cardSpecial.getChildAt(0);

        TextView tvSpecialLabel = new TextView(this);
        tvSpecialLabel.setText("📗  Special Subject Fee");
        tvSpecialLabel.setTextSize(16f);
        tvSpecialLabel.setTypeface(null, Typeface.BOLD);
        tvSpecialLabel.setTextColor(0xFF2E7D32);
        innerSpecial.addView(tvSpecialLabel);

        TextView tvSpecialHint = new TextView(this);
        tvSpecialHint.setText("Applies to Urdu, Pak Studies, Islamiat, per subject.");
        tvSpecialHint.setTextSize(12f);
        tvSpecialHint.setTextColor(0xFF888888);
        LinearLayout.LayoutParams hintLp2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        hintLp2.topMargin = dp(4);
        hintLp2.bottomMargin = dp(12);
        tvSpecialHint.setLayoutParams(hintLp2);
        innerSpecial.addView(tvSpecialHint);

        etSpecialSubjectFee = makeAmountInput("e.g. 2500");
        innerSpecial.addView(etSpecialSubjectFee);
        container.addView(cardSpecial);

        // ── Card: Registration Deadline ────────────────────────────────────
        CardView cardDeadline = makeCard();
        LinearLayout innerDeadline = (LinearLayout) cardDeadline.getChildAt(0);

        TextView tvDeadlineLabel = new TextView(this);
        tvDeadlineLabel.setText("🗓  Registration Deadline");
        tvDeadlineLabel.setTextSize(16f);
        tvDeadlineLabel.setTypeface(null, Typeface.BOLD);
        tvDeadlineLabel.setTextColor(0xFFB71C1C);
        innerDeadline.addView(tvDeadlineLabel);

        TextView tvDeadlineHint = new TextView(this);
        tvDeadlineHint.setText("After this, students will not be able to make a new registration. Leave it empty or press Clear to keep registration open permanently.");
        tvDeadlineHint.setTextSize(12f);
        tvDeadlineHint.setTextColor(0xFF888888);
        LinearLayout.LayoutParams hintLp3 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        hintLp3.topMargin = dp(4);
        hintLp3.bottomMargin = dp(12);
        tvDeadlineHint.setLayoutParams(hintLp3);
        innerDeadline.addView(tvDeadlineHint);

        etRegDeadline = new EditText(this);
        etRegDeadline.setHint("Tap to select date & time");
        etRegDeadline.setFocusable(false);
        etRegDeadline.setClickable(true);
        etRegDeadline.setTextSize(15f);
        etRegDeadline.setTextColor(0xFF333333);
        etRegDeadline.setBackgroundColor(0xFFF0F0F0);
        etRegDeadline.setPadding(dp(12), dp(10), dp(12), dp(10));
        etRegDeadline.setOnClickListener(v -> showDeadlinePicker());
        innerDeadline.addView(etRegDeadline);

        TextView tvClearDeadline = new TextView(this);
        tvClearDeadline.setText("Clear (no deadline — always open)");
        tvClearDeadline.setTextSize(12.5f);
        tvClearDeadline.setTextColor(0xFF1565C0);
        tvClearDeadline.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        clearLp.topMargin = dp(10);
        tvClearDeadline.setLayoutParams(clearLp);
        tvClearDeadline.setOnClickListener(v -> etRegDeadline.setText(""));
        innerDeadline.addView(tvClearDeadline);

        container.addView(cardDeadline);

        // ── Save Button ───────────────────────────────────────────────────
        Button btnSave = new Button(this);
        btnSave.setText("SAVE CHANGES");
        btnSave.setTextColor(0xFFFFFFFF);
        btnSave.setTypeface(null, Typeface.BOLD);
        btnSave.setBackgroundColor(0xFFC62828);
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
        btnLp.topMargin = dp(8);
        btnSave.setLayoutParams(btnLp);
        btnSave.setOnClickListener(v -> saveAllChanges());
        container.addView(btnSave);

        sv.addView(container);
        root.addView(toolbar);
        root.addView(sv);

        // ── Hidden test-status view (see field comment above) ──────────────
        tvTestStatus = new TextView(this);
        tvTestStatus.setTag("test_status_message");
        tvTestStatus.setVisibility(View.GONE);
        root.addView(tvTestStatus);

        setContentView(root);

        loadCurrentFeeStructure();
        loadCurrentDeadline();
    }

    // Shows a Toast (as before) and also sets the same text in the hidden
    // test-status view, so that instrumented tests can verify the message in
    // an OEM-independent way. Behavior/appearance stays exactly the same for
    // real users.
    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        if (tvTestStatus != null) {
            tvTestStatus.setText(message);
        }
    }

    // ── Date & Time picker for the deadline field ───────────────────────────
    private void showDeadlinePicker() {
        Calendar cal = Calendar.getInstance();

        String current = etRegDeadline.getText().toString().trim();
        if (!current.isEmpty()) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(DEADLINE_FORMAT, Locale.getDefault());
                Date d = sdf.parse(current);
                if (d != null) cal.setTime(d);
            } catch (ParseException ignored) {
                // If the old value cannot be parsed, just start from today's date.
            }
        }

        new DatePickerDialog(this, (dView, year, month, dayOfMonth) -> {
            cal.set(Calendar.YEAR, year);
            cal.set(Calendar.MONTH, month);
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth);

            new TimePickerDialog(this, (tView, hourOfDay, minute) -> {
                cal.set(Calendar.HOUR_OF_DAY, hourOfDay);
                cal.set(Calendar.MINUTE, minute);
                SimpleDateFormat sdf = new SimpleDateFormat(DEADLINE_FORMAT, Locale.getDefault());
                etRegDeadline.setText(sdf.format(cal.getTime()));
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show();

        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void loadCurrentFeeStructure() {
        configRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                Long perSubject = snap.child("fee_per_subject").getValue(Long.class);
                Long special = snap.child("fee_special_subject").getValue(Long.class);
                etPerSubjectFee.setText(perSubject != null ? String.valueOf(perSubject) : "3000");
                etSpecialSubjectFee.setText(special != null ? String.valueOf(special) : "2500");
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {
                showMessage("Failed to load current fee structure: " + e.getMessage());
            }
        });
    }

    private void loadCurrentDeadline() {
        regConfigRef.child("deadline").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                String deadline = snap.getValue(String.class);
                etRegDeadline.setText(deadline != null ? deadline : "");
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {
                showMessage("Failed to load registration deadline: " + e.getMessage());
            }
        });
    }

    private void saveAllChanges() {
        String perSubjectStr = etPerSubjectFee.getText().toString().trim();
        String specialStr = etSpecialSubjectFee.getText().toString().trim();
        String deadlineStr = etRegDeadline.getText().toString().trim();

        if (perSubjectStr.isEmpty() || specialStr.isEmpty()) {
            showMessage("Please fill in the fee fields.");
            return;
        }

        long perSubject, special;
        try {
            perSubject = Long.parseLong(perSubjectStr);
            special = Long.parseLong(specialStr);
        } catch (NumberFormatException e) {
            showMessage("Please enter numbers only in the fee fields.");
            return;
        }

        // Deadline is optional — if empty, registration stays open permanently.
        if (!deadlineStr.isEmpty()) {
            try {
                new SimpleDateFormat(DEADLINE_FORMAT, Locale.getDefault()).parse(deadlineStr);
            } catch (ParseException e) {
                showMessage("Deadline date/time is not in the correct format.");
                return;
            }
        }

        Map<String, Object> feeUpdates = new HashMap<>();
        feeUpdates.put("fee_per_subject", perSubject);
        feeUpdates.put("fee_special_subject", special);

        configRef.updateChildren(feeUpdates)
                .addOnFailureListener(e -> showMessage("Fee update failed: " + e.getMessage()));

        Map<String, Object> deadlineUpdates = new HashMap<>();
        // Send null instead of an empty string so that the key is removed from Firebase entirely.
        deadlineUpdates.put("deadline", deadlineStr.isEmpty() ? null : deadlineStr);

        regConfigRef.updateChildren(deadlineUpdates)
                .addOnSuccessListener(unused -> showMessage("Fee structure & deadline updated successfully."))
                .addOnFailureListener(e -> showMessage("Deadline update failed: " + e.getMessage()));
    }

    private CardView makeCard() {
        CardView card = new CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, 0, 0, dp(16));
        card.setLayoutParams(cp);
        card.setRadius(dp(16));
        card.setCardElevation(dp(4));
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(20), dp(20), dp(20), dp(20));
        card.addView(inner);
        return card;
    }

    private EditText makeAmountInput(String hint) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setTextSize(15f);
        et.setTextColor(0xFF333333);
        et.setBackgroundColor(0xFFF0F0F0);
        et.setPadding(dp(12), dp(10), dp(12), dp(10));
        return et;
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density);
    }
}