package com.example.kipscoachingkharian.dashboard;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;

public class ParentHelpActivity extends AppCompatActivity {

    private ImageView btnBack;
    private LinearLayout layoutFaqContainer;

    // Updated FAQ data for Parents
    private final String[][] faqs = {
            {"How can I see my child's marks?",
                    "Open the 'Student Progress' card from your dashboard. You can view marks for quizzes and assignments here."},
            {"Where can I check fee records?",
                    "Go to the 'Fee Records' section to see paid and pending fees, along with monthly breakdowns."},
            {"How do I view new announcements?",
                    "Announcements from the admin or teachers are displayed in the 'Announcements' tab in the bottom navigation bar."},
            {"How do I view my child's assignments and quizzes?",
                    "Go to the 'Assignments and Quizzes' card to see what has been assigned and submission deadlines."},
            {"How do I update my contact information?",
                    "Go to 'My Profile' from the main menu and use the edit icon to update your phone number, password and other details."}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_help);

        btnBack            = findViewById(R.id.btnBack);
        layoutFaqContainer = findViewById(R.id.layoutFaqContainer);

        btnBack.setOnClickListener(v -> finish());

        buildFaqList();
    }

    private void buildFaqList() {
        for (String[] faq : faqs) {
            layoutFaqContainer.addView(createFaqCard(faq[0], faq[1]));
        }
    }

    private CardView createFaqCard(String question, String answer) {
        int dp8  = dpToPx(8);
        int dp12 = dpToPx(12);
        int dp18 = dpToPx(18);

        CardView card = new CardView(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.bottomMargin = dp12;
        card.setLayoutParams(cardParams);
        card.setRadius(dpToPx(16));
        card.setCardElevation(dpToPx(3));
        card.setUseCompatPadding(true);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // Header row (question + chevron)
        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);
        headerRow.setPadding(dp18, dp18, dp18, dp18);
        headerRow.setClickable(true);
        headerRow.setFocusable(true);
        headerRow.setBackgroundResource(android.R.drawable.list_selector_background);

        TextView tvQuestion = new TextView(this);
        tvQuestion.setText(question);
        tvQuestion.setTextColor(0xFF263238);
        tvQuestion.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        tvQuestion.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams qParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tvQuestion.setLayoutParams(qParams);
        headerRow.addView(tvQuestion);

        ImageView ivChevron = new ImageView(this);
        ivChevron.setImageResource(R.drawable.ic_chevron_right);
        LinearLayout.LayoutParams chevronParams = new LinearLayout.LayoutParams(dpToPx(18), dpToPx(18));
        chevronParams.leftMargin = dp8;
        ivChevron.setLayoutParams(chevronParams);
        headerRow.addView(ivChevron);

        // Answer (hidden by default)
        TextView tvAnswer = new TextView(this);
        tvAnswer.setText(answer);
        tvAnswer.setTextColor(0xFF757575);
        tvAnswer.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        tvAnswer.setLineSpacing(dpToPx(2), 1f);
        LinearLayout.LayoutParams aParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        aParams.leftMargin  = dp18;
        aParams.rightMargin = dp18;
        aParams.bottomMargin = dp18;
        tvAnswer.setLayoutParams(aParams);
        tvAnswer.setVisibility(View.GONE);

        headerRow.setOnClickListener(v -> {
            boolean isVisible = tvAnswer.getVisibility() == View.VISIBLE;
            tvAnswer.setVisibility(isVisible ? View.GONE : View.VISIBLE);
            ivChevron.setRotation(isVisible ? 0f : 90f);
        });

        container.addView(headerRow);
        container.addView(tvAnswer);
        card.addView(container);

        return card;
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (dp * density);
    }
}