package com.example.kipscoachingkharian.dashboard;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class TeacherCreateClassFormActivity extends AppCompatActivity {


    private TextView tvTeacherName;

    private TextInputEditText etClassName, etClassCode, etDescription, etClassDuration;
    private TextView etClassDate, etClassTime;
    private AutoCompleteTextView spinnerGrade, etSubject;

    private ImageButton btnClose;
    private android.widget.ImageView ivBack;
    private Button btnCancel, btnCreateClass;
    private TextView tvGenerateMeetLink;

    private BottomNavigationView bottomNav;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    private String selectedDate = "";
    private String selectedTime = "";

    private final String[] GRADES = {
            "9A", "9B", "10A", "10B",
            "11A", "11B", "12A", "12B"
    };

    private final String[] SUBJECTS = {
            "Physics", "Chemistry", "Mathematics", "Biology", "English", "Computer",
            "Urdu", "Islamiyat", "Pak Studies"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_createclasses_form);

        mAuth     = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        initViews();
        loadTeacherInfo();
        setupSubjectDropdown();
        setupGradeDropdown();
        setupDatePicker();
        setupTimePicker();
        setupButtons();
        setupBottomNav();
    }

    private void initViews() {
        tvTeacherName      = findViewById(R.id.tvTeacherName);

        etClassName        = findViewById(R.id.etClassName);
        etSubject          = findViewById(R.id.etSubject);
        etClassCode        = findViewById(R.id.etClassCode);
        etClassDuration    = findViewById(R.id.etClassDuration);
        etDescription      = findViewById(R.id.etDescription);

        etClassDate        = findViewById(R.id.etClassDate);
        etClassTime        = findViewById(R.id.etClassTime);

        styleAsOutlinedField(etClassDate);
        styleAsOutlinedField(etClassTime);

        spinnerGrade       = findViewById(R.id.spinnerGrade);
        btnClose           = findViewById(R.id.btnClose);
        ivBack             = findViewById(R.id.ivBack);
        btnCancel          = findViewById(R.id.btnCancel);
        btnCreateClass     = findViewById(R.id.btnCreateClass);
        tvGenerateMeetLink = findViewById(R.id.tvGenerateMeetLink);
        bottomNav          = findViewById(R.id.bottomNav);
    }

    private void loadTeacherInfo() {}

    private void setupSubjectDropdown() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, SUBJECTS);
        etSubject.setAdapter(adapter);
        etSubject.setOnItemClickListener((parent, view, position, id) ->
                etSubject.setText(SUBJECTS[position], false));
    }

    private void setupGradeDropdown() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, GRADES);
        spinnerGrade.setAdapter(adapter);
        spinnerGrade.setOnItemClickListener((parent, view, position, id) ->
                spinnerGrade.setText(GRADES[position], false));
    }

    private void styleAsOutlinedField(TextView tv) {
        android.graphics.drawable.GradientDrawable border = new android.graphics.drawable.GradientDrawable();
        border.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        border.setCornerRadius(dpToPx(8));
        border.setStroke(dpToPx(1), android.graphics.Color.parseColor("#C8CDD6"));
        border.setColor(android.graphics.Color.WHITE);
        tv.setBackground(border);

        int padH = dpToPx(16);
        int padV = dpToPx(14);
        tv.setPadding(padH, padV, padH, padV);
        tv.setMinimumHeight(dpToPx(52));
        tv.setGravity(android.view.Gravity.CENTER_VERTICAL);
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private void setupDatePicker() {
        etClassDate.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            new DatePickerDialog(this,
                    (view, year, month, day) -> {
                        selectedDate = day + "/" + (month + 1) + "/" + year;
                        etClassDate.setText(selectedDate);
                        etClassDate.setTextColor(android.graphics.Color.parseColor("#1E2A3B"));
                    },
                    cal.get(Calendar.YEAR),
                    cal.get(Calendar.MONTH),
                    cal.get(Calendar.DAY_OF_MONTH)
            ).show();
        });
    }

    private void setupTimePicker() {
        etClassTime.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            new TimePickerDialog(this,
                    (view, hour, minute) -> {
                        String amPm = hour >= 12 ? "PM" : "AM";
                        int hour12  = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
                        selectedTime = String.format("%02d:%02d %s", hour12, minute, amPm);
                        etClassTime.setText(selectedTime);
                        etClassTime.setTextColor(android.graphics.Color.parseColor("#1E2A3B"));
                    },
                    cal.get(Calendar.HOUR_OF_DAY),
                    cal.get(Calendar.MINUTE),
                    false
            ).show();
        });
    }

    private void setupButtons() {
        if (ivBack != null) ivBack.setOnClickListener(v -> finish());
        btnClose.setOnClickListener(v -> finish());
        btnCancel.setOnClickListener(v -> finish());
        tvGenerateMeetLink.setOnClickListener(v -> openGoogleMeetApp());
        btnCreateClass.setOnClickListener(v -> {
            if (validateForm()) {
                saveClassToFirebase();
            }
        });
    }

    private void openGoogleMeetApp() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://meet.google.com/new"));
            intent.setPackage("com.android.chrome");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://meet.google.com/new"));
            startActivity(intent);
        }
    }

    private boolean validateForm() {
        if (TextUtils.isEmpty(etClassName.getText())) return false;
        if (TextUtils.isEmpty(spinnerGrade.getText())) return false;
        if (TextUtils.isEmpty(selectedDate)) return false;
        if (TextUtils.isEmpty(selectedTime)) return false;
        return true;
    }

    private void saveClassToFirebase() {
        if (mAuth.getCurrentUser() == null) return;

        btnCreateClass.setEnabled(false);
        btnCreateClass.setText("Creating...");

        String uid         = mAuth.getCurrentUser().getUid();
        String className   = etClassName.getText().toString().trim();
        String subject     = etSubject.getText().toString().trim();
        String meetLink    = etClassCode.getText().toString().trim();
        String grade       = spinnerGrade.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        String durationStr = etClassDuration.getText() != null
                ? etClassDuration.getText().toString().trim() : "";
        int durationMinutes;
        try {
            durationMinutes = durationStr.isEmpty() ? 60 : Integer.parseInt(durationStr);
        } catch (NumberFormatException e) {
            durationMinutes = 60; // fallback default
        }

        Map<String, Object> classData = new HashMap<>();
        classData.put("className",   className);
        classData.put("subject",     subject);
        classData.put("classLink",   meetLink);
        classData.put("grade",       grade);
        classData.put("description", description);
        classData.put("date",        selectedDate);
        classData.put("time",        selectedTime);
        classData.put("duration",    durationMinutes); // minutes mein, Join button window ke liye
        classData.put("teacherId",   uid);
        classData.put("createdAt",   System.currentTimeMillis());

        mDatabase.child("Classes").child(uid).push().setValue(classData)
                .addOnSuccessListener(unused -> {
                    // ✅ Upcoming Schedule mein save karein
                    saveToUpcomingSchedule(grade, subject, selectedDate, selectedTime);
                    // Notifications bhejein
                    sendNotificationsToAllStudents(className, subject, selectedDate, selectedTime, meetLink);
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    btnCreateClass.setEnabled(true);
                    btnCreateClass.setText("Create Class");
                });
    }

    // 🔥 SAVE TO SCHEDULE LOGIC
    private void saveToUpcomingSchedule(String grade, String subject, String date, String time) {
        // Grade cleaning: "Class 10A" ko sirf "10A" banayein taake student profile se match ho
        String cleanGrade = grade.replace("Class ", "").trim();

        DatabaseReference scheduleRef = mDatabase.child("upcomingSchedule").push();
        Map<String, Object> scheduleMap = new HashMap<>();
        scheduleMap.put("type", "class"); // Dashboard ise Blue card dikhayega
        scheduleMap.put("className", cleanGrade);
        scheduleMap.put("subject", subject);
        scheduleMap.put("classTime", time);
        scheduleMap.put("date", date);
        scheduleMap.put("timestamp", System.currentTimeMillis());
        scheduleRef.setValue(scheduleMap);
    }

    private void sendNotificationsToAllStudents(String className, String subject, String date, String time, String meetLink) {
        String grade = spinnerGrade.getText().toString().trim();
        String gradeNum = grade.trim().replaceAll("[^0-9]", "");

        mDatabase.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                boolean anyStudentFound = false;
                for (DataSnapshot userSnap : snapshot.getChildren()) {
                    String role = userSnap.child("role").getValue(String.class);
                    String classVal = userSnap.child("className").getValue(String.class);

                    if (!"student".equalsIgnoreCase(role) || classVal == null) continue;

                    if (!gradeNum.isEmpty()) {
                        String sNum = classVal.trim().replaceAll("[^0-9]", "");
                        if (!gradeNum.equals(sNum)) continue;
                    }
                    anyStudentFound = true;
                }

                if (anyStudentFound) {
                    Map<String, Object> announcement = new HashMap<>();
                    announcement.put("title", "📚 New Class: " + subject);
                    announcement.put("message", className + " | " + date + " at " + time);
                    announcement.put("classLink", meetLink);
                    announcement.put("targetClass", grade);
                    announcement.put("timestamp", System.currentTimeMillis());
                    announcement.put("type", "new_class");
                    mDatabase.child("Announcements").child("Students").push().setValue(announcement);
                }

                Toast.makeText(TeacherCreateClassFormActivity.this, "Class Created & Scheduled!", Toast.LENGTH_SHORT).show();
                finish();
            }
            @Override public void onCancelled(DatabaseError error) {}
        });
    }

    private void setupBottomNav() {
        bottomNav.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_bottom_home) {
                finish();
                return true;
            }
            return false;
        });
    }
}