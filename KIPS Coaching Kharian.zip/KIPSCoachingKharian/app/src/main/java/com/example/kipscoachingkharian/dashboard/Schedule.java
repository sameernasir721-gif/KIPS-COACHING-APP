package com.example.kipscoachingkharian.dashboard;

public class Schedule {
    private String subject;
    private String time;
    private String day;

    public Schedule(String subject, String time, String day) {
        this.subject = subject;
        this.time = time;
        this.day = day;
    }

    public String getSubject() {
        return subject;
    }

    public String getTime() {
        return time;
    }

    public String getDay() {
        return day;
    }
}
