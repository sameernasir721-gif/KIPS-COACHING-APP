package com.example.kipscoachingkharian.auth;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.android.material.button.MaterialButton;


public class StudentAuthChoiceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_auth_choice);

        MaterialButton btnLogin    = findViewById(R.id.btnChoiceLogin);
        MaterialButton btnRegister = findViewById(R.id.btnChoiceRegister);

        btnLogin.setOnClickListener(v -> openStudentAuth(StudentLoginActivity.MODE_LOGIN));
        btnRegister.setOnClickListener(v -> openStudentAuth(StudentLoginActivity.MODE_REGISTER));
    }

    private void openStudentAuth(String mode) {
        Intent i = new Intent(this, StudentLoginActivity.class);
        i.putExtra(StudentLoginActivity.EXTRA_MODE, mode);
        startActivity(i);
    }
}
