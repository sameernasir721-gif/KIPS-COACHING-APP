package com.example.kipscoachingkharian.auth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.TeacherDashboardActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * Teacher Login Activity
 * Teacher logs in with EMAIL + password.
 * Admin creates teacher account from Admin Dashboard.
 */
public class TeacherLoginActivity extends AppCompatActivity {

    private TextView tabLogin, tvForgotPassword;
    private LinearLayout layoutLogin;
    private MaterialButton btnTeacherLogin;

    private TextInputEditText etTeacherId, etTeacherPassword;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_login);

        mAuth     = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        initViews();
        setupLoginButton();
    }

    private void initViews() {
        tabLogin          = findViewById(R.id.tabLogin);
        layoutLogin       = findViewById(R.id.layoutLogin);
        btnTeacherLogin   = findViewById(R.id.btnTeacherLogin);
        tvForgotPassword  = findViewById(R.id.tvForgotPassword);

        etTeacherId       = findViewById(R.id.etTeacherId);
        etTeacherPassword = findViewById(R.id.etTeacherPassword);

        layoutLogin.setVisibility(View.VISIBLE);
        tabLogin.setBackgroundResource(R.drawable.toggle_bg);
        tabLogin.setTextColor(Color.parseColor("#B71C1C"));

        // ✅ Hint XML se hi aayega — yahan override nahi kar rahe
        etTeacherId.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);

        tvForgotPassword.setOnClickListener(v -> showResetPasswordDialog());
    }

    private void setupLoginButton() {
        btnTeacherLogin.setOnClickListener(v -> {
            String email    = etTeacherId.getText().toString().trim();
            String password = etTeacherPassword.getText().toString().trim();

            if (TextUtils.isEmpty(email)) {
                etTeacherId.setError("Email is required");
                etTeacherId.requestFocus();
                return;
            }
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etTeacherId.setError("Please enter a valid email address");
                etTeacherId.requestFocus();
                return;
            }
            if (TextUtils.isEmpty(password)) {
                etTeacherPassword.setError("Password is required");
                etTeacherPassword.requestFocus();
                return;
            }

            loginTeacher(email, password);
        });
    }

    private void loginTeacher(String email, String password) {
        btnTeacherLogin.setEnabled(false);

        // ✅ Step 1: Pehle DB mein confirm karo ke ye email Teacher record mein
        //    registered hai aur role bhi "Teacher" hai — fake/random email se
        //    Firebase Auth tak pohochne hi nahi diya jayega
        mDatabase.child("Users").orderByChild("email").equalTo(email)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (!snapshot.exists()) {
                            // ✅ Is email se koi Teacher record hi nahi — fake email reject
                            Toast.makeText(TeacherLoginActivity.this,
                                    "❌ Email not found. Contact Admin to get your account.",
                                    Toast.LENGTH_LONG).show();
                            btnTeacherLogin.setEnabled(true);
                            return;
                        }

                        String foundRole = null;
                        for (DataSnapshot user : snapshot.getChildren()) {
                            foundRole = user.child("role").getValue(String.class);
                            break;
                        }

                        if (!"Teacher".equalsIgnoreCase(foundRole)) {
                            Toast.makeText(TeacherLoginActivity.this,
                                    "❌ Access Denied: Teacher accounts only.",
                                    Toast.LENGTH_SHORT).show();
                            btnTeacherLogin.setEnabled(true);
                            return;
                        }

                        // ✅ Step 2: Role confirm — ab Firebase Auth se sign in karo
                        mAuth.signInWithEmailAndPassword(email, password)
                                .addOnCompleteListener(task -> {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(TeacherLoginActivity.this,
                                                "✅ Teacher Login Successful!",
                                                Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(TeacherLoginActivity.this,
                                                TeacherDashboardActivity.class));
                                        finishAffinity();
                                    } else {
                                        // ✅ Galat password ya account exist nahi karta — friendly error
                                        String rawErr = task.getException() != null
                                                ? task.getException().getMessage()
                                                : "Authentication failed";
                                        String friendly = getFriendlyAuthError(rawErr);
                                        Toast.makeText(TeacherLoginActivity.this,
                                                "❌ " + friendly,
                                                Toast.LENGTH_LONG).show();
                                        btnTeacherLogin.setEnabled(true);
                                    }
                                });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(TeacherLoginActivity.this,
                                "Database error: " + error.getMessage(),
                                Toast.LENGTH_SHORT).show();
                        btnTeacherLogin.setEnabled(true);
                    }
                });
    }

    // ── Friendly Firebase Auth error messages ─────────────────────────────────
    private String getFriendlyAuthError(String raw) {
        if (raw == null) return "Login failed. Please try again.";
        if (raw.contains("no user record") || raw.contains("user-not-found")
                || raw.contains("There is no user record"))
            return "This email is not registered. Contact Admin.";
        if (raw.contains("wrong-password") || raw.contains("invalid-credential")
                || raw.contains("password is invalid"))
            return "Incorrect password. Please try again.";
        if (raw.contains("too-many-requests"))
            return "Too many attempts. Please try again later.";
        if (raw.contains("network"))
            return "Network error. Check your internet connection.";
        return raw;
    }

    // ─── RESET PASSWORD (Email only) ──────────────────────────────────────
    private void showResetPasswordDialog() {
        TextInputEditText etEmail = new TextInputEditText(this);
        etEmail.setHint("Enter your registered Email");
        etEmail.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        etEmail.setPadding(40, 30, 40, 30);

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Reset Password")
                .setMessage("Enter your registered email. We'll send a password reset link to it.")
                .setView(etEmail)
                .setPositiveButton("Send Reset Link", (dialog, which) -> {
                    String email = etEmail.getText().toString().trim();

                    if (email.isEmpty()) {
                        Toast.makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                        Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    sendResetEmail(email);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void sendResetEmail(String email) {
        // ✅ Pehle role verify karo — sirf registered Teacher accounts ke liye
        //    reset bheje, koi bhi random email se reset spam nahi ho sakta
        mDatabase.child("Users").orderByChild("email").equalTo(email)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (!snapshot.exists()) {
                            Toast.makeText(TeacherLoginActivity.this,
                                    "❌ Email not found. Contact Admin.",
                                    Toast.LENGTH_LONG).show();
                            return;
                        }

                        String role = null;
                        for (DataSnapshot user : snapshot.getChildren()) {
                            role = user.child("role").getValue(String.class);
                            break;
                        }

                        if (!"Teacher".equalsIgnoreCase(role)) {
                            Toast.makeText(TeacherLoginActivity.this,
                                    "❌ Access Denied: Teacher accounts only.",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        mAuth.sendPasswordResetEmail(email)
                                .addOnCompleteListener(task -> {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(TeacherLoginActivity.this,
                                                "✅ Reset link sent to: " + email,
                                                Toast.LENGTH_LONG).show();
                                    } else {
                                        String err = task.getException() != null
                                                ? task.getException().getMessage()
                                                : "Failed to send reset link";
                                        Toast.makeText(TeacherLoginActivity.this,
                                                "❌ Failed: " + err,
                                                Toast.LENGTH_LONG).show();
                                    }
                                });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(TeacherLoginActivity.this,
                                "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}