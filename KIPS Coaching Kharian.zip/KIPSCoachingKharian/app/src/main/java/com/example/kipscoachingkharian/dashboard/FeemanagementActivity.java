package com.example.kipscoachingkharian.dashboard;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class FeemanagementActivity extends AppCompatActivity {

    private LinearLayout listContainer;
    private LinearLayout summaryRow;
    private EditText etSearch;
    private TextView tvPaidCount, tvUnpaidCount, tvNoRecordCount;

    static class StudentFee {
        String uid, name, className, amount, status, month, dueDate;
        StudentFee(String uid, String n, String c, String a, String s, String m, String d) {
            this.uid = uid; name = n; className = c; amount = a; status = s; month = m; dueDate = d;
        }
    }

    private final List<StudentFee> allStudents = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feemanagement);

        listContainer   = findViewById(R.id.listContainer);
        summaryRow      = findViewById(R.id.summaryRow);
        etSearch        = findViewById(R.id.etSearch);
        tvPaidCount     = findViewById(R.id.tvPaidCount);
        tvUnpaidCount   = findViewById(R.id.tvUnpaidCount);
        tvNoRecordCount = findViewById(R.id.tvNoRecordCount);

        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        showLoading();
        loadFeeData();

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterList(s.toString().trim());
            }
        });
    }

    private void loadFeeData() {
        FirebaseDatabase.getInstance().getReference("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot usersSnap) {
                        List<String> uids    = new ArrayList<>();
                        List<String> names   = new ArrayList<>();
                        List<String> classes = new ArrayList<>();

                        for (DataSnapshot snap : usersSnap.getChildren()) {
                            String role   = snap.child("role").getValue(String.class);
                            String status = snap.child("status").getValue(String.class);
                            if (!"Student".equalsIgnoreCase(role))    continue;
                            if (!"Approved".equalsIgnoreCase(status)) continue;
                            String name = snap.child("name").getValue(String.class);
                            String cls  = snap.child("className").getValue(String.class);
                            if (name == null) continue;
                            uids.add(snap.getKey());
                            names.add(name);
                            classes.add(cls != null ? cls : "");
                        }

                        if (uids.isEmpty()) {
                            runOnUiThread(() -> showEmpty("No approved students found."));
                            return;
                        }

                        FirebaseDatabase.getInstance().getReference("Fees")
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override public void onDataChange(@NonNull DataSnapshot feesSnap) {
                                        allStudents.clear();
                                        for (int i = 0; i < uids.size(); i++) {
                                            String uid  = uids.get(i);
                                            String name = names.get(i);
                                            String cls  = classes.get(i);

                                            DataSnapshot studentFees = feesSnap.child(uid);
                                            if (!studentFees.exists()) {
                                                allStudents.add(new StudentFee(uid, name, cls, "—", "No Record", "—", "—"));
                                                continue;
                                            }

                                            DataSnapshot latest = null;
                                            long latestTime = -1;
                                            for (DataSnapshot record : studentFees.getChildren()) {
                                                Long gen = record.child("generatedAt").getValue(Long.class);
                                                Long sav = record.child("savedAt").getValue(Long.class);
                                                long t = gen != null ? gen : (sav != null ? sav : 0L);
                                                if (t >= latestTime) { latestTime = t; latest = record; }
                                            }

                                            if (latest == null) {
                                                allStudents.add(new StudentFee(uid, name, cls, "—", "No Record", "—", "—"));
                                                continue;
                                            }

                                            String amount  = latest.child("amount").getValue(String.class);
                                            String status2 = latest.child("status").getValue(String.class);
                                            String month   = latest.child("month").getValue(String.class);
                                            String due     = latest.child("dueDate").getValue(String.class);
                                            String amtDisp = (amount != null && !amount.isEmpty() && !amount.equals("—"))
                                                    ? "Rs. " + amount : "—";

                                            allStudents.add(new StudentFee(uid, name, cls, amtDisp,
                                                    status2 != null ? status2 : "Unpaid",
                                                    month   != null ? month   : "—",
                                                    due     != null ? due     : "—"));
                                        }
                                        runOnUiThread(() -> renderList(allStudents));
                                    }
                                    @Override public void onCancelled(@NonNull DatabaseError e) {
                                        runOnUiThread(() -> showEmpty("Failed to load fee data."));
                                    }
                                });
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {
                        runOnUiThread(() -> showEmpty("Failed to load students."));
                    }
                });
    }

    private void renderList(List<StudentFee> list) {
        listContainer.removeAllViews();
        if (list.isEmpty()) { showEmpty("No students found."); return; }

        int paid = 0, unpaid = 0, noRecord = 0;
        for (StudentFee sf : list) {
            if ("Paid".equalsIgnoreCase(sf.status))           paid++;
            else if ("No Record".equalsIgnoreCase(sf.status)) noRecord++;
            else                                              unpaid++;
        }

        summaryRow.setVisibility(View.VISIBLE);
        tvPaidCount.setText(String.valueOf(paid));
        tvUnpaidCount.setText(String.valueOf(unpaid));
        tvNoRecordCount.setText(String.valueOf(noRecord));

        for (StudentFee sf : list) listContainer.addView(makeStudentCard(sf));
    }

    private View makeStudentCard(StudentFee sf) {
        View card = getLayoutInflater().inflate(R.layout.item_student_fee, listContainer, false);

        ((TextView) card.findViewById(R.id.tvName)).setText(sf.name);
        ((TextView) card.findViewById(R.id.tvClass)).setText("📚 Class: " + sf.className);
        ((TextView) card.findViewById(R.id.tvMonth)).setText("📅 " + sf.month);
        ((TextView) card.findViewById(R.id.tvAmount)).setText("💰 " + sf.amount);

        TextView tvDue = card.findViewById(R.id.tvDue);
        tvDue.setText("Due: " + sf.dueDate);
        tvDue.setTextColor(sf.dueDate.equals("—") ? 0xFF999999 : 0xFFE53935);

        boolean isPaid     = "Paid".equalsIgnoreCase(sf.status);
        boolean isNoRecord = "No Record".equalsIgnoreCase(sf.status);
        int badgeBg   = isPaid ? 0xFF43A047 : (isNoRecord ? 0xFF757575 : 0xFFE53935);
        String badge  = isPaid ? "✓ Paid" : (isNoRecord ? "No Record" : "✗ Unpaid");

        TextView tvStatus = card.findViewById(R.id.tvStatus);
        tvStatus.setText(badge);
        tvStatus.getBackground().mutate().setTint(badgeBg);

        return card;
    }

    private void filterList(String query) {
        if (query.isEmpty()) { renderList(allStudents); return; }
        String q = query.toLowerCase();
        List<StudentFee> filtered = new ArrayList<>();
        for (StudentFee sf : allStudents) {
            if (sf.name.toLowerCase().contains(q) ||
                    sf.className.toLowerCase().contains(q) ||
                    sf.status.toLowerCase().contains(q)) {
                filtered.add(sf);
            }
        }
        renderList(filtered);
    }

    private void showLoading() {
        showMessage("Loading fee records...");
    }

    private void showEmpty(String msg) {
        showMessage(msg);
    }

    private void showMessage(String msg) {
        summaryRow.setVisibility(View.GONE);
        listContainer.removeAllViews();
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(14f);
        tv.setTextColor(0xFF888888);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(60), 0, 0);
        listContainer.addView(tv);
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}