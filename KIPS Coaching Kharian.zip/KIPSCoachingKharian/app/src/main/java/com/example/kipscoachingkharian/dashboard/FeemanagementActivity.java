package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * FeemanagementActivity
 * ─────────────────────
 * Admin ke liye — all students ki fee status dikhata hai.
 * ✅ NEW: Har student card pe "Add to Wallet" button hai —
 *         Admin kisi bhi student ke wallet mein amount add kar sakta hai.
 */
public class FeemanagementActivity extends AppCompatActivity {

    private LinearLayout listContainer;
    private EditText etSearch;

    static class StudentFee {
        String uid, name, className, amount, status, month, dueDate;
        StudentFee(String uid, String n, String c, String a, String s, String m, String d) {
            this.uid = uid; name = n; className = c; amount = a; status = s; month = m; dueDate = d;
        }
    }

    private final List<StudentFee> allStudents = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF4F6FA);

        // ── Toolbar ───────────────────────────────────────────────────────
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setBackgroundColor(0xFF1565C0);
        toolbar.setPadding(dp(16), dp(14), dp(16), dp(14));

        ImageView ivBack = new ImageView(this);
        ivBack.setImageResource(android.R.drawable.ic_menu_revert);
        ivBack.setColorFilter(0xFFFFFFFF);
        ivBack.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(dp(24), dp(24));
        bLp.setMarginEnd(dp(14));
        ivBack.setLayoutParams(bLp);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Students Fee Status");
        tvTitle.setTextSize(18f);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);

        toolbar.addView(ivBack);
        toolbar.addView(tvTitle);

        // ── Search Bar ────────────────────────────────────────────────────
        LinearLayout searchLayout = new LinearLayout(this);
        searchLayout.setBackgroundColor(0xFFFFFFFF);
        searchLayout.setPadding(dp(14), dp(10), dp(14), dp(10));

        etSearch = new EditText(this);
        etSearch.setHint("🔍  Search student...");
        etSearch.setTextSize(14f);
        etSearch.setTextColor(0xFF333333);
        etSearch.setHintTextColor(0xFF999999);
        etSearch.setBackgroundColor(Color.TRANSPARENT);
        etSearch.setSingleLine(true);
        etSearch.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        searchLayout.addView(etSearch);

        // ── List ──────────────────────────────────────────────────────────
        ScrollView sv = new ScrollView(this);
        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        listContainer.setPadding(dp(14), dp(14), dp(14), dp(24));
        sv.addView(listContainer);

        root.addView(toolbar);
        root.addView(searchLayout);
        root.addView(sv);
        setContentView(root);

        showLoading();
        loadFeeData();

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterList(s.toString().trim());
            }
        });
    }

    private void loadFeeData() {
        FirebaseDatabase.getInstance().getReference("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot usersSnap) {
                        List<String> uids    = new ArrayList<>();
                        List<String> names   = new ArrayList<>();
                        List<String> classes = new ArrayList<>();

                        for (DataSnapshot snap : usersSnap.getChildren()) {
                            String role   = snap.child("role").getValue(String.class);
                            String status = snap.child("status").getValue(String.class);
                            if (!"Student".equalsIgnoreCase(role))    continue;
                            if (!"Approved".equalsIgnoreCase(status)) continue;
                            String name = snap.child("name").getValue(String.class);
                            String cls  = snap.child("className").getValue(String.class);
                            if (name == null) continue;
                            uids.add(snap.getKey());
                            names.add(name);
                            classes.add(cls != null ? cls : "");
                        }

                        if (uids.isEmpty()) {
                            runOnUiThread(() -> showEmpty("No approved students found."));
                            return;
                        }

                        FirebaseDatabase.getInstance().getReference("Fees")
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override public void onDataChange(@NonNull DataSnapshot feesSnap) {
                                        allStudents.clear();
                                        for (int i = 0; i < uids.size(); i++) {
                                            String uid  = uids.get(i);
                                            String name = names.get(i);
                                            String cls  = classes.get(i);

                                            DataSnapshot studentFees = feesSnap.child(uid);
                                            if (!studentFees.exists()) {
                                                allStudents.add(new StudentFee(uid, name, cls, "—", "No Record", "—", "—"));
                                                continue;
                                            }

                                            DataSnapshot latest = null;
                                            long latestTime = -1;
                                            for (DataSnapshot record : studentFees.getChildren()) {
                                                Long gen = record.child("generatedAt").getValue(Long.class);
                                                Long sav = record.child("savedAt").getValue(Long.class);
                                                long t = gen != null ? gen : (sav != null ? sav : 0L);
                                                if (t >= latestTime) { latestTime = t; latest = record; }
                                            }

                                            if (latest == null) {
                                                allStudents.add(new StudentFee(uid, name, cls, "—", "No Record", "—", "—"));
                                                continue;
                                            }

                                            String amount  = latest.child("amount").getValue(String.class);
                                            String status2 = latest.child("status").getValue(String.class);
                                            String month   = latest.child("month").getValue(String.class);
                                            String due     = latest.child("dueDate").getValue(String.class);
                                            String amtDisp = (amount != null && !amount.isEmpty() && !amount.equals("—"))
                                                    ? "Rs. " + amount : "—";

                                            allStudents.add(new StudentFee(uid, name, cls, amtDisp,
                                                    status2 != null ? status2 : "Unpaid",
                                                    month   != null ? month   : "—",
                                                    due     != null ? due     : "—"));
                                        }
                                        runOnUiThread(() -> renderList(allStudents));
                                    }
                                    @Override public void onCancelled(@NonNull DatabaseError e) {
                                        runOnUiThread(() -> showEmpty("Failed to load fee data."));
                                    }
                                });
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {
                        runOnUiThread(() -> showEmpty("Failed to load students."));
                    }
                });
    }

    private void renderList(List<StudentFee> list) {
        listContainer.removeAllViews();
        if (list.isEmpty()) { showEmpty("No students found."); return; }

        int paid = 0, unpaid = 0, noRecord = 0;
        for (StudentFee sf : list) {
            if ("Paid".equalsIgnoreCase(sf.status))          paid++;
            else if ("No Record".equalsIgnoreCase(sf.status)) noRecord++;
            else                                               unpaid++;
        }

        LinearLayout summaryRow = new LinearLayout(this);
        summaryRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams srp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        srp.setMargins(0, 0, 0, dp(14));
        summaryRow.setLayoutParams(srp);
        summaryRow.addView(makeSummaryCard("Paid",      paid,     0xFF43A047, 0xFFE8F5E9));
        summaryRow.addView(makeSummaryCard("Unpaid",    unpaid,   0xFFE53935, 0xFFFFEBEE));
        summaryRow.addView(makeSummaryCard("No Record", noRecord, 0xFF757575, 0xFFF5F5F5));
        listContainer.addView(summaryRow);

        for (StudentFee sf : list) listContainer.addView(makeStudentCard(sf));
    }

    private android.view.View makeSummaryCard(String label, int count, int textColor, int bgColor) {
        CardView card = new CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        cp.setMarginEnd(dp(8));
        card.setLayoutParams(cp);
        card.setRadius(dp(12));
        card.setCardElevation(dp(2));
        card.setCardBackgroundColor(bgColor);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(10), dp(10), dp(10), dp(10));
        inner.setGravity(Gravity.CENTER);

        TextView tvNum = new TextView(this);
        tvNum.setText(String.valueOf(count));
        tvNum.setTextSize(22f);
        tvNum.setTypeface(null, Typeface.BOLD);
        tvNum.setTextColor(textColor);
        tvNum.setGravity(Gravity.CENTER);

        TextView tvLbl = new TextView(this);
        tvLbl.setText(label);
        tvLbl.setTextSize(10f);
        tvLbl.setTextColor(0xFF666666);
        tvLbl.setGravity(Gravity.CENTER);

        inner.addView(tvNum);
        inner.addView(tvLbl);
        card.addView(inner);
        return card;
    }

    private CardView makeStudentCard(StudentFee sf) {
        CardView card = new CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(cp);
        card.setRadius(dp(12));
        card.setCardElevation(dp(2));
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(14), dp(14), dp(14), dp(14));

        // ── Top row: Name + Status badge ──────────────────────────────────
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvName = new TextView(this);
        tvName.setText(sf.name);
        tvName.setTextSize(15f);
        tvName.setTypeface(null, Typeface.BOLD);
        tvName.setTextColor(0xFF222222);
        tvName.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        boolean isPaid     = "Paid".equalsIgnoreCase(sf.status);
        boolean isNoRecord = "No Record".equalsIgnoreCase(sf.status);
        int badgeBg = isPaid ? 0xFF43A047 : (isNoRecord ? 0xFF757575 : 0xFFE53935);
        String badge = isPaid ? "✓ Paid" : (isNoRecord ? "No Record" : "✗ Unpaid");

        TextView tvStatus = new TextView(this);
        tvStatus.setText(badge);
        tvStatus.setTextSize(11f);
        tvStatus.setTextColor(0xFFFFFFFF);
        tvStatus.setTypeface(null, Typeface.BOLD);
        tvStatus.setPadding(dp(10), dp(4), dp(10), dp(4));
        android.graphics.drawable.GradientDrawable badgeShape =
                new android.graphics.drawable.GradientDrawable();
        badgeShape.setColor(badgeBg);
        badgeShape.setCornerRadius(dp(20));
        tvStatus.setBackground(badgeShape);

        topRow.addView(tvName);
        topRow.addView(tvStatus);

        // ── Divider ───────────────────────────────────────────────────────
        android.view.View divider = new android.view.View(this);
        divider.setBackgroundColor(0xFFF0F0F0);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        divLp.setMargins(0, dp(10), 0, dp(10));
        divider.setLayoutParams(divLp);

        // ── Info row: Class + Month ───────────────────────────────────────
        LinearLayout infoRow = new LinearLayout(this);
        infoRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams irp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        irp.setMargins(0, 0, 0, dp(6));
        infoRow.setLayoutParams(irp);

        TextView tvClass = new TextView(this);
        tvClass.setText("📚 Class: " + sf.className);
        tvClass.setTextSize(12f);
        tvClass.setTextColor(0xFF555555);
        tvClass.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvMonth = new TextView(this);
        tvMonth.setText("📅 " + sf.month);
        tvMonth.setTextSize(12f);
        tvMonth.setTextColor(0xFF555555);
        tvMonth.setGravity(Gravity.END);

        infoRow.addView(tvClass);
        infoRow.addView(tvMonth);

        // ── Amount + Due row ──────────────────────────────────────────────
        LinearLayout amountRow = new LinearLayout(this);
        amountRow.setOrientation(LinearLayout.HORIZONTAL);
        amountRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvAmount = new TextView(this);
        tvAmount.setText("💰 " + sf.amount);
        tvAmount.setTextSize(14f);
        tvAmount.setTypeface(null, Typeface.BOLD);
        tvAmount.setTextColor(0xFF1565C0);
        tvAmount.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvDue = new TextView(this);
        tvDue.setText("Due: " + sf.dueDate);
        tvDue.setTextSize(11f);
        tvDue.setTextColor(sf.dueDate.equals("—") ? 0xFF999999 : 0xFFE53935);
        tvDue.setGravity(Gravity.END);

        amountRow.addView(tvAmount);
        amountRow.addView(tvDue);

        // ── ✅ NEW: "Add to Wallet" button — Admin student ke wallet mein amount add kare ──
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        btnLp.setMargins(0, dp(12), 0, 0);

        Button btnAddWallet = new Button(this);
        btnAddWallet.setText("💳  Add to Wallet");
        btnAddWallet.setTextSize(13f);
        btnAddWallet.setTextColor(0xFFFFFFFF);
        btnAddWallet.setTypeface(null, Typeface.BOLD);
        btnAddWallet.setLayoutParams(btnLp);
        android.graphics.drawable.GradientDrawable btnBg = new android.graphics.drawable.GradientDrawable();
        btnBg.setColor(0xFF1565C0);
        btnBg.setCornerRadius(dp(10));
        btnAddWallet.setBackground(btnBg);
        btnAddWallet.setAllCaps(false);
        btnAddWallet.setOnClickListener(v -> showAddToWalletDialog(sf));

        inner.addView(topRow);
        inner.addView(divider);
        inner.addView(infoRow);
        inner.addView(amountRow);
        inner.addView(btnAddWallet);  // ✅ Add to Wallet button
        card.addView(inner);
        return card;
    }

    // ── ✅ Admin wallet top-up dialog ─────────────────────────────────────────
    private void showAddToWalletDialog(StudentFee sf) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("Jaise: 5000");
        input.setPadding(dp(16), dp(12), dp(16), dp(12));

        new AlertDialog.Builder(this)
                .setTitle("Wallet mein amount add karo")
                .setMessage(sf.name + " ke wallet mein kitna amount add karna hai?")
                .setView(input)
                .setPositiveButton("Add karo", (d, w) -> {
                    String text = input.getText().toString().trim();
                    if (text.isEmpty()) {
                        Toast.makeText(this, "Amount darj karein", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    long amt;
                    try { amt = Long.parseLong(text); }
                    catch (NumberFormatException e) {
                        Toast.makeText(this, "Galat amount", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (amt < 100) {
                        Toast.makeText(this, "Minimum Rs 100 add karna hoga", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    creditStudentWallet(sf, amt);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── ✅ Firebase: student wallet mein balance add karo ─────────────────────
    private void creditStudentWallet(StudentFee sf, long topUpAmount) {
        String today = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());

        FirebaseDatabase.getInstance().getReference("Wallets").child(sf.uid).get()
                .addOnSuccessListener(snap -> {
                    long currentBalance    = 0;
                    long currentTotalTopUp = 0;
                    Object balObj   = snap.child("balance").getValue();
                    Object topUpObj = snap.child("totalTopUp").getValue();
                    if (balObj   != null) currentBalance    = Long.parseLong(balObj.toString());
                    if (topUpObj != null) currentTotalTopUp = Long.parseLong(topUpObj.toString());

                    long newBalance    = currentBalance    + topUpAmount;
                    long newTotalTopUp = currentTotalTopUp + topUpAmount;

                    Map<String, Object> updates = new HashMap<>();
                    updates.put("Wallets/" + sf.uid + "/balance",       newBalance);
                    updates.put("Wallets/" + sf.uid + "/totalTopUp",    newTotalTopUp);
                    updates.put("Wallets/" + sf.uid + "/lastTopUpDate", today);

                    String txId = FirebaseDatabase.getInstance().getReference()
                            .child("Wallets").child(sf.uid).child("transactions").push().getKey();
                    if (txId != null) {
                        updates.put("Wallets/" + sf.uid + "/transactions/" + txId + "/type",        "credit");
                        updates.put("Wallets/" + sf.uid + "/transactions/" + txId + "/amount",      topUpAmount);
                        updates.put("Wallets/" + sf.uid + "/transactions/" + txId + "/description", "Admin ne wallet top-up kiya");
                        updates.put("Wallets/" + sf.uid + "/transactions/" + txId + "/date",        today);
                        updates.put("Wallets/" + sf.uid + "/transactions/" + txId + "/balanceAfter", newBalance);
                    }

                    FirebaseDatabase.getInstance().getReference().updateChildren(updates)
                            .addOnSuccessListener(unused ->
                                    Toast.makeText(this,
                                            "✅ " + sf.name + " ke wallet mein Rs " + topUpAmount + " add ho gaye!",
                                            Toast.LENGTH_LONG).show()
                            )
                            .addOnFailureListener(e ->
                                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show()
                            );
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Wallet read error: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }

    private void filterList(String query) {
        if (query.isEmpty()) { renderList(allStudents); return; }
        List<StudentFee> filtered = new ArrayList<>();
        for (StudentFee sf : allStudents) {
            if (sf.name.toLowerCase().contains(query.toLowerCase()) ||
                    sf.className.toLowerCase().contains(query.toLowerCase()) ||
                    sf.status.toLowerCase().contains(query.toLowerCase())) {
                filtered.add(sf);
            }
        }
        renderList(filtered);
    }

    private void showLoading() {
        listContainer.removeAllViews();
        TextView tv = new TextView(this);
        tv.setText("Loading fee records...");
        tv.setTextSize(14f);
        tv.setTextColor(0xFF888888);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(60), 0, 0);
        listContainer.addView(tv);
    }

    private void showEmpty(String msg) {
        listContainer.removeAllViews();
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(14f);
        tv.setTextColor(0xFF888888);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(60), 0, 0);
        listContainer.addView(tv);
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density);
    }
}