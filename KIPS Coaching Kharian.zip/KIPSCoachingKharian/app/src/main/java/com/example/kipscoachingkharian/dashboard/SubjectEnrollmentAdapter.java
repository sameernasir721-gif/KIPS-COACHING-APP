package com.example.kipscoachingkharian.dashboard;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;

import java.util.ArrayList;
import java.util.List;

public class SubjectEnrollmentAdapter extends RecyclerView.Adapter<SubjectEnrollmentAdapter.SubjectViewHolder> {

    public interface OnRemoveClickListener {
        void onRemoveClick(SubjectEnrollment subject, int position);
    }

    private final List<SubjectEnrollment> list;
    private final OnRemoveClickListener listener;

    public SubjectEnrollmentAdapter(List<SubjectEnrollment> list, OnRemoveClickListener listener) {
        this.list = new ArrayList<>(list);
        this.listener = listener;
    }

    @NonNull
    @Override
    public SubjectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_subject_enrollment, parent, false);
        return new SubjectViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SubjectViewHolder holder, int position) {
        SubjectEnrollment item = list.get(position);
        holder.tvSubjectName.setText(item.getSubjectName());

        holder.ivRemove.setOnClickListener(v -> {

            if (listener != null) listener.onRemoveClick(item, holder.getAdapterPosition());
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void setData(List<SubjectEnrollment> newList) {
        list.clear();
        list.addAll(newList);
        notifyDataSetChanged();
    }

    public void removeAt(int position) {
        if (position < 0 || position >= list.size()) return;
        list.remove(position);
        notifyItemRemoved(position);
    }

    public int getCurrentCount() {
        return list.size();
    }

    static class SubjectViewHolder extends RecyclerView.ViewHolder {
        TextView tvSubjectName;
        ImageView ivRemove;

        SubjectViewHolder(@NonNull View itemView) {
            super(itemView);
            tvSubjectName = itemView.findViewById(R.id.tvSubjectName);
            ivRemove = itemView.findViewById(R.id.ivRemoveSubject);
        }
    }
}