package com.example.kipscoachingkharian.dashboard;



import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class EnrollmentActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;

    private RecyclerView rvEnrolledStudents;
    private LinearLayout layoutEmptyState;
    private EditText etSearchStudent;
    private Spinner spinnerSubject;
    private ImageView ivBack;

    private EnrolledStudentAdapter adapter;

    /** One row per student, loaded once from Users */
    private static class StudentRecord {
        String studentId;
        String studentName;
        List<String> subjects = new ArrayList<>();
    }

    private final List<StudentRecord> allRecords = new ArrayList<>();
    private final List<String> allSubjectNames = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enrollment);

        mDatabase = FirebaseDatabase.getInstance().getReference();

        spinnerSubject      = findViewById(R.id.spinnerSubject);
        etSearchStudent     = findViewById(R.id.etSearchStudent);
        rvEnrolledStudents  = findViewById(R.id.rvEnrolledStudents);
        layoutEmptyState    = findViewById(R.id.layoutEmptyState);
        ivBack              = findViewById(R.id.ivBack);

        ivBack.setOnClickListener(v -> finish());

        setupRecyclerView();
        setupSearch();
        loadAllEnrollments();
    }

    private void setupRecyclerView() {
        rvEnrolledStudents.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EnrolledStudentAdapter(new ArrayList<>(), student -> {
            // Step: Admin selects a student -> view individual subject enrollment details
            Intent intent = new Intent(EnrollmentActivity.this, StudentEnrollmentDetailActivity.class);
            intent.putExtra(StudentEnrollmentDetailActivity.EXTRA_STUDENT_ID, student.getId());
            startActivity(intent);
        });
        rvEnrolledStudents.setAdapter(adapter);
    }

    private void setupSearch() {
        etSearchStudent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                adapter.filter(s.toString());
                toggleEmptyState();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    /** Loads every student's record once from "Users", then builds the subject spinner */
    private void loadAllEnrollments() {
        mDatabase.child("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        allRecords.clear();
                        Set<String> subjectSet = new LinkedHashSet<>();

                        for (DataSnapshot userSnap : snapshot.getChildren()) {

                            String role = userSnap.child("role").getValue(String.class);
                            if (role != null && !"Student".equalsIgnoreCase(role)) continue;

                            StudentRecord record = new StudentRecord();
                            record.studentId = userSnap.getKey();
                            record.studentName = userSnap.child("name").getValue(String.class);
                            if (record.studentName == null) record.studentName = "Unknown Student";

                            for (DataSnapshot subjSnap : userSnap.child("enrolledSubjects").getChildren()) {
                                String subjectName = subjSnap.getValue(String.class);
                                if (subjectName != null && !subjectName.trim().isEmpty()) {
                                    record.subjects.add(subjectName);
                                    subjectSet.add(subjectName);
                                }
                            }

                            allRecords.add(record);
                        }

                        allSubjectNames.clear();
                        allSubjectNames.addAll(subjectSet);
                        Collections.sort(allSubjectNames);

                        if (allSubjectNames.isEmpty()) {
                            Toast.makeText(EnrollmentActivity.this,
                                    "No subject enrollments found yet.", Toast.LENGTH_SHORT).show();
                            toggleEmptyState();
                            return;
                        }

                        bindSubjectSpinner();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(EnrollmentActivity.this,
                                "Failed to load enrollments: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void bindSubjectSpinner() {
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, allSubjectNames);
        spinnerSubject.setAdapter(spinnerAdapter);

        spinnerSubject.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                // Step: Admin selects a specific subject
                filterBySubject(allSubjectNames.get(position));
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        // Auto-load first subject
        filterBySubject(allSubjectNames.get(0));
    }

    private void filterBySubject(String subjectName) {
        List<EnrolledStudent> result = new ArrayList<>();

        for (StudentRecord record : allRecords) {
            for (String s : record.subjects) {
                if (s.equalsIgnoreCase(subjectName)) {
                    result.add(new EnrolledStudent(record.studentId, record.studentName, subjectName));
                    break;
                }
            }
        }

        adapter.updateFullList(result);
        toggleEmptyState();
    }

    /** Exception flow: No students enrolled in this subject -> show "No records found" */
    private void toggleEmptyState() {
        boolean isEmpty = adapter.getCurrentCount() == 0;
        layoutEmptyState.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        rvEnrolledStudents.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
    }
}