package com.example.kipscoachingkharian.dashboard;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONObject;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class CreateAssignmentActivity extends AppCompatActivity {

    public static final String EXTRA_EDIT_MODE       = "edit_mode";
    public static final String EXTRA_ASSIGNMENT_KEY  = "assignment_key";
    public static final String EXTRA_TITLE           = "title";
    public static final String EXTRA_SUBJECT         = "subject";
    public static final String EXTRA_GRADE           = "grade";
    public static final String EXTRA_MARKS           = "marks";
    public static final String EXTRA_DUE_DATE        = "due_date";
    public static final String EXTRA_DUE_TIME        = "due_time";
    public static final String EXTRA_DESCRIPTION     = "description";

    private TextInputEditText etTitle, etMarks, etDescription;
    private AutoCompleteTextView spinnerSubject, spinnerGrade;
    private android.widget.TextView tvDueDate;
    private android.widget.TextView tvDueTime;
    private Button btnCreate, btnSaveDraft;
    private ImageView ivBack;
    private Button btnUploadPdf;
    private TextView tvPdfStatus;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    private String selectedDueDate = "";
    private String selectedDueTime = "";
    private boolean isEditMode = false;
    private String editAssignmentKey = "";
    private String uploadedPdfUrl = ""; // Cloudinary se milne wala URL

    private static final String CLOUDINARY_UPLOAD_URL = "https://api.cloudinary.com/v1_1/dzxkjbtfb/raw/upload";
    private static final String CLOUDINARY_UPLOAD_PRESET = "kips_unsigned";

    private ActivityResultLauncher<String> pdfPickerLauncher;

    private final String[] SUBJECTS = {"Physics", "Chemistry", "Mathematics",
            "Biology", "English", "Computer", "Urdu", "Islamiyat", "Pak Study"};
    private final String[] GRADES = {"9A", "9B", "10A", "10B", "11A", "11B", "12A", "12B"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_assignment);

        mAuth     = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        isEditMode        = getIntent().getBooleanExtra(EXTRA_EDIT_MODE, false);
        editAssignmentKey = getIntent().getStringExtra(EXTRA_ASSIGNMENT_KEY) != null ? getIntent().getStringExtra(EXTRA_ASSIGNMENT_KEY) : "";

        etTitle        = findViewById(R.id.etTitle);
        etMarks        = findViewById(R.id.etMarks);
        etDescription  = findViewById(R.id.etDescription);
        spinnerSubject = findViewById(R.id.spinnerSubject);
        spinnerGrade   = findViewById(R.id.spinnerGrade);
        tvDueDate      = findViewById(R.id.tvDueDate);
        tvDueTime      = findViewById(R.id.tvDueTime);
        btnCreate      = findViewById(R.id.btnCreateAssignment);
        btnSaveDraft   = findViewById(R.id.btnSaveDraft);
        ivBack         = findViewById(R.id.ivBack);
        btnUploadPdf   = findViewById(R.id.btnUploadPdf);
        tvPdfStatus    = findViewById(R.id.tvPdfStatus);

        // PDF picker launcher
        pdfPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(), uri -> {
                    if (uri != null) uploadPdfToCloudinary(uri);
                });

        btnUploadPdf.setOnClickListener(v -> pdfPickerLauncher.launch("application/pdf"));

        if (isEditMode) {
            btnCreate.setText("Update Assignment");
            btnSaveDraft.setText("Save Changes");
            prefillData();
        }

        ivBack.setOnClickListener(v -> finish());

        ArrayAdapter<String> subjectAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, SUBJECTS);
        spinnerSubject.setAdapter(subjectAdapter);
        spinnerSubject.setOnItemClickListener((p, v, pos, id) -> spinnerSubject.setText(SUBJECTS[pos], false));

        ArrayAdapter<String> gradeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, GRADES);
        spinnerGrade.setAdapter(gradeAdapter);
        spinnerGrade.setOnItemClickListener((p, v, pos, id) -> spinnerGrade.setText(GRADES[pos], false));

        tvDueDate.setOnClickListener(v -> showDatePicker());
        tvDueTime.setOnClickListener(v -> showTimePicker());

        btnCreate.setOnClickListener(v -> {
            if (validateForm()) {
                if (isEditMode) updateAssignment("Active");
                else saveAssignment("Active");
            }
        });

        btnSaveDraft.setOnClickListener(v -> {
            if (validateForm()) {
                if (isEditMode) updateAssignment("draft");
                else saveAssignment("draft");
            }
        });

        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                startActivity(new Intent(this, TeacherDashboardActivity.class));
                finish();
                return true;
            }
            return false;
        });
    }

    private void prefillData() {
        etTitle.setText(getIntent().getStringExtra(EXTRA_TITLE));
        etMarks.setText(getIntent().getStringExtra(EXTRA_MARKS));
        etDescription.setText(getIntent().getStringExtra(EXTRA_DESCRIPTION));
        spinnerSubject.setText(getIntent().getStringExtra(EXTRA_SUBJECT), false);
        spinnerGrade.setText(getIntent().getStringExtra(EXTRA_GRADE), false);
        String dueDate = getIntent().getStringExtra(EXTRA_DUE_DATE);
        if (dueDate != null) {
            selectedDueDate = dueDate;
            tvDueDate.setText(dueDate);
            tvDueDate.setTextColor(0xFF1E2A3B);
        }
        String dueTime = getIntent().getStringExtra(EXTRA_DUE_TIME);
        if (dueTime != null && !dueTime.isEmpty()) {
            selectedDueTime = dueTime;
            tvDueTime.setText(dueTime);
            tvDueTime.setTextColor(0xFF1E2A3B);
        }
    }

    private void showDatePicker() {
        Calendar cal = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, day) -> {
            selectedDueDate = day + "/" + (month + 1) + "/" + year;
            tvDueDate.setText(selectedDueDate);
            tvDueDate.setTextColor(0xFF1E2A3B);
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showTimePicker() {
        Calendar cal = Calendar.getInstance();
        new android.app.TimePickerDialog(this, (view, hourOfDay, minute) -> {
            Calendar c = Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY, hourOfDay);
            c.set(Calendar.MINUTE, minute);
            selectedDueTime = new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(c.getTime());
            tvDueTime.setText(selectedDueTime);
            tvDueTime.setTextColor(0xFF1E2A3B);
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show();
    }

    private boolean validateForm() {
        if (TextUtils.isEmpty(etTitle.getText())) return false;
        if (TextUtils.isEmpty(spinnerGrade.getText())) return false;
        if (TextUtils.isEmpty(selectedDueDate)) return false;
        if (TextUtils.isEmpty(selectedDueTime)) {
            Toast.makeText(this, "Please select due time", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void saveAssignment(String status) {
        if (mAuth.getCurrentUser() == null) return;
        btnCreate.setEnabled(false);
        btnSaveDraft.setEnabled(false);
        btnCreate.setText("Saving...");

        String uid = mAuth.getCurrentUser().getUid();
        String postedDate = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Calendar.getInstance().getTime());
        String selectedGrade = spinnerGrade.getText().toString().trim();

        DatabaseReference newRef = mDatabase.child("Assignments").child(uid).push();
        String assignmentKey = newRef.getKey();
        Map<String, Object> data = buildDataMap(uid, postedDate, status);
        data.put("assignmentId", assignmentKey);

        newRef.setValue(data).addOnSuccessListener(unused -> {
            if ("draft".equals(status)) {
                Toast.makeText(this, "Assignment saved as Draft!", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            } else {
                // ✅ Upcoming Schedule mein save karein
                saveToUpcomingSchedule(data, selectedGrade);
                // Purana sharing logic
                shareAssignmentWithStudents(data, selectedGrade, assignmentKey);
            }
        }).addOnFailureListener(e -> {
            btnCreate.setEnabled(true);
            btnSaveDraft.setEnabled(true);
            btnCreate.setText(isEditMode ? "Update Assignment" : "Create Assignment");
            Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    // 🔥 NEW METHOD: Assignment ko Upcoming Schedule node mein save karne ke liye
    private void saveToUpcomingSchedule(Map<String, Object> assignmentData, String grade) {
        DatabaseReference scheduleRef = mDatabase.child("upcomingSchedule").push();

        Map<String, Object> scheduleMap = new HashMap<>();
        scheduleMap.put("type", "assignment");
        scheduleMap.put("targetClass", grade); // Student dashboard isi se filter karega
        scheduleMap.put("message", assignmentData.get("title"));
        scheduleMap.put("subject", assignmentData.get("subject"));
        scheduleMap.put("dueDate", assignmentData.get("dueDate"));
        scheduleMap.put("dueTime", assignmentData.get("dueTime"));
        scheduleMap.put("assignmentId", assignmentData.get("assignmentId")); // Submission check ke liye
        scheduleMap.put("timestamp", System.currentTimeMillis());

        scheduleRef.setValue(scheduleMap);
    }

    // ── PDF Cloudinary upload — study material ki tarah ──────────────────────
    private void uploadPdfToCloudinary(Uri uri) {
        tvPdfStatus.setVisibility(View.VISIBLE);
        tvPdfStatus.setText("Uploading PDF...");
        btnUploadPdf.setEnabled(false);

        new Thread(() -> {
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                byte[] temp = new byte[8192]; int n;
                while ((n = inputStream.read(temp)) != -1) buffer.write(temp, 0, n);
                inputStream.close();
                byte[] bytes = buffer.toByteArray();
                inputStream.close();

                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("file", "assignment.pdf",
                                RequestBody.create(bytes, MediaType.parse("application/pdf")))
                        .addFormDataPart("upload_preset", CLOUDINARY_UPLOAD_PRESET)
                        .addFormDataPart("resource_type", "raw")
                        .build();

                Request request = new Request.Builder()
                        .url(CLOUDINARY_UPLOAD_URL)
                        .post(requestBody)
                        .build();

                Response response = new OkHttpClient().newCall(request).execute();
                String responseBody = response.body().string();
                JSONObject json = new JSONObject(responseBody);
                String url = json.getString("secure_url");

                runOnUiThread(() -> {
                    uploadedPdfUrl = url;
                    tvPdfStatus.setText("✅ PDF uploaded");
                    tvPdfStatus.setTextColor(0xFF2E7D32);
                    btnUploadPdf.setAlpha(0.7f);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    tvPdfStatus.setText("❌ Upload failed");
                    tvPdfStatus.setTextColor(0xFFD50000);
                    btnUploadPdf.setEnabled(true);
                    Toast.makeText(this, "PDF upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private void shareAssignmentWithStudents(Map<String, Object> assignmentData, String grade, String assignmentKey) {
        String subjectVal = assignmentData.get("subject").toString().trim();

        // ✅ FIX: Pehle teacher ke apne "assignedClass/assignedSection" se match
        // hota tha — jo galat tha, kyunki wo teacher ke homeroom se related
        // fields hain, form mein select ki gayi "grade" se nahi. Ab seedha
        // assignment form ki grade (e.g. "9A") use karte hain.
        String targetGrade = (grade != null) ? grade.trim() : "";

        mDatabase.child("Users").addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
            @Override
            public void onDataChange(@androidx.annotation.NonNull com.google.firebase.database.DataSnapshot snapshot) {
                for (com.google.firebase.database.DataSnapshot userSnap : snapshot.getChildren()) {
                    String role = userSnap.child("role").getValue(String.class);
                    String baseClass = userSnap.child("className").getValue(String.class);
                    String section   = userSnap.child("assignedSection").getValue(String.class);

                    if (!"student".equalsIgnoreCase(role) || baseClass == null) continue;

                    // Student ki poori class (number + section) — dashboard/history
                    // jaisa hi smart-merge logic taake format hamesha consistent rahe
                    String trimmedBase = baseClass.trim();
                    boolean baseIsNumberOnly = trimmedBase.matches("\\d+");
                    String studentClass = baseIsNumberOnly && section != null && !section.trim().isEmpty()
                            ? trimmedBase + section.trim()
                            : trimmedBase;

                    if (!studentClass.equalsIgnoreCase(targetGrade)) continue;

                    // Subject match — enrolledSubjects mein hona chahiye
                    if (subjectVal != null && !subjectVal.isEmpty()) {
                        boolean subjectMatch = false;
                        for (com.google.firebase.database.DataSnapshot s : userSnap.child("enrolledSubjects").getChildren()) {
                            String sv = s.getValue(String.class);
                            if (sv != null && sv.trim().equalsIgnoreCase(subjectVal)) { subjectMatch = true; break; }
                        }
                        if (!subjectMatch) continue;
                    }

                    String studentUid = userSnap.getKey();
                    // Share in SharedAssignments
                    mDatabase.child("SharedAssignments").child(studentUid).child(assignmentKey).setValue(assignmentData);

                    // Announcement
                    Map<String, Object> ann = new HashMap<>();
                    ann.put("title", "📝 New Assignment: " + assignmentData.get("title"));
                    ann.put("message", "Subject: " + subjectVal + " | Due: " + assignmentData.get("dueDate"));
                    ann.put("type", "assignment");
                    ann.put("timestamp", System.currentTimeMillis());
                    mDatabase.child("Announcements").child("Students").child(studentUid).child(assignmentKey).setValue(ann);
                }
                Toast.makeText(CreateAssignmentActivity.this, "✅ Assignment shared with students of Class " + grade, Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            }
            @Override public void onCancelled(@androidx.annotation.NonNull com.google.firebase.database.DatabaseError error) {}
        });
    }

    private void updateAssignment(String status) {
        String uid = mAuth.getCurrentUser().getUid();
        Map<String, Object> data = buildDataMap(uid, null, status);
        data.remove("postedDate");
        data.remove("createdAt");

        mDatabase.child("Assignments").child(uid).child(editAssignmentKey).updateChildren(data)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "draft".equals(status) ? "Assignment saved as Draft!" : "Assignment updated!", Toast.LENGTH_SHORT).show();
                    finish();
                });
    }

    private Map<String, Object> buildDataMap(String uid, String postedDate, String status) {
        Map<String, Object> data = new HashMap<>();
        data.put("title", etTitle.getText().toString().trim());
        data.put("subject", spinnerSubject.getText().toString().trim());
        data.put("grade", spinnerGrade.getText().toString().trim());
        data.put("marks", etMarks.getText().toString().trim());
        data.put("dueDate", selectedDueDate);
        data.put("dueTime", selectedDueTime);
        data.put("description", etDescription.getText().toString().trim());
        data.put("teacherId", uid);
        data.put("status", status);
        data.put("pdfUrl", uploadedPdfUrl); // PDF URL — empty if not uploaded
        if (postedDate != null) {
            data.put("postedDate", postedDate);
            data.put("createdAt", System.currentTimeMillis());
        }
        return data;
    }
}