package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TimetableActivity extends AppCompatActivity {

    // --- Cloudinary Configuration ---
    private static final String CLOUD_NAME  = "dvfqe8xpe";
    private static final String API_KEY     = "727365837582369";
    private static final String API_SECRET  = "xM9gxHVBzZOmgv9RawaFZOdHfBs";
    private static final String RAW_UPLOAD_URL = "https://api.cloudinary.com/v1_1/" + CLOUD_NAME + "/raw/upload";

    private ImageView btnBack, btnShare;
    private View pdfContainer;
    private TableLayout mainTable;
    private ProgressDialog progressDialog;

    private int totalTasks = 0, completedTasks = 0;
    private boolean isAnyFailure = false;
    private String currentSelectedTarget = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timetable);

        btnBack      = findViewById(R.id.btnBack);
        btnShare     = findViewById(R.id.btnShare);
        pdfContainer = findViewById(R.id.pdf_container);
        mainTable    = findViewById(R.id.mainTable);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        btnBack.setOnClickListener(v -> finish());
        btnShare.setOnClickListener(v -> showTargetSelectionDialog());
    }

    private void showTargetSelectionDialog() {
        String[] options = {"Students", "Teachers", "Both"};
        final int[] checkedItem = {2}; // Default to "Both"

        new AlertDialog.Builder(this)
                .setTitle("Confirm Timetable Update")
                .setSingleChoiceItems(options, checkedItem[0], (d, which) -> checkedItem[0] = which)
                .setPositiveButton("Process & Upload", (d, which) -> {
                    completedTasks  = 0;
                    isAnyFailure    = false;
                    currentSelectedTarget = options[checkedItem[0]];

                    progressDialog.setMessage("Processing schedule data...");
                    progressDialog.show();

                    startDataProcessing(checkedItem[0]);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startDataProcessing(int targetIndex) {
        // 1. Extract Subjects and Teacher names from the Table rows for Database
        List<Map<String, Object>> tableSlots = extractTableData();

        // 2. Capture PDF and Upload to Cloudinary
        pdfContainer.post(() -> {
            try {
                byte[] pdfBytes = buildPdfFromView(pdfContainer);

                new Thread(() -> {
                    String pdfUrl = uploadToCloudinary(pdfBytes);
                    runOnUiThread(() -> {
                        if (pdfUrl == null || pdfUrl.isEmpty()) {
                            if (progressDialog.isShowing()) progressDialog.dismiss();
                            Toast.makeText(this, "Upload failed. Please try again.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        // 3. Save Structured Rows + PDF Master Link to Firebase
                        saveToFirebase(pdfUrl, tableSlots);

                        // 4. Send Announcements
                        if (targetIndex == 2) { // Both
                            totalTasks = 2;
                            sendNotification("Students", pdfUrl);
                            sendNotification("Teachers", pdfUrl);
                        } else {
                            totalTasks = 1;
                            sendNotification(targetIndex == 0 ? "Students" : "Teachers", pdfUrl);
                        }
                    });
                }).start();
            } catch (Exception e) {
                if (progressDialog.isShowing()) progressDialog.dismiss();
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Scans TableLayout and extracts Section, Class, Time, Subject, and Teacher.
     */
    private List<Map<String, Object>> extractTableData() {
        List<Map<String, Object>> dataList = new ArrayList<>();
        String currentSec = "";
        String currentCls = "";
        String[] dayNames = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};

        for (int i = 0; i < mainTable.getChildCount(); i++) {
            View rowView = mainTable.getChildAt(i);
            if (rowView instanceof TableRow) {
                TableRow row = (TableRow) rowView;
                int count = row.getChildCount();

                // Detect Section Header Row (e.g. SECTION A)
                if (count == 1) {
                    currentSec = ((TextView) row.getChildAt(0)).getText().toString().trim();
                }
                // Detect Data Row (Columns: Class, Time, 5 Days)
                else if (count == 7) {
                    String rowCls = ((TextView) row.getChildAt(0)).getText().toString().trim();
                    if (!rowCls.isEmpty()) currentCls = rowCls;

                    String rowTime = ((TextView) row.getChildAt(1)).getText().toString().trim();

                    // Loop through the 5 Days (Indices 2 to 6)
                    for (int d = 0; d < 5; d++) {
                        TextView cell = (TextView) row.getChildAt(d + 2);
                        String content = cell.getText().toString().trim();

                        if (!content.isEmpty()) {
                            Map<String, Object> slot = new HashMap<>();
                            slot.put("section", currentSec);
                            slot.put("className", currentCls);
                            slot.put("time", rowTime);
                            slot.put("day", dayNames[d]);

                            // Extract Teacher and Subject by splitting the line break
                            if (content.contains("\n")) {
                                String[] parts = content.split("\n");
                                slot.put("subject", parts[0].trim());
                                slot.put("teacher", parts[1].trim());
                            } else {
                                slot.put("subject", content);
                                slot.put("teacher", "Unknown");
                            }
                            dataList.add(slot);
                        }
                    }
                }
            }
        }
        return dataList;
    }

    private void saveToFirebase(String pdfUrl, List<Map<String, Object>> slots) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Timetable_Records");
        String key = ref.push().getKey();

        Map<String, Object> record = new HashMap<>();
        record.put("recordId", key);
        record.put("pdfUrl", pdfUrl);
        record.put("target", currentSelectedTarget);
        record.put("timestamp", System.currentTimeMillis());
        record.put("slots", slots); // Saving detailed subjects/teacher list

        if (key != null) ref.child(key).setValue(record);
    }

    private void sendNotification(String target, String url) {
        DatabaseReference dRef = FirebaseDatabase.getInstance().getReference("Announcements").child(target);
        String id = dRef.push().getKey();

        Map<String, Object> map = new HashMap<>();
        map.put("id", id);
        map.put("title", "🗓️ Timetable Updated!");
        map.put("message", "Your weekly timetable for " + target + " has been updated. You can view your new schedule in the Time Schedule card.");
        map.put("timestamp", System.currentTimeMillis());
        map.put("type", "timetable");

        // Logic: Students get plain text (non-clickable). Others get clickable PDF links.
        if (!target.equals("Students")) {
            map.put("pdfUrl", url);
            map.put("classLink", url);
        }

        if (id != null) dRef.child(id).setValue(map)
                .addOnSuccessListener(a -> check(false))
                .addOnFailureListener(e -> check(true));
    }

    // --- Helper Methods for PDF and Cloudinary ---

    private byte[] buildPdfFromView(View v) throws Exception {
        int w = v.getWidth(), h = v.getHeight();
        v.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int mw = v.getMeasuredWidth(), mh = v.getMeasuredHeight();
        v.layout(0, 0, mw, mh);

        Bitmap b = Bitmap.createBitmap(mw, mh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(Color.WHITE);
        v.draw(c);
        v.layout(0, 0, w, h);

        PdfDocument doc = new PdfDocument();
        PdfDocument.PageInfo pi = new PdfDocument.PageInfo.Builder(mw, mh, 1).create();
        PdfDocument.Page p = doc.startPage(pi);
        p.getCanvas().drawBitmap(b, 0, 0, null);
        doc.finishPage(p);

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        doc.writeTo(bos);
        doc.close();
        b.recycle();
        return bos.toByteArray();
    }

    private String uploadToCloudinary(byte[] pdf) {
        try {
            String b64 = "data:application/pdf;base64," + Base64.encodeToString(pdf, Base64.NO_WRAP);
            long ts = System.currentTimeMillis() / 1000;
            String pid = "timetable_" + ts + ".pdf";
            String sig = sha1("folder=timetables&public_id=" + pid + "&timestamp=" + ts + API_SECRET);

            URL url = new URL(RAW_UPLOAD_URL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setDoOutput(true);
            con.setRequestMethod("POST");
            String bound = "----Bound" + ts;
            con.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + bound);

            OutputStream os = con.getOutputStream();
            String body = "--" + bound + "\r\nContent-Disposition: form-data; name=\"file\"\r\n\r\n" + b64 + "\r\n"
                    + "--" + bound + "\r\nContent-Disposition: form-data; name=\"api_key\"\r\n\r\n" + API_KEY + "\r\n"
                    + "--" + bound + "\r\nContent-Disposition: form-data; name=\"timestamp\"\r\n\r\n" + ts + "\r\n"
                    + "--" + bound + "\r\nContent-Disposition: form-data; name=\"signature\"\r\n\r\n" + sig + "\r\n"
                    + "--" + bound + "\r\nContent-Disposition: form-data; name=\"folder\"\r\n\r\n" + "timetables" + "\r\n"
                    + "--" + bound + "\r\nContent-Disposition: form-data; name=\"public_id\"\r\n\r\n" + pid + "\r\n"
                    + "--" + bound + "--\r\n";

            os.write(body.getBytes("UTF-8"));
            if (con.getResponseCode() == 200) {
                java.util.Scanner s = new java.util.Scanner(con.getInputStream()).useDelimiter("\\A");
                return new JSONObject(s.next()).getString("secure_url");
            }
        } catch (Exception e) { e.printStackTrace(); }
        return "";
    }

    private void check(boolean fail) {
        completedTasks++;
        if (fail) isAnyFailure = true;
        if (completedTasks >= totalTasks) {
            if (progressDialog.isShowing()) progressDialog.dismiss();
            Toast.makeText(this, isAnyFailure ? "Process completed with some errors." : "✅ Success! Timetable updated and published.", Toast.LENGTH_LONG).show();
        }
    }

    private String sha1(String s) {
        try {
            java.security.MessageDigest m = java.security.MessageDigest.getInstance("SHA-1");
            byte[] d = m.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (progressDialog != null && progressDialog.isShowing()) progressDialog.dismiss();
    }
}