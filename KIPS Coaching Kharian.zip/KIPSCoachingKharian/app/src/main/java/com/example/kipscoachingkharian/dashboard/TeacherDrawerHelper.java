package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Color;
import android.content.res.ColorStateList;
import android.view.View;
import android.view.ViewGroup;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;


public class TeacherDrawerHelper {

    public static void attach(AppCompatActivity activity) {
        NavigationView nav = activity.findViewById(R.id.navigationView);
        DrawerLayout drawer;

        if (nav != null && nav.getParent() instanceof DrawerLayout) {

            drawer = (DrawerLayout) nav.getParent();
        } else {
            ViewGroup content = activity.findViewById(android.R.id.content);
            View root = content.getChildAt(0);

            if (root instanceof DrawerLayout) {
                drawer = (DrawerLayout) root;
            } else {
                content.removeView(root);
                drawer = new DrawerLayout(activity);
                drawer.addView(root, new DrawerLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                content.addView(drawer, new ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
            }

            nav = new NavigationView(activity);
            nav.setBackgroundColor(Color.WHITE);
            nav.setItemIconTintList(ColorStateList.valueOf(0xFFB71C1C));
            nav.setItemTextColor(ColorStateList.valueOf(0xFF333333));
            nav.inflateMenu(R.menu.teacher_drawer_menu);
            nav.inflateHeaderView(R.layout.nav_header_teacher);

            DrawerLayout.LayoutParams lp = new DrawerLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
            lp.gravity = GravityCompat.START;
            drawer.addView(nav, lp);

            final NavigationView panel = nav;
            final DrawerLayout host = drawer;
            host.post(() -> {
                int[] loc = new int[2];
                host.getLocationInWindow(loc);
                if (loc[1] > 0) {
                    DrawerLayout.LayoutParams p = (DrawerLayout.LayoutParams) panel.getLayoutParams();
                    p.topMargin = -loc[1];
                    panel.setLayoutParams(p);
                }
            });
        }

        final DrawerLayout dl = drawer;

        nav.setNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_logout) {
                showLogoutDialog(activity);
            }
            dl.closeDrawer(GravityCompat.START);
            return true;
        });

        OnBackPressedCallback backCallback = new OnBackPressedCallback(false) {
            @Override
            public void handleOnBackPressed() {
                dl.closeDrawer(GravityCompat.START);
            }
        };
        activity.getOnBackPressedDispatcher().addCallback(activity, backCallback);
        dl.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override public void onDrawerOpened(View drawerView) { backCallback.setEnabled(true); }
            @Override public void onDrawerClosed(View drawerView) { backCallback.setEnabled(false); }
        });
    }

    private static void showLogoutDialog(AppCompatActivity activity) {
        new AlertDialog.Builder(activity)
                .setTitle("Logout")
                .setMessage("Do you want to logout?")
                .setPositiveButton("Yes, Logout", (dialog, which) -> {
                    FirebaseAuth.getInstance().signOut();
                    Intent intent = new Intent(activity, LoginSelectionActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    activity.startActivity(intent);
                    activity.finishAffinity();
                })
                .setNegativeButton("Cancel", null)
                .setIcon(R.drawable.ic_power)
                .show();
    }
}