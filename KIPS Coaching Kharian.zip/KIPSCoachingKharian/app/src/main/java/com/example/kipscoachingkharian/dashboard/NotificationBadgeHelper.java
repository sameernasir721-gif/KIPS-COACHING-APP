package com.example.kipscoachingkharian.dashboard;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.TextView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashSet;
import java.util.Set;

public class NotificationBadgeHelper {

    private static final String PREFS = "parent_notif_prefs";

    public static void setup(final Activity a) {
        final View tab = a.findViewById(R.id.llNotificationsTab);
        final TextView badge = a.findViewById(R.id.tvNotifBadge);
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (tab == null || user == null) return;

        final String uid = user.getUid();
        final DatabaseReference root = FirebaseDatabase.getInstance().getReference();

        root.child("Users").child(uid).child("registrationId").get().addOnSuccessListener(regSnap -> {
            final String regId = regSnap.getValue(String.class);
            if (regId == null || regId.isEmpty() || a.isDestroyed()) return;

            tab.setOnClickListener(v -> {
                Intent i = new Intent(a, ParentAnnouncementsActivity.class);
                i.putExtra("STUDENT_ID", regId);
                a.startActivity(i);
            });

            if (badge == null) return;
            root.child("Announcements").child("Parents").get().addOnSuccessListener(snapshot -> {
                if (a.isDestroyed()) return;
                SharedPreferences prefs = a.getSharedPreferences(PREFS, Activity.MODE_PRIVATE);
                Set<String> seen = prefs.getStringSet("seen_keys_" + uid, new HashSet<>());
                Set<String> deleted = prefs.getStringSet("deleted_keys_" + uid, new HashSet<>());

                int unseen = 0;
                for (DataSnapshot snap : snapshot.getChildren()) {
                    String target = snap.child("registrationId").getValue(String.class);
                    String type = snap.child("type").getValue(String.class);
                    boolean personal = "fee_confirmation".equalsIgnoreCase(type);
                    boolean hasTarget = target != null && !target.isEmpty();
                    boolean forMyChild = hasTarget ? target.equals(regId) : !personal;
                    if (!forMyChild) continue;
                    String key = snap.getKey();
                    if (!seen.contains(key) && !deleted.contains(key)) unseen++;
                }
                if (unseen > 0) {
                    badge.setText(unseen > 99 ? "99+" : String.valueOf(unseen));
                    badge.setVisibility(View.VISIBLE);
                } else {
                    badge.setVisibility(View.GONE);
                }
            });
        });
    }
}