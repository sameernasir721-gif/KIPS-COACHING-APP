package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.model.Assignment;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ParentAssignmentReportActivity extends AppCompatActivity {

    public static final String EXTRA_STUDENT_UID  = "STUDENT_UID";

    private RecyclerView rvAssignments;
    private View layoutEmpty;
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private EditText etSearch;
    private LinearLayout layoutChips, llHomeTab, llProfileTab;
    private MaterialButton chipAll;

    private String studentUid;
    private String activeChip = "All";
    private final List<String> enrolledSubjects = new ArrayList<>();
    private final List<Assignment> allAssignments = new ArrayList<>();
    private final List<Assignment> filteredAssignments = new ArrayList<>();
    private AssignmentCardAdapter adapter;

    private final int[] CARD_COLORS = {
            0xFFEDDCE1, 0xFFDBDFED, 0xFFBED9C3, 0xFFFFF9C4, 0xFFE8EAF6
    };
    private static final String[] SUBJECTS = {
            "Physics", "Chemistry", "Mathematics", "Biology", "English", "Computer", "Urdu", "Islamiyat", "Pakstudy"
    };
    private static final int[] SUBJECT_ICONS = {
            R.drawable.ic_physics, R.drawable.ic_chemistry, R.drawable.ic_mathematics,
            R.drawable.ic_biology, R.drawable.ic_english, R.drawable.ic_computer,
            R.drawable.ic_urdu, R.drawable.ic_islamiyat, R.drawable.ic_pakstudy
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_assignment_report);

        studentUid = getIntent().getStringExtra(EXTRA_STUDENT_UID);

        rvAssignments = findViewById(R.id.rvAssignments);
        layoutEmpty   = findViewById(R.id.layoutEmpty);
        progressBar   = findViewById(R.id.progressBar);
        tvEmpty       = findViewById(R.id.tvEmpty);
        etSearch      = findViewById(R.id.etSearch);
        layoutChips   = findViewById(R.id.layoutChips);
        chipAll       = findViewById(R.id.chipAll);

        // Bottom Navigation Setup
        llHomeTab     = findViewById(R.id.llHomeTab);
        llProfileTab  = findViewById(R.id.llProfileTab);

        llHomeTab.setOnClickListener(v -> {
            startActivity(new Intent(this, ParentDashboardActivity.class));
            finish();
        });

        llProfileTab.setOnClickListener(v -> {
            startActivity(new Intent(this, ParentProfileActivity.class));
        });

        rvAssignments.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AssignmentCardAdapter(filteredAssignments);
        rvAssignments.setAdapter(adapter);

        chipAll.setOnClickListener(v -> { activeChip = "All"; highlightChip(chipAll); applyFilter(); });

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { applyFilter(); }
        });

        if (studentUid == null || studentUid.isEmpty()) {
            progressBar.setVisibility(View.GONE);
            showEmpty("Error: Student account could not be identified.");
            return;
        }
        fetchStudentThenAssignments();
    }

    private void fetchStudentThenAssignments() {
        FirebaseDatabase.getInstance().getReference("Users").child(studentUid).get()
                .addOnSuccessListener(snap -> {
                    enrolledSubjects.clear();
                    for (DataSnapshot s : snap.child("enrolledSubjects").getChildren()) {
                        String sub = s.getValue(String.class);
                        if (sub != null) enrolledSubjects.add(sub);
                    }
                    buildSubjectChips();
                    loadAssignments();
                })
                .addOnFailureListener(e -> loadAssignments());
    }

    private void buildSubjectChips() {
        int childCount = layoutChips.getChildCount();
        if (childCount > 1) layoutChips.removeViews(1, childCount - 1);

        for (String subject : enrolledSubjects) {
            MaterialButton chip = new MaterialButton(this);
            chip.setText(subject);
            chip.setAllCaps(false);
            chip.setTextSize(14f);
            chip.setTextColor(0xFF333333);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(40));
            lp.setMarginEnd(dpToPx(8));
            chip.setLayoutParams(lp);
            chip.setCornerRadius(dpToPx(20));
            chip.setBackgroundTintList(ColorStateList.valueOf(0xFFE0E0E0));
            chip.setPadding(dpToPx(16), 0, dpToPx(16), 0);
            chip.setOnClickListener(v -> { activeChip = subject; highlightChip(chip); applyFilter(); });
            layoutChips.addView(chip);
        }
        highlightChip(chipAll);
    }

    private void highlightChip(MaterialButton selected) {
        chipAll.setBackgroundTintList(ColorStateList.valueOf(0xFFE0E0E0));
        chipAll.setTextColor(0xFF333333);
        for (int i = 1; i < layoutChips.getChildCount(); i++) {
            View v = layoutChips.getChildAt(i);
            if (v instanceof MaterialButton) {
                ((MaterialButton) v).setBackgroundTintList(ColorStateList.valueOf(0xFFE0E0E0));
                ((MaterialButton) v).setTextColor(0xFF333333);
            }
        }
        selected.setBackgroundTintList(ColorStateList.valueOf(0xFFD2192B));
        selected.setTextColor(0xFFFFFFFF);
    }

    private void loadAssignments() {
        FirebaseDatabase.getInstance().getReference("SharedAssignments").child(studentUid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        allAssignments.clear();
                        for (DataSnapshot aSnap : snapshot.getChildren()) {
                            String status = aSnap.child("status").getValue(String.class);
                            if (!"Active".equalsIgnoreCase(status)) continue;

                            Assignment a = new Assignment();
                            a.setAssignmentId(aSnap.getKey());
                            a.setTeacherId(str(aSnap, "teacherId"));
                            a.setTitle(str(aSnap, "title"));
                            a.setSubject(str(aSnap, "subject"));
                            a.setGrade(str(aSnap, "grade"));
                            a.setMarks(str(aSnap, "marks"));
                            a.setDueDate(str(aSnap, "dueDate"));
                            a.setDueTime(str(aSnap, "dueTime"));
                            a.setPostedDate(str(aSnap, "postedDate"));
                            a.setDescription(str(aSnap, "description"));
                            a.setStatus(status);
                            Long ts = aSnap.child("createdAt").getValue(Long.class);
                            if (ts != null) a.setCreatedAt(ts);
                            allAssignments.add(a);
                        }
                        progressBar.setVisibility(View.GONE);
                        applyFilter();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(ParentAssignmentReportActivity.this,
                                "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void applyFilter() {
        String searchText = etSearch.getText().toString().trim().toLowerCase();
        filteredAssignments.clear();

        for (Assignment a : allAssignments) {
            String subjectNorm = a.getSubject() == null ? "" : a.getSubject().replaceAll("\\s+", "").toLowerCase();
            String chipNorm    = activeChip.replaceAll("\\s+", "").toLowerCase();
            boolean chipMatch = activeChip.equals("All") || subjectNorm.equals(chipNorm);
            boolean searchMatch = searchText.isEmpty()
                    || a.getTitle().toLowerCase().contains(searchText)
                    || a.getSubject().toLowerCase().contains(searchText);
            if (chipMatch && searchMatch) filteredAssignments.add(a);
        }

        adapter.notifyDataSetChanged();
        if (filteredAssignments.isEmpty()) {
            showEmpty(allAssignments.isEmpty() ? "No assignments yet." : "No matching assignment found.");
        } else {
            layoutEmpty.setVisibility(View.GONE);
            rvAssignments.setVisibility(View.VISIBLE);
        }
    }

    private void showEmpty(String message) {
        rvAssignments.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.VISIBLE);
        tvEmpty.setText(message);
    }

    private String str(DataSnapshot snap, String key) {
        String v = snap.child(key).getValue(String.class);
        return v != null ? v : "";
    }

    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
    }

    private class AssignmentCardAdapter extends RecyclerView.Adapter<AssignmentCardAdapter.VH> {

        private final List<Assignment> list;
        AssignmentCardAdapter(List<Assignment> list) { this.list = list; }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_assignment_card, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Assignment a = list.get(position);

            int color = CARD_COLORS[position % CARD_COLORS.length];
            h.cardRoot.setCardBackgroundColor(color);
            h.imgSubjectIcon.setImageResource(getSubjectIcon(a.getSubject()));

            h.tvSubjectName.setText(a.getSubject());
            h.tvAssignmentTitle.setText("Assignment: " + a.getTitle());
            String dueTimeVal = a.getDueTime();
            h.tvDueDate.setText("Due: " + a.getDueDate() +
                    (dueTimeVal == null || dueTimeVal.isEmpty() ? "" : "  " + dueTimeVal));
            h.tvMarks.setText("Marks: " + a.getMarks());

            h.btnSubmit.setOnClickListener(null);
            h.btnSubmit.setText("Pending");
            h.btnSubmit.setBackgroundTintList(ColorStateList.valueOf(0xFF9E9E9E));

            h.tvObtainedMarks.setVisibility(View.GONE);
            FirebaseDatabase.getInstance()
                    .getReference("Submissions")
                    .child(a.getAssignmentId())
                    .child(studentUid)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snap) {
                            String obtained = snap.child("obtainedMarks").getValue(String.class);
                            String status   = snap.child("status").getValue(String.class);

                            if (obtained != null && !obtained.isEmpty() && !"0".equals(obtained)) {
                                h.tvObtainedMarks.setText("✅ Obtained: " + obtained + " / " + a.getMarks());
                                h.tvObtainedMarks.setTextColor(0xFF2E7D32);
                                h.tvObtainedMarks.setVisibility(View.VISIBLE);
                                h.btnSubmit.setText("Graded");
                                h.btnSubmit.setBackgroundTintList(ColorStateList.valueOf(0xFF2E7D32));
                            } else if ("Submitted".equalsIgnoreCase(status)) {
                                h.tvObtainedMarks.setText("⏳ Submitted — awaiting marks");
                                h.tvObtainedMarks.setTextColor(0xFFF57F17);
                                h.tvObtainedMarks.setVisibility(View.VISIBLE);
                                h.btnSubmit.setText("Submitted");
                                h.btnSubmit.setBackgroundTintList(ColorStateList.valueOf(0xFFF57F17));
                            }
                        }
                        @Override public void onCancelled(@NonNull DatabaseError e) {}
                    });

            h.btnView.setOnClickListener(v -> showViewDialog(a));
        }

        @Override
        public int getItemCount() { return list.size(); }

        private void showViewDialog(Assignment a) {
            View dialogView = LayoutInflater.from(ParentAssignmentReportActivity.this)
                    .inflate(R.layout.dialog_view_assignment, null);

            TextView tvTitle       = dialogView.findViewById(R.id.tvDialogTitle);
            TextView tvSubject     = dialogView.findViewById(R.id.tvDialogSubject);
            TextView tvGrade       = dialogView.findViewById(R.id.tvDialogGrade);
            TextView tvMarks       = dialogView.findViewById(R.id.tvDialogMarks);
            TextView tvDueDate     = dialogView.findViewById(R.id.tvDialogDueDate);
            TextView tvPostedDate  = dialogView.findViewById(R.id.tvDialogPostedDate);
            TextView tvDescription = dialogView.findViewById(R.id.tvDialogDescription);
            TextView tvStatus      = dialogView.findViewById(R.id.tvDialogStatus);

            tvTitle.setText(a.getTitle());
            tvSubject.setText("📚 Subject: " + a.getSubject());
            tvGrade.setText("🏫 Class: " + a.getGrade());
            tvMarks.setText("⭐ Total Marks: " + a.getMarks());
            String dueTimeVal = a.getDueTime();
            tvDueDate.setText("⏰ Due Date: " + a.getDueDate() +
                    (dueTimeVal == null || dueTimeVal.isEmpty() ? "" : "  " + dueTimeVal));
            tvPostedDate.setText("📅 Posted: " + a.getPostedDate());
            tvDescription.setText(a.getDescription());
            tvStatus.setText(a.getStatus());
            tvStatus.setBackgroundTintList(ColorStateList.valueOf(0xFF4CAF50));

            new AlertDialog.Builder(ParentAssignmentReportActivity.this)
                    .setView(dialogView)
                    .setPositiveButton("Close", null)
                    .show();
        }

        private int getSubjectIcon(String subject) {
            if (subject == null) return R.drawable.ic_subject;
            for (int i = 0; i < SUBJECTS.length; i++) {
                if (SUBJECTS[i].equalsIgnoreCase(subject)) return SUBJECT_ICONS[i];
            }
            return R.drawable.ic_subject;
        }

        class VH extends RecyclerView.ViewHolder {
            CardView  cardRoot;
            ImageView imgSubjectIcon;
            TextView  tvSubjectName, tvAssignmentTitle, tvDueDate, tvMarks, tvObtainedMarks;
            TextView  btnView, btnSubmit;

            VH(@NonNull View v) {
                super(v);
                cardRoot          = v.findViewById(R.id.cardRoot);
                imgSubjectIcon    = v.findViewById(R.id.imgSubjectIcon);
                tvSubjectName     = v.findViewById(R.id.tvSubjectName);
                tvAssignmentTitle = v.findViewById(R.id.tvAssignmentTitle);
                tvDueDate         = v.findViewById(R.id.tvDueDate);
                tvMarks           = v.findViewById(R.id.tvMarks);
                tvObtainedMarks   = v.findViewById(R.id.tvObtainedMarks);
                btnView           = v.findViewById(R.id.btnView);
                btnSubmit         = v.findViewById(R.id.btnSubmit);
            }
        }
    }
}