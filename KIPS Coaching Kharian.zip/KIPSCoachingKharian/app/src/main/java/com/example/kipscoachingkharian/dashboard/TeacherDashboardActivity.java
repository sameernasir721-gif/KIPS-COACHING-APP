package com.example.kipscoachingkharian.dashboard;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Activity representing the dashboard for Teachers.
 * Displays the teacher's assigned subject and class upon login.
 * Serves as the launchpad for future features like marking attendance or uploading results.
 */
public class TeacherDashboardActivity extends AppCompatActivity {

    private Button btnLogout;
    private TextView tvWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_dashboard);

        // Initialize UI components
        tvWelcome = findViewById(R.id.tvWelcome);
        btnLogout = findViewById(R.id.btnLogout);

        // Retrieve teacher profile data from Firebase
        fetchTeacherData();

        // Handle Logout
        btnLogout.setOnClickListener(v -> {
            // 1. Sign out from Firebase Auth
            FirebaseAuth.getInstance().signOut();

            // 2. Notify User
            Toast.makeText(this, "Logged Out", Toast.LENGTH_SHORT).show();

            // 3. Navigate back to Login Selection and clear stack
            Intent intent = new Intent(this, LoginSelectionActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    /**
     * Fetches the logged-in teacher's details from the Realtime Database.
     * Specifically retrieves 'subject' and 'className' to confirm their assignment.
     */
    private void fetchTeacherData() {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .get().addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        String subject = "General";
                        String className = "N/A";

                        // Check if specific keys exist before retrieving to avoid null errors
                        if (snapshot.hasChild("subject")) {
                            subject = snapshot.child("subject").getValue(String.class);
                        }
                        if (snapshot.hasChild("className")) {
                            className = snapshot.child("className").getValue(String.class);
                        }

                        // Update Welcome Text with retrieved data
                        tvWelcome.setText("Welcome " + subject + " Teacher\n(Class: " + className + ")");
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to load profile", Toast.LENGTH_SHORT).show();
                });
    }
}