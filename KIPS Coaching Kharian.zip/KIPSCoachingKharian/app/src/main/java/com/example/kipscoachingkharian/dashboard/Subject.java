package com.example.kipscoachingkharian.dashboard;

public class Subject {

    private String name;
    private String teacherName;
    private String schedule;
    private int progress;       // 0–100
    private int iconResId;      // drawable resource for the icon
    private int iconBgResId;    // drawable resource for icon background color
    private int progressColor;  // color resource for progress bar tint

    public Subject(String name, String teacherName, String schedule,
                   int progress, int iconResId, int iconBgResId, int progressColor) {
        this.name = name;
        this.teacherName = teacherName;
        this.schedule = schedule;
        this.progress = progress;
        this.iconResId = iconResId;
        this.iconBgResId = iconBgResId;
        this.progressColor = progressColor;
    }

    // ── Getters ──────────────────────────────────────────────

    public String getName() { return name; }
    public String getTeacherName() { return teacherName; }
    public String getSchedule() { return schedule; }
    public int getProgress() { return progress; }
    public int getIconResId() { return iconResId; }
    public int getIconBgResId() { return iconBgResId; }
    public int getProgressColor() { return progressColor; }

    // ── Setters ──────────────────────────────────────────────

    public void setName(String name) { this.name = name; }
    public void setTeacherName(String teacherName) { this.teacherName = teacherName; }
    public void setSchedule(String schedule) { this.schedule = schedule; }
    public void setProgress(int progress) { this.progress = progress; }
    public void setIconResId(int iconResId) { this.iconResId = iconResId; }
    public void setIconBgResId(int iconBgResId) { this.iconBgResId = iconBgResId; }
    public void setProgressColor(int progressColor) { this.progressColor = progressColor; }
}

