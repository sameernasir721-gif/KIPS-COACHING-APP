package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ParentQuizReportActivity extends AppCompatActivity {

    public static final String EXTRA_STUDENT_UID  = "STUDENT_UID";

    private EditText etSearch;
    private LinearLayout layoutChips, layoutQuizCards;
    private TextView tvEmpty;
    private View layoutEmpty;
    private ProgressBar progressBar;
    private LinearLayout llHomeTab, llProfileTab;

    private String studentUid;
    private final List<String> enrolledSubjects = new ArrayList<>();
    private final List<Map<String, Object>> allQuizzes = new ArrayList<>();
    private String activeChip = "All";

    private final Map<String, MaterialButton> chipMap = new HashMap<>();
    private MaterialButton chipAll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_quiz_report);

        studentUid = getIntent().getStringExtra(EXTRA_STUDENT_UID);

        etSearch        = findViewById(R.id.etSearch);
        layoutChips     = findViewById(R.id.layoutChips);
        layoutQuizCards = findViewById(R.id.layoutQuizCards);
        tvEmpty         = findViewById(R.id.tvEmpty);
        layoutEmpty     = findViewById(R.id.layoutEmpty);
        progressBar     = findViewById(R.id.progressBar);
        chipAll         = findViewById(R.id.chipAll);

        // Bottom Nav Setup
        llHomeTab       = findViewById(R.id.llHomeTab);
        llProfileTab    = findViewById(R.id.llProfileTab);

        // Bottom Navigation Actions
        llHomeTab.setOnClickListener(v -> {
            startActivity(new Intent(this, ParentDashboardActivity.class));
            finish();
        });

        llProfileTab.setOnClickListener(v -> {
            startActivity(new Intent(this, ParentProfileActivity.class));
        });

        chipAll.setOnClickListener(v -> { activeChip = "All"; highlightChip(chipAll); renderCards(); });

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { renderCards(); }
        });

        if (studentUid == null || studentUid.isEmpty()) {
            progressBar.setVisibility(View.GONE);
            showEmpty("Error: Student account could not be identified.");
            return;
        }
        fetchStudentThenQuizzes();
    }

    private void fetchStudentThenQuizzes() {
        FirebaseDatabase.getInstance().getReference("Users").child(studentUid).get()
                .addOnSuccessListener(snap -> {
                    enrolledSubjects.clear();
                    for (DataSnapshot s : snap.child("enrolledSubjects").getChildren()) {
                        String sub = s.getValue(String.class);
                        if (sub != null) enrolledSubjects.add(sub);
                    }
                    buildSubjectChips();
                    loadSharedQuizzes();
                })
                .addOnFailureListener(e -> loadSharedQuizzes());
    }

    private void buildSubjectChips() {
        int childCount = layoutChips.getChildCount();
        if (childCount > 1) layoutChips.removeViews(1, childCount - 1);
        chipMap.clear();

        for (String subject : enrolledSubjects) {
            MaterialButton chip = new MaterialButton(this);
            chip.setText(subject);
            chip.setAllCaps(false);
            chip.setTextSize(14f);
            chip.setTextColor(0xFF333333);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(40));
            lp.setMarginEnd(dpToPx(8));
            chip.setLayoutParams(lp);
            chip.setCornerRadius(dpToPx(20));
            chip.setBackgroundTintList(ColorStateList.valueOf(0xFFE0E0E0));
            chip.setPadding(dpToPx(16), 0, dpToPx(16), 0);

            chip.setOnClickListener(v -> { activeChip = subject; highlightChip(chip); renderCards(); });

            layoutChips.addView(chip);
            chipMap.put(subject, chip);
        }
        highlightChip(chipAll);
    }

    private void highlightChip(MaterialButton selected) {
        chipAll.setBackgroundTintList(ColorStateList.valueOf(0xFFE0E0E0));
        chipAll.setTextColor(0xFF333333);
        for (MaterialButton c : chipMap.values()) {
            c.setBackgroundTintList(ColorStateList.valueOf(0xFFE0E0E0));
            c.setTextColor(0xFF333333);
        }
        selected.setBackgroundTintList(ColorStateList.valueOf(0xFFD2192B));
        selected.setTextColor(0xFFFFFFFF);
    }

    private void loadSharedQuizzes() {
        FirebaseDatabase.getInstance().getReference("SharedQuizzes").child(studentUid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        allQuizzes.clear();
                        for (DataSnapshot ds : snapshot.getChildren()) {
                            Map<String, Object> quiz = new HashMap<>();
                            for (DataSnapshot field : ds.getChildren())
                                quiz.put(field.getKey(), field.getValue());
                            if (!quiz.containsKey("quizId")) quiz.put("quizId", ds.getKey());
                            allQuizzes.add(quiz);
                        }
                        allQuizzes.sort((a, b) -> {
                            long ta = a.containsKey("sharedAt") ? ((Number) a.get("sharedAt")).longValue() : 0;
                            long tb = b.containsKey("sharedAt") ? ((Number) b.get("sharedAt")).longValue() : 0;
                            return Long.compare(tb, ta);
                        });
                        progressBar.setVisibility(View.GONE);
                        renderCards();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(ParentQuizReportActivity.this, "Load failed", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void renderCards() {
        layoutQuizCards.removeAllViews();
        String q = etSearch.getText().toString().trim().toLowerCase();

        List<Map<String, Object>> filtered = new ArrayList<>();
        for (Map<String, Object> quiz : allQuizzes) {
            if (!"All".equals(activeChip)) {
                String sub = s(quiz, "subject");
                if (!sub.equalsIgnoreCase(activeChip)) continue;
            }
            if (!q.isEmpty()) {
                if (!s(quiz, "title").toLowerCase().contains(q)
                        && !s(quiz, "subject").toLowerCase().contains(q)) continue;
            }
            filtered.add(quiz);
        }

        if (filtered.isEmpty()) {
            showEmpty(allQuizzes.isEmpty() ? "No quizzes assigned yet." : "No matching quiz found.");
        } else {
            layoutEmpty.setVisibility(View.GONE);
        }

        for (Map<String, Object> quiz : filtered) layoutQuizCards.addView(buildCard(quiz));
    }

    private void showEmpty(String message) {
        layoutEmpty.setVisibility(View.VISIBLE);
        tvEmpty.setText(message);
    }

    private View buildCard(Map<String, Object> quiz) {
        String quizId    = s(quiz, "quizId");
        String title     = s(quiz, "title");
        String subject   = s(quiz, "subject");
        String cls       = s(quiz, "className").isEmpty() ? s(quiz, "grade") : s(quiz, "className");
        String endDate   = s(quiz, "endDate");
        String timeLimit = s(quiz, "timeLimit");

        CardView card = new CardView(this);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(0, dpToPx(6), 0, dpToPx(6));
        card.setLayoutParams(cardLp);
        card.setRadius(dpToPx(12));
        card.setCardElevation(dpToPx(4));
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dpToPx(14), dpToPx(14), dpToPx(14), dpToPx(14));
        card.addView(inner);

        TextView tvSubject = new TextView(this);
        tvSubject.setText(subject);
        tvSubject.setTextColor(0xFFD2192B);
        tvSubject.setTextSize(12f);
        tvSubject.setTypeface(null, Typeface.BOLD);
        inner.addView(tvSubject);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextColor(0xFF1A1A2E);
        tvTitle.setTextSize(16f);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setPadding(0, dpToPx(4), 0, 0);
        inner.addView(tvTitle);

        TextView tvMeta = new TextView(this);
        tvMeta.setText("Class: " + cls + (endDate.isEmpty() ? "" : "  •  Due: " + endDate)
                + (timeLimit.isEmpty() ? "" : "  •  Time: " + timeLimit + " min"));
        tvMeta.setTextColor(0xFF757575);
        tvMeta.setTextSize(13f);
        tvMeta.setPadding(0, dpToPx(4), 0, dpToPx(8));
        inner.addView(tvMeta);

        attachStatusBadge(inner, quiz, quizId);

        return card;
    }

    private void attachStatusBadge(LinearLayout parent, Map<String, Object> quiz, String quizId) {
        FirebaseDatabase.getInstance().getReference("QuizAttempts")
                .child(quizId).child(studentUid).get()
                .addOnSuccessListener(snap -> {
                    TextView badge = new TextView(this);
                    badge.setAllCaps(false);
                    badge.setTextColor(0xFFFFFFFF);
                    badge.setTextSize(13f);
                    badge.setTypeface(null, Typeface.BOLD);
                    badge.setGravity(android.view.Gravity.CENTER);
                    badge.setPadding(0, dpToPx(10), 0, dpToPx(10));
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    lp.setMargins(0, dpToPx(4), 0, 0);
                    badge.setLayoutParams(lp);
                    badge.setBackground(getDrawable(R.drawable.image_round_bg));

                    long now           = System.currentTimeMillis();
                    long startTs       = getLong(quiz, "startTimestamp");
                    long endTs         = getLong(quiz, "endTimestamp");
                    boolean notStarted = startTs > 0 && now < startTs;
                    boolean expired    = endTs   > 0 && now > endTs;

                    if (snap.exists()) {
                        Object scoreObj = snap.child("score").getValue();
                        int score = scoreObj != null ? ((Number) scoreObj).intValue() : 0;
                        Object mcqTotalObj = snap.child("mcqTotal").getValue();
                        int mcqTotal = mcqTotalObj != null ? ((Number) mcqTotalObj).intValue() : 0;
                        Object shortTotalObj = snap.child("shortTotal").getValue();
                        int shortTotal = shortTotalObj != null ? ((Number) shortTotalObj).intValue() : 0;
                        Object shortMarksObj = snap.child("shortMarks").getValue();
                        int shortMarks = shortMarksObj != null ? ((Number) shortMarksObj).intValue() : 0;
                        Object shortStatus = snap.child("shortMarksStatus").getValue();
                        boolean pending = shortStatus != null && shortStatus.toString().equals("pending");

                        String txt;
                        if (shortTotal > 0 && mcqTotal > 0 && pending) {
                            txt = "✓ Attempted  |  MCQ: " + score + "/" + mcqTotal + "  |  Short: Pending";
                        } else if (shortTotal > 0 && mcqTotal > 0) {
                            txt = "✓ Attempted  |  MCQ: " + score + "/" + mcqTotal + "  |  Short: " + shortMarks + "/" + shortTotal;
                        } else if (shortTotal > 0 && pending) {
                            txt = "✓ Attempted  |  Short: Pending";
                        } else if (shortTotal > 0) {
                            txt = "✓ Attempted  |  Short: " + shortMarks + "/" + shortTotal;
                        } else if (mcqTotal > 0) {
                            txt = "✓ Attempted  |  Score: " + score + "/" + mcqTotal;
                        } else {
                            txt = "✓ Attempted  |  Score: " + score;
                        }
                        badge.setText(txt);
                        badge.setBackgroundTintList(ColorStateList.valueOf(0xFF4CAF50));
                    } else if (notStarted) {
                        badge.setText("Not Started Yet");
                        badge.setBackgroundTintList(ColorStateList.valueOf(0xFF9E9E9E));
                    } else if (expired) {
                        badge.setText("Time Over  |  Not Attempted");
                        badge.setBackgroundTintList(ColorStateList.valueOf(0xFF9E9E9E));
                    } else {
                        badge.setText("Not Attempted Yet");
                        badge.setBackgroundTintList(ColorStateList.valueOf(0xFFFF8F00));
                    }
                    parent.addView(badge);
                });
    }

    private String s(Map<String, Object> map, String key) {
        Object v = map.get(key);
        return v != null ? v.toString() : "";
    }

    private long getLong(Map<String, Object> map, String key) {
        Object v = map.get(key);
        if (v instanceof Number) return ((Number) v).longValue();
        return 0L;
    }

    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
    }
}