package com.example.kipscoachingkharian.dashboard;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * Student bottom bar:
 *  - Home / Feedback / Profile icons ek jitne size ke dikhte hain
 *    (PNG files me alag alag khali jagah (padding) thi, isliye size alag lagta tha).
 *  - Jo icon select / click ho wo baqi se thora bara (SELECTED_SCALE) ho jata hai.
 */
public class StudentBottomNavigationView extends BottomNavigationView {

    private static final float ICON_SIZE_DP    = 26f;
    private static final float SELECTED_SCALE  = 1.2f;
    private static final long  ANIM_MS         = 150L;

    // PNG ke andar ki khali jagah barabar karne ke liye (har taraf se inset fraction)
    private static final float HOME_INSET     = 0.10f;   // ic_home: poora bhara hua
    private static final float FEEDBACK_INSET = 0.053f;  // ic_feedback: halka padding
    private static final float PROFILE_INSET  = 0.0f;    // ic_profile: pehle se padding wala

    private boolean iconsNormalized = false;

    public StudentBottomNavigationView(@NonNull Context context) {
        super(context);
        init();
    }

    public StudentBottomNavigationView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public StudentBottomNavigationView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setItemIconSize(Math.round(ICON_SIZE_DP * getResources().getDisplayMetrics().density));
        normalizeIcons();
        // Item views bunne ke baad selected icon ko bara karo
        post(() -> applyScale(getSelectedItemId(), false));
    }

    private void normalizeIcons() {
        if (iconsNormalized) return;
        iconsNormalized = true;
        inset(R.id.nav_bottom_home, HOME_INSET);
        inset(R.id.nav_bottom_feedback, FEEDBACK_INSET);
        inset(R.id.nav_bottom_profile, PROFILE_INSET);
    }

    private void inset(int itemId, float fraction) {
        MenuItem item = getMenu().findItem(itemId);
        if (item == null || item.getIcon() == null || fraction <= 0f) return;
        Drawable icon = item.getIcon();
        item.setIcon(new InsetDrawable(icon, fraction));
    }

    // ── Selection hooks ──────────────────────────────────────────────────────

    @Override
    public void setOnItemSelectedListener(@Nullable OnItemSelectedListener listener) {
        if (listener == null) {
            super.setOnItemSelectedListener(null);
            return;
        }
        super.setOnItemSelectedListener(item -> {
            boolean handled = listener.onNavigationItemSelected(item);
            if (handled) {
                final int id = item.getItemId();
                applyScale(id, true);
                post(() -> applyScale(id, false));
            }
            return handled;
        });
    }

    @Override
    public void setSelectedItemId(int itemId) {
        super.setSelectedItemId(itemId);
        post(() -> applyScale(getSelectedItemId(), true));
    }

    // ── Scale ────────────────────────────────────────────────────────────────

    private void applyScale(int selectedId, boolean animate) {
        Menu menu = getMenu();
        for (int i = 0; i < menu.size(); i++) {
            int id = menu.getItem(i).getItemId();
            View itemView = findViewById(id);
            if (itemView == null) continue;
            View icon = findIconView(itemView);
            if (icon == null) continue;

            allowOverflow(icon);

            float target = (id == selectedId) ? SELECTED_SCALE : 1f;
            if (animate) {
                icon.animate().scaleX(target).scaleY(target).setDuration(ANIM_MS).start();
            } else {
                icon.animate().cancel();
                icon.setScaleX(target);
                icon.setScaleY(target);
            }
        }
    }

    private View findIconView(View itemView) {
        View byId = itemView.findViewById(com.google.android.material.R.id.navigation_bar_item_icon_view);
        if (byId != null) return byId;
        return firstImageView(itemView);
    }

    private View firstImageView(View v) {
        if (v instanceof ImageView) return v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View found = firstImageView(g.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    /** Bara hone wala icon kinaron se kat na jaye. */
    private void allowOverflow(View icon) {
        ViewParent p = icon.getParent();
        while (p instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) p;
            g.setClipChildren(false);
            g.setClipToPadding(false);
            if (g == this) break;
            p = g.getParent();
        }
    }
}
