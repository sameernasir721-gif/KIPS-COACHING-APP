package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PaymentActivity extends AppCompatActivity {

    // ── UI ────────────────────────────────────────────────────────────────────
    private TextView tvStudentNameVal, tvTotalAmount, tvStatusVal, tvFeeMonthVal;

    // ── Data ──────────────────────────────────────────────────────────────────
    private String amount       = "0";
    private String studentName  = "Student";
    private String studentEmail = "student@kips.com";
    private String studentUid   = "";
    private String purpose      = "fee";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        tvStudentNameVal = findViewById(R.id.tv_student_name_val);
        tvTotalAmount    = findViewById(R.id.tv_total_amount);
        tvStatusVal      = findViewById(R.id.tv_status_val);
        tvFeeMonthVal    = findViewById(R.id.tv_fee_month_val);

        ImageView btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        if (getIntent().hasExtra("purpose")) {
            purpose = getIntent().getStringExtra("purpose");
        }

        String month = new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(new Date());
        if (tvFeeMonthVal != null) tvFeeMonthVal.setText(month);

        boolean skipWallet = getIntent().getBooleanExtra("skip_wallet", false);

        // ── Pay Now button (fallback agar auto-launch nahi hua) ──────────────
        findViewById(R.id.btn_pay_now).setOnClickListener(v -> {
            if (amount.equals("0") || amount.isEmpty()) {
                Toast.makeText(this, "Fee amount not correct", Toast.LENGTH_SHORT).show();
                return;
            }
            openWalletScreen();
        });

        // Data load
        if (getIntent().hasExtra("fee_amount")) {
            amount       = getIntent().getStringExtra("fee_amount");
            studentName  = getIntent().getStringExtra("student_name");
            studentEmail = getIntent().getStringExtra("student_email");
            if (studentName  == null) studentName  = "Student";
            if (studentEmail == null) studentEmail = "";
            updateUI();

            // ✅ skip_wallet=true → seedha PayFast launch karo, koi button nahi dabana
            if (skipWallet) {
                fetchConfigAndPay();
            }
        } else {
            fetchStudentData();
        }
    }

    // ── Load student data from Firebase ──────────────────────────────────────
    private void fetchStudentData() {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        studentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        FirebaseDatabase.getInstance().getReference("Users").child(studentUid).get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        studentName  = snapshot.child("name").getValue(String.class);
                        studentEmail = snapshot.child("email").getValue(String.class);
                        Object feeObj = snapshot.child("totalFee").getValue();
                        amount = feeObj != null ? feeObj.toString() : "0";
                        if (studentName  == null) studentName  = "Student";
                        if (studentEmail == null) studentEmail = "";
                        updateUI();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Data load failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void updateUI() {
        if (tvStudentNameVal != null) tvStudentNameVal.setText(studentName);
        if (tvTotalAmount    != null) tvTotalAmount.setText("Rs " + amount);
        // Status Firebase se check karke set karo
        refreshPaymentStatus();
    }

    // ── Firebase se feePaid/feeStatus read karke tv_status_val update karo ─────────
    private void refreshPaymentStatus() {
        if (tvStatusVal == null) return;
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            tvStatusVal.setText("Pending");
            return;
        }
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .get().addOnSuccessListener(snap -> {
                    Boolean feePaid = snap.child("feePaid").getValue(Boolean.class);
                    String feeStatus = snap.child("feeStatus").getValue(String.class);
                    boolean isPaid = Boolean.TRUE.equals(feePaid)
                            || "Paid".equalsIgnoreCase(feeStatus);
                    if (tvStatusVal != null) {
                        tvStatusVal.setText(isPaid ? "Paid" : "Pending");
                        tvStatusVal.setTextColor(isPaid
                                ? android.graphics.Color.parseColor("#2E7D32")  // green
                                : android.graphics.Color.parseColor("#E53935")); // red
                    }
                });
    }

    // ── Wallet screen kholo — balance dikhao, wahan se payment decide hogi ─────────────
    private void openWalletScreen() {
        String feeMonthStr = getIntent().getStringExtra("fee_month");
        if (feeMonthStr == null || feeMonthStr.isEmpty()) {
            feeMonthStr = new java.text.SimpleDateFormat("MMMM yyyy", java.util.Locale.getDefault()).format(new java.util.Date());
        }
        Intent intent = new Intent(this, WalletPaymentActivity.class);
        intent.putExtra("fee_amount",    amount);
        intent.putExtra("student_name",  studentName);
        intent.putExtra("student_email", studentEmail);
        intent.putExtra("fee_month",     feeMonthStr);
        startActivity(intent);
        // PaymentActivity finish mat karo — back press pe PayNow page pe wapis aana chahiye
    }

    // ── PayFast launch via shared helper ─────────────────────────────────────
    private void fetchConfigAndPay() {
        String feeMonth = getIntent().getStringExtra("fee_month") != null
                ? getIntent().getStringExtra("fee_month")
                : new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(new Date());

        PayFastLauncher.launch(this, amount, studentName, studentEmail, feeMonth, purpose);
    }

}