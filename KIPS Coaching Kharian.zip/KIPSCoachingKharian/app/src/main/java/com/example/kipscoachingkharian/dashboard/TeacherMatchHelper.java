package com.example.kipscoachingkharian.dashboard;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class TeacherMatchHelper {

    private TeacherMatchHelper() {}


    public static String normalizeSubject(String raw) {
        return raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
    }


    public static String normalizeClass(String raw) {
        if (raw == null) return "";
        return raw.replaceAll("(?i)class", "").replace(" ", "").trim().toUpperCase(Locale.ROOT);
    }


    public static List<String> splitList(String raw) {
        List<String> out = new ArrayList<>();
        if (raw == null) return out;
        for (String part : raw.split(",")) {
            String t = part.trim();
            if (!t.isEmpty() && !t.equals("-")) out.add(t);
        }
        return out;
    }


    public static Set<String> studentClassCandidates(String className, String section) {
        Set<String> out = new HashSet<>();
        String base = normalizeClass(className);
        if (!base.isEmpty()) out.add(base);
        String combined = combinedClass(className, section);
        if (!combined.isEmpty()) out.add(combined);
        return out;
    }


    public static String studentClassLabel(String className, String section) {
        String combined = combinedClass(className, section);
        return !combined.isEmpty() ? combined : normalizeClass(className);
    }

    private static String combinedClass(String className, String section) {
        String base = normalizeClass(className);
        String sec  = normalizeClass(section);
        if (sec.isEmpty() || !base.matches("\\d+(TH|ST|ND|RD)?")) return "";
        return base.replaceAll("[^0-9]", "") + sec;
    }


    public static List<String> matchedSubjects(Collection<String> teacherSubjects,
                                               Set<String> enrolledNormalized) {
        Map<String, String> out = new LinkedHashMap<>();
        if (teacherSubjects == null || enrolledNormalized == null) return new ArrayList<>();
        for (String s : teacherSubjects) {
            String key = normalizeSubject(s);
            if (!key.isEmpty() && enrolledNormalized.contains(key) && !out.containsKey(key)) {
                out.put(key, s.trim());
            }
        }
        return new ArrayList<>(out.values());
    }


    public static boolean teachesClass(Collection<String> teacherClasses,
                                       Set<String> studentClassCandidates) {
        if (studentClassCandidates == null || studentClassCandidates.isEmpty()) return true;
        if (teacherClasses == null) return false;
        for (String c : teacherClasses) {
            if (studentClassCandidates.contains(normalizeClass(c))) return true;
        }
        return false;
    }
}