package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Submit Assignment Screen
 *
 * Firebase Submission path:
 *   Submissions / {assignmentId} / {studentUid}
 *       ├─ studentName     (String)
 *       ├─ studentClass    (String)
 *       ├─ rollNo          (String)
 *       ├─ answer          (String)
 *       ├─ submittedAt     (long)
 *       ├─ submittedDate   (String)
 *       ├─ assignmentTitle (String)
 *       ├─ subject         (String)
 *       ├─ teacherId       (String)
 *       └─ status          "Submitted" / "Graded"
 */
public class SubmitAssignmentActivity extends AppCompatActivity {

    // ── Intent keys ──────────────────────────────────────────────────────────
    public static final String EXTRA_ASSIGNMENT_ID = "assignment_id";
    public static final String EXTRA_TEACHER_ID    = "teacher_id";
    public static final String EXTRA_TITLE         = "title";
    public static final String EXTRA_SUBJECT       = "subject";
    public static final String EXTRA_MARKS         = "marks";
    public static final String EXTRA_DUE_DATE      = "due_date";
    public static final String EXTRA_DUE_TIME      = "due_time";
    public static final String EXTRA_DESCRIPTION   = "description";

    // ── Views ────────────────────────────────────────────────────────────────
    private TextView          tvAssignTitle, tvSubject, tvMarks, tvDueDate;
    private TextView          tvDescription, tvAlreadySubmitted, tvPdfStatus;
    private TextInputEditText etAnswer;
    private Button            btnSubmit;
    private Button btnUploadPdf;
    private ImageView         ivBack;

    // ── Data ─────────────────────────────────────────────────────────────────
    private String assignmentId, teacherId, title, subject, marks, dueDate, dueTime, description;
    private String studentUid, studentName = "", studentClass = "", rollNo = "";
    private boolean deadlinePassed = false;
    private String submittedPdfUrl = "";

    private static final String CLOUDINARY_UPLOAD_URL    = "https://api.cloudinary.com/v1_1/dzxkjbtfb/raw/upload";
    private static final String CLOUDINARY_UPLOAD_PRESET = "kips_unsigned";

    private DatabaseReference submissionsRef;
    private ActivityResultLauncher<String> filePicker;

    // ─────────────────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_assignment);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) { finish(); return; }
        studentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Intent data
        assignmentId = getIntent().getStringExtra(EXTRA_ASSIGNMENT_ID);
        teacherId    = getIntent().getStringExtra(EXTRA_TEACHER_ID);
        title        = getIntent().getStringExtra(EXTRA_TITLE);
        subject      = getIntent().getStringExtra(EXTRA_SUBJECT);
        marks        = getIntent().getStringExtra(EXTRA_MARKS);
        dueDate      = getIntent().getStringExtra(EXTRA_DUE_DATE);
        dueTime      = getIntent().getStringExtra(EXTRA_DUE_TIME);
        description  = getIntent().getStringExtra(EXTRA_DESCRIPTION);

        // Views
        tvAssignTitle      = findViewById(R.id.tvAssignTitle);
        tvSubject          = findViewById(R.id.tvSubject);
        tvMarks            = findViewById(R.id.tvMarks);
        tvDueDate          = findViewById(R.id.tvDueDate);
        tvDescription      = findViewById(R.id.tvDescription);
        tvAlreadySubmitted = findViewById(R.id.tvAlreadySubmitted);
        etAnswer           = findViewById(R.id.etAnswer);
        btnSubmit          = findViewById(R.id.btnSubmit);
        ivBack             = findViewById(R.id.ivBack);
        btnUploadPdf       = findViewById(R.id.btnUploadPdf);
        tvPdfStatus        = findViewById(R.id.tvPdfStatus);

        // File picker — PDF ya image
        filePicker = registerForActivityResult(
                new ActivityResultContracts.GetContent(), uri -> {
                    if (uri != null) uploadFileToCloudinary(uri);
                });
        btnUploadPdf.setOnClickListener(v -> filePicker.launch("*/*"));

        // Fill UI
        tvAssignTitle.setText(title);
        tvSubject.setText("Subject: " + subject);
        tvMarks.setText("Total Marks: " + marks);
        tvDueDate.setText("Due Date: " + dueDate + (dueTime != null && !dueTime.isEmpty() ? "  " + dueTime : ""));
        tvDescription.setText(description);

        ivBack.setOnClickListener(v -> finish());

        // ⏰ Due date/time guzar jaye to submit option band/blur kar do
        checkDeadlinePassed();

        // Firebase refs
        // Firebase path: Submissions/{assignmentId}/{studentUid}
        submissionsRef = FirebaseDatabase.getInstance()
                .getReference("Submissions")
                .child(assignmentId)
                .child(studentUid);

        // Student info fetch karo, phir check karo pehle submit hua ya nahi
        fetchStudentInfo();

        btnSubmit.setOnClickListener(v -> submitAssignment());
    }

    // ── Student info Firebase se fetch ───────────────────────────────────────
    private void fetchStudentInfo() {
        FirebaseDatabase.getInstance().getReference("Users").child(studentUid)
                .get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        String n = snapshot.child("name").getValue(String.class);
                        String c = snapshot.child("className").getValue(String.class);
                        String r = snapshot.child("rollNo").getValue(String.class);
                        if (n != null) studentName  = n;
                        if (c != null) studentClass = c;
                        if (r != null) rollNo       = r;
                    }
                    // Info mil gayi, check karo already submitted hai ya nahi
                    checkAlreadySubmitted();
                })
                .addOnFailureListener(e -> checkAlreadySubmitted());
    }

    // ── Due date/time guzar gaya? Check karo ─────────────────────────────────
    private void checkDeadlinePassed() {
        deadlinePassed = false;
        if (dueDate == null || dueDate.trim().isEmpty()) return;

        String timePart = (dueTime != null && !dueTime.trim().isEmpty()) ? dueTime.trim() : "11:59 PM";

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("d/M/yyyy hh:mm a", Locale.getDefault());
            Date dueDateTime = sdf.parse(dueDate.trim() + " " + timePart);
            if (dueDateTime != null) {
                Date now = Calendar.getInstance().getTime();
                if (now.after(dueDateTime)) {
                    deadlinePassed = true;
                    applyDeadlineLockUI();
                }
            }
        } catch (ParseException e) {
            // dueDate/dueTime format na ho to ignore karo, submit allow rahe ga
            deadlinePassed = false;
        }
    }

    // ── Submit button band aur blur (faded) dikhao ───────────────────────────
    private void applyDeadlineLockUI() {
        etAnswer.setEnabled(false);
        btnSubmit.setEnabled(false);
        btnSubmit.setText("⏰ Submission Closed");
        btnSubmit.setAlpha(0.4f);

        tvAlreadySubmitted.setVisibility(android.view.View.VISIBLE);
        tvAlreadySubmitted.setText("⏰ Due date/time has passed. Submission is now closed.");
        tvAlreadySubmitted.setTextColor(0xFFD50000);

        tvDueDate.setTextColor(0xFF9E9E9E);
    }

    // ── Check: pehle submit kiya tha to dikhao ───────────────────────────────
    private void checkAlreadySubmitted() {
        submissionsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Already submitted
                    String prevAnswer = snapshot.child("answer").getValue(String.class);
                    String submDate   = snapshot.child("submittedDate").getValue(String.class);

                    tvAlreadySubmitted.setVisibility(android.view.View.VISIBLE);
                    // Show obtained marks if graded
                    String obtainedMarks = snapshot.child("obtainedMarks").getValue(String.class);
                    String statusVal     = snapshot.child("status").getValue(String.class);
                    if (obtainedMarks != null && !obtainedMarks.isEmpty()) {
                        tvAlreadySubmitted.setText("✅ Submitted on: " + submDate
                                + "\n⭐ Marks: " + obtainedMarks + " / " + marks
                                + "  |  Status: Graded");
                        tvAlreadySubmitted.setTextColor(0xFF2E7D32);
                    } else {
                        tvAlreadySubmitted.setText("✅ Submitted on: " + submDate + "\nMarks: Pending");
                        tvAlreadySubmitted.setTextColor(0xFF1565C0);
                    }

                    // Pehla answer dikhao (read-only)
                    if (prevAnswer != null) etAnswer.setText(prevAnswer);
                    etAnswer.setEnabled(false);
                    btnSubmit.setEnabled(false);
                    btnSubmit.setText("Already Submitted");
                    btnSubmit.setAlpha(0.6f);
                } else {
                    tvAlreadySubmitted.setVisibility(android.view.View.GONE);
                    if (deadlinePassed) {
                        applyDeadlineLockUI();
                    } else {
                        etAnswer.setEnabled(true);
                        btnSubmit.setEnabled(true);
                        btnSubmit.setAlpha(1f);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(SubmitAssignmentActivity.this,
                        "Error checking submission", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ── Assignment submit karo Firebase pe ───────────────────────────────────
    private void submitAssignment() {
        if (deadlinePassed) {
            Toast.makeText(this, "⏰ Due date/time has passed. You can't submit now.", Toast.LENGTH_SHORT).show();
            applyDeadlineLockUI();
            return;
        }

        String answer = etAnswer.getText() != null
                ? etAnswer.getText().toString().trim() : "";

        // Agar PDF attach nahi ki to answer zaroori hai
        if (TextUtils.isEmpty(answer) && submittedPdfUrl.isEmpty()) {
            etAnswer.setError("Write your answer or attach a PDF file");
            etAnswer.requestFocus();
            return;
        }

        // Confirm dialog
        new AlertDialog.Builder(this)
                .setTitle("Submit Assignment")
                .setMessage("Do you surely want to submit it?You cannot edit it once you submitted it.")
                .setPositiveButton("Submit", (dialog, which) -> saveToFirebase(answer))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveToFirebase(String answer) {
        btnSubmit.setEnabled(false);
        btnSubmit.setText("Submitting...");

        String submittedDate = new SimpleDateFormat("MMM dd, yyyy  hh:mm a", Locale.getDefault())
                .format(Calendar.getInstance().getTime());

        Map<String, Object> data = new HashMap<>();
        data.put("answer",          answer);
        data.put("studentName",     studentName);
        data.put("studentClass",    studentClass);
        data.put("rollNo",          rollNo);
        data.put("assignmentTitle", title);
        data.put("subject",         subject);
        data.put("teacherId",       teacherId);
        data.put("submittedAt",     System.currentTimeMillis());
        data.put("submittedDate",   submittedDate);
        data.put("status",          "Submitted");
        data.put("pdfUrl",          submittedPdfUrl); // student ka uploaded file

        submissionsRef.setValue(data)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this,
                            "✅ Assignment submitted!", Toast.LENGTH_SHORT).show();

                    // UI update
                    tvAlreadySubmitted.setVisibility(android.view.View.VISIBLE);
                    tvAlreadySubmitted.setText("✅ Submitted on: " + submittedDate);
                    etAnswer.setEnabled(false);
                    btnSubmit.setText("Submitted");
                    btnSubmit.setAlpha(0.6f);

                    // Teacher ko notify karo jisne yeh assignment banayi thi
                    notifyTeacherOfSubmission();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this,
                            "Submit fail: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    btnSubmit.setEnabled(true);
                    btnSubmit.setText("Submit Assignment");
                });
    }

    /**
     * Jab student assignment submit kare, us teacher ko announcement bhejo
     * jisne yeh assignment banayi thi. Yeh Announcements/Teachers node mein
     * push hota hai with targetTeacherId field, taake TeacherAnnouncementsActivity
     * usay filter kar ke sirf relevant teacher ko dikha sake.
     */
    // ── File Cloudinary upload — student ka answer PDF/image ─────────────────
    private void uploadFileToCloudinary(Uri uri) {
        tvPdfStatus.setVisibility(View.VISIBLE);
        tvPdfStatus.setText("Uploading...");
        btnUploadPdf.setEnabled(false);

        new Thread(() -> {
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                byte[] temp = new byte[8192]; int n;
                while ((n = inputStream.read(temp)) != -1) buffer.write(temp, 0, n);
                inputStream.close();
                byte[] bytes = buffer.toByteArray();
                inputStream.close();

                String mimeType = getContentResolver().getType(uri);
                if (mimeType == null) mimeType = "application/octet-stream";

                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("file", "submission",
                                RequestBody.create(bytes, MediaType.parse(mimeType)))
                        .addFormDataPart("upload_preset", CLOUDINARY_UPLOAD_PRESET)
                        .addFormDataPart("resource_type", "raw")
                        .build();

                Request request = new Request.Builder()
                        .url(CLOUDINARY_UPLOAD_URL)
                        .post(requestBody)
                        .build();

                Response response = new OkHttpClient().newCall(request).execute();
                JSONObject json = new JSONObject(response.body().string());
                String url = json.getString("secure_url");

                runOnUiThread(() -> {
                    submittedPdfUrl = url;
                    tvPdfStatus.setText("✅ File uploaded");
                    tvPdfStatus.setTextColor(0xFF2E7D32);
                    btnUploadPdf.setAlpha(0.7f);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    tvPdfStatus.setText("❌ Upload failed");
                    tvPdfStatus.setTextColor(0xFFD50000);
                    btnUploadPdf.setEnabled(true);
                    Toast.makeText(this, "Upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private void notifyTeacherOfSubmission() {
        if (teacherId == null || teacherId.trim().isEmpty()) return;

        Map<String, Object> announcement = new HashMap<>();
        announcement.put("title", "📩 Assignment Submitted");
        announcement.put("message", studentName + " (" + studentClass + ") submitted \""
                + title + "\" - " + subject);
        announcement.put("targetGroup", "Submission");
        announcement.put("targetClass", studentClass);
        announcement.put("targetTeacherId", teacherId);
        announcement.put("timestamp", System.currentTimeMillis());
        announcement.put("type", "assignment_submission");

        FirebaseDatabase.getInstance().getReference("Announcements")
                .child("Teachers").push().setValue(announcement);
    }
}