package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class TeacherPickerActivity extends AppCompatActivity {

    private RecyclerView rvTeachers;
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private EditText etSearch;

    private TeacherPickerAdapter adapter;
    private final List<ParentPickerActivity.UserItem> allTeachers   = new ArrayList<>();
    private final List<ParentPickerActivity.UserItem> filteredList  = new ArrayList<>();

    private String myName, myRole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_picker); // reuse same layout

        myName = getIntent().getStringExtra("MY_NAME");
        myRole = getIntent().getStringExtra("MY_ROLE");

        rvTeachers  = findViewById(R.id.rvParents);
        progressBar = findViewById(R.id.progressBar);
        tvEmpty     = findViewById(R.id.tvEmpty);
        etSearch    = findViewById(R.id.etSearch);

        TextView tvHeader = findViewById(R.id.tvPickerTitle);
        if (tvHeader != null) tvHeader.setText("Select a Teacher");

        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        adapter = new TeacherPickerAdapter(filteredList, user -> {
            Intent intent = new Intent(TeacherPickerActivity.this, ChatActivity.class);
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_ID,   user.uid);
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_NAME, user.name);
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_ROLE, "Teacher");
            intent.putExtra(ChatActivity.EXTRA_MY_NAME,       myName);
            intent.putExtra(ChatActivity.EXTRA_MY_ROLE,       myRole);
            startActivity(intent);
        });

        rvTeachers.setLayoutManager(new LinearLayoutManager(this));
        rvTeachers.setAdapter(adapter);

        loadTeachers();

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i1, int i2, int i3) {}
            @Override public void onTextChanged(CharSequence s, int i1, int i2, int i3) { filter(s.toString()); }
            @Override public void afterTextChanged(Editable e) {}
        });
    }

    private void loadTeachers() {
        progressBar.setVisibility(View.VISIBLE);
        FirebaseDatabase.getInstance().getReference("Users")
                .orderByChild("role").equalTo("Teacher")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        allTeachers.clear();
                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String name    = ds.child("name").getValue(String.class);
                            String subject = ds.child("subject").getValue(String.class);
                            ParentPickerActivity.UserItem item = new ParentPickerActivity.UserItem(
                                    ds.getKey(),
                                    name    != null ? name    : "Unknown",
                                    subject != null ? subject : ""
                            );
                            allTeachers.add(item);
                        }
                        filteredList.clear();
                        filteredList.addAll(allTeachers);
                        adapter.notifyDataSetChanged();
                        progressBar.setVisibility(View.GONE);
                        tvEmpty.setVisibility(filteredList.isEmpty() ? View.VISIBLE : View.GONE);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(TeacherPickerActivity.this,
                                "Error loading teachers", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void filter(String query) {
        filteredList.clear();
        for (ParentPickerActivity.UserItem u : allTeachers) {
            if (u.name.toLowerCase().contains(query.toLowerCase())) filteredList.add(u);
        }
        adapter.notifyDataSetChanged();
        tvEmpty.setVisibility(filteredList.isEmpty() ? View.VISIBLE : View.GONE);
    }

    // ── Inline adapter ───────────────────────────────────────────────────────
    static class TeacherPickerAdapter
            extends RecyclerView.Adapter<ParentPickerActivity.ParentPickerAdapter.VH> {

        interface OnPickListener { void onPick(ParentPickerActivity.UserItem user); }
        private final List<ParentPickerActivity.UserItem> list;
        private final OnPickListener listener;

        TeacherPickerAdapter(List<ParentPickerActivity.UserItem> list, OnPickListener listener) {
            this.list = list; this.listener = listener;
        }
        @NonNull @Override
        public ParentPickerActivity.ParentPickerAdapter.VH onCreateViewHolder(
                @NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_parent_pick_row, parent, false);
            return new ParentPickerActivity.ParentPickerAdapter.VH(v);
        }
        @Override
        public void onBindViewHolder(
                @NonNull ParentPickerActivity.ParentPickerAdapter.VH h, int pos) {
            ParentPickerActivity.UserItem u = list.get(pos);
            h.tvName.setText(u.name);
            h.tvPhone.setText(u.phone); // here phone field holds subject
            if (!u.name.isEmpty())
                h.tvAvatar.setText(String.valueOf(u.name.charAt(0)).toUpperCase());
            h.itemView.setOnClickListener(v -> listener.onPick(u));
        }
        @Override public int getItemCount() { return list.size(); }
    }
}
