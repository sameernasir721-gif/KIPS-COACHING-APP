package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class TeacherPickerActivity extends AppCompatActivity {

    private RecyclerView rvTeachers;
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private EditText etSearch;

    private TeacherPickerAdapter adapter;
    private final List<ParentPickerActivity.UserItem> allTeachers   = new ArrayList<>();
    private final List<ParentPickerActivity.UserItem> filteredList  = new ArrayList<>();

    private String myName, myRole;


    private String studentId;


    private final Set<String> enrolledSubjects = new HashSet<>();

    private final Set<String> studentClassCandidates = new HashSet<>();

    private String studentClassLabel = "";


    private String emptyMessage = "No teachers found for your child's subjects";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_picker);

        myName    = getIntent().getStringExtra("MY_NAME");
        myRole    = getIntent().getStringExtra("MY_ROLE");
        studentId = getIntent().getStringExtra("STUDENT_ID");

        rvTeachers  = findViewById(R.id.rvParents);
        progressBar = findViewById(R.id.progressBar);
        tvEmpty     = findViewById(R.id.tvEmpty);
        etSearch    = findViewById(R.id.etSearch);

        TextView tvHeader = findViewById(R.id.tvPickerTitle);
        if (tvHeader != null) tvHeader.setText("Select a Teacher");

        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        adapter = new TeacherPickerAdapter(filteredList, user -> {
            Intent intent = new Intent(TeacherPickerActivity.this, ChatActivity.class);
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_ID,   user.uid);
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_NAME, user.name);
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_ROLE, "Teacher");
            intent.putExtra(ChatActivity.EXTRA_MY_NAME,       myName);
            intent.putExtra(ChatActivity.EXTRA_MY_ROLE,       myRole);
            startActivity(intent);
        });

        rvTeachers.setLayoutManager(new LinearLayoutManager(this));
        rvTeachers.setAdapter(adapter);


        loadStudentThenTeachers();

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i1, int i2, int i3) {}
            @Override public void onTextChanged(CharSequence s, int i1, int i2, int i3) { filter(s.toString()); }
            @Override public void afterTextChanged(Editable e) {}
        });
    }


    private void loadStudentThenTeachers() {
        if (studentId == null || studentId.trim().isEmpty()) {
            showNoTeachers("Student information not available.");
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        FirebaseDatabase.getInstance().getReference("Users")
                .orderByChild("registrationId").equalTo(studentId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        enrolledSubjects.clear();
                        studentClassCandidates.clear();
                        studentClassLabel = "";

                        boolean studentFound = false;
                        for (DataSnapshot userSnap : snapshot.getChildren()) {

                            String role = readString(userSnap, "role");
                            if (role == null || !role.trim().equalsIgnoreCase("Student")) continue;
                            studentFound = true;

                            for (DataSnapshot subSnap : userSnap.child("enrolledSubjects").getChildren()) {
                                Object v = subSnap.getValue();
                                if (v instanceof String) {
                                    String key = TeacherMatchHelper.normalizeSubject((String) v);
                                    if (!key.isEmpty()) enrolledSubjects.add(key);
                                }
                            }

                            if (enrolledSubjects.isEmpty()) {
                                for (String s : TeacherMatchHelper.splitList(readString(userSnap, "subject"))) {
                                    enrolledSubjects.add(TeacherMatchHelper.normalizeSubject(s));
                                }
                            }

                            String className = readString(userSnap, "className");
                            String section   = readString(userSnap, "assignedSection");
                            studentClassCandidates.addAll(
                                    TeacherMatchHelper.studentClassCandidates(className, section));
                            studentClassLabel = TeacherMatchHelper.studentClassLabel(className, section);
                            break;
                        }

                        if (!studentFound) {
                            showNoTeachers("Linked student not found.");
                        } else if (enrolledSubjects.isEmpty()) {
                            showNoTeachers("Your child is not enrolled in any subject yet.");
                        } else {
                            loadTeachers();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(TeacherPickerActivity.this,
                                "Error loading student's subjects", Toast.LENGTH_SHORT).show();
                    }
                });
    }


    private void loadTeachers() {
        progressBar.setVisibility(View.VISIBLE);
        FirebaseDatabase.getInstance().getReference("Users")
                .orderByChild("role").equalTo("Teacher")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        allTeachers.clear();
                        for (DataSnapshot ds : snapshot.getChildren()) {


                            String status = readString(ds, "status");
                            if (status != null && status.trim().equalsIgnoreCase("Deleted")) continue;


                            List<String> matched = TeacherMatchHelper.matchedSubjects(
                                    readTeacherSubjects(ds), enrolledSubjects);
                            if (matched.isEmpty()) continue;


                            if (!TeacherMatchHelper.teachesClass(
                                    readTeacherClasses(ds), studentClassCandidates)) continue;

                            String name = readString(ds, "name");
                            String label = TextUtils.join(", ", matched);
                            if (!studentClassLabel.isEmpty()) label += "  •  Class " + studentClassLabel;

                            allTeachers.add(new ParentPickerActivity.UserItem(
                                    ds.getKey(),
                                    name != null && !name.trim().isEmpty() ? name : "Unknown",
                                    label));
                        }
                        Collections.sort(allTeachers, (a, b) -> a.name.compareToIgnoreCase(b.name));

                        filteredList.clear();
                        filteredList.addAll(allTeachers);
                        adapter.notifyDataSetChanged();
                        progressBar.setVisibility(View.GONE);
                        updateEmptyState();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(TeacherPickerActivity.this,
                                "Error loading teachers", Toast.LENGTH_SHORT).show();
                    }
                });
    }


    private static List<String> readTeacherSubjects(DataSnapshot t) {
        String raw = firstNonBlank(t, "subjects", "assignedSubject", "subject");
        if (raw != null) return TeacherMatchHelper.splitList(raw);
        List<String> out = new ArrayList<>();
        for (DataSnapshot s : t.child("assignedSubjects").getChildren()) {
            if (s.getKey() != null) out.add(s.getKey());
        }
        return out;
    }


    private static List<String> readTeacherClasses(DataSnapshot t) {
        String raw = firstNonBlank(t, "className", "assignedClasses", "assignedClass");
        if (raw != null) return TeacherMatchHelper.splitList(raw);
        List<String> out = new ArrayList<>();
        for (DataSnapshot c : t.child("assignedClassMap").getChildren()) {
            if (c.getKey() != null) out.add(c.getKey());
        }
        return out;
    }


    private static String firstNonBlank(DataSnapshot snap, String... fields) {
        for (String f : fields) {
            String v = readString(snap, f);
            if (v != null && !v.trim().isEmpty()) return v;
        }
        return null;
    }


    private static String readString(DataSnapshot snap, String key) {
        Object v = snap.child(key).getValue();
        return v instanceof String ? (String) v : null;
    }

    private void showNoTeachers(String message) {
        progressBar.setVisibility(View.GONE);
        allTeachers.clear();
        filteredList.clear();
        adapter.notifyDataSetChanged();
        emptyMessage = message;
        tvEmpty.setText(message);
        tvEmpty.setVisibility(View.VISIBLE);
    }

    private void updateEmptyState() {
        boolean empty = filteredList.isEmpty();
        if (empty) {
            tvEmpty.setText(allTeachers.isEmpty() ? emptyMessage : "No results found");
        }
        tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
    }

    private void filter(String query) {
        filteredList.clear();
        for (ParentPickerActivity.UserItem u : allTeachers) {
            if (u.name.toLowerCase().contains(query.toLowerCase())) filteredList.add(u);
        }
        adapter.notifyDataSetChanged();
        updateEmptyState();
    }


    static class TeacherPickerAdapter
            extends RecyclerView.Adapter<ParentPickerActivity.ParentPickerAdapter.VH> {

        interface OnPickListener { void onPick(ParentPickerActivity.UserItem user); }
        private final List<ParentPickerActivity.UserItem> list;
        private final OnPickListener listener;

        TeacherPickerAdapter(List<ParentPickerActivity.UserItem> list, OnPickListener listener) {
            this.list = list; this.listener = listener;
        }
        @NonNull @Override
        public ParentPickerActivity.ParentPickerAdapter.VH onCreateViewHolder(
                @NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_parent_pick_row, parent, false);
            return new ParentPickerActivity.ParentPickerAdapter.VH(v);
        }
        @Override
        public void onBindViewHolder(
                @NonNull ParentPickerActivity.ParentPickerAdapter.VH h, int pos) {
            ParentPickerActivity.UserItem u = list.get(pos);
            h.tvName.setText(u.name);
            h.tvPhone.setText(u.phone);
            if (!u.name.isEmpty())
                h.tvAvatar.setText(String.valueOf(u.name.charAt(0)).toUpperCase());
            h.itemView.setOnClickListener(v -> listener.onPick(u));
        }
        @Override public int getItemCount() { return list.size(); }
    }
}