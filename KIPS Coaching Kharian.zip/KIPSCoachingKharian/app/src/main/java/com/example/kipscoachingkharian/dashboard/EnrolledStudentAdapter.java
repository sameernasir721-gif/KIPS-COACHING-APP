package com.example.kipscoachingkharian.dashboard;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;

import java.util.ArrayList;
import java.util.List;

public class EnrolledStudentAdapter extends RecyclerView.Adapter<EnrolledStudentAdapter.StudentViewHolder> {

    public interface OnStudentClickListener {
        void onStudentClick(EnrolledStudent student);
    }

    private List<EnrolledStudent> fullList;
    private List<EnrolledStudent> filteredList;
    private final OnStudentClickListener listener;

    public EnrolledStudentAdapter(List<EnrolledStudent> studentList, OnStudentClickListener listener) {
        this.fullList = new ArrayList<>(studentList);
        this.filteredList = new ArrayList<>(studentList);
        this.listener = listener;
    }

    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_enrolled_student, parent, false);
        return new StudentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, int position) {
        EnrolledStudent student = filteredList.get(position);
        holder.tvName.setText(student.getName());
        holder.tvSubject.setText("Subject: " + student.getSubjectName());

        holder.itemView.setOnClickListener(v -> {
            // Step: Admin selects a student to view individual subject enrollment details
            if (listener != null) listener.onStudentClick(student);
        });
    }

    @Override
    public int getItemCount() {
        return filteredList.size();
    }

    /** Called when a new subject's student list is loaded from Firebase */
    public void updateFullList(List<EnrolledStudent> newList) {
        fullList = new ArrayList<>(newList);
        filteredList = new ArrayList<>(newList);
        notifyDataSetChanged();
    }

    /** Called on every search text change (Admin filters/searches students) */
    public void filter(String query) {
        filteredList.clear();
        if (query == null || query.trim().isEmpty()) {
            filteredList.addAll(fullList);
        } else {
            String q = query.toLowerCase().trim();
            for (EnrolledStudent s : fullList) {
                if (s.getName().toLowerCase().contains(q)) {
                    filteredList.add(s);
                }
            }
        }
        notifyDataSetChanged();
    }

    public int getCurrentCount() {
        return filteredList.size();
    }

    static class StudentViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvSubject;

        StudentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvStudentName);
            tvSubject = itemView.findViewById(R.id.tvStudentSubject);
        }
    }
}
