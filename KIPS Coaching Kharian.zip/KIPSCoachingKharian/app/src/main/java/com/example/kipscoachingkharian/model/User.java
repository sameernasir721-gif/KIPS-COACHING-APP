package com.example.kipscoachingkharian.model;

/**
 * Data model representing a user entity in the Firebase Realtime Database.
 * This class is designed to handle all user types (Admin, Teacher, Student, Parent)
 * by utilizing optional fields specific to each role.
 */
public class User {

    // Common fields for all user types
    private String name;
    private String phone;
    private String role;       // Possible values: "Admin", "Teacher", "Student", "Parent"
    private String status;     // Account status (e.g., "Approved", "Pending")
    private String password;   // Stored for reference (Note: Security best practice is to rely on Auth uid)

    // Role-specific fields (Nullable based on role)
    private String className;  // Used by: Student (enrolled class) and Teacher (assigned class)
    private String subject;    // Used by: Teacher (e.g., "Physics", "Math")
    private String linkedChildPhone; // Used by: Parent (to link with a Student account)

    /**
     * Default constructor.
     * Required by Firebase for data deserialization (DataSnapshot.getValue(User.class)).
     */
    public User() { }

    /**
     * Primary constructor for User Registration.
     * Handles the creation of Admins, Teachers, and Students.
     * Note: Parents usually set 'linkedChildPhone' via a setter after instantiation.
     * * @param name      Full Name
     * @param phone     Phone Number (used as ID)
     * @param role      User Role
     * @param status    Approval Status
     * @param password  Account Password
     * @param className Class Name (for Student/Teacher)
     * @param subject   Subject Name (for Teacher only)
     */
    public User(String name, String phone, String role, String status, String password, String className, String subject) {
        this.name = name;
        this.phone = phone;
        this.role = role;
        this.status = status;
        this.password = password;
        this.className = className;
        this.subject = subject;
    }

    // ============================
    // Getters and Setters
    // ============================

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    /**
     * @return The Class Name.
     * For Students: The class they are studying in (e.g., "9th").
     * For Teachers: The class they are in charge of.
     */
    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }

    /**
     * @return The Subject Name.
     * Only applicable for Teachers.
     */
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    /**
     * @return The phone number of the child.
     * Only applicable for Parents to fetch student data.
     */
    public String getLinkedChildPhone() { return linkedChildPhone; }
    public void setLinkedChildPhone(String linkedChildPhone) { this.linkedChildPhone = linkedChildPhone; }
}