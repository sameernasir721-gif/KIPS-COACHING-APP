package com.example.kipscoachingkharian.dashboard;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class ParentAttendanceActivity extends AppCompatActivity {


    public static final String EXTRA_STUDENT_UID = "extra_student_uid";

    private LinearLayout containerHistory;
    private TextView tvHistoryEmpty;
    private ProgressBar progressLoading;

    private String studentClass = null;
    private final List<String> enrolledSubjects = new ArrayList<>();


    private static final String PREFS_NAME = "parent_notif_prefs";
    private SharedPreferences historyPrefs;
    private String deletedHistoryPrefKey;


    private final android.os.Handler refreshHandler = new android.os.Handler();
    private Runnable refreshRunnable;

    private static class ClassRecord {
        String title, subject, date, time, classLink, uniqueKey;
        int durationMinutes = 45;
        long sortMillis;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_attendance);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        containerHistory = findViewById(R.id.containerHistory);
        tvHistoryEmpty   = findViewById(R.id.tvHistoryEmpty);
        progressLoading  = findViewById(R.id.progressLoading);

        historyPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String parentUid = (FirebaseAuth.getInstance().getCurrentUser() != null)
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : "unknown_parent";
        deletedHistoryPrefKey = "deleted_history_" + parentUid;

        String studentUid = getIntent().getStringExtra(EXTRA_STUDENT_UID);
        if (studentUid == null || studentUid.isEmpty()) {
            tvHistoryEmpty.setVisibility(View.VISIBLE);
            tvHistoryEmpty.setText("Student information not available.");
            progressLoading.setVisibility(View.GONE);
            return;
        }

        loadStudentInfoThenHistory(studentUid);

        refreshRunnable = () -> {
            loadClassHistory();
            refreshHandler.postDelayed(refreshRunnable, 30_000);
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshHandler.postDelayed(refreshRunnable, 30_000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        refreshHandler.removeCallbacks(refreshRunnable);
    }



    private void loadStudentInfoThenHistory(String uid) {
        progressLoading.setVisibility(View.VISIBLE);

        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot userSnap) {
                        String baseClass = userSnap.child("className").getValue(String.class);
                        String section   = userSnap.child("assignedSection").getValue(String.class);


                        String trimmedBase = (baseClass != null) ? baseClass.trim() : "";
                        boolean baseIsNumberOnly = trimmedBase.matches("\\d+");
                        studentClass = baseIsNumberOnly && section != null && !section.trim().isEmpty()
                                ? trimmedBase + section.trim()
                                : trimmedBase;

                        enrolledSubjects.clear();
                        for (DataSnapshot subSnap : userSnap.child("enrolledSubjects").getChildren()) {
                            String sub = subSnap.getValue(String.class);
                            if (sub != null) enrolledSubjects.add(sub);
                        }
                        loadClassHistory();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        progressLoading.setVisibility(View.GONE);
                        tvHistoryEmpty.setVisibility(View.VISIBLE);
                    }
                });
    }

    private void loadClassHistory() {
        if (studentClass == null || studentClass.isEmpty()) {
            progressLoading.setVisibility(View.GONE);
            tvHistoryEmpty.setVisibility(View.VISIBLE);
            return;
        }

        FirebaseDatabase.getInstance().getReference("Classes")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        progressLoading.setVisibility(View.GONE);
                        containerHistory.removeAllViews();
                        List<ClassRecord> records = new ArrayList<>();
                        Set<String> deletedKeys = historyPrefs.getStringSet(deletedHistoryPrefKey, new HashSet<>());

                        for (DataSnapshot teacherSnap : snapshot.getChildren()) {
                            for (DataSnapshot classSnap : teacherSnap.getChildren()) {
                                String grade   = classSnap.child("grade").getValue(String.class);
                                String subject = classSnap.child("subject").getValue(String.class);
                                String title   = classSnap.child("className").getValue(String.class);
                                String date    = classSnap.child("date").getValue(String.class);
                                String time    = classSnap.child("time").getValue(String.class);
                                String link    = classSnap.child("classLink").getValue(String.class);
                                Long durLong   = classSnap.child("duration").getValue(Long.class);

                                if (grade == null) continue;
                                boolean gradeMatch = grade.trim().equalsIgnoreCase(studentClass.trim())
                                        || grade.trim().equalsIgnoreCase("Class " + studentClass.trim());
                                if (!gradeMatch) continue;
                                if (subject != null && !subject.trim().isEmpty()
                                        && !isEnrolled(subject)) continue;

                                String uniqueKey = teacherSnap.getKey() + "_" + classSnap.getKey();
                                if (deletedKeys.contains(uniqueKey)) continue; // swipe se delete kiya hua skip karo

                                ClassRecord rec = new ClassRecord();
                                rec.uniqueKey       = uniqueKey;
                                rec.title           = title != null ? title : "Class";
                                rec.subject         = subject != null ? subject : "";
                                rec.date            = date != null ? date : "";
                                rec.time            = time != null ? time : "";
                                rec.classLink       = link;
                                rec.durationMinutes = (durLong != null && durLong > 0) ? durLong.intValue() : 45;
                                rec.sortMillis      = parseMillis(date, time);
                                records.add(rec);
                            }
                        }


                        Collections.sort(records, (a, b) -> Long.compare(b.sortMillis, a.sortMillis));

                        for (ClassRecord rec : records) addHistoryRow(rec);

                        tvHistoryEmpty.setVisibility(records.isEmpty() ? View.VISIBLE : View.GONE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        progressLoading.setVisibility(View.GONE);
                        tvHistoryEmpty.setVisibility(View.VISIBLE);
                    }
                });
    }



    private void addHistoryRow(ClassRecord rec) {
        float dp = getResources().getDisplayMetrics().density;

        long nowMillis    = System.currentTimeMillis();
        long windowStart  = rec.sortMillis - (10 * 60 * 1000);
        long windowEnd    = rec.sortMillis + (rec.durationMinutes * 60L * 1000);

        boolean isLive = rec.sortMillis > 0 && nowMillis >= windowStart && nowMillis <= windowEnd;
        boolean isPast = rec.sortMillis > 0 && nowMillis > windowEnd;

        String statusText = isLive ? "🟢 Live" : (isPast ? "Ended" : "Upcoming");
        int statusColor   = isLive ? 0xFF2E7D32 : (isPast ? 0xFF888888 : 0xFF1565C0);
        int stripColor    = isLive ? 0xFF4CAF50 : (isPast ? 0xFFD2192B : 0xFF1565C0);

        androidx.cardview.widget.CardView card = new androidx.cardview.widget.CardView(this);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(0, 0, 0, (int) (12 * dp));
        card.setLayoutParams(cardLp);
        card.setRadius(12f * dp);
        card.setCardElevation(3f * dp);
        card.setCardBackgroundColor(Color.WHITE);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding((int) (16 * dp), (int) (12 * dp), (int) (16 * dp), (int) (12 * dp));
        row.setGravity(Gravity.CENTER_VERTICAL);


        FrameLayout strip = new FrameLayout(this);
        LinearLayout.LayoutParams stripLp = new LinearLayout.LayoutParams(
                (int) (3 * dp), LinearLayout.LayoutParams.MATCH_PARENT);
        stripLp.setMarginEnd((int) (12 * dp));
        strip.setLayoutParams(stripLp);
        strip.setBackgroundColor(stripColor);
        row.addView(strip);


        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(rec.title);
        tvTitle.setTextSize(15f);
        tvTitle.setTextColor(0xFF1A1A1A);
        tvTitle.setTypeface(null, Typeface.BOLD);
        info.addView(tvTitle);

        TextView tvSub = new TextView(this);
        tvSub.setText((rec.subject != null && !rec.subject.isEmpty() ? rec.subject + "  |  " : "")
                + rec.date + (rec.time.isEmpty() ? "" : " " + rec.time));
        tvSub.setTextSize(12f);
        tvSub.setTextColor(0xFF888888);
        info.addView(tvSub);
        row.addView(info);


        LinearLayout rightCol = new LinearLayout(this);
        rightCol.setOrientation(LinearLayout.VERTICAL);
        rightCol.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView tvStatus = new TextView(this);
        tvStatus.setText(statusText);
        tvStatus.setTextSize(11f);
        tvStatus.setTextColor(statusColor);
        tvStatus.setTypeface(null, Typeface.BOLD);
        rightCol.addView(tvStatus);


        if (isLive) {
            android.widget.Button btnJoin = new android.widget.Button(this);
            btnJoin.setText("Join");
            btnJoin.setTextSize(11f);
            btnJoin.setTextColor(Color.WHITE);
            btnJoin.setTypeface(null, Typeface.BOLD);
            btnJoin.setPadding((int) (10 * dp), 0, (int) (10 * dp), 0);
            btnJoin.setStateListAnimator(null);
            btnJoin.setMinWidth(0);
            btnJoin.setMinimumWidth(0);

            android.graphics.drawable.GradientDrawable btnBg = new android.graphics.drawable.GradientDrawable();
            btnBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
            btnBg.setCornerRadius(20 * dp);
            btnBg.setColor(Color.parseColor("#D50000"));
            btnJoin.setBackground(btnBg);

            LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, (int) (32 * dp));
            btnLp.setMargins(0, (int) (6 * dp), 0, 0);
            btnJoin.setLayoutParams(btnLp);

            final String link = rec.classLink;
            btnJoin.setOnClickListener(v -> {
                if (link != null && !link.isEmpty()) {
                    try {
                        android.content.Intent intent = new android.content.Intent(
                                android.content.Intent.ACTION_VIEW, android.net.Uri.parse(link));
                        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    } catch (Exception e) {
                        android.widget.Toast.makeText(this, "Cannot open link",
                                android.widget.Toast.LENGTH_SHORT).show();
                    }
                } else {
                    android.widget.Toast.makeText(this,
                            "Class link not available. Contact teacher.",
                            android.widget.Toast.LENGTH_LONG).show();
                }
            });
            rightCol.addView(btnJoin);
        }

        row.addView(rightCol);

        card.addView(row);
        attachSwipeToDelete(card, rec);
        containerHistory.addView(card);
    }


    private void attachSwipeToDelete(final View itemView, final ClassRecord rec) {
        final float dp = getResources().getDisplayMetrics().density;
        final float dismissThreshold = 120 * dp;

        itemView.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private boolean swiping = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX();
                        downY = event.getRawY();
                        swiping = false;
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        return false;

                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (!swiping && Math.abs(dx) > (12 * dp) && Math.abs(dx) > Math.abs(dy)) {
                            swiping = true;
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                        }
                        if (swiping) {
                            v.setTranslationX(dx);
                            v.setAlpha(Math.max(0.25f, 1f - (Math.abs(dx) / (600f * dp / 2f))));
                            return true;
                        }
                        return false;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (swiping) {
                            float finalDx = event.getRawX() - downX;
                            v.getParent().requestDisallowInterceptTouchEvent(false);
                            if (Math.abs(finalDx) > dismissThreshold) {
                                float target = finalDx > 0 ? v.getWidth() : -v.getWidth();
                                v.animate().translationX(target).alpha(0f).setDuration(200)
                                        .withEndAction(() -> dismissHistoryItem(rec, v))
                                        .start();
                            } else {
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start();
                            }
                            swiping = false;
                            return true;
                        }
                        return false;
                }
                return false;
            }
        });
    }


    private void dismissHistoryItem(ClassRecord rec, View v) {
        if (rec.uniqueKey != null) {
            Set<String> deletedKeys = new HashSet<>(historyPrefs.getStringSet(deletedHistoryPrefKey, new HashSet<>()));
            deletedKeys.add(rec.uniqueKey);
            historyPrefs.edit().putStringSet(deletedHistoryPrefKey, deletedKeys).apply();
        }
        containerHistory.removeView(v);
        if (containerHistory.getChildCount() == 0) {
            tvHistoryEmpty.setVisibility(View.VISIBLE);
        }
        Toast.makeText(ParentAttendanceActivity.this, "Removed from history", Toast.LENGTH_SHORT).show();
    }



    private boolean isEnrolled(String subject) {
        for (String s : enrolledSubjects) {
            if (s != null && s.trim().equalsIgnoreCase(subject.trim())) return true;
        }
        return false;
    }

    private long parseMillis(String date, String time) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("d/M/yyyy hh:mm a", Locale.ENGLISH);
            String clean = (date != null ? date.trim() : "") + " "
                    + (time != null ? time.replaceAll("[^0-9: APMapm]", "").trim() : "");
            Date d = sdf.parse(clean.trim());
            return d != null ? d.getTime() : 0;
        } catch (ParseException | NullPointerException e) {
            return 0;
        }
    }
}