package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Parent side — apne connected child ka fee status dikhata hai.
 * Student ki FeeActivity ko mirror karta hai, lekin data child ke uid se aata hai.
 * Child uid registrationId se resolve hota hai (role == "Student" filter zaroori,
 * kyunke Parent aur Student same registrationId share karte hain).
 */
public class ParentFeeActivity extends AppCompatActivity {

    private ImageView ivBack;
    private MaterialButton btnPayNow, btnViewChallan;
    private LinearLayout feeContainer, llHomeTab, llProfileTab;
    private TextView tvChildName, tvChildInfo, tvCurrentAmount, tvDueDateCurrent, tvFeeDueLabel;

    private String childRegId  = "";
    private String childUid     = null;
    private String childName    = "Student";
    private String childEmail   = "";
    private String dueAmountTotal = "0";   // fee + fine (jo pay karna hai)
    private String dueMonth       = "";
    private String challanMonth   = "";    // challan view ke liye month

    private final List<FeeItem> allFeeItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_fee);

        ivBack           = findViewById(R.id.ivBack);
        btnPayNow        = findViewById(R.id.btnPayNow);
        btnViewChallan   = findViewById(R.id.btnViewChallan);
        feeContainer     = findViewById(R.id.feeContainer);
        tvChildName      = findViewById(R.id.tvChildName);
        tvChildInfo      = findViewById(R.id.tvChildInfo);
        tvCurrentAmount  = findViewById(R.id.tvCurrentAmount);
        tvDueDateCurrent = findViewById(R.id.tvDueDateCurrent);
        tvFeeDueLabel    = findViewById(R.id.tvFeeDueLabel);

        // ── Bottom navigation (Home / Profile) — baaki parent screens jaisa ──
        llHomeTab    = findViewById(R.id.llHomeTab);
        llProfileTab = findViewById(R.id.llProfileTab);
        if (llHomeTab != null) {
            llHomeTab.setOnClickListener(v -> {
                startActivity(new Intent(this, ParentDashboardActivity.class));
                finish();
            });
        }
        if (llProfileTab != null) {
            llProfileTab.setOnClickListener(v ->
                    startActivity(new Intent(this, ParentProfileActivity.class)));
        }

        // registrationId — ParentDashboard "STUDENT_ID" ya "REGISTRATION_ID" bhejta hai
        childRegId = getIntent().getStringExtra("STUDENT_ID");
        if (childRegId == null) childRegId = getIntent().getStringExtra("REGISTRATION_ID");

        if (ivBack != null) ivBack.setOnClickListener(v -> finish());

        if (btnPayNow != null) {
            btnPayNow.setOnClickListener(v -> {
                if (childUid == null) {
                    Toast.makeText(this, "Fee data is Loading, Please Try Again...",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                if (dueAmountTotal == null || dueAmountTotal.equals("0") || dueAmountTotal.isEmpty()) {
                    Toast.makeText(this, "No Fee Pending",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                // Child ka fee data seedha PaymentActivity ko do (warna woh current-user ka data uthati)
                Intent intent = new Intent(this, PaymentActivity.class);
                intent.putExtra("fee_amount",    dueAmountTotal);
                intent.putExtra("student_name",  childName);
                intent.putExtra("student_email", childEmail);
                intent.putExtra("fee_month",     dueMonth);
                intent.putExtra("STUDENT_ID",    childRegId);
                intent.putExtra("target_uid",    childUid);   // child ke node par fee "Paid" ho
                startActivity(intent);
            });
        }

        if (btnViewChallan != null) {
            btnViewChallan.setOnClickListener(v -> {
                if (childUid == null) {
                    Toast.makeText(this, "Fee data load ho raha hai, thodi der baad try karein",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                if (challanMonth == null || challanMonth.isEmpty()) {
                    Toast.makeText(this, "Is student ka koi challan nahi mila",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent intent = new Intent(this, ParentFeeChallanActivity.class);
                intent.putExtra("child_uid", childUid);
                intent.putExtra("fee_month", challanMonth);
                startActivity(intent);
            });
        }

        if (childRegId == null || childRegId.isEmpty()) {
            Toast.makeText(this, "Error: Student ID not provided", Toast.LENGTH_LONG).show();
            return;
        }
        resolveChildUid();
    }

    /** registrationId → Student uid (role == "Student" filter ke saath) */
    private void resolveChildUid() {
        FirebaseDatabase.getInstance().getReference("Users")
                .orderByChild("registrationId").equalTo(childRegId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot child : snapshot.getChildren()) {
                            String role = child.child("role").getValue(String.class);
                            if (role != null && role.equalsIgnoreCase("Student")) {
                                childUid = child.getKey();

                                String name  = child.child("name").getValue(String.class);
                                String email = child.child("email").getValue(String.class);
                                String grade = child.child("className").getValue(String.class);
                                childName  = (name  != null) ? name  : "Student";
                                childEmail = (email != null) ? email : "";
                                if (tvChildName != null)
                                    tvChildName.setText(childName);
                                if (tvChildInfo != null) {
                                    String info = "ID: " + childRegId
                                            + (grade != null ? "   |   Class: " + grade : "");
                                    tvChildInfo.setText(info);
                                }
                                break; // pehla Student mil gaya
                            }
                        }

                        if (childUid == null) {
                            Toast.makeText(ParentFeeActivity.this,
                                    "Student record not found", Toast.LENGTH_LONG).show();
                            return;
                        }
                        loadFees();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {
                        Toast.makeText(ParentFeeActivity.this,
                                "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void loadFees() {
        FirebaseDatabase.getInstance().getReference("Fees").child(childUid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot feeSnap) {
                        allFeeItems.clear();
                        String latestUnpaidAmount  = "0";
                        String latestUnpaidFine    = "0";
                        String latestUnpaidDueDate = "-";
                        String latestUnpaidMonth   = "";
                        boolean foundUnpaid = false;

                        for (DataSnapshot snap : feeSnap.getChildren()) {
                            String month   = snap.child("month").getValue(String.class);
                            String amount  = snap.child("amount").getValue(String.class);
                            String dueDate = snap.child("dueDate").getValue(String.class);
                            String status  = snap.child("status").getValue(String.class);

                            String lateFine = snap.child("fineAmount").getValue(String.class);
                            if (lateFine == null) {
                                Object fineObj = snap.child("fineAmount").getValue();
                                if (fineObj != null) lateFine = fineObj.toString();
                            }

                            if (month == null) continue;

                            // ✅ Paid date/time — student side (FeeActivity) jaisa: "paidAt" (fallback "savedAt")
                            Long paidAt = snap.child("paidAt").getValue(Long.class);
                            if (paidAt == null) paidAt = snap.child("savedAt").getValue(Long.class);

                            String dispAmount   = (amount  != null) ? amount  : "0";
                            String dispDue      = (dueDate != null) ? dueDate : "-";
                            String dispStatus   = (status  != null) ? status  : "Unpaid";
                            String dispLateFine = (lateFine != null && !lateFine.trim().isEmpty()
                                    && !lateFine.equals("0")) ? lateFine : null;

                            if (!foundUnpaid && dispStatus.equalsIgnoreCase("Unpaid")) {
                                latestUnpaidAmount  = dispAmount;
                                latestUnpaidFine    = (dispLateFine != null) ? dispLateFine : "0";
                                latestUnpaidDueDate = dispDue;
                                latestUnpaidMonth   = month;
                                foundUnpaid = true;
                            }
                            allFeeItems.add(new FeeItem(month, dispAmount, dispDue, dispStatus, dispLateFine, paidAt));
                        }

                        if (tvDueDateCurrent != null)
                            tvDueDateCurrent.setText("Due Date: " + latestUnpaidDueDate);

                        if (foundUnpaid) {
                            // Display aur payment dono raw challan amount (dashboard jaisa)
                            if (tvCurrentAmount != null)
                                tvCurrentAmount.setText(latestUnpaidAmount + " PKR");
                            if (tvFeeDueLabel != null) {
                                long fine = parseLong(latestUnpaidFine);
                                tvFeeDueLabel.setText(fine > 0
                                        ? ("Includes late fine: " + fine + " PKR")
                                        : ("Fee for " + latestUnpaidMonth));
                            }
                            dueAmountTotal = latestUnpaidAmount;
                            dueMonth = latestUnpaidMonth;
                            challanMonth = latestUnpaidMonth;
                        } else {
                            if (tvFeeDueLabel != null) tvFeeDueLabel.setText("All fees cleared!");
                            if (tvCurrentAmount != null) tvCurrentAmount.setText("0 PKR");
                            dueAmountTotal = "0";
                            dueMonth = "";
                            // Sab paid — challan view ke liye latest record ka month
                            challanMonth = allFeeItems.isEmpty() ? "" : allFeeItems.get(0).month;
                        }

                        renderHistory(allFeeItems);
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    private void showCurrentDueBreakdown(String amountStr, String fineStr) {
        long fee  = parseLong(amountStr);
        long fine = parseLong(fineStr);
        long grandTotal = fee + fine;

        if (tvCurrentAmount != null) tvCurrentAmount.setText(grandTotal + " PKR");

        if (tvFeeDueLabel != null) {
            if (fine > 0) {
                tvFeeDueLabel.setText(
                        "Fee: " + fee + " PKR  +  Fine: " + fine + " PKR  =  " + grandTotal + " PKR");
            } else {
                tvFeeDueLabel.setText("Fee Due: " + fee + " PKR");
            }
        }
    }

    private void renderHistory(List<FeeItem> items) {
        if (feeContainer == null) return;
        feeContainer.removeAllViews();

        if (items.isEmpty()) {
            TextView tv = new TextView(this);
            tv.setText("No record found");
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, 50, 0, 50);
            feeContainer.addView(tv);
            return;
        }
        for (FeeItem item : items) addHistoryRow(item);
    }

    private void addHistoryRow(FeeItem item) {
        boolean isPaid = item.status.equalsIgnoreCase("Paid");
        float dp = getResources().getDisplayMetrics().density;

        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setPadding(0, 0, 0, (int)(4*dp));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding((int)(10*dp), (int)(15*dp), (int)(10*dp), (int)(15*dp));

        TextView tvMonth = new TextView(this);
        tvMonth.setText(item.month);
        tvMonth.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));

        long fee  = parseLong(item.amount);
        long fine = parseLong(item.lateFine);
        long total = fee + fine;

        TextView tvAmount = new TextView(this);
        tvAmount.setText(total + " PKR");
        tvAmount.setTypeface(null, Typeface.BOLD);
        tvAmount.setPadding(0, 0, (int)(10*dp), 0);

        TextView tvBadge = new TextView(this);
        tvBadge.setText(item.status);
        tvBadge.setTextColor(0xFFFFFFFF);
        tvBadge.setPadding((int)(10*dp), (int)(4*dp), (int)(10*dp), (int)(4*dp));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(isPaid ? 0xFF2E7D32 : 0xFFC62828);
        bg.setCornerRadius(5 * dp);
        tvBadge.setBackground(bg);

        row.addView(tvMonth);
        row.addView(tvAmount);
        row.addView(tvBadge);
        wrapper.addView(row);

        if (item.lateFine != null && fine > 0) {
            TextView tvBreakdown = new TextView(this);
            tvBreakdown.setText("Fee: " + fee + " PKR  +  Fine: " + fine + " PKR  =  " + total + " PKR");
            tvBreakdown.setTextColor(0xFFC62828);
            tvBreakdown.setTextSize(12f);
            tvBreakdown.setTypeface(null, Typeface.BOLD);
            tvBreakdown.setPadding((int)(10*dp), 0, (int)(10*dp), (int)(10*dp));
            wrapper.addView(tvBreakdown);
        }

        // ✅ Paid date/time — student side (FeeActivity) jaisa, sirf jab Firebase mein available ho
        if (item.paidAt != null && item.paidAt > 0) {
            TextView tvPaidDate = new TextView(this);
            String formatted = new java.text.SimpleDateFormat(
                    "dd MMM yyyy, hh:mm a", java.util.Locale.getDefault())
                    .format(new java.util.Date(item.paidAt));
            tvPaidDate.setText("Paid on: " + formatted);
            tvPaidDate.setTextColor(0xFF555555);
            tvPaidDate.setTextSize(12f);
            tvPaidDate.setPadding((int)(10*dp), 0, (int)(10*dp), (int)(6*dp));
            wrapper.addView(tvPaidDate);
        }

        feeContainer.addView(wrapper);
    }

    private long parseLong(String s) {
        if (s == null || s.trim().isEmpty()) return 0;
        try { return Long.parseLong(s.trim()); }
        catch (NumberFormatException e) { return 0; }
    }

    private static class FeeItem {
        String month, amount, dueDate, status, lateFine;
        Long paidAt;
        FeeItem(String m, String a, String d, String s, String lf, Long paidAt) {
            month = m; amount = a; dueDate = d; status = s; lateFine = lf; this.paidAt = paidAt;
        }
    }
}