package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class ParentFeedbackActivity extends AppCompatActivity {
    private EditText etFeedback;
    private RatingBar rbInput;
    private Button btnSubmit;
    private LinearLayout layoutSubmit, layoutAll, llHome, llProfile;
    private TextView tabSubmit, tabAll;
    private TextView tvOverallRatingDigit, tvTotalReviews;
    private RatingBar rbOverallStars;

    // RecyclerView Elements
    private RecyclerView rvFeedbacks;
    private ParentFeedbackAdapter adapter;
    private ArrayList<ParentFeedbackModel> feedbackList;

    // Firebase
    private DatabaseReference dbRef, userRef;
    private String currentParentName = "Parent";
    private String currentUid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_feedback);

        initViews();

        // 1. Initialize Firebase
        currentUid = FirebaseAuth.getInstance().getUid();
        dbRef = FirebaseDatabase.getInstance().getReference("Feedbacks").child("Parent");

        // 2. Setup RecyclerView
        feedbackList = new ArrayList<>();
        adapter = new ParentFeedbackAdapter(feedbackList);
        rvFeedbacks.setLayoutManager(new LinearLayoutManager(this));
        rvFeedbacks.setAdapter(adapter);

        // 3. Fetch current Parent Name for the feedback entry
        fetchParentName();

        // 4. Click Listeners


        btnSubmit.setOnClickListener(v -> submitFeedbackToFirebase());

        tabSubmit.setOnClickListener(v -> showSubmitTab());

        tabAll.setOnClickListener(v -> showAllFeedbackTab());

        // Bottom Nav Listeners
        llHome.setOnClickListener(v -> finish()); // Go back to Dashboard

        llProfile.setOnClickListener(v -> {
            startActivity(new Intent(ParentFeedbackActivity.this, ParentProfileActivity.class));
        });

        // 5. Load Data and Calculate Average
        loadRealtimeFeedbacks();
    }

    private void initViews() {
        layoutSubmit = findViewById(R.id.layoutSubmitFeedback);
        layoutAll = findViewById(R.id.layoutAllFeedback);
        etFeedback = findViewById(R.id.etFeedback);
        rbInput = findViewById(R.id.rbInput);
        btnSubmit = findViewById(R.id.btnSubmitFeedback);
        tabSubmit = findViewById(R.id.tabSubmit);
        tabAll = findViewById(R.id.tabAll);
        llHome = findViewById(R.id.llHomeTab);
        llProfile = findViewById(R.id.llProfileTab);
        rvFeedbacks = findViewById(R.id.rvFeedbacks);
        tvOverallRatingDigit = findViewById(R.id.tvOverallRatingDigit);
        tvTotalReviews = findViewById(R.id.tvTotalReviews);
        rbOverallStars = findViewById(R.id.rbOverallStars);
    }

    private void fetchParentName() {
        if (currentUid != null) {
            userRef = FirebaseDatabase.getInstance().getReference("Users").child(currentUid);
            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        String name = snapshot.child("name").getValue(String.class);
                        if (name != null) {
                            currentParentName = name;
                        }
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {}
            });
        }
    }

    private void submitFeedbackToFirebase() {
        String feedbackMsg = etFeedback.getText().toString().trim();
        float ratingValue = rbInput.getRating();
        String currentTime = new SimpleDateFormat("dd MMM yyyy | hh:mm a", Locale.getDefault()).format(new Date());

        if (feedbackMsg.isEmpty()) {
            Toast.makeText(this, "Please write your feedback first", Toast.LENGTH_SHORT).show();
            return;
        }

        if (ratingValue == 0) {
            Toast.makeText(this, "Please provide a star rating", Toast.LENGTH_SHORT).show();
            return;
        }

        String feedbackId = dbRef.push().getKey();
        ParentFeedbackModel feedbackModel = new ParentFeedbackModel(
                feedbackId,
                currentParentName,
                feedbackMsg,
                String.valueOf(ratingValue),
                currentTime
        );

        if (feedbackId != null) {
            dbRef.child(feedbackId).setValue(feedbackModel).addOnSuccessListener(aVoid -> {
                Toast.makeText(ParentFeedbackActivity.this, "Feedback Submitted Successfully!", Toast.LENGTH_SHORT).show();
                etFeedback.setText("");
                rbInput.setRating(0);
                showAllFeedbackTab(); // Switch to view results
            }).addOnFailureListener(e -> {
                Toast.makeText(ParentFeedbackActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void loadRealtimeFeedbacks() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                feedbackList.clear();
                float totalStars = 0;
                int totalCount = 0;

                for (DataSnapshot data : snapshot.getChildren()) {
                    ParentFeedbackModel model = data.getValue(ParentFeedbackModel.class);
                    if (model != null) {
                        feedbackList.add(0, model); // Add to top of list

                        try {
                            float rating = Float.parseFloat(model.getRating());
                            totalStars += rating;
                            totalCount++;
                        } catch (Exception ignored) {}
                    }
                }

                // Update the Average Rating Card
                if (totalCount > 0) {
                    float average = totalStars / totalCount;
                    tvOverallRatingDigit.setText(String.format(Locale.ENGLISH, "%.1f", average));
                    rbOverallStars.setRating(average);
                    tvTotalReviews.setText("Based on " + totalCount + " reviews");
                } else {
                    tvOverallRatingDigit.setText("0.0");
                    rbOverallStars.setRating(0);
                    tvTotalReviews.setText("No reviews yet");
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ParentFeedbackActivity.this, "Database Error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showSubmitTab() {
        layoutSubmit.setVisibility(View.VISIBLE);
        layoutAll.setVisibility(View.GONE);

        // Styling for Active Tab
        tabSubmit.setBackgroundResource(R.drawable.bg_gradient);
        tabSubmit.setTextColor(Color.WHITE);

        // Styling for Inactive Tab
        tabAll.setBackgroundResource(R.drawable.tab_right_outline);
        tabAll.setTextColor(Color.parseColor("#D50000"));
    }

    private void showAllFeedbackTab() {
        layoutSubmit.setVisibility(View.GONE);
        layoutAll.setVisibility(View.VISIBLE);

        // Styling for Active Tab
        tabAll.setBackgroundResource(R.drawable.bg_gradient);
        tabAll.setTextColor(Color.WHITE);

        // Styling for Inactive Tab
        tabSubmit.setBackgroundResource(R.drawable.tab_left_outline);
        tabSubmit.setTextColor(Color.parseColor("#D50000"));
    }
}