package com.example.kipscoachingkharian.dashboard;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.example.kipscoachingkharian.R;

public class ParentSettingActivity extends AppCompatActivity {

    private static final String PREFS_NAME    = "kips_prefs";
    private static final String KEY_FONT_SIZE = "parent_font_size";
    private static final String KEY_THEME     = "parent_theme";  // 0 = White, 1 = Black

    private ImageView btnBack;
    private LinearLayout itemFontSize, itemTheme, itemPrivacy;
    private TextView tvFontSizeValue, tvThemeValue;

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_setting);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        initViews();
        loadCurrentSettings();
        setListeners();
    }

    private void initViews() {
        btnBack         = findViewById(R.id.btnBack);
        itemFontSize    = findViewById(R.id.itemFontSize);
        itemTheme       = findViewById(R.id.itemTheme);
        itemPrivacy     = findViewById(R.id.itemPrivacy);
        tvFontSizeValue = findViewById(R.id.tvFontSizeValue);
        tvThemeValue    = findViewById(R.id.tvThemeValue);
    }

    private void loadCurrentSettings() {
        int fontSize = prefs.getInt(KEY_FONT_SIZE, 1);
        tvFontSizeValue.setText(fontSizeLabel(fontSize));

        int theme = prefs.getInt(KEY_THEME, 0);
        tvThemeValue.setText(theme == 1 ? "Black" : "White");
    }

    private String fontSizeLabel(int size) {
        switch (size) {
            case 0: return "Small";
            case 2: return "Large";
            default: return "Medium";
        }
    }

    private void setListeners() {
        btnBack.setOnClickListener(v -> finish());

        itemFontSize.setOnClickListener(v -> showFontSizeDialog());
        itemTheme.setOnClickListener(v -> showThemeDialog());
        itemPrivacy.setOnClickListener(v -> showPrivacyDialog());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // FONT SIZE DIALOG
    // ─────────────────────────────────────────────────────────────────────────
    private void showFontSizeDialog() {
        int savedSize = prefs.getInt(KEY_FONT_SIZE, 1);
        String[] options = {"Small", "Medium", "Large"};

        new AlertDialog.Builder(this)
                .setTitle("Font Size")
                .setSingleChoiceItems(options, savedSize, null)
                .setPositiveButton("Apply", (dialog, which) -> {
                    android.widget.ListView lv = ((AlertDialog) dialog).getListView();
                    int selected = lv.getCheckedItemPosition();
                    prefs.edit().putInt(KEY_FONT_SIZE, selected).apply();
                    tvFontSizeValue.setText(fontSizeLabel(selected));
                    Toast.makeText(this, "Font size updated!", Toast.LENGTH_SHORT).show();
                    recreate();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // THEME DIALOG
    // ─────────────────────────────────────────────────────────────────────────
    private void showThemeDialog() {
        int savedTheme = prefs.getInt(KEY_THEME, 0);
        String[] options = {"White", "Black"};

        new AlertDialog.Builder(this)
                .setTitle("Theme")
                .setSingleChoiceItems(options, savedTheme, null)
                .setPositiveButton("Apply", (dialog, which) -> {
                    android.widget.ListView lv = ((AlertDialog) dialog).getListView();
                    int selected = lv.getCheckedItemPosition();
                    prefs.edit().putInt(KEY_THEME, selected).apply();
                    tvThemeValue.setText(selected == 1 ? "Black" : "White");

                    AppCompatDelegate.setDefaultNightMode(
                            selected == 1
                                    ? AppCompatDelegate.MODE_NIGHT_YES
                                    : AppCompatDelegate.MODE_NIGHT_NO
                    );

                    Toast.makeText(this,
                            "Theme set to " + (selected == 1 ? "Black" : "White"),
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVACY DIALOG
    // ─────────────────────────────────────────────────────────────────────────
    private void showPrivacyDialog() {
        String privacyText =
                "Privacy Policy for Parents\n\n" +
                        "• Your personal information and your child's academic records are used solely " +
                        "for educational monitoring within the KIPS Coaching Kharian app and are never " +
                        "shared with unauthorized parties.\n\n" +
                        "• Your child's academic data, including  quiz results and progress " +
                        "reports, is strictly confidential and only visible to you, your child, and " +
                        "their assigned teachers.\n\n" +
                        "• Your account credentials and password are stored securely using industry-standard " +
                        "encryption and are never accessible to other users or staff.\n\n" +
                        "• We maintain a strict policy never to sell, trade, or transfer your or " +
                        "your child's personal information to any third party under any circumstances.\n\n" +
                        "• Fee payment details and financial history are processed securely and are " +
                        "accessible only to you and the institute's administration.\n\n" +
                        "• You have the right to update your contact information and manage your " +
                        "account details at any time through the My Profile section.\n\n" +
                        "• By using this app, you agree to the collection and use of information " +
                        "to facilitate your child's academic tracking as described in this policy.";


        new AlertDialog.Builder(this)
                .setTitle("Privacy Policy")
                .setMessage(privacyText)
                .setPositiveButton("OK", null)
                .show();
    }

    // ── Font Scale ────────────────────────────────────────────────────────────
    @Override
    protected void attachBaseContext(android.content.Context newBase) {
        SharedPreferences p = newBase.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int size = p.getInt(KEY_FONT_SIZE, 1);
        float scale;
        switch (size) {
            case 0: scale = 0.85f; break;
            case 2: scale = 1.15f; break;
            default: scale = 1.0f;
        }
        android.content.res.Configuration config = new android.content.res.Configuration();
        config.fontScale = scale;
        android.content.Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }
}