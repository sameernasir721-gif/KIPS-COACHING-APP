package com.example.kipscoachingkharian.dashboard;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

// FIXED: Using your app's correct R file
import com.example.kipscoachingkharian.R;

import java.util.List;

// FIXED: Renamed to SubjectAdaptor to match your file name
public class SubjectAdaptor extends RecyclerView.Adapter<SubjectAdaptor.SubjectViewHolder> {

    private final Context context;
    private final List<Subject> subjectList;
    private OnSubjectClickListener listener;

    // ── Interface for item click callback ────────────────────
    public interface OnSubjectClickListener {
        void onSubjectClick(Subject subject, int position);
    }

    // FIXED: Constructor name updated
    public SubjectAdaptor(Context context, List<Subject> subjectList) {
        this.context = context;
        this.subjectList = subjectList;
    }

    public void setOnSubjectClickListener(OnSubjectClickListener listener) {
        this.listener = listener;
    }

    // ── Inflate item layout ───────────────────────────────────
    @NonNull
    @Override
    public SubjectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_subject, parent, false);
        return new SubjectViewHolder(view);
    }

    // ── Bind data to each item ────────────────────────────────
    @Override
    public void onBindViewHolder(@NonNull SubjectViewHolder holder, int position) {
        Subject subject = subjectList.get(position);

        holder.tvSubjectName.setText(subject.getName());
        holder.tvTeacherName.setText("Teacher: " + subject.getTeacherName());
        holder.tvSchedule.setText(subject.getSchedule());
        holder.tvProgressPercent.setText(subject.getProgress() + "%");
        holder.progressBar.setProgress(subject.getProgress());

        // Set icon and its background
        holder.imgSubjectIcon.setImageResource(subject.getIconResId());
        holder.imgSubjectIcon.setBackgroundResource(subject.getIconBgResId());

        // Apply the subject-specific progress bar color
        holder.progressBar.setProgressTintList(
                ColorStateList.valueOf(ContextCompat.getColor(context, subject.getProgressColor()))
        );

        // Item click
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onSubjectClick(subject, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return subjectList.size();
    }

    // ── ViewHolder ────────────────────────────────────────────
    static class SubjectViewHolder extends RecyclerView.ViewHolder {

        ImageView imgSubjectIcon;
        TextView tvSubjectName;
        TextView tvTeacherName;
        TextView tvSchedule;
        ProgressBar progressBar;
        TextView tvProgressPercent;

        SubjectViewHolder(@NonNull View itemView) {
            super(itemView);
            imgSubjectIcon      = itemView.findViewById(R.id.imgSubjectIcon);
            tvSubjectName       = itemView.findViewById(R.id.tvSubjectName);
            tvTeacherName       = itemView.findViewById(R.id.tvTeacherName);
            tvSchedule          = itemView.findViewById(R.id.tvSchedule);
            progressBar         = itemView.findViewById(R.id.progressBar);
            tvProgressPercent   = itemView.findViewById(R.id.tvProgressPercent);
        }
    }
}