package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class ParentAnnouncementsActivity extends AppCompatActivity {

    private EditText etSearch;
    private LinearLayout containerAnnouncements;
    private ImageView ivBack;
    private LinearLayout llHomeTab, llProfileTab;

    private DatabaseReference mDatabase;
    private String myParentUid, myChildRegId;
    private SharedPreferences seenPrefs;
    private String seenKeysPrefKey;
    private String deletedKeysPrefKey;
    private static final String PREFS_NAME = "parent_notif_prefs";

    private final List<NotifItem> masterList = new ArrayList<>();

    static class NotifItem {
        String title, message, type, firebaseKey, targetRegId;
        long timestamp;

        NotifItem(String title, String message, String type, Long timestamp, String firebaseKey, String targetRegId) {
            this.title = title != null ? title : "";
            this.message = message != null ? message : "";
            this.type = type != null ? type : "";
            this.timestamp = timestamp != null ? timestamp : 0L;
            this.firebaseKey = firebaseKey;
            this.targetRegId = targetRegId;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_announcments);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) { finish(); return; }

        myParentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        seenPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        seenKeysPrefKey = "seen_keys_" + myParentUid;
        deletedKeysPrefKey = "deleted_keys_" + myParentUid;

        initViews();

        // STEP 1: پہلے اپنے بچے کی ID حاصل کریں
        fetchMyChildRegistrationId();
    }

    private void fetchMyChildRegistrationId() {
        mDatabase.child("Users").child(myParentUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        myChildRegId = snapshot.child("registrationId").getValue(String.class);
                        if (myChildRegId != null && !myChildRegId.isEmpty()) {
                            // STEP 2: اب اعلانات لوڈ کریں
                            fetchAnnouncements();
                        } else {
                            showEmptyState("No child linked to this account.");
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void fetchAnnouncements() {
        mDatabase.child("Announcements").child("Parents")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        masterList.clear();
                        for (DataSnapshot snap : snapshot.getChildren()) {
                            // فائر بیس سے ڈیٹا نکالنا
                            String targetId = snap.child("registrationId").getValue(String.class);

                            // صرف وہ میسج ایڈ کریں جو اس بچے کے لیے ہو یا سب کے لیے (General) ہو
                            if (targetId == null || targetId.isEmpty() || targetId.equals(myChildRegId)) {
                                masterList.add(new NotifItem(
                                        snap.child("title").getValue(String.class),
                                        snap.child("message").getValue(String.class),
                                        snap.child("type").getValue(String.class),
                                        snap.child("timestamp").getValue(Long.class),
                                        snap.getKey(),
                                        targetId
                                ));
                            }
                        }
                        Collections.sort(masterList, (a, b) -> Long.compare(b.timestamp, a.timestamp));
                        renderList("");
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void renderList(String query) {
        containerAnnouncements.removeAllViews();
        Set<String> seenKeys = new HashSet<>(seenPrefs.getStringSet(seenKeysPrefKey, new HashSet<>()));
        Set<String> deletedKeys = new HashSet<>(seenPrefs.getStringSet(deletedKeysPrefKey, new HashSet<>()));

        int shownCount = 0;
        for (NotifItem item : masterList) {
            if (deletedKeys.contains(item.firebaseKey)) continue;
            if (query.isEmpty() || item.title.toLowerCase().contains(query.toLowerCase())) {
                inflateView(item, !seenKeys.contains(item.firebaseKey));
                shownCount++;
            }
        }
        if (shownCount == 0) showEmptyState("No announcements for your child.");
    }

    private void inflateView(NotifItem item, boolean isNew) {
        View v = LayoutInflater.from(this).inflate(R.layout.item_parent_announcements, containerAnnouncements, false);
        TextView tvTitle = v.findViewById(R.id.tvAnnouncementTitle);
        TextView tvMsg = v.findViewById(R.id.tvAnnouncementMessage);
        TextView tvDate = v.findViewById(R.id.tvAnnouncementDate);
        TextView tvNew = v.findViewById(R.id.tvNewTag);

        tvTitle.setText(item.title);
        tvMsg.setText(item.message);
        if (item.timestamp > 0) {
            tvDate.setText(new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(new Date(item.timestamp)));
        }

        tvNew.setVisibility(isNew ? View.VISIBLE : View.GONE);

        v.setOnClickListener(view -> {
            if (isNew) {
                Set<String> updated = new HashSet<>(seenPrefs.getStringSet(seenKeysPrefKey, new HashSet<>()));
                updated.add(item.firebaseKey);
                seenPrefs.edit().putStringSet(seenKeysPrefKey, updated).apply();
                tvNew.setVisibility(View.GONE);
            }
            new AlertDialog.Builder(this).setTitle(item.title).setMessage(item.message).setPositiveButton("OK", null).show();
        });

        attachSwipeToDelete(v, item);
        containerAnnouncements.addView(v);
    }

    /**
     * Card ko horizontal swipe karne pe drag + fade animate karta hai; agar
     * swipe threshold se zyada ho to card animate ho ke gayab ho jata hai aur
     * uska firebaseKey "deleted" list mein save ho jata hai (taake dobara na
     * dikhe). Halke se swipe pe card wapas apni jagah snap ho jata hai.
     * Yeh bilkul wahi (student side wala) working tarika hai jo ScrollView ke
     * andar bhi reliably chalta hai — sirf clearly horizontal movement ko
     * swipe treat kiya jata hai, taake vertical scroll ke sath conflict na ho.
     */
    private void attachSwipeToDelete(final View itemView, final NotifItem item) {
        final float dp = getResources().getDisplayMetrics().density;
        final float dismissThreshold = 120 * dp;

        itemView.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private boolean swiping = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX();
                        downY = event.getRawY();
                        swiping = false;
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        return false; // click bhi kaam karta rahe

                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (!swiping && Math.abs(dx) > (12 * dp) && Math.abs(dx) > Math.abs(dy)) {
                            swiping = true;
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                        }
                        if (swiping) {
                            v.setTranslationX(dx);
                            v.setAlpha(Math.max(0.25f, 1f - (Math.abs(dx) / (600f * dp / 2f))));
                            return true;
                        }
                        return false;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (swiping) {
                            float finalDx = event.getRawX() - downX;
                            v.getParent().requestDisallowInterceptTouchEvent(false);
                            if (Math.abs(finalDx) > dismissThreshold) {
                                float target = finalDx > 0 ? v.getWidth() : -v.getWidth();
                                v.animate().translationX(target).alpha(0f).setDuration(200)
                                        .withEndAction(() -> dismissAnnouncement(item, v))
                                        .start();
                            } else {
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start();
                            }
                            swiping = false;
                            return true;
                        }
                        return false;
                }
                return false;
            }
        });
    }

    /**
     * Announcement ko permanently (is parent ke liye) hide kar deta hai —
     * firebaseKey ko "deleted" list mein save kar ke, list se remove karta hai.
     */
    private void dismissAnnouncement(NotifItem item, View v) {
        markDeletedLocally(item.firebaseKey);
        containerAnnouncements.removeView(v);
        masterList.remove(item);
        if (containerAnnouncements.getChildCount() == 0) {
            showEmptyState("No announcements for your child.");
        }
        Toast.makeText(ParentAnnouncementsActivity.this, "Announcement deleted", Toast.LENGTH_SHORT).show();
    }

    private void markDeletedLocally(String firebaseKey) {
        if (firebaseKey == null) return;
        Set<String> deleted = new HashSet<>(seenPrefs.getStringSet(deletedKeysPrefKey, new HashSet<>()));
        deleted.add(firebaseKey);
        seenPrefs.edit().putStringSet(deletedKeysPrefKey, deleted).apply();
    }

    private void initViews() {
        ivBack = findViewById(R.id.ivBack);
        etSearch = findViewById(R.id.etSearchAnnouncements);
        containerAnnouncements = findViewById(R.id.containerAnnouncements);
        llHomeTab = findViewById(R.id.llHomeTab);
        llProfileTab = findViewById(R.id.llProfileTab);
        if (ivBack != null) ivBack.setOnClickListener(v -> finish());
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
            @Override public void onTextChanged(CharSequence s, int i, int i1, int i2) { renderList(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });
        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        if (llHomeTab != null) llHomeTab.setOnClickListener(v -> finish());
        if (llProfileTab != null) llProfileTab.setOnClickListener(v -> {
            if (FirebaseAuth.getInstance().getCurrentUser() != null) {
                Intent intent = new Intent(ParentAnnouncementsActivity.this, ParentProfileActivity.class);
                intent.putExtra("STUDENT_ID", myChildRegId);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Please Login Again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showEmptyState(String msg) {
        containerAnnouncements.removeAllViews();
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setPadding(50, 150, 50, 50);
        tv.setGravity(android.view.Gravity.CENTER);
        containerAnnouncements.addView(tv);
    }
}