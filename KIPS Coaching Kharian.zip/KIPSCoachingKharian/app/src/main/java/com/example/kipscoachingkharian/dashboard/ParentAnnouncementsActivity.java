package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class ParentAnnouncementsActivity extends AppCompatActivity {

    private EditText etSearch;
    private LinearLayout containerAnnouncements;
    private ImageView ivBack;
    private LinearLayout llHomeTab, llProfileTab;

    private DatabaseReference mDatabase;
    private String myParentUid, myChildRegId;
    private SharedPreferences seenPrefs;
    private String seenKeysPrefKey;
    private String deletedKeysPrefKey;
    private static final String PREFS_NAME = "parent_notif_prefs";

    private final List<NotifItem> masterList = new ArrayList<>();

    static class NotifItem {
        String title, message, type, firebaseKey, targetRegId;
        long timestamp;

        NotifItem(String title, String message, String type, Long timestamp, String firebaseKey, String targetRegId) {
            this.title = title != null ? title : "";
            this.message = message != null ? message : "";
            this.type = type != null ? type : "";
            this.timestamp = timestamp != null ? timestamp : 0L;
            this.firebaseKey = firebaseKey;
            this.targetRegId = targetRegId;
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        NotificationBadgeHelper.setup(this);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_announcments);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) { finish(); return; }

        myParentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        seenPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        seenKeysPrefKey = "seen_keys_" + myParentUid;
        deletedKeysPrefKey = "deleted_keys_" + myParentUid;

        initViews();


        fetchMyChildRegistrationId();
    }

    private void fetchMyChildRegistrationId() {
        mDatabase.child("Users").child(myParentUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        myChildRegId = snapshot.child("registrationId").getValue(String.class);
                        if (myChildRegId != null && !myChildRegId.isEmpty()) {
                            fetchAnnouncements();
                        } else {
                            showEmptyState("No child linked to this account.");
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void fetchAnnouncements() {
        mDatabase.child("Announcements").child("Parents")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        masterList.clear();
                        for (DataSnapshot snap : snapshot.getChildren()) {

                            String targetId = snap.child("registrationId").getValue(String.class);
                            String type     = snap.child("type").getValue(String.class);


                            boolean isPersonalType = "fee_confirmation".equalsIgnoreCase(type);
                            boolean hasTarget = targetId != null && !targetId.isEmpty();

                            boolean shouldShow = hasTarget
                                    ? targetId.equals(myChildRegId)
                                    : !isPersonalType;

                            if (shouldShow) {
                                masterList.add(new NotifItem(
                                        snap.child("title").getValue(String.class),
                                        snap.child("message").getValue(String.class),
                                        type,
                                        snap.child("timestamp").getValue(Long.class),
                                        snap.getKey(),
                                        targetId
                                ));
                            }
                        }
                        Collections.sort(masterList, (a, b) -> Long.compare(b.timestamp, a.timestamp));
                        renderList("");
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void renderList(String query) {
        containerAnnouncements.removeAllViews();
        Set<String> seenKeys = new HashSet<>(seenPrefs.getStringSet(seenKeysPrefKey, new HashSet<>()));
        Set<String> deletedKeys = new HashSet<>(seenPrefs.getStringSet(deletedKeysPrefKey, new HashSet<>()));

        int shownCount = 0;
        for (NotifItem item : masterList) {
            if (deletedKeys.contains(item.firebaseKey)) continue;
            if (query.isEmpty() || item.title.toLowerCase().contains(query.toLowerCase())) {
                inflateView(item, !seenKeys.contains(item.firebaseKey));
                shownCount++;
            }
        }
        if (shownCount == 0) showEmptyState("No announcements for your child.");
    }

    private static final int DELETE_REVEAL_DP = 76;
    private Snackbar undoSnackbar = null;
    private View openedCard = null;

    private void inflateView(NotifItem item, boolean isNew) {

        FrameLayout row = new FrameLayout(this);
        row.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View v = LayoutInflater.from(this).inflate(R.layout.item_parent_announcements, row, false);


        FrameLayout deleteLayer = new FrameLayout(this);
        android.graphics.drawable.GradientDrawable redBg = new android.graphics.drawable.GradientDrawable();
        redBg.setColor(0xFFE53935);
        redBg.setCornerRadius(dpToPx(12));
        deleteLayer.setBackground(redBg);
        deleteLayer.setVisibility(View.INVISIBLE);   // visible only while the card is swiped
        FrameLayout.LayoutParams layerLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        if (v.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams cardLp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
            layerLp.setMargins(cardLp.leftMargin, cardLp.topMargin, cardLp.rightMargin, cardLp.bottomMargin);
        }
        row.addView(deleteLayer, layerLp);

        ImageView bin = new ImageView(this);
        bin.setImageResource(R.drawable.ic_delete_bin);
        bin.setContentDescription("Delete notification");
        int pad = dpToPx(24);
        bin.setPadding(pad, 0, pad, 0);
        deleteLayer.addView(bin, new FrameLayout.LayoutParams(
                dpToPx(DELETE_REVEAL_DP), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));

        row.addView(v);
        v.setTag(deleteLayer);

        TextView tvTitle = v.findViewById(R.id.tvAnnouncementTitle);
        TextView tvMsg = v.findViewById(R.id.tvAnnouncementMessage);
        TextView tvDate = v.findViewById(R.id.tvAnnouncementDate);
        TextView tvNew = v.findViewById(R.id.tvNewTag);

        tvTitle.setText(item.title);
        tvMsg.setText(item.message);
        if (item.timestamp > 0) {
            tvDate.setText(new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(new Date(item.timestamp)));
        }

        tvNew.setVisibility(isNew ? View.VISIBLE : View.GONE);

        v.setOnClickListener(view -> {

            if (view.getTranslationX() != 0f) {
                setCardOpen(view, false);
                return;
            }
            if (isNew) {
                Set<String> updated = new HashSet<>(seenPrefs.getStringSet(seenKeysPrefKey, new HashSet<>()));
                updated.add(item.firebaseKey);
                seenPrefs.edit().putStringSet(seenKeysPrefKey, updated).apply();
                tvNew.setVisibility(View.GONE);
            }
            new AlertDialog.Builder(this).setTitle(item.title).setMessage(item.message).setPositiveButton("OK", null).show();
        });


        bin.setOnClickListener(x -> deleteWithUndo(item, v));

        enableSwipeToReveal(v, deleteLayer);
        containerAnnouncements.addView(row);
    }


    private void enableSwipeToReveal(View card, View deleteLayer) {
        final int reveal = dpToPx(DELETE_REVEAL_DP);
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        final float[] down = new float[3];          // downX, downY, start translation
        final boolean[] swiping = {false};

        card.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = e.getRawX();
                    down[1] = e.getRawY();
                    down[2] = card.getTranslationX();
                    swiping[0] = false;
                    return false;

                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - down[0];
                    float dy = e.getRawY() - down[1];
                    if (!swiping[0]) {
                        // Only a clearly horizontal drag counts (so vertical scrolling still works)
                        if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                            swiping[0] = true;
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            v.setPressed(false);
                            if (openedCard != null && openedCard != card) setCardOpen(openedCard, false);
                        } else {
                            return false;
                        }
                    }
                    float tx = Math.max(-reveal, Math.min(0f, down[2] + dx));
                    card.setTranslationX(tx);
                    deleteLayer.setVisibility(tx < 0f ? View.VISIBLE : View.INVISIBLE);
                    return true;
                }

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (swiping[0]) {
                        swiping[0] = false;
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        setCardOpen(card, card.getTranslationX() < -reveal / 2f);
                        return true;
                    }
                    return false;
            }
            return false;
        });
    }

    private void setCardOpen(View card, boolean open) {
        final View layer = (View) card.getTag();
        if (layer != null && open) layer.setVisibility(View.VISIBLE);

        card.animate()
                .translationX(open ? -dpToPx(DELETE_REVEAL_DP) : 0f)
                .setDuration(160)
                .withEndAction(() -> {
                    if (!open && layer != null) layer.setVisibility(View.INVISIBLE);
                })
                .start();

        if (open) openedCard = card;
        else if (openedCard == card) openedCard = null;
    }

    /**
     * Deletes the notification (hidden for this parent on this device) and shows a short
     * Snackbar with UNDO. If UNDO is tapped within ~4 seconds the notification comes back.
     */
    private void deleteWithUndo(NotifItem item, View card) {
        openedCard = null;
        markDeletedLocally(item.firebaseKey);

        card.animate()
                .translationX(-card.getWidth())
                .alpha(0f)
                .setDuration(180)
                .withEndAction(() -> renderList(etSearch.getText().toString()))
                .start();

        showUndoSnackbar(item);
    }

    private void showUndoSnackbar(NotifItem item) {
        // Close the previous snackbar so multiple deletes don't stack/queue
        if (undoSnackbar != null && undoSnackbar.isShown()) undoSnackbar.dismiss();

        View root = findViewById(android.R.id.content);
        Snackbar bar = Snackbar.make(root, "Notification deleted", 4000)
                .setAction("UNDO", x -> restoreAnnouncement(item));
        undoSnackbar = bar;

        View sbView = bar.getView();
        sbView.setBackgroundResource(R.drawable.bg_snackbar_undo);

        ViewGroup.LayoutParams lp = sbView.getLayoutParams();
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) lp;
            int side = dpToPx(16);
            mlp.leftMargin = side;
            mlp.rightMargin = side;
            mlp.bottomMargin = dpToPx(12);
            sbView.setLayoutParams(mlp);
        }
        sbView.setElevation(dpToPx(12));

        TextView tvText = sbView.findViewById(
                getResources().getIdentifier("snackbar_text", "id", getPackageName()));
        if (tvText != null) {
            tvText.setTextColor(0xFF000000);
            tvText.setTextSize(15f);
            tvText.setTypeface(tvText.getTypeface(), android.graphics.Typeface.BOLD);
            tvText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_delete_bin, 0, 0, 0);
            tvText.setCompoundDrawablePadding(dpToPx(10));
            tvText.setCompoundDrawableTintList(android.content.res.ColorStateList.valueOf(0xFF000000));
        }
        bar.setActionTextColor(0xFFEF5350);
        TextView tvAction = sbView.findViewById(
                getResources().getIdentifier("snackbar_action", "id", getPackageName()));
        if (tvAction != null) {
            tvAction.setTextSize(14f);
            tvAction.setTypeface(tvAction.getTypeface(), android.graphics.Typeface.BOLD);
        }

        View bottomBar = findViewById(R.id.bottomNavigationView);
        if (bottomBar != null) bar.setAnchorView(bottomBar);
        bar.show();
    }

    private void restoreAnnouncement(NotifItem item) {
        if (item.firebaseKey != null) {
            Set<String> deleted = new HashSet<>(seenPrefs.getStringSet(deletedKeysPrefKey, new HashSet<>()));
            deleted.remove(item.firebaseKey);
            seenPrefs.edit().putStringSet(deletedKeysPrefKey, deleted).apply();
        }
        renderList(etSearch.getText().toString());
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private void markDeletedLocally(String firebaseKey) {
        if (firebaseKey == null) return;
        Set<String> deleted = new HashSet<>(seenPrefs.getStringSet(deletedKeysPrefKey, new HashSet<>()));
        deleted.add(firebaseKey);
        seenPrefs.edit().putStringSet(deletedKeysPrefKey, deleted).apply();
    }

    private void initViews() {
        ivBack = findViewById(R.id.ivBack);
        etSearch = findViewById(R.id.etSearchAnnouncements);
        containerAnnouncements = findViewById(R.id.containerAnnouncements);
        llHomeTab = findViewById(R.id.llHomeTab);
        llProfileTab = findViewById(R.id.llProfileTab);
        if (ivBack != null) ivBack.setOnClickListener(v -> finish());
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
            @Override public void onTextChanged(CharSequence s, int i, int i1, int i2) { renderList(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });
        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        if (llHomeTab != null) llHomeTab.setOnClickListener(v -> finish());
        if (llProfileTab != null) llProfileTab.setOnClickListener(v -> {
            if (FirebaseAuth.getInstance().getCurrentUser() != null) {
                Intent intent = new Intent(ParentAnnouncementsActivity.this, ParentProfileActivity.class);
                intent.putExtra("STUDENT_ID", myChildRegId);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Please Login Again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showEmptyState(String msg) {
        containerAnnouncements.removeAllViews();
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setPadding(50, 150, 50, 50);
        tv.setGravity(Gravity.CENTER);
        containerAnnouncements.addView(tv);
    }
}