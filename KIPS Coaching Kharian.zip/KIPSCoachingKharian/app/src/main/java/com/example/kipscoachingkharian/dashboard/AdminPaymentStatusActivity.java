package com.example.kipscoachingkharian.dashboard;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminPaymentStatusActivity extends AppCompatActivity {

    private LinearLayout containerPayments;
    private TextView tvSummaryHeader;
    private ImageView btnBack;
    private DatabaseReference usersRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_payment_status);

        // System Default Action Bar hiding layer safety
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // XML bindings configuration
        btnBack = findViewById(R.id.btnPaymentBack);
        tvSummaryHeader = findViewById(R.id.tvPaymentSummaryHeader);
        containerPayments = findViewById(R.id.containerAdminPayments);

        // 🔥 BACK CLICK LISTENERS LOGIC
        btnBack.setOnClickListener(v -> {
            finish(); // Yeh back activity par direct pop/return kar dega
        });

        // Main database tracking integration setup
        usersRef = FirebaseDatabase.getInstance().getReference("Users");

        fetchStudentPaymentRecords();
    }

    private void fetchStudentPaymentRecords() {
        usersRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (containerPayments == null) return;
                containerPayments.removeAllViews(); // View re-write cleaner

                if (!snapshot.exists()) {
                    tvSummaryHeader.setText("No Records Active");
                    return;
                }

                int totalPaidCount = 0;
                int totalPendingCount = 0;

                for (DataSnapshot studentSnap : snapshot.getChildren()) {
                    try {
                        String role = studentSnap.child("role").getValue(String.class);

                        // 🔥 FIX 1: Firebase check — Database me "Student" ya "Students" dono me se kuch bhi ho, accept karega
                        if (role == null || (!role.equalsIgnoreCase("Student") && !role.equalsIgnoreCase("Students"))) {
                            continue; // Direct filter non-students records out
                        }

                        String name = studentSnap.child("name").getValue(String.class);
                        String className = studentSnap.child("className").getValue(String.class);

                        if (name == null) name = "Unknown Student";
                        if (className == null) className = "N/A";

                        String feeStatus = studentSnap.child("feeStatus").getValue(String.class);
                        String amount = studentSnap.child("feeAmount").getValue(String.class);

                        // Fallbacks description mapping
                        if (feeStatus == null || feeStatus.trim().isEmpty()) {
                            feeStatus = "Pending";
                        }
                        if (amount == null || amount.trim().isEmpty()) {
                            amount = "0";
                        }

                        // 🔥 FIX 2: Safe Equals Trim Check for upper/lower case variance
                        if (feeStatus.trim().equalsIgnoreCase("Paid")) {
                            totalPaidCount++;
                        } else {
                            totalPendingCount++;
                        }

                        addPaymentRowCard(name, className, amount, feeStatus.trim());

                    } catch (Exception e) {
                        Log.e("AdminPayment", "Row print exception: " + e.getMessage());
                    }
                }

                // Header metadata values updater engine
                tvSummaryHeader.setText("🟢 Total Paid: " + totalPaidCount + "  |  🔴 Total Pending: " + totalPendingCount);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AdminPaymentStatusActivity.this, "DB Cancelled: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addPaymentRowCard(String name, String className, String amount, String status) {
        // Direct View Injection without standard adapters
        View v = LayoutInflater.from(this).inflate(R.layout.item_admin_payment, containerPayments, false);

        TextView tvName   = v.findViewById(R.id.tvAdminStudentName);
        TextView tvClass  = v.findViewById(R.id.tvAdminStudentClass);
        TextView tvAmount = v.findViewById(R.id.tvAdminPaymentAmount);
        TextView tvStatus = v.findViewById(R.id.tvAdminPaymentStatus);

        if (tvName != null) tvName.setText(name);
        if (tvClass != null) tvClass.setText("Class: " + className);
        if (tvAmount != null) tvAmount.setText("Rs. " + amount);

        if (tvStatus != null) {
            tvStatus.setText(status.toUpperCase());

            // Color badge engine injection styling properties
            if (status.equalsIgnoreCase("Paid")) {
                tvStatus.setTextColor(Color.parseColor("#2E7D32"));
                tvStatus.setBackgroundColor(Color.parseColor("#E8F5E9"));
            } else {
                tvStatus.setTextColor(Color.parseColor("#C62828"));
                tvStatus.setBackgroundColor(Color.parseColor("#FFEBEE"));
            }
        }

        containerPayments.addView(v);
    }
}