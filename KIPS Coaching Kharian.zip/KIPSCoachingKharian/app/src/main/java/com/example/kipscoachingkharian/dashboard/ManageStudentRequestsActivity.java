package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ManageStudentRequestsActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private LinearLayout containerRequests;
    private TextView tvLoading;
    private View ivBack;

    private String currentFilter = "Pending";
    private List<DataSnapshot> allStudentsList = new ArrayList<>();
    private int totalCount = 0, pendingCount = 0, approvedCount = 0, rejectedCount = 0;

    private static final int SECTION_CAPACITY = 10;

    // Real-time listener (replaces the refresh button)
    private ValueEventListener usersListener;

    // Pull down to refresh
    private SwipeRefreshLayout swipeRefresh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.example.kipscoachingkharian.R.layout.activity_manage_students_requests);

        mDatabase         = FirebaseDatabase.getInstance().getReference();
        containerRequests = findViewById(com.example.kipscoachingkharian.R.id.containerStudentRequests);
        tvLoading         = findViewById(com.example.kipscoachingkharian.R.id.tvStudentLoading);

        setupBackButton();
        setupPullToRefresh();
        fetchData();
    }

    // Header ka back arrow + phone ka system back button / gesture
    private void setupBackButton() {
        ivBack = findViewById(com.example.kipscoachingkharian.R.id.ivBack);
        if (ivBack != null) {
            ivBack.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());
        }

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // Refresh chal raha ho toh pehle usay roko
                if (swipeRefresh != null && swipeRefresh.isRefreshing()) {
                    swipeRefresh.setRefreshing(false);
                }
                setEnabled(false);
                getOnBackPressedDispatcher().onBackPressed(); // phir screen band
            }
        });
    }

    // Wraps the ScrollView in a SwipeRefreshLayout from code (no XML change needed)
    private void setupPullToRefresh() {
        View scroll = containerRequests;
        while (scroll != null && !(scroll instanceof ScrollView) && !(scroll instanceof NestedScrollView)) {
            ViewParent p = scroll.getParent();
            scroll = (p instanceof View) ? (View) p : null;
        }
        if (scroll == null || !(scroll.getParent() instanceof ViewGroup)) return;

        ViewGroup parent = (ViewGroup) scroll.getParent();
        int index = parent.indexOfChild(scroll);
        ViewGroup.LayoutParams lp = scroll.getLayoutParams();
        int oldId = scroll.getId();

        parent.removeView(scroll);
        scroll.setId(View.generateViewId());

        swipeRefresh = new SwipeRefreshLayout(this);
        swipeRefresh.setId(oldId);
        swipeRefresh.setColorSchemeColors(0xFF1565C0);
        swipeRefresh.addView(scroll, new ViewGroup.LayoutParams(-1, -1));
        parent.addView(swipeRefresh, index, lp);

        swipeRefresh.setOnRefreshListener(() -> {
            // Remove the old listener and load fresh data
            if (usersListener != null) {
                mDatabase.child("Users").removeEventListener(usersListener);
                usersListener = null;
            }
            fetchData();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (usersListener != null) {
            mDatabase.child("Users").removeEventListener(usersListener);
        }
    }

    private void fetchData() {
        if (tvLoading != null) tvLoading.setVisibility(View.VISIBLE);

        // Don't attach the listener twice
        if (usersListener != null) return;

        usersListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                allStudentsList.clear();
                totalCount = 0; pendingCount = 0; approvedCount = 0; rejectedCount = 0;

                for (DataSnapshot userSnap : snapshot.getChildren()) {
                    String role = userSnap.child("role").getValue(String.class);
                    if (role == null || !"Student".equalsIgnoreCase(role)) continue;

                    // Hide test accounts
                    if (isTestAccount(userSnap)) continue;

                    String status = userSnap.child("status").getValue(String.class);
                    if (status == null) status = "Pending";

                    totalCount++;
                    if (status.equalsIgnoreCase("Pending"))       pendingCount++;
                    else if (status.equalsIgnoreCase("Approved")) approvedCount++;
                    else if (status.equalsIgnoreCase("Rejected")) rejectedCount++;

                    allStudentsList.add(userSnap);
                }

                // Approved first, then Pending, then Rejected.
                // Inside each group: numeric order of registrationId (highest / latest on top).
                Collections.sort(allStudentsList, (a, b) -> {
                    int ra = statusRank(a.child("status").getValue(String.class));
                    int rb = statusRank(b.child("status").getValue(String.class));
                    if (ra != rb) return Integer.compare(ra, rb);

                    long na = extractNumber(a.child("registrationId").getValue(String.class));
                    long nb = extractNumber(b.child("registrationId").getValue(String.class));
                    boolean hasA = na != Long.MAX_VALUE;
                    boolean hasB = nb != Long.MAX_VALUE;
                    if (hasA != hasB) return hasA ? -1 : 1; // no number -> last
                    if (hasA) return Long.compare(nb, na);  // 10 above 2
                    return 0;
                });

                updateUI();
                if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (tvLoading != null) tvLoading.setVisibility(View.GONE);
                if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
            }
        };

        mDatabase.child("Users").addValueEventListener(usersListener);
    }

    private int statusRank(String status) {
        if (status == null) return 1;                       // Pending
        if (status.equalsIgnoreCase("Approved")) return 0;
        if (status.equalsIgnoreCase("Pending"))  return 1;
        return 2;                                           // Rejected
    }

    // "student012" -> 12,  "45" -> 45,  null / no digits -> Long.MAX_VALUE
    private long extractNumber(String s) {
        if (s == null) return Long.MAX_VALUE;
        Matcher m = Pattern.compile("\\d+").matcher(s);
        if (m.find()) {
            String digits = m.group();
            if (digits.length() > 18) digits = digits.substring(0, 18);
            try {
                return Long.parseLong(digits);
            } catch (NumberFormatException ignored) { }
        }
        return Long.MAX_VALUE;
    }

    private boolean isTestAccount(DataSnapshot userSnap) {
        String name  = userSnap.child("name").getValue(String.class);
        String email = userSnap.child("email").getValue(String.class);
        return (name != null && name.toLowerCase().contains("test"))
                || (email != null && email.toLowerCase().contains("test"));
    }

    private void updateUI() {
        containerRequests.removeAllViews();
        if (tvLoading != null) tvLoading.setVisibility(View.GONE);

        addSummaryCards();

        String headerTitle = currentFilter.equals("Total") ? "All Students" : currentFilter + " Requests";
        containerRequests.addView(makeSectionHeader(headerTitle, getHeaderColor(currentFilter)));

        boolean hasData = false;
        for (DataSnapshot userSnap : allStudentsList) {
            String status = userSnap.child("status").getValue(String.class);
            if (status == null) status = "Pending";
            if (!currentFilter.equals("Total") && !status.equalsIgnoreCase(currentFilter)) continue;

            hasData = true;
            String uid    = userSnap.getKey();
            String name   = userSnap.child("name").getValue(String.class);
            String email  = userSnap.child("email").getValue(String.class);
            String cls    = userSnap.child("className").getValue(String.class);
            String role   = userSnap.child("role").getValue(String.class);

            Object phoneObj = userSnap.child("phone").getValue();
            if (phoneObj == null) phoneObj = userSnap.child("phoneNumber").getValue();
            String phone = phoneObj != null ? String.valueOf(phoneObj).trim() : "N/A";

            String rejectionReason = userSnap.child("rejectionReason").getValue(String.class);

            Boolean emailVerifiedObj = userSnap.child("emailVerified").getValue(Boolean.class);
            boolean emailVerified = emailVerifiedObj != null && emailVerifiedObj;

            containerRequests.addView(makeStudentCard(uid, name, phone, email, cls,
                    getSubjects(userSnap), status, role, rejectionReason, emailVerified));
        }
        if (!hasData) showEmpty("No " + currentFilter.toLowerCase() + " records found.");
    }

    private void showRejectionReasonDialog(String name, String reason) {
        String displayReason = (reason != null && !reason.trim().isEmpty())
                ? reason : "Documentation incomplete or criteria not met.";

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(20), dp(24), dp(16));

        TextView tvTitle = new TextView(this);
        tvTitle.setText("❌  Request Rejected");
        tvTitle.setTextSize(17f);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setTextColor(0xFFB71C1C);
        tvTitle.setPadding(0, 0, 0, dp(8));
        layout.addView(tvTitle);

        TextView tvName = new TextView(this);
        tvName.setText("Student: " + (name != null ? name : "-"));
        tvName.setTextSize(14f);
        tvName.setTextColor(0xFF555555);
        tvName.setPadding(0, 0, 0, dp(12));
        layout.addView(tvName);

        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        divider.setBackgroundColor(0xFFEEEEEE);
        layout.addView(divider);

        TextView tvReasonLabel = new TextView(this);
        tvReasonLabel.setText("Reason for Rejection:");
        tvReasonLabel.setTextSize(13f);
        tvReasonLabel.setTextColor(0xFF888888);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-1, -2);
        llp.topMargin = dp(12);
        llp.bottomMargin = dp(6);
        tvReasonLabel.setLayoutParams(llp);
        layout.addView(tvReasonLabel);

        TextView tvReason = new TextView(this);
        tvReason.setText(displayReason);
        tvReason.setTextSize(15f);
        tvReason.setTextColor(0xFFB71C1C);
        tvReason.setTypeface(null, Typeface.BOLD);
        tvReason.setPadding(dp(14), dp(12), dp(14), dp(12));
        tvReason.setBackgroundColor(0xFFFFEBEE);
        tvReason.setLineSpacing(dp(4), 1f);
        layout.addView(tvReason);

        new AlertDialog.Builder(this)
                .setView(layout)
                .setPositiveButton("OK", null)
                .show();
    }

    private void fetchReasonAndShow(String uid, String name) {
        mDatabase.child("Users").child(uid).child("rejectionReason")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String freshReason = snapshot.getValue(String.class);
                        showRejectionReasonDialog(name, freshReason);
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        showRejectionReasonDialog(name, null);
                    }
                });
    }

    private View makeStudentCard(String uid, String name, String phone, String email, String cls,
                                 String subjects, String status, String role, String rejectionReason,
                                 boolean emailVerified) {

        int cardBg;
        switch (status.toLowerCase()) {
            case "approved": cardBg = 0xFFF1FFF1; break;
            case "rejected": cardBg = 0xFFFFF1F1; break;
            default:         cardBg = 0xFFFFFFFF; break;
        }

        androidx.cardview.widget.CardView card = new androidx.cardview.widget.CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(cp);
        card.setRadius(dp(12));
        card.setCardElevation(dp(3));
        card.setCardBackgroundColor(cardBg);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(14), dp(14), dp(14), dp(14));

        TextView tvName = new TextView(this);
        tvName.setText(name != null ? name : "-");
        tvName.setTextSize(16f);
        tvName.setTypeface(null, Typeface.BOLD);
        tvName.setTextColor(0xFF1565C0);
        inner.addView(tvName);

        addInfoRow(inner, "👤 Role",     role);
        addInfoRow(inner, "📞 Phone",    phone);
        addInfoRow(inner, "📧 Email",    email);
        addInfoRow(inner, "✅ Email Status", emailVerified ? "Verified" : "Not Verified Yet");
        addInfoRow(inner, "🏫 Class",    cls);
        addInfoRow(inner, "📚 Subjects", subjects);

        if (status.equalsIgnoreCase("Rejected")) {
            TextView tvBanner = new TextView(this);
            tvBanner.setText("❌ Rejected — Tap to see reason");
            tvBanner.setTextSize(13f);
            tvBanner.setTextColor(0xFFB71C1C);
            tvBanner.setTypeface(null, Typeface.BOLD);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.topMargin = dp(10);
            tvBanner.setLayoutParams(rp);
            tvBanner.setPadding(dp(10), dp(10), dp(10), dp(10));
            tvBanner.setBackgroundColor(0xFFFFEBEE);

            tvBanner.setOnClickListener(v -> fetchReasonAndShow(uid, name));
            card.setOnClickListener(v    -> fetchReasonAndShow(uid, name));

            inner.addView(tvBanner);
        }

        if (status.equalsIgnoreCase("Pending")) {
            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setPadding(0, dp(10), 0, 0);

            Button btnApprove = new Button(this);
            btnApprove.setText("✅ Approve");
            btnApprove.setBackgroundColor(0xFF388E3C);
            btnApprove.setTextColor(0xFFFFFFFF);
            LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, -2, 1f);
            p1.setMarginEnd(dp(5));
            btnApprove.setLayoutParams(p1);
            // Grey button if the email is not verified
            if (!emailVerified) {
                btnApprove.setBackgroundColor(0xFF9E9E9E);
            }
            btnApprove.setOnClickListener(v -> {
                if (!emailVerified) {
                    new AlertDialog.Builder(this)
                            .setTitle("Email Not Verified")
                            .setMessage((name != null ? name : "This student")
                                    + " has not verified their email (" + email + ") yet. "
                                    + "The request cannot be approved until the email is verified. "
                                    + "Ask the student to verify their email, then pull down to refresh the list.")
                            .setPositiveButton("OK", null)
                            .show();
                } else {
                    startAutoApproval(uid, name, email, cls);
                }
            });

            Button btnReject = new Button(this);
            btnReject.setText("❌ Reject");
            btnReject.setBackgroundColor(0xFFB71C1C);
            btnReject.setTextColor(0xFFFFFFFF);
            btnReject.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
            btnReject.setOnClickListener(v -> promptReject(uid, name, email));

            btnRow.addView(btnApprove);
            btnRow.addView(btnReject);
            inner.addView(btnRow);
        }

        card.addView(inner);
        return card;
    }

    private void startAutoApproval(String uid, String name, String email, String className) {
        String classDigit = className != null ? className.replaceAll("[^0-9]", "") : "9";
        if (classDigit.isEmpty()) classDigit = "9";
        final String finalClassDigit = classDigit;
        checkSectionCapacity(finalClassDigit, "A", uid, name, email);
    }

    private void checkSectionCapacity(String classDigit, String section,
                                      String uid, String name, String email) {
        mDatabase.child("Users")
                .orderByChild("className").equalTo(classDigit + section)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.getChildrenCount() < SECTION_CAPACITY) {
                            generateStudentIdAndSave(uid, name, email, section, classDigit + section);
                        } else {
                            char next = (char) (section.charAt(0) + 1);
                            checkSectionCapacity(classDigit, String.valueOf(next), uid, name, email);
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void generateStudentIdAndSave(String uid, String name, String email,
                                          String section, String formattedClass) {
        mDatabase.child("Metadata").child("studentCounter")
                .runTransaction(new Transaction.Handler() {
                    @NonNull @Override
                    public Transaction.Result doTransaction(@NonNull MutableData d) {
                        Long v = d.getValue(Long.class);
                        d.setValue(v == null ? 1 : v + 1);
                        return Transaction.success(d);
                    }
                    @Override
                    public void onComplete(DatabaseError error, boolean committed, DataSnapshot snap) {
                        if (committed) {
                            String uniqueId = "student" + String.format("%03d", (long) snap.getValue());
                            saveData(uid, name, email, section, formattedClass, uniqueId);
                        }
                    }
                });
    }

    private void saveData(String uid, String name, String email,
                          String section, String formattedClass, String id) {
        Map<String, Object> map = new HashMap<>();
        map.put("status", "Approved");
        map.put("registrationId", id);
        map.put("assignedSection", section);
        map.put("className", formattedClass);

        mDatabase.child("Users").child(uid).updateChildren(map)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this,
                            name + " Approved — Section " + section, Toast.LENGTH_SHORT).show();
                    sendMail(email, "Approved",
                            "Welcome " + name + "! Your ID is " + id
                                    + " and you are assigned to Class " + formattedClass);

                    WalletBonusHelper.creditWelcomeBonus(uid, name);

                    // ✅ NEW: approve hote hi is mahine ka fee challan auto generate
                    FeeChallanHelper.generateOnApproval(uid);

                    // No need to call fetchData(): the listener updates the list automatically
                });
    }

    private void promptReject(String uid, String name, String email) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(16), dp(24), dp(8));

        EditText input = new EditText(this);
        input.setHint("Enter reason for rejection...");
        input.setMinLines(2);
        layout.addView(input);

        new AlertDialog.Builder(this)
                .setTitle("Reject Request")
                .setView(layout)
                .setPositiveButton("Reject & Send Mail", (dialog, which) -> {
                    String reason = input.getText().toString().trim();
                    if (reason.isEmpty()) reason = "Documentation incomplete or criteria not met.";
                    final String finalReason = reason;

                    Map<String, Object> rejectMap = new HashMap<>();
                    rejectMap.put("status", "Rejected");
                    rejectMap.put("rejectionReason", finalReason);

                    mDatabase.child("Users").child(uid).updateChildren(rejectMap)
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(this,
                                        name + " Rejected.", Toast.LENGTH_SHORT).show();
                                sendMail(email, "Rejected",
                                        "Dear " + name + ",\nYour request has been rejected.\nReason: "
                                                + finalReason);
                                // No need to call fetchData(): the listener updates the list automatically
                            });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void sendMail(String email, String status, String message) {
        if (email == null || email.equals("-")) return;
        Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL,   new String[]{email});
        intent.putExtra(Intent.EXTRA_SUBJECT, "Registration " + status + " - KIPS");
        intent.putExtra(Intent.EXTRA_TEXT,    message);
        try { startActivity(Intent.createChooser(intent, "Send Email...")); } catch (Exception ignored) {}
    }

    private void addSummaryCards() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(makeSummaryCard("Total",    totalCount,    0xFF1565C0, 0xFFE3F2FD));
        row.addView(makeSummaryCard("Pending",  pendingCount,  0xFFE65100, 0xFFFFF3E0));
        row.addView(makeSummaryCard("Approved", approvedCount, 0xFF2E7D32, 0xFFE8F5E9));
        row.addView(makeSummaryCard("Rejected", rejectedCount, 0xFFB71C1C, 0xFFFFEBEE));
        containerRequests.addView(row);
    }

    private View makeSummaryCard(String label, int count, int textColor, int bgColor) {
        androidx.cardview.widget.CardView card = new androidx.cardview.widget.CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
        cp.setMargins(dp(2), 0, dp(2), dp(10));
        card.setLayoutParams(cp);
        card.setRadius(dp(8));
        card.setCardBackgroundColor(bgColor);
        if (currentFilter.equalsIgnoreCase(label)) card.setCardElevation(dp(8));

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(5), dp(10), dp(5), dp(10));
        inner.setGravity(Gravity.CENTER);

        TextView tvNum = new TextView(this);
        tvNum.setText(String.valueOf(count));
        tvNum.setTextSize(18f);
        tvNum.setTextColor(textColor);
        tvNum.setTypeface(null, Typeface.BOLD);

        TextView tvLbl = new TextView(this);
        tvLbl.setText(label);
        tvLbl.setTextSize(10f);
        tvLbl.setTextColor(textColor);

        inner.addView(tvNum);
        inner.addView(tvLbl);
        card.addView(inner);
        card.setOnClickListener(v -> { currentFilter = label; updateUI(); });
        return card;
    }

    private void addInfoRow(LinearLayout parent, String label, String value) {
        TextView tv = new TextView(this);
        tv.setText(label + ": " + (value != null ? value : "-"));
        tv.setTextSize(13f);
        tv.setPadding(0, dp(2), 0, 0);
        parent.addView(tv);
    }

    private View makeSectionHeader(String title, int color) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(15f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(color);
        tv.setPadding(0, dp(10), 0, dp(10));
        return tv;
    }

    private String getSubjects(DataSnapshot snap) {
        DataSnapshot subsSnap = snap.child("enrolledSubjects");
        if (!subsSnap.exists()) return "None";
        List<String> list = new ArrayList<>();
        for (DataSnapshot s : subsSnap.getChildren()) {
            String sub = s.getValue(String.class);
            if (sub != null) list.add(sub);
        }
        return list.isEmpty() ? "None" : TextUtils.join(", ", list);
    }

    private int getHeaderColor(String status) {
        if (status.equalsIgnoreCase("Pending"))  return 0xFFE65100;
        if (status.equalsIgnoreCase("Approved")) return 0xFF2E7D32;
        if (status.equalsIgnoreCase("Rejected")) return 0xFFB71C1C;
        return 0xFF1565C0;
    }

    private void showEmpty(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(50), 0, 0);
        containerRequests.addView(tv);
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}