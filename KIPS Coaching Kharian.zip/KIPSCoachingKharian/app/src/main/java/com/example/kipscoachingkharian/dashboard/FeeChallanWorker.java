package com.example.kipscoachingkharian.dashboard;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;


public class FeeChallanWorker extends Worker {

    private static final String UNIQUE_NAME = "fee_challan_auto";
    private static final long LATE_FINE = 200L;

    private static final Set<String> SPECIAL = new HashSet<>(Arrays.asList(
            "urdu",
            "pakistan studies", "pak studies", "pak study", "pakistan study", "p.st", "pst",
            "islamiat", "islamic studies", "islamiyat", "islamiyat studies"));

    public FeeChallanWorker(@NonNull Context c, @NonNull WorkerParameters p) {
        super(c, p);
    }

    /** Admin dashboard ke onCreate() mein ek dafa call karo. */
    public static void schedule(Context context) {
        PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(
                FeeChallanWorker.class, 6, TimeUnit.HOURS)
                .setConstraints(new Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build())
                .build();

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, req);
    }

    @NonNull
    @Override
    public Result doWork() {
        try {
            DatabaseReference root = FirebaseDatabase.getInstance().getReference();

            DataSnapshot cfg   = Tasks.await(root.child("payment_config").get());
            DataSnapshot users = Tasks.await(root.child("Users").get());

            long feeN = num(cfg.child("fee_per_subject"), 3000L);
            long feeS = num(cfg.child("fee_special_subject"), 2500L);

            Calendar cal = Calendar.getInstance();
            int today = cal.get(Calendar.DAY_OF_MONTH);
            cal.set(Calendar.DAY_OF_MONTH, 15);
            String dueDate  = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).format(cal.getTime());
            String month    = new SimpleDateFormat("MMMM yyyy",  Locale.ENGLISH).format(cal.getTime());
            String monthKey = month.replace(" ", "_");
            long fine = today > 15 ? LATE_FINE : 0L;

            // child username -> parent uid
            Map<String, String> parentOf = new HashMap<>();
            for (DataSnapshot u : users.getChildren()) {
                if ("Parent".equalsIgnoreCase(str(u.child("role")))) {
                    String l = str(u.child("linkedChildUsername"));
                    if (l != null && !l.trim().isEmpty()) {
                        parentOf.put(l.trim().toLowerCase(), u.getKey());
                    }
                }
            }

            for (DataSnapshot u : users.getChildren()) {
                if (!"Student".equalsIgnoreCase(str(u.child("role")))) continue;
                if (!"Approved".equalsIgnoreCase(str(u.child("status")))) continue;

                String name = str(u.child("name"));
                if (name == null) continue;

                String uid      = u.getKey();
                String cls      = str(u.child("className"));
                String username = str(u.child("username"));

                List<String> subs = new ArrayList<>();
                for (DataSnapshot s : u.child("enrolledSubjects").getChildren()) {
                    String x = str(s);
                    if (x != null) subs.add(x);
                }

                long base = 0;
                Map<String, Long> sf = new HashMap<>();
                for (String s : subs) {
                    long f = SPECIAL.contains(s.trim().toLowerCase()) ? feeS : feeN;
                    sf.put(s, f);
                    base += f;
                }
                long total = base + fine;

                DatabaseReference ref = root.child("Fees").child(uid).child(monthKey);
                DataSnapshot snap = Tasks.await(ref.get());

                if (!snap.exists()) {
                    // ── Naye mahine ka challan ──
                    Map<String, Object> d = new HashMap<>();
                    d.put("studentName",   name);
                    d.put("className",     cls == null ? "" : cls);
                    d.put("month",         month);
                    d.put("dueDate",       dueDate);
                    d.put("subjects",      subs);
                    d.put("feePerSubject", feeN);
                    d.put("totalSubjects", subs.size());
                    d.put("baseFee",       String.valueOf(base));
                    d.put("lateFine",      String.valueOf(fine));
                    d.put("amount",        String.valueOf(total));
                    d.put("subjectFees",   sf);
                    d.put("generatedAt",   System.currentTimeMillis());
                    d.put("status",        "Unpaid");
                    Tasks.await(ref.setValue(d));

                    notif(root, uid,
                            name + "'s fee challan for " + month + " has been generated. Amount: Rs. "
                                    + total + ". Due Date: " + dueDate,
                            name, month, total, dueDate, fine);

                    String pid = username == null ? null : parentOf.get(username.trim().toLowerCase());
                    if (pid != null) {
                        notif(root, pid,
                                "Your child " + name + "'s fee challan for " + month
                                        + " has been generated. Amount: Rs. " + total
                                        + ". Due Date: " + dueDate,
                                name, month, total, dueDate, fine);
                    }

                } else if (!"Paid".equalsIgnoreCase(str(snap.child("status")))) {
                    // ── Unpaid: naya rate / subjects / late fine update ──
                    Map<String, Object> up = new HashMap<>();
                    up.put("feePerSubject", feeN);
                    up.put("baseFee",       String.valueOf(base));
                    up.put("lateFine",      String.valueOf(fine));
                    up.put("amount",        String.valueOf(total));
                    up.put("subjectFees",   sf);
                    up.put("subjects",      subs);
                    up.put("totalSubjects", subs.size());
                    Tasks.await(ref.updateChildren(up));
                }
                // Paid ho to kuch nahi chhedna
            }
            return Result.success();

        } catch (Exception e) {
            return Result.retry();
        }
    }

    private void notif(DatabaseReference root, String target, String msg, String name,
                       String month, long amount, String due, long fine) throws Exception {
        Map<String, Object> n = new HashMap<>();
        n.put("title",       fine > 0 ? "⚠️ Fee Overdue!" : "📋 Fee Challan Generated");
        n.put("message",     msg);
        n.put("type",        "fee_pending");
        n.put("studentName", name);
        n.put("amount",      String.valueOf(amount));
        n.put("dueDate",     due);
        n.put("month",       month);
        n.put("isLate",      fine > 0);
        n.put("lateFine",    String.valueOf(fine));
        n.put("timestamp",   System.currentTimeMillis());
        n.put("isRead",      false);
        Tasks.await(root.child("Notifications").child(target).push().setValue(n));
    }

    private static String str(DataSnapshot s) {
        return (s == null || !s.exists() || s.getValue() == null) ? null : String.valueOf(s.getValue());
    }

    private static long num(DataSnapshot s, long def) {
        Object v = s.getValue();
        return v instanceof Number ? ((Number) v).longValue() : def;
    }
}
