package com.example.kipscoachingkharian.dashboard;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.example.kipscoachingkharian.R;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class StudentListActivity extends AppCompatActivity {

    private LinearLayout containerStudents;
    private TextView tvStudentCount;
    private MaterialAutoCompleteTextView spinnerClassFilter;
    private EditText etSearch;

    // ✅ Teacher ki saari assigned classes/subjects (multi-select se aati hain)
    private final Set<String> teacherClasses  = new HashSet<>();  // e.g. {"9A", "10B"}
    private final Set<String> teacherSubjects = new HashSet<>();  // e.g. {"Physics", "Math"}
    private String searchQuery = "";

    // "All Classes" + same grades jo Create Class screen mein hain
    private static final String ALL_CLASSES = "All Classes";
    private static final String[] CLASS_OPTIONS = {
            "All Classes",
            "Class 9A", "Class 9B", "Class 10A", "Class 10B",
            "Class 11A", "Class 11B", "Class 12A", "Class 12B"
    };

    // Selected class filter, e.g. "Class 10A" or "All Classes"
    private String selectedClass = ALL_CLASSES;

    private final List<StudentItem> allStudents = new ArrayList<>();
    private ValueEventListener studentsListener;

    private static class StudentItem {
        String name, regId, className, displayClass, matchedSubject;
        StudentItem(String name, String regId, String className, String displayClass, String matchedSubject) {
            this.name = name; this.regId = regId;
            this.className = className;
            this.displayClass = displayClass; this.matchedSubject = matchedSubject;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_list);

        containerStudents  = findViewById(R.id.containerStudents);
        tvStudentCount     = findViewById(R.id.tvStudentCount);
        spinnerClassFilter = findViewById(R.id.spinnerClassFilter);
        etSearch           = findViewById(R.id.etSearchStudents);

        android.widget.ImageView ivMenu = findViewById(R.id.ivMenu);
        if (ivMenu != null) ivMenu.setOnClickListener(v -> finish());

        setupClassDropdown();

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                searchQuery = s.toString().toLowerCase().trim();
                renderList();
            }
        });

        String teacherUid = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : null;
        if (teacherUid == null) { finish(); return; }

        FirebaseDatabase.getInstance().getReference("Users").child(teacherUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        loadTeacherAssignments(snapshot);
                        setupClassDropdownDefault();
                        fetchAndShowStudents();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        fetchAndShowStudents();
                    }
                });
    }

    // ── Teacher ki assigned classes + subjects parse karo ─────────────────────
    // Support karta hai:
    //   1. assignedClasses: "9A, 10B"          (comma-separated string)
    //   2. assignedClassMap: {9A: true, 10B: true}  (map)
    //   3. subjects: "Physics, Math"           (comma-separated string)
    //   4. assignedSubjects: {Physics: true}   (map)
    //   Purane single-value fields (assignedClass/subject) bhi fallback ke liye
    private void loadTeacherAssignments(DataSnapshot snapshot) {
        teacherClasses.clear();
        teacherSubjects.clear();

        // ── Classes ──
        String classesStr = snapshot.child("assignedClasses").getValue(String.class);
        if (classesStr == null || classesStr.trim().isEmpty())
            classesStr = snapshot.child("className").getValue(String.class);
        if (classesStr != null && !classesStr.trim().isEmpty()) {
            for (String c : classesStr.split(",")) {
                String trimmed = c.trim();
                if (!trimmed.isEmpty()) teacherClasses.add(normalizeClass(trimmed));
            }
        }
        // Map version bhi check karo
        for (DataSnapshot c : snapshot.child("assignedClassMap").getChildren()) {
            if (c.getKey() != null) teacherClasses.add(normalizeClass(c.getKey()));
        }
        // Purana single-value fallback
        String oldClass = snapshot.child("assignedClass").getValue(String.class);
        if (oldClass != null && !oldClass.trim().isEmpty())
            teacherClasses.add(normalizeClass(oldClass.trim()));

        // ── Subjects ──
        String subjectsStr = snapshot.child("subjects").getValue(String.class);
        if (subjectsStr == null || subjectsStr.trim().isEmpty())
            subjectsStr = snapshot.child("subject").getValue(String.class);
        if (subjectsStr != null && !subjectsStr.trim().isEmpty()) {
            for (String s : subjectsStr.split(",")) {
                String trimmed = s.trim();
                if (!trimmed.isEmpty()) teacherSubjects.add(trimmed.toLowerCase());
            }
        }
        for (DataSnapshot s : snapshot.child("assignedSubjects").getChildren()) {
            if (s.getKey() != null) teacherSubjects.add(s.getKey().trim().toLowerCase());
        }
    }

    // "9A" / "Class 9A" / "9-A" sab ko "9A" format mein laata hai (uppercase, no spaces)
    private String normalizeClass(String raw) {
        return raw.replace("Class", "").replace(" ", "").trim().toUpperCase();
    }

    // ── Dropdown ko teacher ki pehli assigned class par default select karo ────
    private void setupClassDropdownDefault() {
        if (teacherClasses.size() == 1) {
            String only = teacherClasses.iterator().next(); // e.g. "9A"
            String num  = only.replaceAll("[^0-9]", "");
            String sec  = only.replaceAll("[0-9]", "");
            String guess = "Class " + num + sec;
            for (String opt : CLASS_OPTIONS) {
                if (opt.equalsIgnoreCase(guess)) {
                    selectedClass = opt;
                    spinnerClassFilter.setText(opt, false);
                    break;
                }
            }
        }
        // Agar teacher ki multiple classes hain to "All Classes" hi rahega default
        // (dropdown se woh khud filter kar sakta hai)
    }

    // ── Class selector dropdown (jaisa Create Class screen mein hai) ───────────
    private void setupClassDropdown() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, CLASS_OPTIONS);
        spinnerClassFilter.setAdapter(adapter);
        spinnerClassFilter.setText(selectedClass, false);

        spinnerClassFilter.setOnItemClickListener((parent, view, position, id) -> {
            selectedClass = CLASS_OPTIONS[position];
            spinnerClassFilter.setText(selectedClass, false);
            renderList();
        });
    }

    private void fetchAndShowStudents() {
        studentsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                allStudents.clear();

                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                    String role = userSnapshot.child("role").getValue(String.class);
                    if (role == null || !role.trim().equalsIgnoreCase("Student")) continue;

                    String className = userSnapshot.child("className").getValue(String.class);
                    String studentClassNorm = className != null ? normalizeClass(className) : "";

                    // ✅ 1. Class match — student teacher ki assigned classes mein se kisi mein ho
                    boolean classMatch = teacherClasses.isEmpty() // agar koi class assign nahi to skip
                            ? false
                            : teacherClasses.contains(studentClassNorm);
                    if (!classMatch) continue;

                    // ✅ 2. Subject match — student ke enrolledSubjects mein teacher ka
                    //    koi bhi assigned subject ho
                    String matchedSubject = null;
                    if (!teacherSubjects.isEmpty()) {
                        for (DataSnapshot s : userSnapshot.child("enrolledSubjects").getChildren()) {
                            String sv = s.getValue(String.class);
                            if (sv != null && teacherSubjects.contains(sv.trim().toLowerCase())) {
                                matchedSubject = sv.trim();
                                break;
                            }
                        }
                        if (matchedSubject == null) continue; // koi subject match nahi hua
                    }

                    String name  = userSnapshot.child("name").getValue(String.class);
                    String regId = userSnapshot.child("registrationId").getValue(String.class);
                    if (regId == null) regId = userSnapshot.child("studentId").getValue(String.class);
                    if (regId == null) regId = "";

                    String section      = userSnapshot.child("assignedSection").getValue(String.class);
                    String displayClass = className != null ? className : "-";
                    if (section != null && !section.isEmpty() && !displayClass.contains(section))
                        displayClass += " (" + section + ")";

                    allStudents.add(new StudentItem(
                            name != null ? name : "Unknown Student",
                            regId, className != null ? className : "", displayClass,
                            matchedSubject != null ? matchedSubject : ""));
                }
                renderList();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(StudentListActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };

        FirebaseDatabase.getInstance().getReference("Users")
                .addValueEventListener(studentsListener);
    }

    // ── Selected dropdown class se student ka className match karo ─────────────
    private boolean matchesSelectedClass(StudentItem s) {
        if (selectedClass.equals(ALL_CLASSES)) return true;

        String num = selectedClass.replaceAll("[^0-9]", "");
        String sec = selectedClass.replaceAll("[^A-Za-z]", "").replace("Class", "").trim();

        String studentClass = s.className == null ? "" : s.className.trim();
        if (studentClass.isEmpty()) return false;

        String sNum = studentClass.replaceAll("[^0-9]", "");
        boolean numOk = !num.isEmpty() && num.equals(sNum);
        boolean secOk = sec.isEmpty() || studentClass.toUpperCase().contains(sec.toUpperCase());
        return numOk && secOk;
    }

    private void renderList() {
        containerStudents.removeAllViews();
        int count = 0;

        for (StudentItem s : allStudents) {
            if (!matchesSelectedClass(s)) continue;

            if (!searchQuery.isEmpty()
                    && !s.name.toLowerCase().contains(searchQuery)
                    && !s.regId.toLowerCase().contains(searchQuery)
                    && !s.displayClass.toLowerCase().contains(searchQuery)) continue;

            View v = LayoutInflater.from(this).inflate(R.layout.item_student, containerStudents, false);
            ((TextView) v.findViewById(R.id.tvItemStudentName))
                    .setText(s.name + " (" + s.displayClass + ")");
            ((TextView) v.findViewById(R.id.tvItemStudentID))
                    .setText(!s.regId.isEmpty() ? "ID: " + s.regId : "ID: N/A");
            ((TextView) v.findViewById(R.id.tvItemStudentSubjects))
                    .setText("Subject: " + (!s.matchedSubject.isEmpty() ? s.matchedSubject : "-")
                            + " | Class: " + s.displayClass);
            containerStudents.addView(v);
            count++;
        }

        if (tvStudentCount != null)
            tvStudentCount.setText(count + " student" + (count != 1 ? "s" : "") + " found");

        if (count == 0)
            showNoDataText(searchQuery.isEmpty()
                    ? "No students found for " + selectedClass + "."
                    : "No results for \"" + searchQuery + "\"");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (studentsListener != null)
            FirebaseDatabase.getInstance().getReference("Users").removeEventListener(studentsListener);
    }

    private void showNoDataText(String message) {
        TextView tv = new TextView(this);
        tv.setText(message);
        tv.setTextSize(16);
        tv.setGravity(android.view.Gravity.CENTER);
        tv.setPadding(0, 50, 0, 0);
        containerStudents.addView(tv);
    }
}