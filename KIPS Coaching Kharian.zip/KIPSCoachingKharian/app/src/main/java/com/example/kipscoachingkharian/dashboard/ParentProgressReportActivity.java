package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

public class ParentProgressReportActivity extends AppCompatActivity {

    public static final String EXTRA_STUDENT_UID  = "STUDENT_UID";
    public static final String EXTRA_STUDENT_NAME = "STUDENT_NAME";

    // ── Views ─────────────────────────────────────────────────────────────────
    private RecyclerView     rvProgress;
    private LinearLayout     layoutEmpty, layoutLoading;
    private LinearLayout     layoutProgressSection, layoutReportSection;
    private TextView         tvStudentName, tvHeaderSubtitle, tvOverallPercent;
    private TextView         chipProgress, chipReport;
    private EditText         etSearch;
    private View             cardSearch;

    private BarChart  barChart;
    private PieChart  pieChart;
    private LineChart lineChartTrend;   // Progress Trend (Monthly/Yearly)
    private LineChart lineChart;        // Daily Progress

    private TextView chipMonthly, chipYearly, tvTrendEmpty, tvNoHistory;
    private Spinner  spinnerSubject;

    private LinearLayout llHomeTab, llProfileTab;

    // ── State ─────────────────────────────────────────────────────────────────
    private boolean showMonthlyTrend = true;

    static class ScoreEntry {
        long   timestamp;
        double percent;
    }
    private final List<ScoreEntry> allScoreEntries = new ArrayList<>();

    private String studentUid;
    private final List<ProgressItem> progressList  = new ArrayList<>(); // full
    private final List<ProgressItem> filteredList  = new ArrayList<>(); // after search
    private ProgressAdapter adapter;

    static class ProgressItem {
        String subject, className;
        int classAttended, classTotal, attendancePct,
                assignMarks, assignTotal, quizMarks, quizTotal, avgPercent;
    }

    // ── onCreate ──────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_progress_report);

        studentUid = getIntent().getStringExtra(EXTRA_STUDENT_UID);
        String nameExtra = getIntent().getStringExtra(EXTRA_STUDENT_NAME);

        // Bind views
        rvProgress            = findViewById(R.id.rvProgress);
        layoutEmpty           = findViewById(R.id.layoutEmpty);
        layoutLoading         = findViewById(R.id.layoutLoading);
        layoutProgressSection = findViewById(R.id.layoutProgressSection);
        layoutReportSection   = findViewById(R.id.layoutReportSection);
        tvStudentName         = findViewById(R.id.tvStudentName);
        tvHeaderSubtitle      = findViewById(R.id.tvHeaderSubtitle);
        tvOverallPercent      = findViewById(R.id.tvOverallPercent);
        etSearch              = findViewById(R.id.etSearch);
        cardSearch            = findViewById(R.id.cardSearch);
        chipProgress          = findViewById(R.id.chipProgress);
        chipReport            = findViewById(R.id.chipReport);
        barChart              = findViewById(R.id.barChart);
        pieChart              = findViewById(R.id.pieChart);
        lineChartTrend        = findViewById(R.id.lineChartTrend);
        lineChart             = findViewById(R.id.lineChart);
        spinnerSubject        = findViewById(R.id.spinnerSubject);
        chipMonthly           = findViewById(R.id.chipMonthly);
        chipYearly            = findViewById(R.id.chipYearly);
        tvTrendEmpty          = findViewById(R.id.tvTrendEmpty);
        tvNoHistory           = findViewById(R.id.tvNoHistory);
        llHomeTab             = findViewById(R.id.llHomeTab);
        llProfileTab          = findViewById(R.id.llProfileTab);

        // Header mein student name set karo agar intent se mila ho
        if (nameExtra != null && !nameExtra.isEmpty()) {
            tvStudentName.setText(nameExtra);
        }

        // Bottom nav
        llHomeTab.setOnClickListener(v -> finish());
        llProfileTab.setOnClickListener(v ->
                startActivity(new Intent(this, ParentProfileActivity.class)));

        // Tab toggle
        chipProgress.setOnClickListener(v -> toggleTabs(true));
        chipReport.setOnClickListener(v   -> toggleTabs(false));

        // Monthly / Yearly trend toggle
        chipMonthly.setOnClickListener(v -> {
            showMonthlyTrend = true;
            updateTrendUI();
        });
        chipYearly.setOnClickListener(v -> {
            showMonthlyTrend = false;
            updateTrendUI();
        });

        // RecyclerView
        adapter = new ProgressAdapter(filteredList);
        rvProgress.setLayoutManager(new LinearLayoutManager(this));
        rvProgress.setAdapter(adapter);
        rvProgress.setNestedScrollingEnabled(false);

        // Search
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                filterReports(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        if (studentUid != null) {
            loadStudentInfo();
            loadProgressReports();
        }
    }

    // ── Tab Toggle ────────────────────────────────────────────────────────────
    private void toggleTabs(boolean showProgress) {
        layoutProgressSection.setVisibility(showProgress ? View.VISIBLE : View.GONE);
        layoutReportSection.setVisibility(showProgress   ? View.GONE   : View.VISIBLE);
        cardSearch.setVisibility(showProgress             ? View.VISIBLE : View.GONE);

        chipProgress.setBackgroundResource(showProgress ? R.drawable.bg_tab_selected   : R.drawable.bg_tab_unselected);
        chipProgress.setTextColor(showProgress          ? Color.WHITE                  : 0xFFB71C1C);
        chipReport.setBackgroundResource(showProgress   ? R.drawable.bg_tab_unselected : R.drawable.bg_tab_selected);
        chipReport.setTextColor(showProgress            ? 0xFFB71C1C                   : Color.WHITE);

        if (!showProgress) {
            setupBarChart();
            setupPieChart();
            loadTrendData();
        }
    }

    private void updateTrendUI() {
        chipMonthly.setBackgroundResource(showMonthlyTrend  ? R.drawable.bg_tab_selected   : R.drawable.bg_tab_unselected);
        chipMonthly.setTextColor(showMonthlyTrend           ? Color.WHITE                  : 0xFFB71C1C);
        chipYearly.setBackgroundResource(!showMonthlyTrend  ? R.drawable.bg_tab_selected   : R.drawable.bg_tab_unselected);
        chipYearly.setTextColor(!showMonthlyTrend           ? Color.WHITE                  : 0xFFB71C1C);
        drawTrendChart();
    }

    // ── Firebase: Student Info ─────────────────────────────────────────────────
    private void loadStudentInfo() {
        FirebaseDatabase.getInstance().getReference("Users").child(studentUid).get()
                .addOnSuccessListener(snap -> {
                    if (snap.exists()) {
                        String name  = snap.child("name").getValue(String.class);
                        String grade = snap.child("className").getValue(String.class);
                        String info  = (name != null ? name : "Student");
                        if (grade != null && !grade.isEmpty()) info += "  |  Grade: " + grade;
                        tvHeaderSubtitle.setText(info);
                        if (name != null) tvStudentName.setText(name);
                    }
                });
    }

    // ── Firebase: SharedProgress ──────────────────────────────────────────────
    private void loadProgressReports() {
        layoutLoading.setVisibility(View.VISIBLE);
        layoutEmpty.setVisibility(View.GONE);
        rvProgress.setVisibility(View.GONE);

        FirebaseDatabase.getInstance().getReference("SharedProgress").child(studentUid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        progressList.clear();

                        for (DataSnapshot s : snapshot.getChildren()) {
                            ProgressItem p   = new ProgressItem();
                            p.subject        = getStr(s, "subject");
                            p.className      = getStr(s, "className");
                            p.classAttended  = getInt(s, "classAttended");
                            p.classTotal     = getInt(s, "classTotal");
                            p.attendancePct  = getInt(s, "attendancePct");
                            p.assignMarks    = getInt(s, "assignMarks");
                            p.assignTotal    = getInt(s, "assignTotal");
                            p.quizMarks      = getInt(s, "quizMarks");
                            p.quizTotal      = getInt(s, "quizTotal");
                            p.avgPercent     = getInt(s, "avgPercent");
                            progressList.add(p);
                        }

                        layoutLoading.setVisibility(View.GONE);
                        filterReports(etSearch.getText().toString());

                        if (!progressList.isEmpty()) {
                            rvProgress.setVisibility(View.VISIBLE);
                            updateOverall();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        layoutLoading.setVisibility(View.GONE);
                    }
                });
    }

    // ── Overall % ─────────────────────────────────────────────────────────────
    private void updateOverall() {
        int totalObt = 0, totalMax = 0;
        for (ProgressItem p : progressList) {
            totalObt += p.assignMarks + p.quizMarks;
            totalMax += p.assignTotal + p.quizTotal;
        }
        int overall = totalMax == 0 ? 0 : (int) ((totalObt * 100.0) / totalMax);
        tvOverallPercent.setText(overall + "%");
    }

    // ── Search Filter ─────────────────────────────────────────────────────────
    private void filterReports(String query) {
        filteredList.clear();
        if (query.trim().isEmpty()) {
            filteredList.addAll(progressList);
        } else {
            String q = query.toLowerCase().trim();
            for (ProgressItem p : progressList) {
                if (p.subject.toLowerCase().contains(q) ||
                        (p.className != null && p.className.toLowerCase().contains(q))) {
                    filteredList.add(p);
                }
            }
        }
        adapter.notifyDataSetChanged();
        layoutEmpty.setVisibility(filteredList.isEmpty() ? View.VISIBLE : View.GONE);
        if (!filteredList.isEmpty()) rvProgress.setVisibility(View.VISIBLE);
    }

    // ── Bar Chart ─────────────────────────────────────────────────────────────
    private void setupBarChart() {
        if (progressList.isEmpty()) return;

        ArrayList<BarEntry> entries = new ArrayList<>();
        ArrayList<String>   labels  = new ArrayList<>();

        for (int i = 0; i < progressList.size(); i++) {
            ProgressItem p = progressList.get(i);
            entries.add(new BarEntry(i, p.avgPercent));
            String[] words = p.subject.trim().split("\\s+");
            StringBuilder lbl = new StringBuilder();
            for (int w = 0; w < Math.min(3, words.length); w++) {
                if (w > 0) lbl.append(" ");
                lbl.append(words[w]);
            }
            labels.add(lbl.toString());
        }

        BarDataSet dataSet = new BarDataSet(entries, "Avg %");
        dataSet.setColors(
                0xFF90CAF9, 0xFFA5D6A7, 0xFFFFCC80,
                0xFFCE93D8, 0xFFEF9A9A, 0xFF80DEEA, 0xFFFFF176);
        dataSet.setValueTextColor(0xFF424242);
        dataSet.setValueTextSize(11f);
        dataSet.setDrawValues(true);

        BarData data = new BarData(dataSet);
        data.setBarWidth(0.5f);
        barChart.setData(data);
        barChart.getDescription().setEnabled(false);
        barChart.getLegend().setEnabled(false);
        barChart.getAxisRight().setEnabled(false);
        barChart.getAxisLeft().setAxisMaximum(100f);
        barChart.getAxisLeft().setAxisMinimum(0f);
        barChart.getAxisLeft().setDrawGridLines(false);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setDrawGridLines(false);
        if (labels.size() > 5) xAxis.setLabelRotationAngle(-30f);

        barChart.animateY(1000);
        barChart.invalidate();
    }

    // ── Pie Chart ─────────────────────────────────────────────────────────────
    private void setupPieChart() {
        if (progressList.isEmpty()) return;

        List<String> subjects = new ArrayList<>();
        for (ProgressItem p : progressList) subjects.add(p.subject);

        ArrayAdapter<String> spinAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, subjects);
        spinAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSubject.setAdapter(spinAdapter);

        drawPieForSubject(progressList.get(0));

        spinnerSubject.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                drawPieForSubject(progressList.get(pos));
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });
    }

    private void drawPieForSubject(ProgressItem p) {
        ArrayList<PieEntry> entries = new ArrayList<>();
        entries.add(new PieEntry((float) p.assignMarks,
                "Assignments (" + p.assignMarks + "/" + p.assignTotal + ")"));
        entries.add(new PieEntry((float) p.quizMarks,
                "Quizzes (" + p.quizMarks + "/" + p.quizTotal + ")"));
        entries.add(new PieEntry((float) p.classAttended,
                "Classes (" + p.classAttended + "/" + p.classTotal + ")"));

        PieDataSet set = new PieDataSet(entries, "");
        set.setColors(new int[]{
                Color.parseColor("#90CAF9"),
                Color.parseColor("#A5D6A7"),
                Color.parseColor("#FFCC80")
        });
        set.setSliceSpace(3f);
        set.setValueTextColor(Color.BLACK);
        set.setValueTextSize(11f);

        PieData data = new PieData(set);
        data.setValueFormatter(new PercentFormatter(pieChart));

        pieChart.setData(data);
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.WHITE);
        pieChart.setHoleRadius(45f);
        pieChart.setTransparentCircleRadius(50f);
        pieChart.setCenterText(p.subject);
        pieChart.setCenterTextSize(14f);
        pieChart.setDrawEntryLabels(false);

        Legend l = pieChart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        l.setDrawInside(false);
        l.setWordWrapEnabled(true);
        l.setTextSize(11f);

        pieChart.animateXY(1000, 1000);
        pieChart.invalidate();
    }

    // ── Trend Data: QuizAttempts + Submissions ────────────────────────────────
    private void loadTrendData() {
        allScoreEntries.clear();

        FirebaseDatabase.getInstance().getReference("QuizAttempts")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot quizSnap) {
                        for (DataSnapshot quiz : quizSnap.getChildren()) {
                            DataSnapshot my = quiz.child(studentUid);
                            if (!my.exists()) continue;

                            Long score    = my.child("score").getValue(Long.class);
                            Long mcqTot   = my.child("mcqTotal").getValue(Long.class);
                            Long shortTot = my.child("shortTotal").getValue(Long.class);
                            Long ts       = my.child("timestamp").getValue(Long.class);

                            int obtained = score    != null ? score.intValue()    : 0;
                            int total    = (mcqTot  != null ? mcqTot.intValue()   : 0)
                                    + (shortTot != null ? shortTot.intValue() : 0);

                            if (total > 0 && ts != null) {
                                ScoreEntry e = new ScoreEntry();
                                e.timestamp  = ts;
                                e.percent    = (obtained * 100.0) / total;
                                allScoreEntries.add(e);
                            }
                        }
                        loadAssignmentTrendData();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        loadAssignmentTrendData();
                    }
                });
    }

    private void loadAssignmentTrendData() {
        FirebaseDatabase.getInstance().getReference("Submissions")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot submissionsSnap) {
                        for (DataSnapshot assignSnap : submissionsSnap.getChildren()) {
                            DataSnapshot mySub = assignSnap.child(studentUid);
                            if (!mySub.exists()) continue;

                            String obtainedStr = mySub.child("obtainedMarks").getValue(String.class);
                            Long   submittedAt = mySub.child("submittedAt").getValue(Long.class);
                            if (obtainedStr == null || obtainedStr.trim().isEmpty()
                                    || submittedAt == null) continue;

                            String teacherId   = mySub.child("teacherId").getValue(String.class);
                            String assignmentId = assignSnap.getKey();

                            double obtained;
                            try { obtained = Double.parseDouble(obtainedStr.trim()); }
                            catch (NumberFormatException ex) { continue; }

                            if (teacherId == null || assignmentId == null) continue;

                            final long ts = submittedAt;
                            final double obt = obtained;

                            FirebaseDatabase.getInstance().getReference("Assignments")
                                    .child(teacherId).child(assignmentId).child("marks")
                                    .get().addOnSuccessListener(marksSnap -> {
                                        String totalStr = marksSnap.getValue(String.class);
                                        if (totalStr == null || totalStr.trim().isEmpty()) return;
                                        double total;
                                        try { total = Double.parseDouble(totalStr.trim()); }
                                        catch (NumberFormatException ex) { return; }
                                        if (total <= 0) return;

                                        ScoreEntry e = new ScoreEntry();
                                        e.timestamp  = ts;
                                        e.percent    = (obt * 100.0) / total;
                                        allScoreEntries.add(e);

                                        drawTrendChart();
                                        drawDailyProgressChart();
                                    });
                        }
                        drawTrendChart();
                        drawDailyProgressChart();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        drawTrendChart();
                        drawDailyProgressChart();
                    }
                });
    }

    // ── Monthly/Yearly Trend Chart ────────────────────────────────────────────
    private void drawTrendChart() {
        if (allScoreEntries.isEmpty()) {
            lineChartTrend.clear();
            lineChartTrend.setVisibility(View.GONE);
            tvTrendEmpty.setVisibility(View.VISIBLE);
            return;
        }

        SimpleDateFormat keyFmt   = new SimpleDateFormat(showMonthlyTrend ? "yyyy-MM" : "yyyy", Locale.getDefault());
        SimpleDateFormat labelFmt = new SimpleDateFormat(showMonthlyTrend ? "MMM yy"  : "yyyy", Locale.getDefault());

        Map<String, List<Double>> grouped = new TreeMap<>();
        Map<String, String>       labels  = new LinkedHashMap<>();

        for (ScoreEntry e : allScoreEntries) {
            String key = keyFmt.format(new java.util.Date(e.timestamp));
            grouped.computeIfAbsent(key, k -> new ArrayList<>()).add(e.percent);
            labels.put(key, labelFmt.format(new java.util.Date(e.timestamp)));
        }

        if (grouped.isEmpty()) {
            lineChartTrend.clear();
            lineChartTrend.setVisibility(View.GONE);
            tvTrendEmpty.setVisibility(View.VISIBLE);
            return;
        }

        lineChartTrend.setVisibility(View.VISIBLE);
        tvTrendEmpty.setVisibility(View.GONE);

        ArrayList<Entry>  entries = new ArrayList<>();
        ArrayList<String> xLabels = new ArrayList<>();
        int idx = 0;
        for (Map.Entry<String, List<Double>> g : grouped.entrySet()) {
            double sum = 0;
            for (double pct : g.getValue()) sum += pct;
            entries.add(new Entry(idx, (float)(sum / g.getValue().size())));
            xLabels.add(labels.get(g.getKey()));
            idx++;
        }

        LineDataSet ds = new LineDataSet(entries, "Average Progress %");
        ds.setColor(0xFFB71C1C);
        ds.setCircleColor(0xFFB71C1C);
        ds.setCircleRadius(4.5f);
        ds.setLineWidth(2.5f);
        ds.setValueTextSize(10f);
        ds.setValueTextColor(0xFF424242);
        ds.setDrawFilled(true);
        ds.setFillColor(0xFFFFCDD2);
        ds.setFillAlpha(80);
        ds.setMode(LineDataSet.Mode.CUBIC_BEZIER);

        lineChartTrend.setData(new LineData(ds));

        XAxis xAxis = lineChartTrend.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xLabels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setDrawGridLines(false);
        xAxis.setTextSize(10f);
        xAxis.setAvoidFirstLastClipping(true);
        if (xLabels.size() > 6) {
            xAxis.setLabelRotationAngle(-45f);
            xAxis.setLabelCount(6, false);
        } else {
            xAxis.setLabelRotationAngle(0f);
            xAxis.setLabelCount(xLabels.size(), false);
        }
        lineChartTrend.setExtraBottomOffset(14f);
        lineChartTrend.getAxisLeft().setAxisMinimum(0f);
        lineChartTrend.getAxisLeft().setAxisMaximum(100f);
        lineChartTrend.getAxisLeft().setDrawGridLines(true);
        lineChartTrend.getAxisRight().setEnabled(false);
        lineChartTrend.getDescription().setEnabled(false);
        lineChartTrend.getLegend().setEnabled(true);
        lineChartTrend.setTouchEnabled(true);
        lineChartTrend.setPinchZoom(true);
        lineChartTrend.animateX(800);
        lineChartTrend.invalidate();
    }

    // ── Daily Progress Chart ──────────────────────────────────────────────────
    private void drawDailyProgressChart() {
        if (lineChart == null) return;

        if (allScoreEntries.isEmpty()) {
            lineChart.clear();
            lineChart.setVisibility(View.GONE);
            if (tvNoHistory != null) tvNoHistory.setVisibility(View.VISIBLE);
            return;
        }

        // Student side ki tarah: din-wise group karo aur har din ka average nikalo
        SimpleDateFormat dayKeyFormat   = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat dayLabelFormat = new SimpleDateFormat("dd MMM",     Locale.getDefault());

        Map<String, List<Double>> grouped  = new TreeMap<>();
        Map<String, String>       dayLabels = new LinkedHashMap<>();

        for (ScoreEntry entry : allScoreEntries) {
            String key = dayKeyFormat.format(new java.util.Date(entry.timestamp));
            grouped.computeIfAbsent(key, k -> new ArrayList<>()).add(entry.percent);
            dayLabels.put(key, dayLabelFormat.format(new java.util.Date(entry.timestamp)));
        }

        if (grouped.isEmpty()) {
            lineChart.clear();
            lineChart.setVisibility(View.GONE);
            if (tvNoHistory != null) tvNoHistory.setVisibility(View.VISIBLE);
            return;
        }

        lineChart.setVisibility(View.VISIBLE);
        if (tvNoHistory != null) tvNoHistory.setVisibility(View.GONE);

        ArrayList<Entry>  entries = new ArrayList<>();
        ArrayList<String> xLabels = new ArrayList<>();
        int index = 0;
        for (Map.Entry<String, List<Double>> g : grouped.entrySet()) {
            double sum = 0;
            for (double p : g.getValue()) sum += p;
            double avg = sum / g.getValue().size();
            entries.add(new Entry(index, (float) avg));
            xLabels.add(dayLabels.get(g.getKey()));
            index++;
        }

        LineDataSet ds = new LineDataSet(entries, "Daily Average %");
        ds.setColor(0xFF2E7D32);
        ds.setCircleColor(0xFF2E7D32);
        ds.setCircleRadius(4f);
        ds.setCircleHoleRadius(2f);
        ds.setDrawCircleHole(true);
        ds.setCircleHoleColor(Color.WHITE);
        ds.setLineWidth(2.5f);
        ds.setDrawValues(true);
        ds.setValueTextSize(10f);
        ds.setValueTextColor(0xFF1B5E20);
        ds.setValueFormatter(new com.github.mikephil.charting.formatter.ValueFormatter() {
            @Override
            public String getPointLabel(Entry entry) {
                return Math.round(entry.getY()) + "%";
            }
        });
        ds.setDrawFilled(true);
        ds.setFillColor(0xFFA5D6A7);
        ds.setFillAlpha(80);
        ds.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        ds.setHighlightEnabled(true);
        ds.setHighlightLineWidth(1.5f);
        ds.setHighLightColor(0xFF2E7D32);
        ds.setDrawHorizontalHighlightIndicator(false);

        LineData lineData = new LineData(ds);
        lineData.setHighlightEnabled(true);
        lineChart.setData(lineData);
        lineChart.setExtraTopOffset(24f);
        lineChart.setExtraBottomOffset(28f);
        lineChart.setExtraLeftOffset(8f);
        lineChart.setExtraRightOffset(20f);
        lineChart.setNoDataText("No progress history yet");

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xLabels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setDrawGridLines(false);
        xAxis.setDrawLabels(true);
        xAxis.setTextSize(10f);
        xAxis.setTextColor(0xFF616161);
        xAxis.setAxisLineColor(0xFFBDBDBD);
        xAxis.setAvoidFirstLastClipping(true);
        xAxis.setLabelRotationAngle(0f);
        xAxis.setLabelCount(xLabels.size(), false);

        lineChart.getAxisLeft().setAxisMinimum(0f);
        lineChart.getAxisLeft().setAxisMaximum(100f);
        lineChart.getAxisLeft().setGranularity(20f);
        lineChart.getAxisLeft().setLabelCount(6, true);
        lineChart.getAxisLeft().setDrawGridLines(true);
        lineChart.getAxisLeft().setGridColor(0xFFEEEEEE);
        lineChart.getAxisLeft().setGridLineWidth(0.7f);
        lineChart.getAxisLeft().setTextSize(11f);
        lineChart.getAxisLeft().setTextColor(0xFF616161);
        lineChart.getAxisLeft().setAxisLineColor(0xFFBDBDBD);
        lineChart.getAxisLeft().setValueFormatter(new com.github.mikephil.charting.formatter.ValueFormatter() {
            @Override public String getFormattedValue(float value) { return (int) value + "%"; }
        });
        lineChart.getAxisRight().setEnabled(false);
        lineChart.getDescription().setEnabled(false);
        lineChart.getLegend().setEnabled(true);
        lineChart.getLegend().setTextSize(12f);
        lineChart.getLegend().setTextColor(0xFF424242);
        lineChart.getLegend().setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        lineChart.getLegend().setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        lineChart.getLegend().setForm(Legend.LegendForm.LINE);

        lineChart.setTouchEnabled(true);
        lineChart.setDragEnabled(true);
        lineChart.setScaleEnabled(false);
        lineChart.setPinchZoom(false);
        lineChart.fitScreen();

        float visiblePoints = Math.min(5f, xLabels.size());
        lineChart.setVisibleXRangeMaximum(visiblePoints);
        lineChart.setVisibleXRangeMinimum(visiblePoints);
        lineChart.moveViewToX(0);

        // Touch marker (date + %)
        final ArrayList<String> xLabelsRef = xLabels;
        com.github.mikephil.charting.components.MarkerView mv =
                new com.github.mikephil.charting.components.MarkerView(this, R.layout.marker_chart) {
                    private TextView tvDate, tvPct;
                    @Override
                    public void refreshContent(Entry e, com.github.mikephil.charting.highlight.Highlight h) {
                        if (tvDate == null) tvDate = findViewById(R.id.tvMarkerDate);
                        if (tvPct  == null) tvPct  = findViewById(R.id.tvMarkerPercent);
                        int i = (int) e.getX();
                        tvDate.setText((i >= 0 && i < xLabelsRef.size()) ? xLabelsRef.get(i) : "");
                        tvPct.setText(Math.round(e.getY()) + "%");
                        super.refreshContent(e, h);
                    }
                    @Override
                    public com.github.mikephil.charting.utils.MPPointF getOffset() {
                        return new com.github.mikephil.charting.utils.MPPointF(-(getWidth() / 2f), -getHeight() - 10f);
                    }
                };
        lineChart.setMarkerView(mv);
        lineChart.animateX(900);
        lineChart.invalidate();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private String getStr(DataSnapshot snap, String key) {
        String v = snap.child(key).getValue(String.class);
        return v != null ? v : "--";
    }

    private int getInt(DataSnapshot snap, String key) {
        Object v = snap.child(key).getValue();
        if (v == null) return 0;
        if (v instanceof Number) return ((Number) v).intValue();
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return 0; }
    }

    // ── RecyclerView Adapter ──────────────────────────────────────────────────
    class ProgressAdapter extends RecyclerView.Adapter<ProgressAdapter.VH> {
        private final List<ProgressItem> mList;
        ProgressAdapter(List<ProgressItem> list) { this.mList = list; }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_progress_report, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int pos) {
            ProgressItem p = mList.get(pos);

            h.tvSubject.setText(p.subject);
            h.tvClass.setText("Class: " + (p.className != null ? p.className : "--"));
            h.tvClassVal.setText(p.classAttended + "/" + p.classTotal + "\n(" + p.attendancePct + "%)");
            h.tvAssignVal.setText(p.assignMarks + "/" + p.assignTotal);
            h.tvQuizVal.setText(p.quizMarks + "/" + p.quizTotal);
            h.tvAvgVal.setText(p.avgPercent + "%");
            h.progressBar.setProgress(p.avgPercent);

            int color = (p.avgPercent >= 75) ? 0xFF388E3C
                    : (p.avgPercent >= 50     ? 0xFFFF8F00 : 0xFFD32F2F);
            h.progressBar.getProgressDrawable()
                    .setColorFilter(color, PorterDuff.Mode.SRC_IN);

            // Subject icons — same as Student side
            if (h.ivSubject != null) {
                String sub = p.subject.toLowerCase();
                int imgRes;
                if      (sub.contains("math"))      imgRes = R.drawable.ic_mathematics;
                else if (sub.contains("english"))   imgRes = R.drawable.ic_english;
                else if (sub.contains("physics"))   imgRes = R.drawable.ic_physics;
                else if (sub.contains("chemistry")) imgRes = R.drawable.ic_chemistry;
                else if (sub.contains("biology"))   imgRes = R.drawable.ic_biology;
                else if (sub.contains("computer"))  imgRes = R.drawable.ic_computer;
                else if (sub.contains("urdu"))      imgRes = R.drawable.ic_urdu;
                else if (sub.contains("islamiyat")) imgRes = R.drawable.ic_islamiyat;
                else if (sub.contains("pak"))       imgRes = R.drawable.ic_pakstudy;
                else                                imgRes = R.drawable.ic_studentpr;
                h.ivSubject.setImageResource(imgRes);
            }
        }

        @Override public int getItemCount() { return mList.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView     tvSubject, tvClass, tvClassVal, tvAssignVal, tvQuizVal, tvAvgVal;
            ProgressBar  progressBar;
            ImageView    ivSubject;

            VH(View v) {
                super(v);
                tvSubject   = v.findViewById(R.id.tvSubject);
                tvClass     = v.findViewById(R.id.tvClass);
                tvClassVal  = v.findViewById(R.id.tvClassVal);
                tvAssignVal = v.findViewById(R.id.tvAssignVal);
                tvQuizVal   = v.findViewById(R.id.tvQuizVal);
                tvAvgVal    = v.findViewById(R.id.tvAvgVal);
                progressBar = v.findViewById(R.id.progressBar);
                ivSubject   = v.findViewById(R.id.ivSubject);
            }
        }
    }
}