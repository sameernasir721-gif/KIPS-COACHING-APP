package com.example.kipscoachingkharian.dashboard;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.kipscoachingkharian.R;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class TodayAtAGlanceActivity extends AppCompatActivity {

    private TextView tvTodayDate;

    // Classes card
    private MaterialCardView cardGlanceClassesFull;
    private TextView tvGlanceClassesFull, tvClassesDetail;

    // Assignments card
    private MaterialCardView cardGlanceAssignmentsFull;
    private TextView tvGlanceAssignmentsFull, tvAssignmentsDetail;

    // Submissions card
    private MaterialCardView cardGlanceSubmissionsFull;
    private TextView tvGlanceSubmissionsFull, tvSubmissionsDetail;

    // Quizzes card
    private MaterialCardView cardGlanceQuizzesFull;
    private TextView tvGlanceQuizzesFull, tvQuizzesDetail;

    private String teacherUid;
    private DatabaseReference dbRef;

    private String todayShort; // d/M/yyyy
    private String todayFull;  // dd/MM/yyyy

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_today_at_a_glance);

        teacherUid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        dbRef = FirebaseDatabase.getInstance().getReference();

        todayShort = new SimpleDateFormat("d/M/yyyy", Locale.getDefault()).format(new Date());
        todayFull  = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());

        // Back button
        ImageView ivBack = findViewById(R.id.ivBack);
        ivBack.setOnClickListener(v -> finish());

        // Today's date header
        tvTodayDate = findViewById(R.id.tvTodayDate);
        tvTodayDate.setText(new SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(new Date()));

        // Init views
        cardGlanceClassesFull     = findViewById(R.id.cardGlanceClassesFull);
        tvGlanceClassesFull       = findViewById(R.id.tvGlanceClassesFull);
        tvClassesDetail           = findViewById(R.id.tvClassesDetail);

        cardGlanceAssignmentsFull = findViewById(R.id.cardGlanceAssignmentsFull);
        tvGlanceAssignmentsFull   = findViewById(R.id.tvGlanceAssignmentsFull);
        tvAssignmentsDetail       = findViewById(R.id.tvAssignmentsDetail);

        cardGlanceSubmissionsFull = findViewById(R.id.cardGlanceSubmissionsFull);
        tvGlanceSubmissionsFull   = findViewById(R.id.tvGlanceSubmissionsFull);
        tvSubmissionsDetail       = findViewById(R.id.tvSubmissionsDetail);

        cardGlanceQuizzesFull     = findViewById(R.id.cardGlanceQuizzesFull);
        tvGlanceQuizzesFull       = findViewById(R.id.tvGlanceQuizzesFull);
        tvQuizzesDetail           = findViewById(R.id.tvQuizzesDetail);

        // Card click listeners
        cardGlanceClassesFull.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherCreateClassActivity.class)));

        cardGlanceAssignmentsFull.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherAssignmentActivity.class)));

        cardGlanceSubmissionsFull.setOnClickListener(v ->
                startActivity(new Intent(this, AllSubmissionsActivity.class)));

        cardGlanceQuizzesFull.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherQuizzesActivity.class)));

        // Load data from Firebase
        loadClassesToday();
        loadAssignmentsDueToday();
        loadSubmissionsPending();
        loadActiveQuizzesToday();
    }

    // ── 1. Classes Today ──────────────────────────────────────────────────────
    private void loadClassesToday() {
        dbRef.child("Classes").child(teacherUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        int count = 0;
                        for (DataSnapshot cls : snapshot.getChildren()) {
                            String date = cls.child("date").getValue(String.class);
                            if (date != null &&
                                    (date.equals(todayShort) || date.equals(todayFull))) {
                                count++;
                            }
                        }
                        final int total = count;
                        runOnUiThread(() -> {
                            if (total == 0) {
                                tvGlanceClassesFull.setText("None scheduled today");
                                tvClassesDetail.setText("No classes are scheduled for today");
                            } else {
                                tvGlanceClassesFull.setText(total + (total == 1 ? " class" : " classes") + " scheduled");
                                tvClassesDetail.setText("Tap to view all scheduled classes");
                            }
                        });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        runOnUiThread(() -> tvGlanceClassesFull.setText("Error loading data"));
                    }
                });
    }

    // ── 2. Assignments Due Today ──────────────────────────────────────────────
    private void loadAssignmentsDueToday() {
        dbRef.child("Assignments").child(teacherUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        int count = 0;
                        for (DataSnapshot asgn : snapshot.getChildren()) {
                            String dueDate = asgn.child("dueDate").getValue(String.class);
                            if (dueDate != null &&
                                    (dueDate.equals(todayShort) || dueDate.equals(todayFull))) {
                                count++;
                            }
                        }
                        final int total = count;
                        runOnUiThread(() -> {
                            if (total == 0) {
                                tvGlanceAssignmentsFull.setText("No assignments due today");
                                tvAssignmentsDetail.setText("All clear — no deadlines today");
                            } else {
                                tvGlanceAssignmentsFull.setText(total + " assignment" + (total == 1 ? "" : "s") + " due today");
                                tvAssignmentsDetail.setText("Tap to manage assignments");
                            }
                        });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        runOnUiThread(() -> tvGlanceAssignmentsFull.setText("Error loading data"));
                    }
                });
    }

    // ── 3. Submissions Pending Check ──────────────────────────────────────────
    private void loadSubmissionsPending() {
        dbRef.child("Assignments").child(teacherUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                            runOnUiThread(() -> {
                                tvGlanceSubmissionsFull.setText("No submissions to check");
                                tvSubmissionsDetail.setText("No assignments have been submitted yet");
                            });
                            return;
                        }

                        int totalAssignments = (int) snapshot.getChildrenCount();
                        AtomicInteger remaining  = new AtomicInteger(totalAssignments);
                        AtomicInteger pending    = new AtomicInteger(0);

                        for (DataSnapshot asgn : snapshot.getChildren()) {
                            String assignmentKey = asgn.getKey();
                            if (assignmentKey == null) {
                                if (remaining.decrementAndGet() == 0) updateSubmissions(pending.get());
                                continue;
                            }

                            dbRef.child("Submissions").child(assignmentKey)
                                    .addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot subSnap) {
                                            for (DataSnapshot sub : subSnap.getChildren()) {
                                                Object grade   = sub.child("grade").getValue();
                                                Object marks   = sub.child("marks").getValue();
                                                Object checked = sub.child("checked").getValue();
                                                if (grade == null && marks == null && !Boolean.TRUE.equals(checked)) {
                                                    pending.incrementAndGet();
                                                }
                                            }
                                            if (remaining.decrementAndGet() == 0)
                                                updateSubmissions(pending.get());
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {
                                            if (remaining.decrementAndGet() == 0)
                                                updateSubmissions(pending.get());
                                        }
                                    });
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        runOnUiThread(() -> tvGlanceSubmissionsFull.setText("Error loading data"));
                    }
                });
    }

    private void updateSubmissions(int count) {
        runOnUiThread(() -> {
            if (count == 0) {
                tvGlanceSubmissionsFull.setText("All submissions checked ✓");
                tvSubmissionsDetail.setText("Great job — nothing pending!");
            } else {
                tvGlanceSubmissionsFull.setText(count + " submission" + (count == 1 ? "" : "s") + " pending review");
                tvSubmissionsDetail.setText("Tap to review pending submissions");
            }
        });
    }

    // ── 4. Active Quizzes ─────────────────────────────────────────────────────
    private void loadActiveQuizzesToday() {
        dbRef.child("Quizzes").child(teacherUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        int active = 0;
                        for (DataSnapshot quiz : snapshot.getChildren()) {
                            String status  = quiz.child("status").getValue(String.class);
                            String endDate = quiz.child("endDate").getValue(String.class);

                            if ("active".equalsIgnoreCase(status)) {
                                if (endDate == null || endDate.isEmpty()
                                        || endDate.equals(todayShort)
                                        || endDate.equals(todayFull)
                                        || !isDateBefore(endDate, todayFull)) {
                                    active++;
                                }
                            }
                        }
                        final int total = active;
                        runOnUiThread(() -> {
                            if (total == 0) {
                                tvGlanceQuizzesFull.setText("No active quizzes");
                                tvQuizzesDetail.setText("No quizzes are currently running");
                            } else {
                                tvGlanceQuizzesFull.setText(total + " quiz" + (total == 1 ? "" : "zes") + " currently active");
                                tvQuizzesDetail.setText("Tap to manage quizzes");
                            }
                        });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        runOnUiThread(() -> tvGlanceQuizzesFull.setText("Error loading data"));
                    }
                });
    }

    private boolean isDateBefore(String dateStr, String todayStr) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date d     = sdf.parse(dateStr);
            Date today = sdf.parse(todayStr);
            if (d == null || today == null) return false;
            return d.before(today);
        } catch (Exception e) {
            return false;
        }
    }
}