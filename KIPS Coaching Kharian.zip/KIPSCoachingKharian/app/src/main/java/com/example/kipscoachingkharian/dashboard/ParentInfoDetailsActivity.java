package com.example.kipscoachingkharian.dashboard;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class ParentInfoDetailsActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPhone, etStudentId, etCurrentPassword, etNewPassword, etConfirmPassword;
    private TextView tvInitial;
    private ImageView ivEditProfile, ivToggleCurrentPass, btnBack;
    private MaterialButton btnUpdate;
    private LinearLayout layoutNewPassword;

    private boolean isEditing = false;
    private boolean isPassVisible = false;

    private DatabaseReference mDatabase;
    private FirebaseAuth mAuth;
    private String currentUid;
    private String actualStoredPassword = "";
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_info_details);

        mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() != null) {
            currentUid = mAuth.getCurrentUser().getUid();
            mDatabase = FirebaseDatabase.getInstance().getReference("Users").child(currentUid);
        } else {
            finish();
            return;
        }

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Processing...");
        progressDialog.setCancelable(false);

        initViews();
        loadDataFromFirebase();

        if (btnBack != null) btnBack.setOnClickListener(v -> finish());
        if (ivEditProfile != null) ivEditProfile.setOnClickListener(v -> toggleEditMode());
        if (btnUpdate != null) btnUpdate.setOnClickListener(v -> validateAndUpdate());
        if (ivToggleCurrentPass != null) ivToggleCurrentPass.setOnClickListener(v -> togglePasswordVisibility());
    }

    private void initViews() {
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etStudentId = findViewById(R.id.etStudentId);
        etCurrentPassword = findViewById(R.id.etCurrentPassword);
        etNewPassword = findViewById(R.id.etNewPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword); // New field initialized
        layoutNewPassword = findViewById(R.id.layoutNewPassword);
        tvInitial = findViewById(R.id.tvDetailInitial);
        ivEditProfile = findViewById(R.id.ivEditProfile);
        ivToggleCurrentPass = findViewById(R.id.ivToggleCurrentPass);
        btnUpdate = findViewById(R.id.btnUpdateProfile);
        btnBack = findViewById(R.id.btnBack);

        disableFields();
    }

    private void disableFields() {
        etName.setEnabled(false);
        etEmail.setEnabled(false);
        etStudentId.setEnabled(false);
        etPhone.setEnabled(false);
        etCurrentPassword.setEnabled(false);

        etCurrentPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        isPassVisible = false;

        if (layoutNewPassword != null) layoutNewPassword.setVisibility(View.GONE);
        if (btnUpdate != null) btnUpdate.setVisibility(View.GONE);
    }

    private void loadDataFromFirebase() {
        if (mDatabase == null) return;
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String name = snapshot.child("name").getValue(String.class);
                    etName.setText(name != null ? name : "");
                    etEmail.setText(snapshot.child("email").getValue(String.class));
                    etPhone.setText(snapshot.child("phone").getValue(String.class));
                    String regId = snapshot.child("registrationId").getValue(String.class);
                    etStudentId.setText(regId != null ? regId : "Not Assigned");

                    String dbPass = snapshot.child("password").getValue(String.class);
                    if (dbPass != null) {
                        actualStoredPassword = dbPass;
                        if (!isEditing) {
                            etCurrentPassword.setText(actualStoredPassword);
                        }
                    }
                    if (name != null && !name.isEmpty()) {
                        tvInitial.setText(name.substring(0, 1).toUpperCase());
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void toggleEditMode() {
        isEditing = !isEditing;
        if (isEditing) {
            etPhone.setEnabled(true);
            etCurrentPassword.setEnabled(true);
            etCurrentPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            etCurrentPassword.setText("");
            etCurrentPassword.setHint("Verify Old Password");
            isPassVisible = false;

            layoutNewPassword.setVisibility(View.VISIBLE);
            btnUpdate.setVisibility(View.VISIBLE);
            ivEditProfile.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        } else {
            disableFields();
            etCurrentPassword.setText(actualStoredPassword);
            etCurrentPassword.setHint("Password");
            ivEditProfile.setImageResource(R.drawable.ic_edit);
            etNewPassword.setText("");
            etConfirmPassword.setText(""); // Clear confirm field
        }
    }

    private void togglePasswordVisibility() {
        isPassVisible = !isPassVisible;
        int inputType = isPassVisible ?
                InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD :
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD;

        etCurrentPassword.setInputType(inputType);
        etNewPassword.setInputType(inputType);
        etConfirmPassword.setInputType(inputType); // Sync with toggle

        etCurrentPassword.setSelection(etCurrentPassword.length());
        if (etNewPassword.getText().length() > 0) etNewPassword.setSelection(etNewPassword.length());
    }

    private void validateAndUpdate() {
        String inputOldPass = etCurrentPassword.getText().toString().trim();
        String newPass = etNewPassword.getText().toString().trim();
        String confirmPass = etConfirmPassword.getText().toString().trim(); // Fetch confirm pass

        if (inputOldPass.isEmpty()) {
            etCurrentPassword.setError("Old password required");
            return;
        }

        if (!inputOldPass.equals(actualStoredPassword)) {
            etCurrentPassword.setError("Incorrect current password!");
            return;
        }

        if (!newPass.isEmpty()) {
            // Password matching check
            if (confirmPass.isEmpty()) {
                etConfirmPassword.setError("Please confirm your new password");
                return;
            }
            if (!newPass.equals(confirmPass)) {
                etConfirmPassword.setError("Passwords do not match!");
                return;
            }
            if (!isStrongPassword(newPass)) {
                etNewPassword.setError("Weak password! Use 8+ chars with symbols.");
                return;
            }

            progressDialog.show();
            reAuthenticateAndSave(actualStoredPassword, newPass);
        } else {
            progressDialog.show();
            saveToDatabase(actualStoredPassword);
        }
    }

    private void reAuthenticateAndSave(String oldPass, String newPass) {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null && user.getEmail() != null) {
            AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(), oldPass);
            user.reauthenticate(credential).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    user.updatePassword(newPass).addOnCompleteListener(updateTask -> {
                        if (updateTask.isSuccessful()) {
                            saveToDatabase(newPass);
                        } else {
                            progressDialog.dismiss();
                            Toast.makeText(this, "Auth Update Failed", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Authentication Failed", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void saveToDatabase(String passToSave) {
        Map<String, Object> updates = new HashMap<>();
        updates.put("phone", etPhone.getText().toString().trim());
        updates.put("password", passToSave);

        mDatabase.updateChildren(updates).addOnSuccessListener(aVoid -> {
            actualStoredPassword = passToSave;
            progressDialog.dismiss();
            Toast.makeText(this, "Profile Updated Successfully!", Toast.LENGTH_SHORT).show();
            toggleEditMode();
        }).addOnFailureListener(e -> {
            progressDialog.dismiss();
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    private boolean isStrongPassword(String password) {
        return Pattern.compile("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$").matcher(password).matches();
    }
}