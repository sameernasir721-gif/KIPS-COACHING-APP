package com.example.kipscoachingkharian.auth;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;

import com.example.kipscoachingkharian.R;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.card.MaterialCardView;

/**
 * Activity that serves as the entry point for the application.
 * It presents a dashboard of cards allowing the user to select their role
 * (Admin, Teacher, Student, or Parent) and navigates to the respective login screen.
 */
public class LoginSelectionActivity extends AppCompatActivity {

    // UI Components for role selection
    private MaterialCardView cardAdmin, cardTeacher, cardStudent, cardParent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_selection);

        // Initialize UI references
        cardAdmin = findViewById(R.id.cardAdmin);
        cardTeacher = findViewById(R.id.cardTeacher);
        cardStudent = findViewById(R.id.cardStudent);
        cardParent = findViewById(R.id.cardParent);

        // Set up navigation listeners for each role

        // Navigate to Admin Login
        cardAdmin.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, AdminLoginActivity.class)));

        // Navigate to Teacher Login
        cardTeacher.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, TeacherLoginActivity.class)));

        // Navigate to Student Login
        cardStudent.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, StudentLoginActivity.class)));

        // Navigate to Parent Login
        cardParent.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, ParentLoginActivity.class)));
    }

    /**
     * Handles the device back button press.
     * Shows a confirmation dialog before exiting the app to prevent accidental closures.
     * Uses finishAffinity() to ensure all activities in the stack are cleared.
     */
    @Override
    public void onBackPressed() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Exit Application")
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    // Close the application completely
                    finishAffinity();
                })
                .setNegativeButton("No", null) // Dismiss dialog on 'No'
                .show();
    }
}