package com.example.kipscoachingkharian.auth;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;

import com.example.kipscoachingkharian.R;
import com.google.android.material.card.MaterialCardView;

public class LoginSelectionActivity extends AppCompatActivity {

    private MaterialCardView cardAdmin, cardTeacher, cardStudent, cardParent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_selection);

        cardAdmin = findViewById(R.id.cardAdmin);
        cardTeacher = findViewById(R.id.cardTeacher);
        cardStudent = findViewById(R.id.cardStudent);
        cardParent = findViewById(R.id.cardParent);

        // Admin card - admin login screen par jaye
        cardAdmin.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, AdminLoginActivity.class)));


        cardStudent.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, StudentAuthChoiceActivity.class)));


        cardTeacher.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, TeacherLoginActivity.class)));

        // Parent card - parent login screen par jaye
        cardParent.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, ParentLoginActivity.class)));
    }
}