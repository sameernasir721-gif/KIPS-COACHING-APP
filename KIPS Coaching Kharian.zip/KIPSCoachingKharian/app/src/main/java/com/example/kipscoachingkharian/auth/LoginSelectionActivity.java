package com.example.kipscoachingkharian.auth;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;

import com.example.kipscoachingkharian.R;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.card.MaterialCardView;

public class LoginSelectionActivity extends AppCompatActivity {

    private MaterialCardView cardAdmin, cardTeacher, cardStudent, cardParent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_selection);

        cardAdmin = findViewById(R.id.cardAdmin);
        cardTeacher = findViewById(R.id.cardTeacher);
        cardStudent = findViewById(R.id.cardStudent);
        cardParent = findViewById(R.id.cardParent);

        // Admin card - admin login screen par jaye
        cardAdmin.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, AdminLoginActivity.class)));

        // Student card - student login screen par jaye
        cardStudent.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, StudentLoginActivity.class)));

        // Teacher card - teacher login screen par jaye
        cardTeacher.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, TeacherLoginActivity.class)));

        // Parent card - parent login screen par jaye
        cardParent.setOnClickListener(v ->
                startActivity(new Intent(LoginSelectionActivity.this, ParentLoginActivity.class)));
    }

    @Override
    public void onBackPressed() {
        new MaterialAlertDialogBuilder(this)
                .setMessage("Are you want to exit?")
                .setPositiveButton("Yes", (dialog, which) -> finishAffinity())
                .setNegativeButton("No", null)
                .show();
    }
}
