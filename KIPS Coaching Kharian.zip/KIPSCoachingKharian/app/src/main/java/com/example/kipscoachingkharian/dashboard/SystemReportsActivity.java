package com.example.kipscoachingkharian.dashboard;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

public class SystemReportsActivity extends AppCompatActivity {

    private LinearLayout reportContainer;

    private int sTotal = 0, sApproved = 0, sPending = 0, sRejected = 0;
    private int pTotal = 0, pApproved = 0, pPending = 0, pRejected = 0;
    private int tTotal = 0;

    private final Map<String, Integer> classCounts = new TreeMap<>();

    private final Map<String, int[]> dailyStudents = new LinkedHashMap<>();
    private final Map<String, int[]> dailyParents  = new LinkedHashMap<>();
    private final Map<String, int[]> dailyTeachers = new LinkedHashMap<>();
    private boolean hasCreatedAt = false;

    private final Map<String, Integer> dailyLoginCounts      = new LinkedHashMap<>();
    private final Map<String, Integer> dailyStudentRegCounts = new LinkedHashMap<>();
    private final Map<String, Integer> dailyParentRegCounts  = new LinkedHashMap<>();
    private String[] last7DayKeys;
    private String[] last7DayLabels;

    private int totalQuizzes = 0, totalAttempted = 0;
    private int totalAssignments = 0, totalSubmissions = 0;

    // ── Attendance ──
    private int totalAttendanceRecords = 0, presentCount = 0, absentCount = 0, leaveCount = 0;
    private final Map<String, int[]> dailyAttendance = new LinkedHashMap<>(); // [present, absent, leave]

    private boolean usersLoaded       = false;
    private boolean quizzesLoaded     = false;
    private boolean attemptsLoaded    = false;
    private boolean assignmentsLoaded = false;
    private boolean submissionsLoaded = false;
    private boolean dailyLoginsLoaded = false;
    private boolean attendanceLoaded  = false;

    // Safely reads a Firebase value as String, whatever its actual type.
    private String safeString(DataSnapshot snap) {
        if (snap == null || !snap.exists()) return null;
        Object v = snap.getValue();
        return v != null ? String.valueOf(v) : null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_system_reports);

        reportContainer = findViewById(R.id.reportContainer);
        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        showLoading();
        initDailyMaps();
        loadUsers();
        loadQuizzes();
        loadAttempts();
        loadAssignments();
        loadSubmissions();
        loadDailyLogins();
        loadAttendance();
    }

    private void initDailyMaps() {
        SimpleDateFormat labelFmt = new SimpleDateFormat("dd MMM",     Locale.getDefault());
        SimpleDateFormat keyFmt   = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        last7DayKeys   = new String[7];
        last7DayLabels = new String[7];

        for (int i = 6; i >= 0; i--) {
            long time  = System.currentTimeMillis() - (long) i * 86400000L;
            String label = labelFmt.format(new Date(time));
            String key   = keyFmt.format(new Date(time));

            last7DayKeys[6 - i]   = key;
            last7DayLabels[6 - i] = label;

            dailyStudents.put(label, new int[]{0});
            dailyParents.put(label,  new int[]{0});
            dailyTeachers.put(label, new int[]{0});
            dailyLoginCounts.put(key,      0);
            dailyStudentRegCounts.put(key, 0);
            dailyParentRegCounts.put(key,  0);
            dailyAttendance.put(key, new int[]{0, 0, 0});
        }
    }

    private void loadDailyLogins() {
        FirebaseDatabase.getInstance().getReference("DailyLogins")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dateSnap : snapshot.getChildren()) {
                            String date = dateSnap.getKey();
                            if (date != null && dailyLoginCounts.containsKey(date))
                                dailyLoginCounts.put(date, (int) dateSnap.getChildrenCount());
                        }
                        dailyLoginsLoaded = true;
                        tryRender();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        dailyLoginsLoaded = true; tryRender();
                    }
                });
    }

    // Attendance/{groupPushId}/{recordPushId} = { date, markedBy, status, timestamp }
    private void loadAttendance() {
        FirebaseDatabase.getInstance().getReference("Attendance")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        SimpleDateFormat keyFmt       = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                        SimpleDateFormat dateFieldFmt = new SimpleDateFormat("d/M/yyyy",   Locale.getDefault());

                        for (DataSnapshot groupSnap : snapshot.getChildren()) {
                            for (DataSnapshot recordSnap : groupSnap.getChildren()) {

                                String status = safeString(recordSnap.child("status"));
                                if (status == null) continue;
                                status = status.trim();

                                // 1) Prefer "timestamp" (epoch millis / seconds)
                                String dateKey = null;
                                Object rawTs = recordSnap.child("timestamp").getValue();
                                Long ts = null;
                                try {
                                    if (rawTs instanceof Long) ts = (Long) rawTs;
                                    else if (rawTs instanceof Double) ts = ((Double) rawTs).longValue();
                                    else if (rawTs instanceof String) ts = Long.parseLong((String) rawTs);
                                } catch (Exception ignored) {}

                                if (ts != null) {
                                    if (ts < 10000000000L) ts *= 1000; // seconds -> millis
                                    dateKey = keyFmt.format(new Date(ts));
                                } else {
                                    // 2) Fallback: parse "date" field e.g. "2/9/2026"
                                    String dateStr = safeString(recordSnap.child("date"));
                                    if (dateStr != null) {
                                        try {
                                            dateKey = keyFmt.format(dateFieldFmt.parse(dateStr.trim()));
                                        } catch (Exception ignored) {}
                                    }
                                }

                                int[] bucket = (dateKey != null && dailyAttendance.containsKey(dateKey))
                                        ? dailyAttendance.get(dateKey) : null;

                                totalAttendanceRecords++;
                                if (status.equalsIgnoreCase("Present")) {
                                    presentCount++;
                                    if (bucket != null) bucket[0]++;
                                } else if (status.equalsIgnoreCase("Absent")) {
                                    absentCount++;
                                    if (bucket != null) bucket[1]++;
                                } else if (status.equalsIgnoreCase("Leave")) {
                                    leaveCount++;
                                    if (bucket != null) bucket[2]++;
                                }
                            }
                        }
                        attendanceLoaded = true;
                        tryRender();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        attendanceLoaded = true; tryRender();
                    }
                });
    }

    private void loadUsers() {
        FirebaseDatabase.getInstance().getReference("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM", Locale.getDefault());
                        long currentTime  = System.currentTimeMillis();
                        long sevenDaysAgo = currentTime - (7L * 86400000L);

                        for (DataSnapshot snap : snapshot.getChildren()) {
                            String role   = safeString(snap.child("role"));
                            String status = safeString(snap.child("status"));

                            if (role == null || role.trim().isEmpty())
                                role = guessRoleFromFields(snap);
                            else
                                role = role.trim();

                            if (role == null) continue;
                            String st = status != null ? status.trim() : "";

                            // ── Registration date (Students & Parents only) ──
                            String normalized = extractDateKey(snap);
                            if (normalized != null) {
                                if ("Student".equalsIgnoreCase(role)
                                        && dailyStudentRegCounts.containsKey(normalized)) {
                                    dailyStudentRegCounts.put(normalized,
                                            dailyStudentRegCounts.get(normalized) + 1);
                                } else if ("Parent".equalsIgnoreCase(role)
                                        && dailyParentRegCounts.containsKey(normalized)) {
                                    dailyParentRegCounts.put(normalized,
                                            dailyParentRegCounts.get(normalized) + 1);
                                }
                            }

                            // ── createdAt trend chart ──
                            Object rawTime = snap.child("createdAt").getValue();
                            if (rawTime == null) rawTime = snap.child("registeredAt").getValue();
                            if (rawTime == null) rawTime = snap.child("timestamp").getValue();

                            Long createdAt = null;
                            try {
                                if (rawTime instanceof Long) createdAt = (Long) rawTime;
                                else if (rawTime instanceof Double) createdAt = ((Double) rawTime).longValue();
                                else if (rawTime instanceof String) createdAt = Long.parseLong((String) rawTime);
                            } catch (Exception ignored) {}

                            if (createdAt != null) {
                                if (createdAt < 10000000000L) createdAt *= 1000;
                                if (createdAt >= sevenDaysAgo && createdAt <= currentTime + 86400000L) {
                                    String dateKey = sdf.format(new Date(createdAt));
                                    if (role.equalsIgnoreCase("Student") && dailyStudents.containsKey(dateKey)) {
                                        dailyStudents.get(dateKey)[0]++; hasCreatedAt = true;
                                    } else if (role.equalsIgnoreCase("Parent") && dailyParents.containsKey(dateKey)) {
                                        dailyParents.get(dateKey)[0]++; hasCreatedAt = true;
                                    } else if (role.equalsIgnoreCase("Teacher") && st.equalsIgnoreCase("Approved")
                                            && dailyTeachers.containsKey(dateKey)) {
                                        dailyTeachers.get(dateKey)[0]++; hasCreatedAt = true;
                                    }
                                }
                            }

                            if (role.equalsIgnoreCase("Student")) {
                                sTotal++;
                                if (st.equalsIgnoreCase("Approved")) {
                                    sApproved++;
                                    String cls = safeString(snap.child("className"));
                                    if (cls != null && !cls.trim().isEmpty())
                                        classCounts.put(cls.trim(), classCounts.getOrDefault(cls.trim(), 0) + 1);
                                } else if (st.equalsIgnoreCase("Pending")) sPending++;
                                else sRejected++;
                            } else if (role.equalsIgnoreCase("Teacher")) {
                                if (st.equalsIgnoreCase("Approved")) tTotal++;
                            } else if (role.equalsIgnoreCase("Parent")) {
                                pTotal++;
                                if (st.equalsIgnoreCase("Approved")) pApproved++;
                                else if (st.equalsIgnoreCase("Pending")) pPending++;
                                else pRejected++;
                            }
                        }
                        usersLoaded = true;
                        tryRender();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {
                        usersLoaded = true; tryRender();
                    }
                });
    }

    // Kisi bhi user record se registration date nikalta hai ("yyyy-MM-dd" key mein).
    // Multiple fields aur formats (string date / epoch millis / epoch seconds) support karta hai.
    private String extractDateKey(DataSnapshot snap) {
        String[] fields = {"enrollmentDate", "registeredAt", "registrationDate",
                "createdAt", "timestamp", "joinedAt", "date"};
        String[] patterns = {"dd-MM-yyyy", "d-M-yyyy", "dd/MM/yyyy", "d/M/yyyy",
                "yyyy-MM-dd", "dd MMM yyyy", "dd-MMM-yyyy"};
        SimpleDateFormat outFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        for (String f : fields) {
            Object raw = snap.child(f).getValue();
            if (raw == null) continue;

            Long ts = null;
            if (raw instanceof Long) {
                ts = (Long) raw;
            } else if (raw instanceof Double) {
                ts = ((Double) raw).longValue();
            } else if (raw instanceof String) {
                String s = ((String) raw).trim();
                if (s.matches("\\d{9,}")) {
                    ts = Long.parseLong(s);
                } else {
                    for (String p : patterns) {
                        try {
                            SimpleDateFormat in = new SimpleDateFormat(p, Locale.getDefault());
                            in.setLenient(false);
                            return outFmt.format(in.parse(s));
                        } catch (Exception ignored) { }
                    }
                }
            }

            if (ts != null) {
                if (ts < 10000000000L) ts *= 1000; // seconds -> millis
                return outFmt.format(new Date(ts));
            }
        }
        return null;
    }

    private String guessRoleFromFields(DataSnapshot snap) {
        if (snap.hasChild("className") || snap.hasChild("fatherName") || snap.hasChild("enrolledSubjects")) return "Student";
        if (snap.hasChild("assignedSubjects") || snap.hasChild("assignedClasses") || snap.hasChild("subjects")) return "Teacher";
        if (snap.hasChild("childName") || snap.hasChild("studentId") || snap.hasChild("relation")) return "Parent";
        return null;
    }

    private void loadQuizzes() {
        FirebaseDatabase.getInstance().getReference("Quizzes")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot tSnap : snapshot.getChildren())
                            for (DataSnapshot qSnap : tSnap.getChildren())
                                if (qSnap.hasChild("title") || qSnap.hasChild("className")) totalQuizzes++;
                        quizzesLoaded = true; tryRender();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) { quizzesLoaded = true; tryRender(); }
                });
    }

    private void loadAttempts() {
        FirebaseDatabase.getInstance().getReference("QuizAttempts")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot qSnap : snapshot.getChildren())
                            totalAttempted += (int) qSnap.getChildrenCount();
                        attemptsLoaded = true; tryRender();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) { attemptsLoaded = true; tryRender(); }
                });
    }

    private void loadAssignments() {
        FirebaseDatabase.getInstance().getReference("Assignments")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot tSnap : snapshot.getChildren())
                            for (DataSnapshot aSnap : tSnap.getChildren())
                                if (aSnap.hasChild("title") || aSnap.hasChild("subject") || aSnap.hasChild("dueDate"))
                                    totalAssignments++;
                        assignmentsLoaded = true; tryRender();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) { assignmentsLoaded = true; tryRender(); }
                });
    }

    private void loadSubmissions() {
        FirebaseDatabase.getInstance().getReference("Submissions")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot aSnap : snapshot.getChildren())
                            totalSubmissions += (int) aSnap.getChildrenCount();
                        submissionsLoaded = true; tryRender();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) { submissionsLoaded = true; tryRender(); }
                });
    }

    private void tryRender() {
        if (usersLoaded && quizzesLoaded && attemptsLoaded
                && assignmentsLoaded && submissionsLoaded && dailyLoginsLoaded && attendanceLoaded)
            runOnUiThread(this::renderReport);
    }

    private void renderReport() {
        reportContainer.removeAllViews();

        addSectionHeader("Students Overview", 0xFF1565C0);
        addMetricRow(
                metric("Total",    String.valueOf(sTotal),    0xFF1565C0, 0xFFE3F2FD),
                metric("Approved", String.valueOf(sApproved), 0xFF2E7D32, 0xFFE8F5E9));
        addMetricRow(
                metric("Pending",  String.valueOf(sPending),  0xFFE65100, 0xFFFFF3E0),
                metric("Rejected", String.valueOf(sRejected), 0xFFC62828, 0xFFFFEBEE));
        addPieChart(
                new String[]{"Approved", "Pending", "Rejected"},
                new float[]{sApproved, sPending, sRejected},
                new int[]{0xFF43A047, 0xFFFF9800, 0xFFE53935},
                "Students\n" + sTotal);
        addBarChart(
                new String[]{"Approved", "Pending", "Rejected"},
                new float[]{sApproved, sPending, sRejected},
                new int[]{0xFF43A047, 0xFFFF9800, 0xFFE53935},
                "Student Requests Breakdown");

        addSectionHeader("Class-wise Students", 0xFF8E24AA);
        addClassWiseChart();

        addSectionHeader("Parents Overview", 0xFF00838F);
        addMetricRow(
                metric("Total",    String.valueOf(pTotal),    0xFF00838F, 0xFFE0F7FA),
                metric("Approved", String.valueOf(pApproved), 0xFF2E7D32, 0xFFE8F5E9));
        addMetricRow(
                metric("Pending",  String.valueOf(pPending),  0xFFE65100, 0xFFFFF3E0),
                metric("Rejected", String.valueOf(pRejected), 0xFFC62828, 0xFFFFEBEE));
        addPieChart(
                new String[]{"Approved", "Pending", "Rejected"},
                new float[]{pApproved, pPending, pRejected},
                new int[]{0xFF43A047, 0xFFFF9800, 0xFFE53935},
                "Parents\n" + pTotal);

        addSectionHeader("Teachers Overview", 0xFF6A1B9A);
        addWideMetricCard("Approved Teachers", String.valueOf(tTotal), 0xFF6A1B9A, 0xFFF3E5F5);

        addSectionHeader("Attendance Overview", 0xFF2E7D32);
        addMetricRow(
                metric("Present", String.valueOf(presentCount), 0xFF2E7D32, 0xFFE8F5E9),
                metric("Absent",  String.valueOf(absentCount),  0xFFC62828, 0xFFFFEBEE));
        addMetricRow(
                metric("Leave",   String.valueOf(leaveCount),   0xFFE65100, 0xFFFFF3E0),
                metric("Total",   String.valueOf(totalAttendanceRecords), 0xFF1565C0, 0xFFE3F2FD));
        if (totalAttendanceRecords > 0) {
            addPieChart(
                    new String[]{"Present", "Absent", "Leave"},
                    new float[]{presentCount, absentCount, leaveCount},
                    new int[]{0xFF43A047, 0xFFE53935, 0xFFFF9800},
                    "Attendance\n" + totalAttendanceRecords);
        }
        addDailyAttendanceChart();

        addSectionHeader("Daily Active Users (Last 7 Days)", 0xFF00796B);
        addDailyLoginsBarChart();
        addDailyRegBarChart("Student Registrations Per Day", dailyStudentRegCounts, 0xFF1565C0);
        addDailyRegBarChart("Parent Registrations Per Day",  dailyParentRegCounts,  0xFF00838F);
        addDailyTrendChart();
        addDailyTotalBarChart();

        addSectionHeader("Quizzes Overview", 0xFF0277BD);
        addMetricRow(
                metric("Total Quizzes", String.valueOf(totalQuizzes),  0xFF0277BD, 0xFFE1F5FE),
                metric("Attempted",     String.valueOf(totalAttempted), 0xFF00695C, 0xFFE0F2F1));

        addSectionHeader("Assignments Overview", 0xFF33691E);
        addMetricRow(
                metric("Total Assignments", String.valueOf(totalAssignments), 0xFF33691E, 0xFFF1F8E9),
                metric("Submissions",       String.valueOf(totalSubmissions), 0xFF4527A0, 0xFFEDE7F6));
    }

    private void addDailyAttendanceChart() {
        CardView card = makeCard();
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(12), dp(12), dp(12), dp(8));

        TextView tvHead = new TextView(this);
        tvHead.setText("Attendance Per Day (Present / Absent / Leave)");
        tvHead.setTypeface(null, Typeface.BOLD);
        tvHead.setTextColor(0xFF2E7D32);
        tvHead.setPadding(0, 0, 0, dp(8));
        inner.addView(tvHead);

        if (totalAttendanceRecords == 0) {
            TextView tvEmpty = new TextView(this);
            tvEmpty.setText("Pichle 7 din ka koi attendance data nahi mila.");
            tvEmpty.setGravity(Gravity.CENTER);
            tvEmpty.setPadding(0, dp(16), 0, dp(16));
            tvEmpty.setTextColor(0xFF888888);
            inner.addView(tvEmpty);
            card.addView(inner);
            reportContainer.addView(card);
            return;
        }

        List<BarEntry> entries = new ArrayList<>();
        String[] labels = new String[7];
        for (int i = 0; i < last7DayKeys.length; i++) {
            String key = last7DayKeys[i];
            int[] counts = dailyAttendance.containsKey(key) ? dailyAttendance.get(key) : new int[]{0, 0, 0};
            entries.add(new BarEntry(i, new float[]{counts[0], counts[1], counts[2]}));
            labels[i] = last7DayLabels[i];
        }

        BarDataSet ds = new BarDataSet(entries, "");
        ds.setColors(0xFF43A047, 0xFFE53935, 0xFFFF9800);
        ds.setStackLabels(new String[]{"Present", "Absent", "Leave"});

        BarChart barChart = new BarChart(this);
        barChart.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(220)));
        barChart.setData(new BarData(ds));
        barChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));
        barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        barChart.getXAxis().setGranularity(1f);
        barChart.getDescription().setEnabled(false);
        barChart.animateY(800);

        inner.addView(barChart);
        card.addView(inner);
        reportContainer.addView(card);
    }

    private void addDailyLoginsBarChart() {
        CardView card = makeCard();
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(12), dp(12), dp(12), dp(8));

        TextView tvHead = new TextView(this);
        tvHead.setText("Student Logins Per Day");
        tvHead.setTypeface(null, Typeface.BOLD);
        tvHead.setTextColor(0xFF00796B);
        tvHead.setPadding(0, 0, 0, dp(8));
        inner.addView(tvHead);

        boolean hasData = false;
        for (int count : dailyLoginCounts.values()) if (count > 0) { hasData = true; break; }

        if (!hasData) {
            TextView tvEmpty = new TextView(this);
            tvEmpty.setText("Koi login data nahi mila — students ne pichle 7 din mein login nahi kiya.");
            tvEmpty.setGravity(Gravity.CENTER);
            tvEmpty.setPadding(0, dp(16), 0, dp(16));
            tvEmpty.setTextColor(0xFF888888);
            inner.addView(tvEmpty);
            card.addView(inner);
            reportContainer.addView(card);
            return;
        }

        List<BarEntry> entries = new ArrayList<>();
        String[] labels = new String[7];
        for (int i = 0; i < last7DayKeys.length; i++) {
            String key = last7DayKeys[i];
            int count  = dailyLoginCounts.containsKey(key) ? dailyLoginCounts.get(key) : 0;
            entries.add(new BarEntry(i, count));
            labels[i] = last7DayLabels[i];
        }

        BarDataSet ds = new BarDataSet(entries, "Logins");
        ds.setColor(0xFF00796B);
        ds.setValueTextSize(10f);

        BarChart barChart = new BarChart(this);
        barChart.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(220)));
        barChart.setData(new BarData(ds));
        barChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));
        barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        barChart.getXAxis().setGranularity(1f);
        barChart.getDescription().setEnabled(false);
        barChart.getLegend().setEnabled(false);
        barChart.animateY(800);

        inner.addView(barChart);
        card.addView(inner);
        reportContainer.addView(card);
    }

    private void addDailyRegBarChart(String title, Map<String, Integer> regMap, int color) {
        CardView card = makeCard();
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(12), dp(12), dp(12), dp(8));

        TextView tvHead = new TextView(this);
        tvHead.setText(title);
        tvHead.setTypeface(null, Typeface.BOLD);
        tvHead.setTextColor(color);
        tvHead.setPadding(0, 0, 0, dp(8));
        inner.addView(tvHead);

        boolean hasData = false;
        for (int count : regMap.values()) if (count > 0) { hasData = true; break; }

        if (!hasData) {
            TextView tvEmpty = new TextView(this);
            tvEmpty.setText("Pichle 7 din mein koi naya registration nahi hua.");
            tvEmpty.setGravity(Gravity.CENTER);
            tvEmpty.setPadding(0, dp(16), 0, dp(16));
            tvEmpty.setTextColor(0xFF888888);
            inner.addView(tvEmpty);
            card.addView(inner);
            reportContainer.addView(card);
            return;
        }

        List<BarEntry> entries = new ArrayList<>();
        String[] labels = new String[7];
        for (int i = 0; i < last7DayKeys.length; i++) {
            String key = last7DayKeys[i];
            entries.add(new BarEntry(i, regMap.containsKey(key) ? regMap.get(key) : 0));
            labels[i] = last7DayLabels[i];
        }

        BarDataSet ds = new BarDataSet(entries, "");
        ds.setColor(color);
        ds.setValueTextSize(10f);

        BarChart barChart = new BarChart(this);
        barChart.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(200)));
        barChart.setData(new BarData(ds));
        barChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));
        barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        barChart.getXAxis().setGranularity(1f);
        barChart.getDescription().setEnabled(false);
        barChart.getLegend().setEnabled(false);
        barChart.animateY(800);

        inner.addView(barChart);
        card.addView(inner);
        reportContainer.addView(card);
    }

    private void addDailyTrendChart() {
        CardView card = makeCard();
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(12), dp(12), dp(12), dp(8));

        if (!hasCreatedAt) {
            TextView tvInfo = new TextView(this);
            tvInfo.setText("ℹ️  Registration trend requires 'createdAt' field in user records.");
            tvInfo.setGravity(Gravity.CENTER);
            tvInfo.setPadding(0, dp(20), 0, dp(20));
            card.addView(tvInfo);
            reportContainer.addView(card);
            return;
        }

        String[] dates = dailyStudents.keySet().toArray(new String[0]);
        List<Entry> sEnt = new ArrayList<>(), pEnt = new ArrayList<>(), tEnt = new ArrayList<>();
        for (int i = 0; i < dates.length; i++) {
            sEnt.add(new Entry(i, dailyStudents.get(dates[i])[0]));
            pEnt.add(new Entry(i, dailyParents.get(dates[i])[0]));
            tEnt.add(new Entry(i, dailyTeachers.get(dates[i])[0]));
        }

        LineChart lineChart = new LineChart(this);
        lineChart.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(240)));
        lineChart.setData(new LineData(
                makeLineDataSet(sEnt, "Students", 0xFF1565C0, 0xFF1565C0, 30),
                makeLineDataSet(pEnt, "Parents",  0xFF00838F, 0xFF00838F, 20),
                makeLineDataSet(tEnt, "Teachers", 0xFF6A1B9A, 0xFF6A1B9A, 20)));
        lineChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(dates));
        lineChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        lineChart.getXAxis().setGranularity(1f);
        lineChart.getDescription().setEnabled(false);
        lineChart.animateX(800);

        inner.addView(lineChart);
        card.addView(inner);
        reportContainer.addView(card);
    }

    private void addDailyTotalBarChart() {
        if (!hasCreatedAt) return;
        CardView card = makeCard();
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(12), dp(12), dp(12), dp(8));

        String[] dates = dailyStudents.keySet().toArray(new String[0]);
        List<BarEntry> entries = new ArrayList<>();
        for (int i = 0; i < dates.length; i++) {
            entries.add(new BarEntry(i, new float[]{
                    dailyStudents.get(dates[i])[0],
                    dailyParents.get(dates[i])[0],
                    dailyTeachers.get(dates[i])[0]}));
        }

        BarDataSet ds = new BarDataSet(entries, "");
        ds.setColors(0xFF1565C0, 0xFF00838F, 0xFF6A1B9A);
        ds.setStackLabels(new String[]{"Students", "Parents", "Teachers"});

        BarChart barChart = new BarChart(this);
        barChart.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(220)));
        barChart.setData(new BarData(ds));
        barChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(dates));
        barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        barChart.getDescription().setEnabled(false);
        barChart.animateY(800);

        inner.addView(barChart);
        card.addView(inner);
        reportContainer.addView(card);
    }

    private LineDataSet makeLineDataSet(List<Entry> entries, String label, int lineColor, int fillColor, int fillAlpha) {
        LineDataSet ds = new LineDataSet(entries, label);
        ds.setColor(lineColor); ds.setCircleColor(lineColor); ds.setLineWidth(2f);
        ds.setDrawFilled(true); ds.setFillColor(fillColor); ds.setFillAlpha(fillAlpha);
        ds.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        return ds;
    }

    private void addClassWiseChart() {
        if (classCounts.isEmpty()) return;
        String[] labels = new String[classCounts.size()];
        float[]  values = new float[classCounts.size()];
        int[] palette   = {0xFF8E24AA, 0xFF1E88E5, 0xFF00897B, 0xFFEF6C00};
        int[] colors    = new int[classCounts.size()];
        int i = 0;
        for (Map.Entry<String, Integer> entry : classCounts.entrySet()) {
            labels[i] = entry.getKey(); values[i] = entry.getValue();
            colors[i] = palette[i % palette.length]; i++;
        }
        addBarChart(labels, values, colors, "Students per Class");
    }

    private void addPieChart(String[] labels, float[] values, int[] colors, String centerText) {
        CardView card = makeCard();
        PieChart pieChart = new PieChart(this);
        pieChart.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(240)));
        List<PieEntry> entries = new ArrayList<>();
        for (int i = 0; i < labels.length; i++) if (values[i] > 0) entries.add(new PieEntry(values[i], labels[i]));
        PieDataSet ds = new PieDataSet(entries, ""); ds.setColors(colors);
        pieChart.setData(new PieData(ds)); pieChart.setCenterText(centerText);
        pieChart.getDescription().setEnabled(false); pieChart.animateY(800);
        card.addView(pieChart); reportContainer.addView(card);
    }

    private void addBarChart(String[] labels, float[] values, int[] colors, String title) {
        CardView card = makeCard();
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(12), dp(12), dp(12), dp(8));
        TextView tv = new TextView(this); tv.setText(title); tv.setTypeface(null, Typeface.BOLD); inner.addView(tv);
        BarChart barChart = new BarChart(this);
        barChart.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(200)));
        List<BarEntry> entries = new ArrayList<>();
        for (int i = 0; i < values.length; i++) entries.add(new BarEntry(i, values[i]));
        BarDataSet ds = new BarDataSet(entries, ""); ds.setColors(colors);
        barChart.setData(new BarData(ds));
        barChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));
        barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        barChart.getDescription().setEnabled(false); barChart.animateY(800);
        inner.addView(barChart); card.addView(inner); reportContainer.addView(card);
    }

    private Object[] metric(String label, String value, int textColor, int bgColor) {
        return new Object[]{label, value, textColor, bgColor};
    }

    private void addMetricRow(Object[] left, Object[] right) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(makeMetricCard((String) left[0],  (String) left[1],  (int) left[2],  (int) left[3]));
        row.addView(makeMetricCard((String) right[0], (String) right[1], (int) right[2], (int) right[3]));
        reportContainer.addView(row);
    }

    private CardView makeMetricCard(String label, String value, int textColor, int bgColor) {
        CardView card = new CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
        cp.setMargins(dp(4), dp(4), dp(4), dp(4));
        card.setLayoutParams(cp); card.setRadius(dp(14)); card.setCardBackgroundColor(bgColor);
        LinearLayout inner = new LinearLayout(this); inner.setOrientation(LinearLayout.VERTICAL); inner.setPadding(dp(14), dp(14), dp(14), dp(14));
        TextView tvVal = new TextView(this); tvVal.setText(value); tvVal.setTextSize(24f); tvVal.setTypeface(null, Typeface.BOLD); tvVal.setTextColor(textColor);
        TextView tvLab = new TextView(this); tvLab.setText(label); tvLab.setTextSize(11f);
        inner.addView(tvVal); inner.addView(tvLab); card.addView(inner); return card;
    }

    private void addWideMetricCard(String label, String value, int textColor, int bgColor) {
        CardView card = new CardView(this); card.setRadius(dp(14)); card.setCardBackgroundColor(bgColor);
        LinearLayout inner = new LinearLayout(this); inner.setOrientation(LinearLayout.VERTICAL); inner.setPadding(dp(20), dp(18), dp(20), dp(18));
        TextView tvVal = new TextView(this); tvVal.setText(value); tvVal.setTextSize(32f); tvVal.setTypeface(null, Typeface.BOLD); tvVal.setTextColor(textColor);
        TextView tvLab = new TextView(this); tvLab.setText(label);
        inner.addView(tvVal); inner.addView(tvLab); card.addView(inner); reportContainer.addView(card);
    }

    private void addSectionHeader(String title, int color) {
        TextView tv = new TextView(this); tv.setText(title); tv.setTextSize(16f); tv.setTypeface(null, Typeface.BOLD); tv.setTextColor(color);
        tv.setPadding(0, dp(15), 0, dp(5)); reportContainer.addView(tv);
    }

    private CardView makeCard() {
        CardView card = new CardView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp); card.setRadius(dp(14)); return card;
    }

    private void showLoading() {
        TextView tv = new TextView(this); tv.setText("Loading report..."); tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(50), 0, 0); reportContainer.addView(tv);
    }

    private int dp(int val) { return (int) (val * getResources().getDisplayMetrics().density); }
}