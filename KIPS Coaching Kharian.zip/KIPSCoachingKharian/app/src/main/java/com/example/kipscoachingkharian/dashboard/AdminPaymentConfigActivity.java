package com.example.kipscoachingkharian.dashboard;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class AdminPaymentConfigActivity extends AppCompatActivity {


    EditText etMerchantId, etMerchantKey, etPassphrase;
    RadioGroup rgEnvironment;
    RadioButton rbSandbox, rbLive;
    Button btnSaveConfig;

    DatabaseReference configRef;
    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_payment_config);

        etMerchantId  = findViewById(R.id.et_merchant_id);
        etMerchantKey = findViewById(R.id.et_secured_key);   // existing ID reuse
        etPassphrase  = findViewById(R.id.et_passphrase);    // passphrase field
        rgEnvironment = findViewById(R.id.rg_environment);
        rbSandbox     = findViewById(R.id.rb_sandbox);
        rbLive        = findViewById(R.id.rb_live);
        btnSaveConfig = findViewById(R.id.btn_save_config);

        // Back button
        View btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        configRef = FirebaseDatabase.getInstance().getReference("payment_config");

        dialog = new ProgressDialog(this);
        dialog.setCancelable(false);

        loadExistingConfig();

        btnSaveConfig.setOnClickListener(v -> saveConfiguration());
    }

    // ── Load existing config ──────────────────────────────────────────────────
    private void loadExistingConfig() {
        dialog.setMessage("Loading configuration...");
        dialog.show();

        configRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dialog.dismiss();
                if (snapshot.exists()) {
                    String mid  = snapshot.child("merchant_id").getValue(String.class);
                    String mkey = snapshot.child("merchant_key").getValue(String.class);
                    String pass = snapshot.child("passphrase").getValue(String.class);
                    String env  = snapshot.child("environment").getValue(String.class);

                    if (mid  != null) etMerchantId.setText(mid);
                    if (mkey != null && etMerchantKey != null) etMerchantKey.setText(mkey);
                    if (pass != null && etPassphrase  != null) etPassphrase.setText(pass);

                    if ("live".equalsIgnoreCase(env)) rbLive.setChecked(true);
                    else                              rbSandbox.setChecked(true);
                } else {
                    // ✅ Pre-fill PayFast SA Sandbox defaults
                    etMerchantId.setText("10050379");
                    if (etMerchantKey != null) etMerchantKey.setText("7asdpor0djjhv");
                    rbSandbox.setChecked(true);
                    Toast.makeText(AdminPaymentConfigActivity.this,
                            "Sandbox credentials pre-filled — please Save",
                            Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialog.dismiss();
                Toast.makeText(AdminPaymentConfigActivity.this,
                        "Failed to load: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ── Save config ───────────────────────────────────────────────────────────
    private void saveConfiguration() {
        String merchantId  = etMerchantId.getText().toString().trim();
        String merchantKey = etMerchantKey != null ? etMerchantKey.getText().toString().trim() : "";
        String passphrase  = etPassphrase  != null ? etPassphrase.getText().toString().trim()  : "";

        if (TextUtils.isEmpty(merchantId)) {
            etMerchantId.setError("Merchant ID is required");
            etMerchantId.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(merchantKey)) {
            if (etMerchantKey != null) {
                etMerchantKey.setError("Merchant Key is required");
                etMerchantKey.requestFocus();
            }
            return;
        }

        String environment = (rgEnvironment.getCheckedRadioButtonId() == R.id.rb_live)
                ? "live" : "sandbox";

        if ("live".equals(environment)) {
            Toast.makeText(this,
                    "⚠️ Live mode — real transactions will occur!", Toast.LENGTH_LONG).show();
        }

        dialog.setMessage("Saving configuration...");
        dialog.show();

        HashMap<String, Object> configMap = new HashMap<>();
        configMap.put("merchant_id",  merchantId);
        configMap.put("merchant_key", merchantKey);
        configMap.put("passphrase",   passphrase);
        configMap.put("environment",  environment);
        configMap.put("updated_at",   System.currentTimeMillis());

        configRef.setValue(configMap).addOnCompleteListener(task -> {
            dialog.dismiss();
            if (task.isSuccessful()) {
                Toast.makeText(this, "✅ PayFast configuration saved!", Toast.LENGTH_LONG).show();
                finish();
            } else {
                Toast.makeText(this, "❌ Save failed. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}