package com.example.kipscoachingkharian.dashboard;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class StudentProfileInfoActivity extends AppCompatActivity {

    private static final int REQ_CHANGE_PASSWORD = 101;

    private EditText etName, etEmail, etPhone, etStudentId;
    private TextView tvInitial;
    private ImageView btnBack;
    private TextView tvEditProfile;
    private MaterialButton btnUpdate;
    private ImageView ivChangePasswordArrow;

    private boolean isEditing = false;

    // Password change page se aaya hua data (null = password change nahi hua)
    private String pendingOldPassword = null;
    private String pendingNewPassword = null;

    private DatabaseReference mDatabase;
    private FirebaseAuth mAuth;
    private String currentUid;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_profile_info);

        mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() != null) {
            currentUid = mAuth.getCurrentUser().getUid();
            mDatabase = FirebaseDatabase.getInstance().getReference("Users").child(currentUid);
        } else {
            finish();
            return;
        }

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Processing...");
        progressDialog.setCancelable(false);

        initViews();
        loadDataFromFirebase();

        if (btnBack != null)       btnBack.setOnClickListener(v -> finish());
        if (tvEditProfile != null) tvEditProfile.setOnClickListener(v -> toggleEditMode());
        if (btnUpdate != null)     btnUpdate.setOnClickListener(v -> validateAndUpdate());

        if (ivChangePasswordArrow != null) {
            ivChangePasswordArrow.setOnClickListener(v -> {
                Intent intent = new Intent(this, StudentChangePasswordActivity.class);
                startActivityForResult(intent, REQ_CHANGE_PASSWORD);
            });
        }
    }

    /** StudentChangePasswordActivity se Done dabane par yahan aata hai */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CHANGE_PASSWORD && resultCode == RESULT_OK && data != null) {
            pendingOldPassword = data.getStringExtra(StudentChangePasswordActivity.EXTRA_OLD_PASSWORD);
            pendingNewPassword = data.getStringExtra(StudentChangePasswordActivity.EXTRA_NEW_PASSWORD);
            Toast.makeText(this,
                    "Password ready. Press 'Update & Save' to apply changes.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void initViews() {
        etName                = findViewById(R.id.etName);
        etEmail               = findViewById(R.id.etEmail);
        etPhone               = findViewById(R.id.etPhone);
        etStudentId           = findViewById(R.id.etStudentId);
        ivChangePasswordArrow = findViewById(R.id.ivChangePasswordArrow);
        tvInitial             = findViewById(R.id.tvDetailInitial);
        tvEditProfile         = findViewById(R.id.tvEditProfile);
        btnUpdate             = findViewById(R.id.btnUpdateProfile);
        btnBack               = findViewById(R.id.btnBack);

        disableFields();
    }

    private void disableFields() {
        etName.setEnabled(false);
        etEmail.setEnabled(false);
        etPhone.setEnabled(false);
        etStudentId.setEnabled(false);

        if (btnUpdate != null)             btnUpdate.setVisibility(View.GONE);
        if (ivChangePasswordArrow != null) ivChangePasswordArrow.setVisibility(View.GONE);
    }

    private void loadDataFromFirebase() {
        if (mDatabase == null) return;

        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String name = snapshot.child("name").getValue(String.class);
                    etName.setText(name != null ? name : "");
                    etEmail.setText(snapshot.child("email").getValue(String.class));
                    etPhone.setText(snapshot.child("phone").getValue(String.class));

                    String regId = snapshot.child("registrationId").getValue(String.class);
                    etStudentId.setText(regId != null ? regId : "Not Assigned");

                    if (name != null && !name.isEmpty()) {
                        tvInitial.setText(String.valueOf(name.charAt(0)).toUpperCase());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(StudentProfileInfoActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void toggleEditMode() {
        isEditing = !isEditing;

        if (isEditing) {
            etPhone.setEnabled(true);
            btnUpdate.setVisibility(View.VISIBLE);
            tvEditProfile.setText("Cancel");
            if (ivChangePasswordArrow != null) ivChangePasswordArrow.setVisibility(View.VISIBLE);
        } else {
            // Cancel dabaya — pending password bhi clear karo
            pendingOldPassword = null;
            pendingNewPassword = null;
            disableFields();
            tvEditProfile.setText("Edit");
        }
    }

    private void validateAndUpdate() {
        String newPhone = etPhone.getText().toString().trim();

        if (newPhone.isEmpty()) {
            etPhone.setError("Phone number cannot be empty");
            return;
        }

        progressDialog.show();

        if (pendingNewPassword != null) {
            // Password bhi change karna hai — pehle re-authenticate, phir sab save + logout
            changePasswordThenSave(newPhone);
        } else {
            // Sirf phone update karo
            savePhoneOnly(newPhone);
        }
    }

    /** Password change + phone update + logout */
    private void changePasswordThenSave(String newPhone) {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null || user.getEmail() == null) {
            progressDialog.dismiss();
            return;
        }

        AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(), pendingOldPassword);
        user.reauthenticate(credential).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                user.updatePassword(pendingNewPassword).addOnCompleteListener(updateTask -> {
                    if (updateTask.isSuccessful()) {
                        // Firebase Auth update hua — ab DB update karo
                        Map<String, Object> updates = new HashMap<>();
                        updates.put("phone", newPhone);
                        updates.put("password", pendingNewPassword);

                        mDatabase.updateChildren(updates).addOnSuccessListener(unused -> {
                            progressDialog.dismiss();
                            Toast.makeText(this,
                                    "Profile & Password Updated! Please login again.",
                                    Toast.LENGTH_SHORT).show();
                            logoutAndGoToLogin();
                        }).addOnFailureListener(e -> {
                            progressDialog.dismiss();
                            Toast.makeText(this, "DB Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
                    } else {
                        progressDialog.dismiss();
                        Toast.makeText(this, "Password update failed!", Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                progressDialog.dismiss();
                Toast.makeText(this, "Authentication failed!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Sirf phone update */
    private void savePhoneOnly(String newPhone) {
        Map<String, Object> updates = new HashMap<>();
        updates.put("phone", newPhone);

        mDatabase.updateChildren(updates).addOnSuccessListener(aVoid -> {
            progressDialog.dismiss();
            Toast.makeText(this, "Profile Updated Successfully!", Toast.LENGTH_SHORT).show();
            toggleEditMode();
        }).addOnFailureListener(e -> {
            progressDialog.dismiss();
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    private void logoutAndGoToLogin() {
        mAuth.signOut();
        Intent intent = new Intent(this, LoginSelectionActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}