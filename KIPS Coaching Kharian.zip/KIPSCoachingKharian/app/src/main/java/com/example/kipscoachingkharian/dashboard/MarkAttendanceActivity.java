package com.example.kipscoachingkharian.dashboard;

import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;


public class MarkAttendanceActivity extends AppCompatActivity {

    public static final String EXTRA_CLASS_ID = "extra_class_id";
    public static final String EXTRA_TITLE    = "extra_title";
    public static final String EXTRA_SUBJECT  = "extra_subject";
    public static final String EXTRA_GRADE    = "extra_grade";
    public static final String EXTRA_DATE     = "extra_date";

    private LinearLayout containerStudentAttendance;
    private TextView tvStudentCount;
    private Button btnSaveAttendance;

    private DatabaseReference mDatabase;
    private String teacherUid = "";

    private String classId, title, subject, grade, classDate;


    private final Map<String, String> statusMap = new HashMap<>();

    private final Map<String, Button[]> toggleButtonsMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mark_attendance);

        classId   = getIntent().getStringExtra(EXTRA_CLASS_ID);
        title     = getIntent().getStringExtra(EXTRA_TITLE);
        subject   = getIntent().getStringExtra(EXTRA_SUBJECT);
        grade     = getIntent().getStringExtra(EXTRA_GRADE);
        classDate = getIntent().getStringExtra(EXTRA_DATE);

        if (classDate == null || classDate.isEmpty()) {
            classDate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        }

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            teacherUid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        }
        mDatabase = FirebaseDatabase.getInstance().getReference();

        containerStudentAttendance = findViewById(R.id.containerStudentAttendance);
        tvStudentCount             = findViewById(R.id.tvStudentCount);
        btnSaveAttendance          = findViewById(R.id.btnSaveAttendance);

        TextView tvClassInfo = findViewById(R.id.tvClassInfo);
        if (tvClassInfo != null) {
            tvClassInfo.setText((title != null ? title : "Class") +
                    (subject != null ? " · " + subject : "") +
                    (grade != null ? " · " + grade : ""));
        }

        ImageView ivBack = findViewById(R.id.ivBack);
        if (ivBack != null) ivBack.setOnClickListener(v -> finish());

        btnSaveAttendance.setOnClickListener(v -> saveAttendance());

        if (classId == null || classId.isEmpty()) {
            Toast.makeText(this, "Class not found.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadStudentsForThisClass();
    }

    private void loadStudentsForThisClass() {
        String targetGrade = (grade != null) ? grade.trim() : "";
        String targetSubject = (subject != null) ? subject.trim() : "";

        mDatabase.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<String[]> matchedStudents = new ArrayList<>(); // {uid, name}

                for (DataSnapshot userSnap : snapshot.getChildren()) {
                    String role = userSnap.child("role").getValue(String.class);
                    if (!"student".equalsIgnoreCase(role)) continue;

                    String baseClass = userSnap.child("className").getValue(String.class);
                    String section   = userSnap.child("assignedSection").getValue(String.class);
                    if (baseClass == null) continue;


                    String trimmedBase = baseClass.trim();
                    boolean baseIsNumberOnly = trimmedBase.matches("\\d+");
                    String studentClass = baseIsNumberOnly && section != null && !section.trim().isEmpty()
                            ? trimmedBase + section.trim()
                            : trimmedBase;

                    if (!studentClass.equalsIgnoreCase(targetGrade)) continue;


                    if (!targetSubject.isEmpty()) {
                        boolean subjectMatch = false;
                        for (DataSnapshot s : userSnap.child("enrolledSubjects").getChildren()) {
                            String sv = s.getValue(String.class);
                            if (sv != null && sv.trim().equalsIgnoreCase(targetSubject)) {
                                subjectMatch = true;
                                break;
                            }
                        }
                        if (!subjectMatch) continue;
                    }

                    String name = userSnap.child("name").getValue(String.class);
                    matchedStudents.add(new String[]{userSnap.getKey(), name != null ? name : "Unnamed"});
                }

                loadExistingAttendanceThenRender(matchedStudents);
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MarkAttendanceActivity.this,
                        "Failed to load students: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadExistingAttendanceThenRender(List<String[]> matchedStudents) {
        mDatabase.child("Attendance").child(classId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Map<String, String> existing = new HashMap<>();
                        for (DataSnapshot s : snapshot.getChildren()) {
                            String status = s.child("status").getValue(String.class);
                            if (status != null) existing.put(s.getKey(), status);
                        }
                        renderStudentList(matchedStudents, existing);
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        renderStudentList(matchedStudents, new HashMap<>());
                    }
                });
    }

    private void renderStudentList(List<String[]> matchedStudents, Map<String, String> existingStatus) {
        containerStudentAttendance.removeAllViews();
        statusMap.clear();
        toggleButtonsMap.clear();

        if (matchedStudents.isEmpty()) {
            tvStudentCount.setText("No students found for this class.");
            btnSaveAttendance.setEnabled(false);
            return;
        }

        tvStudentCount.setText(matchedStudents.size() + " student(s) in this class");
        btnSaveAttendance.setEnabled(true);

        for (String[] student : matchedStudents) {
            String uid  = student[0];
            String name = student[1];
            String preset = existingStatus.getOrDefault(uid, "Present"); // default Present
            statusMap.put(uid, preset);
            addStudentRow(uid, name, preset);
        }
    }

    private void addStudentRow(String uid, String name, String initialStatus) {
        androidx.cardview.widget.CardView card = new androidx.cardview.widget.CardView(this);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.setMargins(0, 0, 0, 10);
        card.setLayoutParams(cardLp);
        card.setRadius(10f);
        card.setCardElevation(2f);
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(28, 20, 20, 20);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvName = new TextView(this);
        tvName.setText(name);
        tvName.setTextSize(15f);
        tvName.setTextColor(0xFF1A1A1A);
        tvName.setTypeface(null, Typeface.BOLD);
        tvName.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(tvName);

        Button btnPresent = new Button(this);
        btnPresent.setText("Present");
        btnPresent.setTextSize(12f);
        btnPresent.setTextColor(0xFFFFFFFF);
        btnPresent.setStateListAnimator(null);
        LinearLayout.LayoutParams presentLp = new LinearLayout.LayoutParams(-2, -2);
        presentLp.setMarginEnd(8);
        btnPresent.setLayoutParams(presentLp);

        Button btnAbsent = new Button(this);
        btnAbsent.setText("Absent");
        btnAbsent.setTextSize(12f);
        btnAbsent.setTextColor(0xFFFFFFFF);
        btnAbsent.setStateListAnimator(null);
        btnAbsent.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));

        Button[] pair = new Button[]{btnPresent, btnAbsent};
        toggleButtonsMap.put(uid, pair);
        applyToggleColors(pair, initialStatus);

        btnPresent.setOnClickListener(v -> {
            statusMap.put(uid, "Present");
            applyToggleColors(pair, "Present");
        });
        btnAbsent.setOnClickListener(v -> {
            statusMap.put(uid, "Absent");
            applyToggleColors(pair, "Absent");
        });

        row.addView(btnPresent);
        row.addView(btnAbsent);
        card.addView(row);
        containerStudentAttendance.addView(card);
    }

    private void applyToggleColors(Button[] pair, String status) {
        boolean present = "Present".equalsIgnoreCase(status);
        pair[0].setBackgroundTintList(ColorStateList.valueOf(present ? 0xFF2E7D32 : 0xFFC8C8C8));
        pair[1].setBackgroundTintList(ColorStateList.valueOf(!present ? 0xFFD50000 : 0xFFC8C8C8));
    }

    private void saveAttendance() {
        if (statusMap.isEmpty()) return;

        btnSaveAttendance.setEnabled(false);
        btnSaveAttendance.setText("Saving...");

        Map<String, Object> updates = new HashMap<>();
        long now = System.currentTimeMillis();

        for (Map.Entry<String, String> entry : statusMap.entrySet()) {
            String uid = entry.getKey();
            String status = entry.getValue();

            Map<String, Object> record = new HashMap<>();
            record.put("status", status);
            record.put("date", classDate);
            record.put("markedBy", teacherUid);
            record.put("timestamp", now);
            updates.put(uid, record);
        }

        mDatabase.child("Attendance").child(classId).updateChildren(updates)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "✅ Attendance saved!", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    btnSaveAttendance.setEnabled(true);
                    btnSaveAttendance.setText("Save Attendance");
                    Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}
