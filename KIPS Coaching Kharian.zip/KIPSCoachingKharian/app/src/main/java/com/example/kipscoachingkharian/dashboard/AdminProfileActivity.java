package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class AdminProfileActivity extends AppCompatActivity {

    private TextView tvName, tvRole;
    private CardView itemMyProfile, itemSettings, itemHelp, itemLogout;
    private BottomNavigationView bottomNav;

    private FirebaseAuth      mAuth;
    private DatabaseReference dbRef;   // root reference
    private DatabaseReference adminRef; // profile fields jahan bhi mile wahan point karega

    private String adminName  = "";
    private String adminEmail = "";
    private String adminPhone = "";
    private String adminRole  = "Admin";
    // ✅ REMOVED: adminPass field — password ab kahin bhi plaintext store/hold nahi hota.
    // Firebase Auth khud securely (hashed) handle karta hai. DB ya SharedPreferences
    // mein password rakhna security risk tha, isliye poori tarah hata diya gaya hai.
    private String adminUid   = "";     // ✅ UID store karo

    private static final String PREFS_NAME = "AdminPrefs";
    // ✅ REMOVED: KEY_PASS — ab password SharedPreferences mein save nahi hota.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_profile);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) { goToLogin(); return; }

        adminUid = currentUser.getUid();
        dbRef    = FirebaseDatabase.getInstance().getReference();
        adminRef = dbRef.child("Users").child(adminUid);

        initViews();
        loadAdminData();
        setupClicks();
        setupBottomNav();
    }

    private void initViews() {
        tvName        = findViewById(R.id.tv_name);
        tvRole        = findViewById(R.id.tv_role);
        itemMyProfile = findViewById(R.id.item_my_profile);
        itemSettings  = findViewById(R.id.item_settings);
        itemHelp      = findViewById(R.id.item_help);
        itemLogout    = findViewById(R.id.item_logout);
        bottomNav     = findViewById(R.id.bottomNav);
    }

    // ✅ Helper: check karta hai ke Activity abhi bhi UI operations ke liye safe hai.
    // Async Firebase callbacks activity destroy hone ke baad bhi fire ho sakte hain,
    // aur us waqt setText()/AlertDialog.show() call karna crash (BadTokenException,
    // ya destroyed-view crash) de sakta hai.
    private boolean isSafe() {
        return !isFinishing() && !isDestroyed();
    }

    // ── Firebase se admin data load ───────────────────────────────────────────
    // ✅ FIX: Admin ka actual record "Users/{uid}" mein nahi balke root-level
    // "Admin" node mein save hai (jaisa Firebase console screenshot mein dikha),
    // is liye ab teen jagah check ki jati hain:
    //   1) Users/{uid}   2) root "Admin" node   3) Users node email se query
    private void loadAdminData() {
        adminRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!isSafe()) return; // ✅ activity gone, ignore
                if (snapshot.exists() && snapshot.hasChild("name")) {
                    // UID node mein data mil gaya
                    populateAdminData(snapshot);
                } else {
                    // ✅ Users/{uid} mein nahi mila — root-level "Admin" node check karo
                    dbRef.child("Admin").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot adminSnap) {
                            if (!isSafe()) return;
                            if (adminSnap.exists() && adminSnap.hasChild("name")) {
                                populateAdminData(adminSnap);
                                // ✅ Ab password update etc. isi node pe hoga
                                adminRef = dbRef.child("Admin");
                            } else {
                                // Root "Admin" node mein bhi nahi mila — email se Users query karo
                                queryUsersByEmail();
                            }
                        }
                        @Override public void onCancelled(@NonNull DatabaseError e) {
                            if (isSafe()) queryUsersByEmail();
                        }
                    });
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {
                if (isSafe()) queryUsersByEmail();
            }
        });
    }

    private void queryUsersByEmail() {
        String email = mAuth.getCurrentUser() != null
                ? mAuth.getCurrentUser().getEmail() : null;
        if (email == null) return;

        dbRef.child("Users").orderByChild("email").equalTo(email)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snap) {
                        if (!isSafe()) return;
                        for (DataSnapshot child : snap.getChildren()) {
                            populateAdminData(child);
                            // ✅ Actual node key save karo taake password update sahi path pe ho
                            adminRef = child.getRef();
                            break;
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    private void populateAdminData(DataSnapshot snapshot) {
        adminName  = get(snapshot, "name");
        adminEmail = get(snapshot, "email");
        adminPhone = get(snapshot, "phone");
        if (adminPhone.isEmpty()) adminPhone = get(snapshot, "username");
        if (adminPhone.isEmpty()) adminPhone = get(snapshot, "phoneNumber");
        if (adminPhone.isEmpty()) adminPhone = get(snapshot, "phone no");
        adminRole  = get(snapshot, "role");
        // ✅ REMOVED: password ab DB se read/store nahi hota.

        tvName.setText(adminName.isEmpty() ? "KIPS Admin" : adminName);
        tvRole.setText(adminRole.isEmpty() ? "Admin"      : adminRole);
    }

    private void setupClicks() {
        itemMyProfile.setOnClickListener(v -> showCredentialsDialog());
        itemSettings.setOnClickListener(v  -> showChangePasswordDialog());
        itemHelp.setOnClickListener(v      -> showAboutDialog());
        itemLogout.setOnClickListener(v    -> showLogoutDialog());
    }

    // ── Saved credentials dialog ──────────────────────────────────────────────
    private void showCredentialsDialog() {
        String savedEmail = adminEmail.isEmpty() ? "——" : adminEmail;
        String savedPhone = adminPhone.isEmpty() ? "——" : adminPhone;
        // ✅ Password ab kabhi dikhaya nahi jata (ye plaintext nahi rakha jata).
        // Sirf ek masked placeholder dikhaya jata hai; asal change "Change Password"
        // dialog se hoga jahan current password verify karke naya set hota hai.

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(20), dp(24), dp(8));

        TextView tvTitle = new TextView(this);
        tvTitle.setText("👤  Admin Profile");
        tvTitle.setTextSize(17f);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(0xFF1565C0);
        tvTitle.setPadding(0, 0, 0, dp(12));
        layout.addView(tvTitle);

        addDivider(layout);
        layout.addView(makeCredRow("🧑  Name",     adminName.isEmpty()  ? "——" : adminName));
        layout.addView(makeCredRow("📧  Email",    savedEmail));
        layout.addView(makeCredRow("📞  Phone",    savedPhone));
        layout.addView(makeCredRow("🔑  Password", "••••••••"));
        layout.addView(makeCredRow("🏷️  Role",     adminRole.isEmpty()  ? "Admin" : adminRole));

        new AlertDialog.Builder(this)
                .setView(layout)
                .setPositiveButton("✏️ Edit Profile", (d, w) -> showEditProfileDialog())
                .setNegativeButton("Close", null)
                .show();
    }

    private LinearLayout makeCredRow(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(14);
        row.setLayoutParams(rp);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(12f);
        tvLabel.setTextColor(0xFF888888);
        row.addView(tvLabel);

        TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(15f);
        tvValue.setTextColor(0xFF1A1A1A);
        tvValue.setTypeface(null, android.graphics.Typeface.BOLD);
        tvValue.setPadding(0, dp(2), 0, dp(10));
        row.addView(tvValue);

        addDivider(row);
        return row;
    }

    private void addDivider(LinearLayout parent) {
        View line = new View(this);
        line.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        line.setBackgroundColor(0xFFF0F0F0);
        parent.addView(line);
    }

    // ── Edit Profile dialog ───────────────────────────────────────────────────
    private void showEditProfileDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(16), dp(24), dp(8));

        EditText etName  = makeField("Full Name",    adminName);
        EditText etPhone = makeField("Phone Number", adminPhone);

        layout.addView(makeLabel("Name"));  layout.addView(etName);
        layout.addView(makeLabel("Phone")); layout.addView(etPhone);

        new AlertDialog.Builder(this)
                .setTitle("✏️ Edit Profile")
                .setView(layout)
                .setPositiveButton("Save", (d, w) -> {
                    String name  = etName.getText().toString().trim();
                    String phone = etPhone.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "Naam zaroor likhein", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    HashMap<String, Object> map = new HashMap<>();
                    map.put("name",  name);
                    map.put("phone", phone);
                    adminRef.updateChildren(map)
                            .addOnSuccessListener(a -> {
                                if (isSafe()) {
                                    adminName  = name;
                                    adminPhone = phone;
                                    tvName.setText(name); // ✅ UI turant refresh
                                    Toast.makeText(this, "✅ Profile updated!", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .addOnFailureListener(e -> {
                                if (isSafe()) {
                                    Toast.makeText(this, "❌ Update failed: " + e.getMessage(),
                                            Toast.LENGTH_LONG).show();
                                }
                            });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Change Password dialog ────────────────────────────────────────────────
    private void showChangePasswordDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(16), dp(24), dp(8));

        EditText etOld     = makeField("Purana password", "");
        EditText etNew     = makeField("Naya password (min 6)", "");
        EditText etConfirm = makeField("Naya password confirm", "");

        int passType = android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD;
        etOld.setInputType(passType);
        etNew.setInputType(passType);
        etConfirm.setInputType(passType);

        layout.addView(makeLabel("Current Password")); layout.addView(etOld);
        layout.addView(makeLabel("New Password"));     layout.addView(etNew);
        layout.addView(makeLabel("Confirm Password")); layout.addView(etConfirm);

        new AlertDialog.Builder(this)
                .setTitle("🔑 Change Password")
                .setView(layout)
                .setPositiveButton("Update", (d, w) -> {
                    String oldP = etOld.getText().toString().trim();
                    String newP = etNew.getText().toString().trim();
                    String conP = etConfirm.getText().toString().trim();

                    if (oldP.isEmpty()) {
                        Toast.makeText(this, "Purana password likhein", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (newP.length() < 6) {
                        Toast.makeText(this, "Password kam az kam 6 characters ka ho",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (!newP.equals(conP)) {
                        Toast.makeText(this, "Password match nahi kiya", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    updatePassword(oldP, newP);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ✅ FIX: Password sirf Firebase Auth mein update hota hai (securely hashed).
    // Database ya SharedPreferences mein plaintext password ab kabhi save nahi hota —
    // pehle wala code DB aur local storage mein raw password likh raha tha, jo
    // security risk tha (agar DB rules loose hon to koi bhi sab passwords parh sakta tha).
    private void updatePassword(String oldPassword, String newPassword) {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) return;

        String email = user.getEmail() != null ? user.getEmail() : adminEmail;
        if (email == null || email.isEmpty()) {
            Toast.makeText(this, "❌ Email nahi mila, password change nahi ho sakta",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        AuthCredential cred = EmailAuthProvider.getCredential(email, oldPassword);

        user.reauthenticate(cred).addOnCompleteListener(reAuth -> {
            if (!isSafe()) return; // ✅ activity band ho chuki, aage kuch mat karo
            if (!reAuth.isSuccessful()) {
                // Note: agar admin ka account Email/Password provider se sign-in
                // nahi hai (e.g. Google sign-in), ye hamesha fail hoga chahe
                // "purana password" sahi bhi ho. Filhal app sirf email/password
                // login assume karta hai.
                Toast.makeText(this, "❌ Purana password galat hai",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // ── Firebase Auth password update (securely handled by Firebase) ──
            user.updatePassword(newPassword).addOnCompleteListener(task -> {
                if (!isSafe()) return;
                if (!task.isSuccessful()) {
                    Toast.makeText(this,
                            "❌ Update failed: " + (task.getException() != null
                                    ? task.getException().getMessage() : "Unknown"),
                            Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(this,
                        "✅ Password successfully change ho gaya!",
                        Toast.LENGTH_SHORT).show();
            });
        });
    }

    private void showAboutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("About App")
                .setMessage("KIPS Coaching Kharian\nVersion: 1.0\nStatus: Running")
                .setPositiveButton("OK", null)
                .show();
    }

    private void showLogoutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Kya aap logout karna chahte hain?")
                .setPositiveButton("Yes", (d, w) -> {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().clear().apply();
                    mAuth.signOut();
                    goToLogin();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void setupBottomNav() {
        if (bottomNav == null) return;
        bottomNav.setSelectedItemId(R.id.nav_profile);
        bottomNav.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_home) {
                Intent i = new Intent(this, AdminDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
                return true;
            }
            return false;
        });
    }

    private void goToLogin() {
        Intent i = new Intent(this, LoginSelectionActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    private EditText makeField(String hint, String value) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setText(value);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(4);
        et.setLayoutParams(lp);
        return et;
    }

    private TextView makeLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12f);
        tv.setTextColor(0xFF888888);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        tv.setLayoutParams(lp);
        return tv;
    }

    private String get(DataSnapshot snap, String key) {
        // ✅ FIX: Firebase mein kabhi field String hoti hai, kabhi Number (Long/Double).
        // Pehle seedha String.class maang rahe thay jo Long value milne par crash
        // kar deta tha ("Failed to convert value of type java.lang.Long to String").
        // Ab generic Object nikal ke safely String mein convert karte hain.
        Object v = snap.child(key).getValue();
        return v != null ? String.valueOf(v) : "";
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}