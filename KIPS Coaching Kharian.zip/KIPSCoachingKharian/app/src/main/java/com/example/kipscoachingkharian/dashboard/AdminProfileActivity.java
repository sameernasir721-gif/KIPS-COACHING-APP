package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class AdminProfileActivity extends AppCompatActivity {

    private TextView tvName, tvRole;
    private CardView itemMyProfile, itemSettings, itemHelp, itemLogout;
    private BottomNavigationView bottomNav;

    private FirebaseAuth      mAuth;
    private DatabaseReference adminRef;

    private String adminName  = "";
    private String adminEmail = "";
    private String adminPhone = "";
    private String adminRole  = "Admin";
    private String adminPass  = "";

    private static final String PREFS_NAME = "AdminPrefs";
    private static final String KEY_EMAIL  = "admin_email";
    private static final String KEY_PASS   = "admin_pass";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_profile);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) { goToLogin(); return; }

        adminRef = FirebaseDatabase.getInstance()
                .getReference("Users").child(currentUser.getUid());

        initViews();
        loadAdminData();
        setupClicks();
        setupBottomNav();
    }

    private void initViews() {
        tvName        = findViewById(R.id.tv_name);
        tvRole        = findViewById(R.id.tv_role);
        itemMyProfile = findViewById(R.id.item_my_profile);
        itemSettings  = findViewById(R.id.item_settings);
        itemHelp      = findViewById(R.id.item_help);
        itemLogout    = findViewById(R.id.item_logout);
        bottomNav     = findViewById(R.id.bottomNav);
    }

    // ── Firebase se admin data load ───────────────────────────────────────────
    private void loadAdminData() {
        adminRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) return;

                adminName  = get(snapshot, "name");
                adminEmail = get(snapshot, "email");
                adminPhone = get(snapshot, "phone");
                if (adminPhone.isEmpty()) adminPhone = get(snapshot, "username");
                if (adminPhone.isEmpty()) adminPhone = get(snapshot, "phoneNumber");
                adminRole  = get(snapshot, "role");
                adminPass  = get(snapshot, "password");

                // SharedPreferences se pass bhi check karo
                if (adminPass.isEmpty()) {
                    adminPass = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                            .getString(KEY_PASS, "");
                }

                tvName.setText(adminName.isEmpty() ? "KIPS Admin" : adminName);
                tvRole.setText(adminRole.isEmpty() ? "Admin"      : adminRole);
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        });
    }

    private void setupClicks() {
        // ✅ My Profile: pehle credentials show, phir edit option
        itemMyProfile.setOnClickListener(v -> showCredentialsDialog());
        itemSettings.setOnClickListener(v  -> showChangePasswordDialog());
        itemHelp.setOnClickListener(v      -> showAboutDialog());
        itemLogout.setOnClickListener(v    -> showLogoutDialog());
    }

    // ── Saved credentials dialog ──────────────────────────────────────────────
    private void showCredentialsDialog() {
        // SharedPreferences se saved pass
        // ✅ Firebase se jo data load hua wahi seedha show karo
        String savedEmail = adminEmail.isEmpty() ? "——" : adminEmail;
        String savedPhone = adminPhone.isEmpty() ? "——" : adminPhone;

        String savedPass = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getString(KEY_PASS, adminPass);
        if (savedPass.isEmpty()) savedPass = adminPass;
        if (savedPass.isEmpty()) savedPass = "——";

        // Dialog layout
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(20), dp(24), dp(8));

        // Header
        TextView tvTitle = new TextView(this);
        tvTitle.setText("👤  Admin Profile");
        tvTitle.setTextSize(17f);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(0xFF1565C0);
        tvTitle.setPadding(0, 0, 0, dp(12));
        layout.addView(tvTitle);

        // Divider
        addDivider(layout);

        // Credential rows
        layout.addView(makeCredRow("🧑  Name",     adminName.isEmpty()  ? "——" : adminName));
        layout.addView(makeCredRow("📧  Email",    savedEmail));
        layout.addView(makeCredRow("📞  Phone",    savedPhone));
        layout.addView(makeCredRow("🔑  Password", savedPass));
        layout.addView(makeCredRow("🏷️  Role",     adminRole.isEmpty()  ? "Admin" : adminRole));

        new AlertDialog.Builder(this)
                .setView(layout)
                .setPositiveButton("✏️ Edit Profile", (d, w) -> showEditProfileDialog())
                .setNegativeButton("Close", null)
                .show();
    }

    // ── Credential row helper ─────────────────────────────────────────────────
    private LinearLayout makeCredRow(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(14);
        row.setLayoutParams(rp);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(12f);
        tvLabel.setTextColor(0xFF888888);
        row.addView(tvLabel);

        TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(15f);
        tvValue.setTextColor(0xFF1A1A1A);
        tvValue.setTypeface(null, android.graphics.Typeface.BOLD);
        tvValue.setPadding(0, dp(2), 0, dp(10));
        row.addView(tvValue);

        addDivider(row);
        return row;
    }

    private void addDivider(LinearLayout parent) {
        View line = new View(this);
        line.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        line.setBackgroundColor(0xFFF0F0F0);
        parent.addView(line);
    }

    // ── Edit Profile dialog ───────────────────────────────────────────────────
    private void showEditProfileDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(16), dp(24), dp(8));

        EditText etName  = makeField("Full Name",     adminName);
        EditText etEmail = makeField("Email",         adminEmail);
        EditText etPhone = makeField("Phone Number",  adminPhone);

        layout.addView(makeLabel("Name"));  layout.addView(etName);
        layout.addView(makeLabel("Email")); layout.addView(etEmail);
        layout.addView(makeLabel("Phone")); layout.addView(etPhone);

        new AlertDialog.Builder(this)
                .setTitle("✏️ Edit Profile")
                .setView(layout)
                .setPositiveButton("Save", (d, w) -> {
                    String name  = etName.getText().toString().trim();
                    String email = etEmail.getText().toString().trim();
                    String phone = etPhone.getText().toString().trim();

                    if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                        Toast.makeText(this, "Saare fields fill karein",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    saveProfile(name, email, phone);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveProfile(String name, String email, String phone) {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) return;

        HashMap<String, Object> map = new HashMap<>();
        map.put("name",  name);
        map.put("email", email);
        map.put("phone", phone);

        adminRef.updateChildren(map).addOnSuccessListener(a -> {
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putString(KEY_EMAIL, email).apply();

            if (!email.equals(adminEmail)) {
                user.updateEmail(email).addOnSuccessListener(b ->
                        Toast.makeText(this, "✅ Profile updated!", Toast.LENGTH_SHORT).show());
            } else {
                Toast.makeText(this, "✅ Profile updated!", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(e ->
                Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    // ── Change Password dialog — programmatic (no XML needed) ─────────────────
    private void showChangePasswordDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(16), dp(24), dp(8));

        EditText etOld     = makeField("Purana password", "");
        EditText etNew     = makeField("Naya password (min 6)", "");
        EditText etConfirm = makeField("Naya password confirm", "");

        etOld.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        etNew.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        etConfirm.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

        layout.addView(makeLabel("Current Password")); layout.addView(etOld);
        layout.addView(makeLabel("New Password"));     layout.addView(etNew);
        layout.addView(makeLabel("Confirm Password")); layout.addView(etConfirm);

        new AlertDialog.Builder(this)
                .setTitle("🔑 Change Password")
                .setView(layout)
                .setPositiveButton("Update", (d, w) -> {
                    String oldP = etOld.getText().toString().trim();
                    String newP = etNew.getText().toString().trim();
                    String conP = etConfirm.getText().toString().trim();

                    if (oldP.isEmpty()) {
                        Toast.makeText(this, "Purana password likhein", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (newP.length() < 6) {
                        Toast.makeText(this, "Password kam az kam 6 characters ka ho",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (!newP.equals(conP)) {
                        Toast.makeText(this, "Password match nahi kiya",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    updatePassword(oldP, newP);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void updatePassword(String oldPassword, String newPassword) {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) return;

        String email = user.getEmail() != null ? user.getEmail() : adminEmail;
        AuthCredential cred = EmailAuthProvider.getCredential(email, oldPassword);

        user.reauthenticate(cred).addOnCompleteListener(reAuth -> {
            if (!reAuth.isSuccessful()) {
                Toast.makeText(this, "❌ Purana password galat hai",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            user.updatePassword(newPassword).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    adminRef.child("password").setValue(newPassword);
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                            .putString(KEY_PASS, newPassword).apply();
                    Toast.makeText(this, "✅ Password successfully change ho gaya!",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "❌ Error: " +
                                    (task.getException() != null
                                            ? task.getException().getMessage() : "Unknown"),
                            Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    // ── About ─────────────────────────────────────────────────────────────────
    private void showAboutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("About App")
                .setMessage("KIPS Coaching Kharian\nVersion: 1.0\nStatus: Running")
                .setPositiveButton("OK", null)
                .show();
    }

    // ── Logout ────────────────────────────────────────────────────────────────
    private void showLogoutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Kya aap logout karna chahte hain?")
                .setPositiveButton("Yes", (d, w) -> {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().clear().apply();
                    mAuth.signOut();
                    goToLogin();
                })
                .setNegativeButton("No", null)
                .show();
    }

    // ── Bottom Nav ────────────────────────────────────────────────────────────
    private void setupBottomNav() {
        if (bottomNav == null) return;
        bottomNav.setSelectedItemId(R.id.nav_profile);
        bottomNav.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_home) {
                Intent i = new Intent(this, AdminDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
                return true;
            }
            return false;
        });
    }

    private void goToLogin() {
        Intent i = new Intent(this, LoginSelectionActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    // ── UI helpers ────────────────────────────────────────────────────────────
    private EditText makeField(String hint, String value) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setText(value);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(4);
        et.setLayoutParams(lp);
        return et;
    }

    private TextView makeLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12f);
        tv.setTextColor(0xFF888888);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        tv.setLayoutParams(lp);
        return tv;
    }

    private String get(DataSnapshot snap, String key) {
        String v = snap.child(key).getValue(String.class);
        return v != null ? v : "";
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}