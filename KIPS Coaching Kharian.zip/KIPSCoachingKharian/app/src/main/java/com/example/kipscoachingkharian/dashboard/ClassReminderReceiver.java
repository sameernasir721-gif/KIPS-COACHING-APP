package com.example.kipscoachingkharian.dashboard;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.example.kipscoachingkharian.R;

public class ClassReminderReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID   = "class_reminder_channel";
    private static final String CHANNEL_NAME = "Class Reminders";
    private static final int    NOTIF_ID     = 5001;

    @Override
    public void onReceive(Context context, Intent intent) {
        String subject   = intent.getStringExtra("subject");
        String className = intent.getStringExtra("className");
        String time      = intent.getStringExtra("time");

        if (subject   == null) subject   = "Class";
        if (className == null) className = "";
        if (time      == null) time      = "";

        String title = "⏰ Class in 15 minutes!";
        String msg   = subject
                + (!className.isEmpty() ? " — " + className : "")
                + (!time.isEmpty()      ? " at " + time      : "");

        createNotificationChannel(context);

        // Dashboard pe click karne par TeacherTimeScheduleActivity khule
        Intent openIntent = new Intent(context, TeacherTimeScheduleActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                context, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_anno)
                .setContentTitle(title)
                .setContentText(msg)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(msg))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pi);

        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, builder.build());
    }

    private void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("15 minute reminder before each class");
            NotificationManager nm =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }
}