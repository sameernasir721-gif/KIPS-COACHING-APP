package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AddTeacherActivity extends AppCompatActivity {

    private TextInputEditText etName, etPhone, etEmail, etPass, etSubject, etClass;
    private Button btnCreate;
    private FirebaseAuth      mAuth;
    private DatabaseReference mDatabase;

    private static final String[] ALL_SUBJECTS = {
            "Mathematics", "Physics", "Chemistry", "Biology", "English",
            "Urdu", "Computer Science", "Pakistan Studies", "Islamiat"
    };

    private static final String[] ALL_CLASSES = {
            "9A", "9B", "10A", "10B", "11A", "11B", "12A", "12B"
    };

    private static final String[] ALLOWED_DOMAINS = {
            "gmail.com", "yahoo.com", "outlook.com", "hotmail.com",
            "icloud.com", "live.com"
    };

    private final List<String> selectedSubjects = new ArrayList<>();
    private final List<String> selectedClasses  = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_teacher);

        mAuth     = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        etName    = findViewById(R.id.etTeacherName);
        etPhone   = findViewById(R.id.etTeacherPhone);
        etEmail   = findViewById(R.id.etTeacherEmail);
        etSubject = findViewById(R.id.etTeacherSubject);
        etPass    = findViewById(R.id.etTeacherPass);
        etClass   = findViewById(R.id.etTeacherClass);
        btnCreate = findViewById(R.id.btnCreateTeacherSubmit);

        etSubject.setFocusable(false);
        etSubject.setOnClickListener(v ->
                showMultiSelectDialog("Subjects", ALL_SUBJECTS, selectedSubjects, etSubject));

        if (etClass != null) {
            etClass.setFocusable(false);
            etClass.setOnClickListener(v ->
                    showMultiSelectDialog("Classes", ALL_CLASSES, selectedClasses, etClass));
        }

        btnCreate.setOnClickListener(v -> validateAndCreate());
    }

    private void showMultiSelectDialog(String title, String[] array,
                                       List<String> selectedList,
                                       TextInputEditText editText) {
        boolean[] checked = new boolean[array.length];
        for (int i = 0; i < array.length; i++)
            if (selectedList.contains(array[i])) checked[i] = true;

        new AlertDialog.Builder(this)
                .setTitle("Select " + title)
                .setMultiChoiceItems(array, checked, (dialog, which, isChecked) -> {
                    if (isChecked) { if (!selectedList.contains(array[which])) selectedList.add(array[which]); }
                    else selectedList.remove(array[which]);
                })
                .setPositiveButton("OK", (dialog, which) ->
                        editText.setText(TextUtils.join(", ", selectedList)))
                .show();
    }

    private void validateAndCreate() {
        String name     = etName.getText().toString().trim();
        String username = etPhone.getText().toString().trim();
        String email    = etEmail.getText().toString().trim();
        String pass     = etPass.getText().toString().trim();

        if (name.isEmpty()) { etName.setError("Name required"); return; }
        if (username.isEmpty()) { etPhone.setError("Phone/Username required"); return; }

        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Valid email is required"); return;
        }

        boolean domainValid = false;
        String domain = email.substring(email.indexOf("@") + 1).toLowerCase();
        for (String d : ALLOWED_DOMAINS) { if (domain.equals(d)) { domainValid = true; break; } }
        if (!domainValid) {
            etEmail.setError("Please use a real email provider (Gmail/Yahoo/Outlook)"); return;
        }

        if (pass.length() < 6) { etPass.setError("Password must be 6+ chars"); return; }

        if (selectedSubjects.isEmpty()) {
            Toast.makeText(this, "Pehle subjects select karein!", Toast.LENGTH_SHORT).show(); return;
        }
        if (selectedClasses.isEmpty()) {
            Toast.makeText(this, "Pehle classes select karein!", Toast.LENGTH_SHORT).show(); return;
        }

        btnCreate.setEnabled(false);
        btnCreate.setText("Creating...");
        createTeacherAccount(name, username, email, pass);
    }

    private void createTeacherAccount(String name, String username, String email, String pass) {
        SharedPreferences prefs = getSharedPreferences("AdminPrefs", MODE_PRIVATE);
        String adminEmail = prefs.getString("admin_email", null);
        String adminPass  = prefs.getString("admin_pass",  null);

        mAuth.createUserWithEmailAndPassword(email, pass)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            user.sendEmailVerification();
                            String uid = user.getUid();
                            saveToDatabase(uid, name, username, email, pass, adminEmail, adminPass);
                        }
                    } else {
                        btnCreate.setEnabled(true);
                        btnCreate.setText("Create Account");
                        Toast.makeText(this, "Error: " + task.getException().getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void saveToDatabase(String uid, String name, String username,
                                String email, String pass,
                                String adminEmail, String adminPass) {

        String subjectsStr = TextUtils.join(", ", selectedSubjects);
        String classesStr  = TextUtils.join(", ", selectedClasses);

        // ✅ Sab fields save ho rahi hain — name, username, password, classes, subjects
        Map<String, Object> userMap = new HashMap<>();
        userMap.put("uid",             uid);
        userMap.put("name",            name);
        userMap.put("username",        username);       // phone number
        userMap.put("email",           email);
        userMap.put("password",        pass);           // ✅ password
        userMap.put("role",            "Teacher");
        userMap.put("status",          "Approved");
        userMap.put("subjects",        subjectsStr);    // ✅ subjects string
        userMap.put("assignedClasses", classesStr);     // ✅ classes string
        userMap.put("assignedSubject", subjectsStr);    // extra field — ManageTeacher bhi read karta hai
        userMap.put("className",       classesStr);     // extra field — ManageTeacher bhi read karta hai
        userMap.put("isEmailVerified", false);
        userMap.put("createdAt",       System.currentTimeMillis());

        // Subject aur Class maps — query ke liye
        Map<String, Object> subjectsMap = new HashMap<>();
        for (String s : selectedSubjects) subjectsMap.put(s, true);

        Map<String, Object> classesMap = new HashMap<>();
        for (String c : selectedClasses) classesMap.put(c, true);

        userMap.put("assignedSubjects", subjectsMap);
        userMap.put("assignedClassMap", classesMap);

        // ── Users node ───────────────────────────────────────────────────
        mDatabase.child("Users").child(uid).setValue(userMap)
                .addOnCompleteListener(task -> {
                    // ── Teachers node ────────────────────────────────────
                    mDatabase.child("Teachers").child(uid).setValue(userMap);

                    // ── Admin session restore ─────────────────────────────
                    if (adminEmail != null && adminPass != null) {
                        mAuth.signInWithEmailAndPassword(adminEmail, adminPass)
                                .addOnCompleteListener(t -> {
                                    btnCreate.setEnabled(true);
                                    btnCreate.setText("Create Account");
                                    Toast.makeText(this,
                                            "✅ Teacher account created!",
                                            Toast.LENGTH_LONG).show();
                                    sendLoginCredentialsEmail(email, name, pass);
                                    finish();
                                });
                    } else {
                        btnCreate.setEnabled(true);
                        btnCreate.setText("Create Account");
                        Toast.makeText(this, "✅ Teacher created!", Toast.LENGTH_SHORT).show();
                        sendLoginCredentialsEmail(email, name, pass);
                        finish();
                    }
                });
    }

    private void sendLoginCredentialsEmail(String email, String name, String password) {
        try {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:"));
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
            intent.putExtra(Intent.EXTRA_SUBJECT, "Your KIPS Coaching Teacher Account - Login Details");
            intent.putExtra(Intent.EXTRA_TEXT,
                    "Dear " + name + ",\n\n"
                            + "Your Teacher account has been created at KIPS Coaching Kharian.\n\n"
                            + "Login Email: " + email + "\n"
                            + "Password: "    + password + "\n\n"
                            + "Please verify your email using the link sent to your inbox, then login to the app.\n\n"
                            + "Regards,\nKIPS Coaching Kharian");
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No email app found.", Toast.LENGTH_SHORT).show();
        }
    }
}