package com.example.kipscoachingkharian.dashboard;

import android.app.DownloadManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.os.Build;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TeacherTimeScheduleActivity extends AppCompatActivity {

    private View layoutPdfActions;
    private MaterialButton btnViewTimetablePdf;
    private MaterialButton btnShareTimetablePdf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_time_schedule);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, LoginSelectionActivity.class));
            finish();
            return;
        }

        ImageView ivMenu = findViewById(R.id.ivMenu);
        ivMenu.setOnClickListener(v -> finish());

        // ✅ View PDF + Download views
        layoutPdfActions     = findViewById(R.id.layoutPdfActions);
        btnViewTimetablePdf  = findViewById(R.id.btnViewTimetablePdf);
        btnShareTimetablePdf = findViewById(R.id.btnShareTimetablePdf);
        styleButtons();

        setupBottomNav();
        loadLatestTimetablePdf();
        checkScheduleConflicts();
    }

    // ── Buttons ko student wali screenshot jesi style do ──────────────────────
    private void styleButtons() {
        if (btnViewTimetablePdf != null) {
            // VIEW button — light blue background, red text
            btnViewTimetablePdf.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(0xFFBBDEFB)); // light blue
            btnViewTimetablePdf.setTextColor(0xFFD50000);                    // red text
            btnViewTimetablePdf.setText("VIEW");
            btnViewTimetablePdf.setStrokeColor(
                    android.content.res.ColorStateList.valueOf(0xFFBBDEFB));
        }

        if (btnShareTimetablePdf != null) {
            // DOWNLOAD button — red background, white text
            btnShareTimetablePdf.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(0xFFD50000)); // red
            btnShareTimetablePdf.setTextColor(0xFFFFFFFF);                   // white text
            btnShareTimetablePdf.setText("DOWNLOAD");
        }
    }

    // ── "Announcements/Teachers" se sabse latest timetable PDF dhoondo ────────
    private void loadLatestTimetablePdf() {
        if (btnViewTimetablePdf == null) return;

        FirebaseDatabase.getInstance().getReference("Announcements").child("Teachers")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String latestPdfUrl = null;
                        long latestTimestamp = -1;

                        for (DataSnapshot item : snapshot.getChildren()) {
                            String type = item.child("type").getValue(String.class);
                            String pdfUrl = item.child("pdfUrl").getValue(String.class);
                            Long timestampL = item.child("timestamp").getValue(Long.class);
                            long timestamp = (timestampL != null) ? timestampL : 0;

                            if ("timetable".equals(type) && pdfUrl != null && !pdfUrl.isEmpty()
                                    && timestamp > latestTimestamp) {
                                latestTimestamp = timestamp;
                                latestPdfUrl = pdfUrl;
                            }
                        }

                        if (latestPdfUrl != null) {
                            final String pdfUrlToOpen = latestPdfUrl;

                            if (layoutPdfActions != null) layoutPdfActions.setVisibility(View.VISIBLE);

                            btnViewTimetablePdf.setOnClickListener(v -> {
                                try {
                                    Intent pdfIntent = new Intent(Intent.ACTION_VIEW);
                                    pdfIntent.setDataAndType(Uri.parse(pdfUrlToOpen), "application/pdf");
                                    pdfIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                            | Intent.FLAG_GRANT_READ_URI_PERMISSION);

                                    if (pdfIntent.resolveActivity(getPackageManager()) != null) {
                                        startActivity(pdfIntent);
                                    } else {
                                        // Koi app "application/pdf" handle nahi kar rahi —
                                        // browser mein kholo (jo URL ko khud detect kar lega)
                                        Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                                                Uri.parse(pdfUrlToOpen));
                                        startActivity(browserIntent);
                                    }
                                } catch (Exception e) {
                                    Toast.makeText(TeacherTimeScheduleActivity.this,
                                            "PDF nahi khul saki: " + e.getMessage(),
                                            Toast.LENGTH_LONG).show();
                                }
                            });

                            if (btnShareTimetablePdf != null) {
                                btnShareTimetablePdf.setOnClickListener(v ->
                                        downloadTimetablePdf(pdfUrlToOpen));
                            }
                        } else {
                            if (layoutPdfActions != null) layoutPdfActions.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (layoutPdfActions != null) layoutPdfActions.setVisibility(View.GONE);
                    }
                });
    }

    // ── PDF ko asal mein phone ke Downloads folder mein save karo ─────────────
    private void downloadTimetablePdf(String pdfUrl) {
        try {
            String fileName = "KIPS_Timetable_" + System.currentTimeMillis() + ".pdf";

            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(pdfUrl));
            request.setTitle("KIPS Timetable");
            request.setDescription("Timetable PDF download ho rahi hai...");
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS, fileName);
            request.setMimeType("application/pdf");
            request.allowScanningByMediaScanner();

            DownloadManager downloadManager =
                    (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (downloadManager != null) {
                downloadManager.enqueue(request);
                Toast.makeText(this,
                        "📥 Download shuru ho gayi — Downloads folder mein milegi",
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Download service available nahi hai",
                        Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Download nahi ho saki: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    // ── Check conflicts in latest timetable for this teacher ─────────────────
    private void checkScheduleConflicts() {
        String currentUserName = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getDisplayName() : null;

        // Get teacher name from Firebase Users node
        String uid = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : null;
        if (uid == null) return;

        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot userSnap) {
                        String teacherName = userSnap.child("name").getValue(String.class);
                        if (teacherName == null || teacherName.isEmpty()) return;

                        // Load latest Timetable_Records
                        FirebaseDatabase.getInstance().getReference("Timetable_Records")
                                .orderByChild("timestamp")
                                .limitToLast(1)
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        for (DataSnapshot record : snapshot.getChildren()) {
                                            DataSnapshot slotsSnap = record.child("slots");
                                            List<Map<String, Object>> mySlots = new ArrayList<>();

                                            for (DataSnapshot slot : slotsSnap.getChildren()) {
                                                String teacher = slot.child("teacher").getValue(String.class);
                                                if (teacher != null && teacher.trim().equalsIgnoreCase(teacherName.trim())) {
                                                    java.util.HashMap<String, Object> s = new java.util.HashMap<>();
                                                    s.put("day",       slot.child("day").getValue(String.class));
                                                    s.put("time",      slot.child("time").getValue(String.class));
                                                    s.put("subject",   slot.child("subject").getValue(String.class));
                                                    s.put("className", slot.child("className").getValue(String.class));
                                                    mySlots.add(s);
                                                }
                                            }

                                            // Check conflicts
                                            List<String> conflicts = new ArrayList<>();
                                            for (int i = 0; i < mySlots.size(); i++) {
                                                for (int j = i + 1; j < mySlots.size(); j++) {
                                                    String day1  = (String) mySlots.get(i).get("day");
                                                    String time1 = (String) mySlots.get(i).get("time");
                                                    String day2  = (String) mySlots.get(j).get("day");
                                                    String time2 = (String) mySlots.get(j).get("time");

                                                    if (day1 != null && day1.equalsIgnoreCase(day2)
                                                            && time1 != null && time1.equalsIgnoreCase(time2)) {
                                                        String msg = "⚠️ " + day1 + " at " + time1 + ":\n"
                                                                + "• " + mySlots.get(i).get("subject") + " (" + mySlots.get(i).get("className") + ")"
                                                                + "\n• " + mySlots.get(j).get("subject") + " (" + mySlots.get(j).get("className") + ")";
                                                        if (!conflicts.contains(msg)) conflicts.add(msg);
                                                    }
                                                }
                                            }

                                            if (!conflicts.isEmpty()) {
                                                StringBuilder sb = new StringBuilder("Schedule conflicts detected:\n\n");
                                                for (String c : conflicts) sb.append(c).append("\n\n");

                                                new AlertDialog.Builder(TeacherTimeScheduleActivity.this)
                                                        .setTitle("⚠️ Schedule Conflict!")
                                                        .setMessage(sb.toString().trim())
                                                        .setPositiveButton("OK", null)
                                                        .setCancelable(true)
                                                        .show();
                                            }

                                            // Schedule reminders for today's classes
                                            scheduleClassReminders(mySlots);
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {}
                                });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    // ── Schedule 15-min reminders for today's classes ───────────────────────
    private void scheduleClassReminders(List<Map<String, Object>> mySlots) {
        String[] days = {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
        Calendar now = Calendar.getInstance();
        String todayName = days[now.get(Calendar.DAY_OF_WEEK) - 1];

        createNotificationChannel();
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        int reqCode = 1000;
        for (Map<String, Object> slot : mySlots) {
            String day     = (String) slot.get("day");
            String time    = (String) slot.get("time");
            String subject = (String) slot.get("subject");
            String cls     = (String) slot.get("className");

            if (day == null || time == null || !day.equalsIgnoreCase(todayName)) continue;

            // Parse start time from "3:40-4:20" format
            String startTime = time.contains("-") ? time.split("-")[0].trim() : time.trim();
            try {
                // Try both "H:mm" and "h:mm a" formats
                Calendar classTime = Calendar.getInstance();
                boolean parsed = false;

                // Format: "3:40" (24-hour or 12-hour without AM/PM)
                if (startTime.matches("\\d{1,2}:\\d{2}")) {
                    String[] parts = startTime.split(":");
                    int hour   = Integer.parseInt(parts[0]);
                    int minute = Integer.parseInt(parts[1]);
                    classTime.set(Calendar.HOUR_OF_DAY, hour);
                    classTime.set(Calendar.MINUTE, minute);
                    classTime.set(Calendar.SECOND, 0);
                    parsed = true;
                }

                if (!parsed) continue;

                // Reminder = 15 mins before class
                classTime.add(Calendar.MINUTE, -15);

                // Only schedule if reminder time is in future
                if (classTime.after(now)) {
                    Intent intent = new Intent(this, ClassReminderReceiver.class);
                    intent.putExtra("subject", subject);
                    intent.putExtra("className", cls);
                    intent.putExtra("time", time);

                    PendingIntent pi = PendingIntent.getBroadcast(
                            this, reqCode++, intent,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                            && !alarmManager.canScheduleExactAlarms()) {
                        alarmManager.set(AlarmManager.RTC_WAKEUP,
                                classTime.getTimeInMillis(), pi);
                    } else {
                        alarmManager.setExact(AlarmManager.RTC_WAKEUP,
                                classTime.getTimeInMillis(), pi);
                    }
                }
            } catch (Exception ignored) {}
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    "class_reminder", "Class Reminders",
                    NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Upcoming class notifications");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    // ── BroadcastReceiver — fires 15 mins before class ───────────────────────
    public static class ClassReminderReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String subject   = intent.getStringExtra("subject");
            String className = intent.getStringExtra("className");
            String time      = intent.getStringExtra("time");

            android.app.Notification notif =
                    new androidx.core.app.NotificationCompat.Builder(context, "class_reminder")
                            .setSmallIcon(android.R.drawable.ic_dialog_info)
                            .setContentTitle("📚 Upcoming Class in 15 mins!")
                            .setContentText(subject + " | " + className + " at " + time)
                            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                            .setAutoCancel(true)
                            .build();

            NotificationManager nm =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify((int) System.currentTimeMillis(), notif);
        }
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                startActivity(new Intent(this, TeacherDashboardActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_Announcment) {
                startActivity(new Intent(this, TeacherAnnouncementsActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileMenuActivity.class));
                finish(); return true;
            }
            return false;
        });
    }
}