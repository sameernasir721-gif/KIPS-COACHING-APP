package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.regex.Pattern;

public class TeacherChangePasswordActivity extends AppCompatActivity {

    public static final String EXTRA_OLD_PASSWORD = "old_password";
    public static final String EXTRA_NEW_PASSWORD = "new_password";

    private EditText etCurrentPassword, etNewPassword, etConfirmNewPassword;
    private ImageView ivToggleCurrentPass, ivToggleNewPass, ivToggleConfirmPass, btnBack;
    private MaterialButton btnDone;

    private boolean isCurrentPassVisible = false;
    private boolean isNewPassVisible     = false;
    private boolean isConfirmPassVisible = false;

    private String actualStoredPassword = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_change_password);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() == null) { finish(); return; }

        DatabaseReference mDatabase = FirebaseDatabase.getInstance()
                .getReference("Users")
                .child(mAuth.getCurrentUser().getUid());

        initViews();
        loadStoredPassword(mDatabase);

        btnBack.setOnClickListener(v -> finish());
        ivToggleCurrentPass.setOnClickListener(v -> toggleVisibility(etCurrentPassword, isCurrentPassVisible = !isCurrentPassVisible));
        ivToggleNewPass.setOnClickListener(v -> toggleVisibility(etNewPassword, isNewPassVisible = !isNewPassVisible));
        ivToggleConfirmPass.setOnClickListener(v -> toggleVisibility(etConfirmNewPassword, isConfirmPassVisible = !isConfirmPassVisible));
        btnDone.setOnClickListener(v -> validateAndReturn());
    }

    private void initViews() {
        etCurrentPassword    = findViewById(R.id.etCurrentPassword);
        etNewPassword        = findViewById(R.id.etNewPassword);
        etConfirmNewPassword = findViewById(R.id.etConfirmNewPassword);
        ivToggleCurrentPass  = findViewById(R.id.ivToggleCurrentPass);
        ivToggleNewPass      = findViewById(R.id.ivToggleNewPass);
        ivToggleConfirmPass  = findViewById(R.id.ivToggleConfirmPass);
        btnDone              = findViewById(R.id.btnDone);
        btnBack              = findViewById(R.id.btnBack);
    }

    private void loadStoredPassword(DatabaseReference db) {
        db.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String dbPass = snapshot.child("password").getValue(String.class);
                if (dbPass != null) actualStoredPassword = dbPass;
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(TeacherChangePasswordActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void validateAndReturn() {
        String oldPass     = etCurrentPassword.getText().toString().trim();
        String newPass     = etNewPassword.getText().toString().trim();
        String confirmPass = etConfirmNewPassword.getText().toString().trim();

        if (oldPass.isEmpty()) {
            etCurrentPassword.setError("Current password required");
            return;
        }
        if (!oldPass.equals(actualStoredPassword)) {
            etCurrentPassword.setError("Incorrect current password!");
            return;
        }
        if (newPass.isEmpty()) {
            etNewPassword.setError("New password required");
            return;
        }
        if (!isStrongPassword(newPass)) {
            etNewPassword.setError("Weak password! Use 8+ chars with symbols.");
            return;
        }
        if (confirmPass.isEmpty() || !newPass.equals(confirmPass)) {
            etConfirmNewPassword.setError("Passwords do not match!");
            return;
        }

        Intent result = new Intent();
        result.putExtra(EXTRA_OLD_PASSWORD, oldPass);
        result.putExtra(EXTRA_NEW_PASSWORD, newPass);
        setResult(RESULT_OK, result);
        finish();
    }

    private boolean isStrongPassword(String password) {
        return Pattern.compile(
                "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$"
        ).matcher(password).matches();
    }

    private void toggleVisibility(EditText et, boolean visible) {
        et.setInputType(visible
                ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        et.setSelection(et.getText().length());
    }
}