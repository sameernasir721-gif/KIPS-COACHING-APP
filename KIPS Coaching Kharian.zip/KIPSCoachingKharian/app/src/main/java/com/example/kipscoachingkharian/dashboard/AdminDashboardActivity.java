package com.example.kipscoachingkharian.dashboard;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.firebase.auth.FirebaseAuth;

/**
 * Activity representing the main dashboard for Administrators.
 * Currently serves as a landing page after login and handles secure logout functionality.
 * Future admin features (e.g., managing users, posting notices) will be linked here.
 */
public class AdminDashboardActivity extends AppCompatActivity {

    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        // Initialize UI components
        btnLogout = findViewById(R.id.btnLogout);

        // Set up Logout functionality
        btnLogout.setOnClickListener(v -> {
            // 1. Sign out from Firebase Authentication
            FirebaseAuth.getInstance().signOut();

            // 2. Notify the user
            Toast.makeText(this, "Logged Out", Toast.LENGTH_SHORT).show();

            // 3. Navigate back to the Login Selection screen
            Intent intent = new Intent(this, LoginSelectionActivity.class);

            // 4. Clear the activity stack
            // FLAG_ACTIVITY_NEW_TASK: Starts the activity in a new task.
            // FLAG_ACTIVITY_CLEAR_TASK: Clears all existing activities in the current task.
            // This prevents the user from pressing 'Back' to return to the dashboard after logging out.
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

            startActivity(intent);
            finish(); // Ensure this activity is destroyed
        });
    }
}