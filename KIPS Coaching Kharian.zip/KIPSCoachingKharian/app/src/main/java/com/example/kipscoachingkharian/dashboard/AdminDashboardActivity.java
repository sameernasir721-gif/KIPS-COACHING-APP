package com.example.kipscoachingkharian.dashboard;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity; // Login screen import kiye
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminDashboardActivity extends AppCompatActivity {

    private static final String PREFS_NAME  = "AdminPrefs";
    private static final String KEY_EMAIL   = "admin_email";
    private static final String KEY_PASS    = "admin_pass";

    private DatabaseReference mDatabase;
    private FirebaseAuth mAuth;

    // Navigation and Drawer fields
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private ImageView ivMenuToggle, ivProfile;

    private CardView cardStudent, cardTeacher, cardParents, cardPayments,
            cardSystemReports, cardNotifications, cardPaymentConfig, cardSchedule, cardManageUser, cardFeedback;

    private TextView tvparent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Firebase Instance Initialize karein
        mAuth     = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // 2. 🔥 SESSION CHECK LOGIC: Agar admin logged in nahi hai, toh selection screen par bhejein
        if (mAuth.getCurrentUser() == null) {
            goToLoginSelection();
            return; // Niche wala code execute nahi hoga
        }

        // Agar admin logged in hai, toh hi layout show ho
        setContentView(R.layout.activity_admin_dashboard);

        initViews();
        setupNavigationDrawer();
        setupCardClicks();
        showAdminName();
    }

    private void initViews() {
        // Drawer elements binding
        drawerLayout      = findViewById(R.id.drawerLayout);
        navigationView    = findViewById(R.id.navigationView);
        ivMenuToggle      = findViewById(R.id.ivMenuToggle);
        ivProfile         = findViewById(R.id.ivProfile);

        // Grid Cards
        cardStudent       = findViewById(R.id.Student);
        cardTeacher       = findViewById(R.id.Teacher);
        cardParents       = findViewById(R.id.Parents);
        cardFeedback      = findViewById(R.id.cardFeedback);
        cardPayments      = findViewById(R.id.Payments);
        cardSystemReports = findViewById(R.id.SystemReports);
        cardNotifications = findViewById(R.id.Notifications);
        cardPaymentConfig = findViewById(R.id.PaymentConfig);
        cardSchedule      = findViewById(R.id.cardTimetable);
        cardManageUser    = findViewById(R.id.cardManageUser);

        tvparent          = findViewById(R.id.tvparent);
    }

    private void setupNavigationDrawer() {
        // FIXED TOGGLE CLICK ENGINE (Forced slide action activation)
        if (ivMenuToggle != null) {
            ivMenuToggle.setOnClickListener(v -> {
                if (!drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.openDrawer(GravityCompat.START, true);
                } else {
                    drawerLayout.closeDrawer(GravityCompat.START, true);
                }
            });
        }

        if (ivProfile != null) {
            ivProfile.setOnClickListener(v -> openProfileActivity());
        }

        // Side panel option tracker routing
        if (navigationView != null) {
            navigationView.setNavigationItemSelectedListener(item -> {
                int id = item.getItemId();

                if (id == R.id.nav_home) {
                    drawerLayout.closeDrawer(GravityCompat.START, true);
                    Toast.makeText(this, "You are already on Home Dashboard", Toast.LENGTH_SHORT).show();

                } else if (id == R.id.nav_profile) {
                    drawerLayout.closeDrawer(GravityCompat.START, true);
                    openProfileActivity();
                }

                return true;
            });
        }
    }

    // Profile Screen launch karne ka method
    private void openProfileActivity() {
        Intent profileIntent = new Intent(AdminDashboardActivity.this, AdminProfileActivity.class);
        startActivity(profileIntent);
    }

    private void showAdminName() {
        if (mAuth.getCurrentUser() != null) {
            String uid = mAuth.getCurrentUser().getUid();
            mDatabase.child("Users").child(uid).child("name")
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            String name = snapshot.getValue(String.class);
                            if (name != null) tvparent.setText("Hi! " + name);
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {}
                    });
        }
    }

    private void setupCardClicks() {
        cardStudent.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, ManageStudentRequestsActivity.class);
            startActivity(intent);
        });

        cardTeacher.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, AddTeacherActivity.class);
            startActivity(intent);
        });

        cardParents.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, ManageParentRequestsActivity.class);
            startActivity(intent);
        });

        cardSchedule.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, TimetableActivity.class);
            startActivity(intent);
        });
        cardFeedback.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, FeedManagmentActivity.class);
            startActivity(intent);
        });

        cardNotifications.setOnClickListener(v ->
                startActivity(new Intent(AdminDashboardActivity.this, ManageAnnouncementsActivity.class)));

        cardPayments.setOnClickListener(v ->
                startActivity(new Intent(AdminDashboardActivity.this, AdminFeeActivity.class)));

        cardSystemReports.setOnClickListener(v ->
                startActivity(new Intent(AdminDashboardActivity.this, SystemReportsActivity.class)));

        cardPaymentConfig.setOnClickListener(v ->
                startActivity(new Intent(AdminDashboardActivity.this, AdminPaymentConfigActivity.class)));

        cardManageUser.setOnClickListener(v ->
                startActivity(new Intent(AdminDashboardActivity.this, ManageUserActivity.class)));
    }

    // Simple routing method to Login Selection Screen
    private void goToLoginSelection() {
        Intent intent = new Intent(AdminDashboardActivity.this, LoginSelectionActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    public static void saveAdminCredentials(android.content.Context ctx, String email, String password) {
        ctx.getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putString(KEY_EMAIL, email)
                .putString(KEY_PASS, password)
                .apply();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout != null && drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START, true);
        } else {
            super.onBackPressed();
        }
    }
}
