package com.example.kipscoachingkharian.dashboard;

public class StudyMaterial {
    private String title;
    private String type;
    private String subject;
    private String grade;
    private String description;
    private String fileUrl;
    private String fileSize;
    private String uploadedDate;
    private String teacherId;
    private long   createdAt;
    private String status; // "draft" or "uploaded"

    public StudyMaterial() {}

    public StudyMaterial(String title, String type, String subject, String grade,
                         String description, String fileUrl, String fileSize,
                         String uploadedDate, String teacherId, long createdAt, String status) {
        this.title        = title;
        this.type         = type;
        this.subject      = subject;
        this.grade        = grade;
        this.description  = description;
        this.fileUrl      = fileUrl;
        this.fileSize     = fileSize;
        this.uploadedDate = uploadedDate;
        this.teacherId    = teacherId;
        this.createdAt    = createdAt;
        this.status       = status;
    }

    public String getTitle()        { return title; }
    public String getType()         { return type; }
    public String getSubject()      { return subject; }
    public String getGrade()        { return grade; }
    public String getDescription()  { return description; }
    public String getFileUrl()      { return fileUrl; }
    public String getFileSize()     { return fileSize; }
    public String getUploadedDate() { return uploadedDate; }
    public String getTeacherId()    { return teacherId; }
    public long   getCreatedAt()    { return createdAt; }
    public String getStatus()       { return status; }

    public void setTitle(String title)               { this.title        = title; }
    public void setType(String type)                 { this.type         = type; }
    public void setSubject(String subject)           { this.subject      = subject; }
    public void setGrade(String grade)               { this.grade        = grade; }
    public void setDescription(String description)   { this.description  = description; }
    public void setFileUrl(String fileUrl)           { this.fileUrl      = fileUrl; }
    public void setFileSize(String fileSize)         { this.fileSize     = fileSize; }
    public void setUploadedDate(String uploadedDate) { this.uploadedDate = uploadedDate; }
    public void setTeacherId(String teacherId)       { this.teacherId    = teacherId; }
    public void setCreatedAt(long createdAt)         { this.createdAt    = createdAt; }
    public void setStatus(String status)             { this.status       = status; }
}