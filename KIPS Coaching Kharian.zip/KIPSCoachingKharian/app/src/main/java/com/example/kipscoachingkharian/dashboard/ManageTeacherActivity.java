package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class ManageTeacherActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private LinearLayout containerTeachers;
    private TextView tvCount, tvLoading;
    private Button btnAddTeacher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_teacher);

        mDatabase         = FirebaseDatabase.getInstance().getReference();
        containerTeachers = findViewById(R.id.containerTeachersList);
        tvCount           = findViewById(R.id.tvTotalTeachersCount);
        tvLoading         = findViewById(R.id.tvTeachersLoading);
        btnAddTeacher     = findViewById(R.id.btnAddNewTeacher);

        btnAddTeacher.setOnClickListener(v ->
                startActivity(new Intent(this, AddTeacherActivity.class)));

        loadTeachersData();
    }

    // ── Firebase: Users node se Teachers load ────────────────────────────────
    private void loadTeachersData() {
        if (tvLoading != null) tvLoading.setVisibility(View.VISIBLE);

        mDatabase.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                containerTeachers.removeAllViews();
                if (tvLoading != null) tvLoading.setVisibility(View.GONE);

                int count = 0;
                for (DataSnapshot snap : snapshot.getChildren()) {
                    String role = snap.child("role").getValue(String.class);
                    if (role == null || !"Teacher".equalsIgnoreCase(role)) continue;

                    // ✅ Deleted (soft-deleted) teachers ko list mein show na karo
                    String delStatus = snap.child("status").getValue(String.class);
                    if ("Deleted".equalsIgnoreCase(delStatus)) continue;

                    count++;

                    String nodeKey = snap.getKey(); // teacher naam (key)

                    // ── Name ──────────────────────────────────────────────
                    String name = snap.child("name").getValue(String.class);
                    if (name == null || name.isEmpty()) name = nodeKey;

                    // ── Username (phone number) ───────────────────────────
                    String username = snap.child("username").getValue(String.class);
                    if (username == null) username = snap.child("phone").getValue(String.class);
                    if (username == null) username = "-";

                    // ── Email ─────────────────────────────────────────────
                    String email = snap.child("email").getValue(String.class);
                    if (email == null) email = "-";

                    // ── Password ──────────────────────────────────────────
                    String pass = snap.child("password").getValue(String.class);
                    if (pass == null) pass = "-";

                    // ── Class (multiple field names check) ────────────────
                    String cls = snap.child("className").getValue(String.class);
                    if (cls == null || cls.isEmpty())
                        cls = snap.child("assignedClasses").getValue(String.class);
                    if (cls == null || cls.isEmpty())
                        cls = snap.child("assignedClass").getValue(String.class);
                    if (cls == null || cls.isEmpty()) cls = "-";

                    // ── Subject (multiple field names check) ──────────────
                    String subject = snap.child("subjects").getValue(String.class);
                    if (subject == null || subject.isEmpty())
                        subject = snap.child("assignedSubject").getValue(String.class);
                    if (subject == null || subject.isEmpty())
                        subject = snap.child("subject").getValue(String.class);
                    if (subject == null || subject.isEmpty()) subject = "-";

                    // ── Status ────────────────────────────────────────────
                    String status = snap.child("status").getValue(String.class);
                    if (status == null) status = "Approved";

                    createTeacherCard(nodeKey, name, username, email, pass, cls, subject, status);
                }

                if (tvCount != null) tvCount.setText(String.valueOf(count));
                if (count == 0) showEmptyState("Koi teacher registered nahi hai abhi.");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (tvLoading != null) tvLoading.setVisibility(View.GONE);
                Toast.makeText(ManageTeacherActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ── Teacher card ──────────────────────────────────────────────────────────
    private void createTeacherCard(String nodeKey, String name, String username,
                                   String email, String pass,
                                   String cls, String subject, String status) {
        androidx.cardview.widget.CardView card = new androidx.cardview.widget.CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(cp);
        card.setRadius(dp(12));
        card.setCardElevation(dp(4));
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(16), dp(16), dp(16), dp(16));

        // Teacher naam — bold blue header
        TextView tvName = new TextView(this);
        tvName.setText("👤 " + name);
        tvName.setTextSize(16f);
        tvName.setTypeface(null, android.graphics.Typeface.BOLD);
        tvName.setTextColor(0xFF1565C0);
        tvName.setPadding(0, 0, 0, dp(10));
        inner.addView(tvName);

        // ✅ Saari fields show — username, password, class bhi
        TextView tvInfo = new TextView(this);
        tvInfo.setText(
                "👤 Username:  " + username
                        + "\n📧 Email:     " + email
                        + "\n🔑 Password:  " + pass
                        + "\n🏫 Classes:   " + cls
                        + "\n📚 Subjects:  " + subject
                        + "\n✅ Status:    " + status);
        tvInfo.setTextSize(13.5f);
        tvInfo.setTextColor(0xFF333333);
        tvInfo.setLineSpacing(dp(4), 1f);
        tvInfo.setPadding(0, 0, 0, dp(12));
        inner.addView(tvInfo);

        // Edit / Delete buttons
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        Button btnEdit = new Button(this);
        btnEdit.setText("✏️ Edit");
        btnEdit.setBackgroundColor(0xFF1E88E5);
        btnEdit.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, -2, 1f);
        p1.setMarginEnd(dp(8));
        btnEdit.setLayoutParams(p1);
        btnEdit.setOnClickListener(v ->
                showEditDialog(nodeKey, name, username, cls, subject));

        Button btnDelete = new Button(this);
        btnDelete.setText("🗑️ Delete");
        btnDelete.setBackgroundColor(0xFFE53935);
        btnDelete.setTextColor(0xFFFFFFFF);
        btnDelete.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        btnDelete.setOnClickListener(v -> promptDelete(nodeKey, name));

        btnRow.addView(btnEdit);
        btnRow.addView(btnDelete);
        inner.addView(btnRow);

        card.addView(inner);
        containerTeachers.addView(card);
    }

    // ── Edit dialog ───────────────────────────────────────────────────────────
    private void showEditDialog(String nodeKey, String cName, String cUsername,
                                String cClass, String cSub) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(16), dp(24), dp(8));

        EditText etName     = makeField("Teacher Name",             cName);
        EditText etUsername = makeField("Username / Phone",         cUsername);
        EditText etClass    = makeField("Classes (e.g. 9A, 10B)",  cClass);
        EditText etSub      = makeField("Subjects (e.g. Physics)",  cSub);

        layout.addView(makeLabel("Name"));     layout.addView(etName);
        layout.addView(makeLabel("Username")); layout.addView(etUsername);
        layout.addView(makeLabel("Classes"));  layout.addView(etClass);
        layout.addView(makeLabel("Subjects")); layout.addView(etSub);

        new AlertDialog.Builder(this)
                .setTitle("Edit Teacher")
                .setView(layout)
                .setPositiveButton("Save", (d, w) -> {
                    String name     = etName.getText().toString().trim();
                    String username = etUsername.getText().toString().trim();
                    String cls      = etClass.getText().toString().trim();
                    String sub      = etSub.getText().toString().trim();

                    if (name.isEmpty()) {
                        Toast.makeText(this, "Naam khali nahi ho sakta!",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Map<String, Object> map = new HashMap<>();
                    map.put("name",            name);
                    map.put("username",        username.isEmpty() ? "-" : username);
                    map.put("className",       cls.isEmpty() ? "-" : cls);
                    map.put("assignedClasses", cls.isEmpty() ? "-" : cls);
                    map.put("subjects",        sub.isEmpty() ? "-" : sub);
                    map.put("assignedSubject", sub.isEmpty() ? "-" : sub);

                    // Users node update
                    mDatabase.child("Users").child(nodeKey).updateChildren(map)
                            .addOnSuccessListener(a -> {
                                Toast.makeText(this, "✅ Teacher updated!",
                                        Toast.LENGTH_SHORT).show();
                                loadTeachersData(); // refresh
                            });

                    // Teachers node bhi update karo (agar wahan hai)
                    mDatabase.child("Teachers").child(nodeKey).updateChildren(map);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Delete (Soft Delete — Firebase se actual record delete nahi hota) ─────
    private void promptDelete(String nodeKey, String name) {
        new AlertDialog.Builder(this)
                .setTitle("Confirm Delete")
                .setMessage("\"" + name + "\" ko delete karna chahte hain?")
                .setPositiveButton("Delete", (d, w) -> {
                    Map<String, Object> deleteMap = new HashMap<>();
                    deleteMap.put("status", "Deleted");

                    // Sirf status update hoga, record Firebase se delete nahi hoga
                    // (student history / purana data linked rahega)
                    mDatabase.child("Users").child(nodeKey).updateChildren(deleteMap)
                            .addOnSuccessListener(a -> {
                                Toast.makeText(this, name + " removed from list.",
                                        Toast.LENGTH_SHORT).show();
                                loadTeachersData(); // list refresh
                            });

                    mDatabase.child("Teachers").child(nodeKey).updateChildren(deleteMap);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── UI Helpers ────────────────────────────────────────────────────────────
    private EditText makeField(String hint, String value) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setText(value != null ? value : "");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(4);
        et.setLayoutParams(lp);
        return et;
    }

    private TextView makeLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12f);
        tv.setTextColor(0xFF888888);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        tv.setLayoutParams(lp);
        return tv;
    }

    private void showEmptyState(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(60), 0, 0);
        containerTeachers.addView(tv);
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}