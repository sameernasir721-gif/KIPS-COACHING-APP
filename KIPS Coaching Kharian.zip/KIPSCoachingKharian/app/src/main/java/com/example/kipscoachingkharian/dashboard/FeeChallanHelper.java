package com.example.kipscoachingkharian.dashboard;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;


public class FeeChallanHelper {

    private static final long LATE_FINE = 200L;

    private static final Set<String> SPECIAL = new HashSet<>(Arrays.asList(
            "urdu",
            "pakistan studies", "pak studies", "pak study", "pakistan study", "p.st", "pst",
            "islamiat", "islamic studies", "islamiyat", "islamiyat studies"));

    public static void generateOnApproval(@NonNull final String studentUid) {
        final DatabaseReference root = FirebaseDatabase.getInstance().getReference();

        root.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot db) {
                DataSnapshot u = db.child("Users").child(studentUid);
                if (!u.exists()) return;

                String name = str(u.child("name"));
                if (name == null) return;
                String cls      = str(u.child("className"));
                String username = str(u.child("username"));

                long feeN = num(db.child("payment_config").child("fee_per_subject"), 3000L);
                long feeS = num(db.child("payment_config").child("fee_special_subject"), 2500L);

                List<String> subs = new ArrayList<>();
                for (DataSnapshot s : u.child("enrolledSubjects").getChildren()) {
                    String x = str(s);
                    if (x != null) subs.add(x);
                }

                long base = 0;
                Map<String, Long> subjectFees = new HashMap<>();
                for (String s : subs) {
                    long f = SPECIAL.contains(s.trim().toLowerCase()) ? feeS : feeN;
                    subjectFees.put(s, f);
                    base += f;
                }

                Calendar cal = Calendar.getInstance();
                int today = cal.get(Calendar.DAY_OF_MONTH);
                cal.set(Calendar.DAY_OF_MONTH, 15);
                String dueDate  = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).format(cal.getTime());
                String month    = new SimpleDateFormat("MMMM yyyy",  Locale.ENGLISH).format(cal.getTime());
                String monthKey = month.replace(" ", "_");

                // Agar nayi approval par late fine nahi chahiye to isay 0L kar do
                long fine  = today > 15 ? LATE_FINE : 0L;
                long total = base + fine;

                // Challan pehle se bana ho to dobara na banao
                if (db.child("Fees").child(studentUid).child(monthKey).exists()) return;

                Map<String, Object> d = new HashMap<>();
                d.put("studentName",   name);
                d.put("className",     cls == null ? "" : cls);
                d.put("month",         month);
                d.put("dueDate",       dueDate);
                d.put("subjects",      subs);
                d.put("feePerSubject", feeN);
                d.put("totalSubjects", subs.size());
                d.put("baseFee",       String.valueOf(base));
                d.put("lateFine",      String.valueOf(fine));
                d.put("amount",        String.valueOf(total));
                d.put("subjectFees",   subjectFees);
                d.put("generatedAt",   System.currentTimeMillis());
                d.put("status",        "Unpaid");
                root.child("Fees").child(studentUid).child(monthKey).setValue(d);

                // Student ko notification
                push(root, studentUid,
                        name + "'s fee challan for " + month + " has been generated. Amount: Rs. "
                                + total + ". Due Date: " + dueDate,
                        name, month, total, dueDate, fine);

                // Parent ko notification
                if (username != null && !username.trim().isEmpty()) {
                    for (DataSnapshot p : db.child("Users").getChildren()) {
                        if (!"Parent".equalsIgnoreCase(str(p.child("role")))) continue;
                        String linked = str(p.child("linkedChildUsername"));
                        if (linked == null || !linked.trim().equalsIgnoreCase(username.trim())) continue;
                        push(root, p.getKey(),
                                "Your child " + name + "'s fee challan for " + month
                                        + " has been generated. Amount: Rs. " + total
                                        + ". Due Date: " + dueDate,
                                name, month, total, dueDate, fine);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError e) {}
        });
    }

    private static void push(DatabaseReference root, String target, String msg, String name,
                             String month, long amount, String due, long fine) {
        Map<String, Object> n = new HashMap<>();
        n.put("title",       fine > 0 ? "⚠️ Fee Overdue!" : "📋 Fee Challan Generated");
        n.put("message",     msg);
        n.put("type",        "fee_pending");
        n.put("studentName", name);
        n.put("amount",      String.valueOf(amount));
        n.put("dueDate",     due);
        n.put("month",       month);
        n.put("isLate",      fine > 0);
        n.put("lateFine",    String.valueOf(fine));
        n.put("timestamp",   System.currentTimeMillis());
        n.put("isRead",      false);
        root.child("Notifications").child(target).push().setValue(n);
    }

    private static String str(DataSnapshot s) {
        return (s == null || !s.exists() || s.getValue() == null) ? null : String.valueOf(s.getValue());
    }

    private static long num(DataSnapshot s, long def) {
        Object v = s.getValue();
        return v instanceof Number ? ((Number) v).longValue() : def;
    }
}
