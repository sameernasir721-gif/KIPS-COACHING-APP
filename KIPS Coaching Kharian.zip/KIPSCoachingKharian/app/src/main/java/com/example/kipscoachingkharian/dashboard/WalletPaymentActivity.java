package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * WalletPaymentActivity
 * ─────────────────────
 * • Sirf wallet balance + is mahine ki fee dikhata hai
 * • Koi transaction history, top-up message, ya "kaha se aya" wala
 *   detail show nahi hota — bilkul simple summary screen
 * • "Pay through PayFast" button seedha PayFast WebView kholta hai
 *   (PaymentActivity se hop nahi karta)
 */
public class WalletPaymentActivity extends AppCompatActivity {

    // ── UI ────────────────────────────────────────────────────────────────────
    private TextView tvWalletBalance;
    private TextView tvFeeMonth;
    private TextView tvFeeAmount;
    private Button   btnPayPayFast;

    // ── Data ──────────────────────────────────────────────────────────────────
    private String uid;
    private DatabaseReference mDb;

    private String feeAmount    = "0";
    private String feeMonth     = "";
    private String studentName  = "";
    private String studentEmail = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet_payment);

        uid = FirebaseAuth.getInstance().getUid();
        mDb = FirebaseDatabase.getInstance().getReference();

        bindViews();
        readIntentData();
        loadWalletBalance();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadWalletBalance();
    }

    // ── View binding ──────────────────────────────────────────────────────────
    private void bindViews() {
        tvWalletBalance = findViewById(R.id.tvWalletBalance);
        tvFeeMonth      = findViewById(R.id.tvWalletFeeMonth);
        tvFeeAmount     = findViewById(R.id.tvWalletFeeAmount);
        btnPayPayFast   = findViewById(R.id.btnPayViaPayFast);

        // Back
        View btnBack = findViewById(R.id.btnWalletBack);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        // Pay through PayFast — seedha PayFast launch, koi extra hop nahi
        if (btnPayPayFast != null) {
            btnPayPayFast.setOnClickListener(v -> {
                if (feeAmount == null || feeAmount.equals("0") || feeAmount.trim().isEmpty()) {
                    Toast.makeText(this, "Fee amount not correct", Toast.LENGTH_SHORT).show();
                    return;
                }
                PayFastLauncher.launch(this, feeAmount, studentName, studentEmail, feeMonth, "fee");
            });
        }
    }

    // ── Intent data ───────────────────────────────────────────────────────────
    private void readIntentData() {
        Intent i     = getIntent();
        feeMonth     = i.getStringExtra("fee_month")     != null ? i.getStringExtra("fee_month")     : "";
        studentName  = i.getStringExtra("student_name")  != null ? i.getStringExtra("student_name")  : "Student";
        studentEmail = i.getStringExtra("student_email") != null ? i.getStringExtra("student_email") : "";
        feeAmount    = i.getStringExtra("fee_amount")    != null ? i.getStringExtra("fee_amount")    : "0";

        if (tvFeeMonth  != null) tvFeeMonth.setText(feeMonth.isEmpty() ? "-" : feeMonth);
        if (tvFeeAmount != null) tvFeeAmount.setText("Rs " + feeAmount);
    }

    // ── Load wallet balance — sirf read, koi history nahi ─────────────────────
    private void loadWalletBalance() {
        if (uid == null) return;
        mDb.child("Wallets").child(uid).child("balance").get()
                .addOnSuccessListener(snap -> {
                    long balance = 0;
                    Object balObj = snap.getValue();
                    if (balObj != null) {
                        try { balance = Long.parseLong(balObj.toString()); }
                        catch (NumberFormatException ignored) { }
                    }
                    if (tvWalletBalance != null) tvWalletBalance.setText("Rs " + balance);
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Wallet load failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}