package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChildDetailInfoActivity extends AppCompatActivity {

    private TextView tvName, tvStudentIdDisplay, tvClass, tvEnrollmentDate, tvSubjects;
    private String studentIdFromIntent;
    private String linkedStudentUid = null;
    private String linkedStudentName = null;
    private DatabaseReference mDatabase;
    private FirebaseAuth mAuth;
    private Query studentQuery;
    private ValueEventListener studentListener;

    // CardViews declaration
    private CardView cardReports, cardQuizzes, cardAssignments;
    private LinearLayout llHomeTab, llProfileTab;

    // ── Upcoming Schedule containers (parent read-only) ──
    private LinearLayout containerUpcomingClasses;
    private LinearLayout containerUpcomingQuizzes;
    private LinearLayout containerUpcomingAssignments;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child_details);

        mAuth = FirebaseAuth.getInstance();
        studentIdFromIntent = getIntent().getStringExtra("STUDENT_ID");

        initViews();
        setupBottomNavigation();
        setupCardListeners();

        mDatabase = FirebaseDatabase.getInstance().getReference("Users");

        if (studentIdFromIntent != null && !studentIdFromIntent.isEmpty()) {
            fetchStudentByRegistrationId();
        } else {
            Toast.makeText(this, "Error: Student ID not provided", Toast.LENGTH_SHORT).show();
        }
    }

    private void initViews() {
        tvName = findViewById(R.id.tvStudentName);
        tvStudentIdDisplay = findViewById(R.id.tvStudentId);
        tvClass = findViewById(R.id.tvClass);
        tvEnrollmentDate = findViewById(R.id.tvEnrollmentDate);
        tvSubjects = findViewById(R.id.tvSubjects);

        cardReports = findViewById(R.id.cardReports);
        cardQuizzes = findViewById(R.id.cardQuizzes);
        cardAssignments = findViewById(R.id.cardAssignments);

        llHomeTab = findViewById(R.id.llHomeTab);
        llProfileTab = findViewById(R.id.llProfileTab);

        // Upcoming Schedule containers
        containerUpcomingClasses     = findViewById(R.id.containerUpcomingClasses);
        containerUpcomingQuizzes     = findViewById(R.id.containerUpcomingQuizzes);
        containerUpcomingAssignments = findViewById(R.id.containerUpcomingAssignments);
    }

    private void setupCardListeners() {
        // ✅ Fixed: Bottom grid Progress Report card now opens ParentProgressReportActivity
        cardReports.setOnClickListener(v -> {
            if (!ensureStudentLinked()) return;
            Intent intent = new Intent(this, ParentProgressReportActivity.class);
            intent.putExtra(ParentProgressReportActivity.EXTRA_STUDENT_UID, linkedStudentUid);
            startActivity(intent);
        });

        cardQuizzes.setOnClickListener(v -> {
            if (!ensureStudentLinked()) return;
            Intent intent = new Intent(this, ParentQuizReportActivity.class);
            intent.putExtra(ParentQuizReportActivity.EXTRA_STUDENT_UID, linkedStudentUid);
            startActivity(intent);
        });

        cardAssignments.setOnClickListener(v -> {
            if (!ensureStudentLinked()) return;
            Intent intent = new Intent(this, ParentAssignmentReportActivity.class);
            intent.putExtra(ParentAssignmentReportActivity.EXTRA_STUDENT_UID, linkedStudentUid);
            startActivity(intent);
        });
    }

    private boolean ensureStudentLinked() {
        if (linkedStudentUid == null || linkedStudentUid.isEmpty()) {
            Toast.makeText(this, "Fetching student data... please wait a moment.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void fetchStudentByRegistrationId() {
        studentQuery = mDatabase.orderByChild("registrationId").equalTo(studentIdFromIntent);
        studentListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    boolean studentFound = false;
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        // ⚠️ Parent aur Student same registrationId share karte hain,
                        // isliye role check zaroori hai warna Parent ka apna record
                        // galti se "linked student" ban sakta hai.
                        String role = snapshot.child("role").getValue(String.class);
                        if (role == null || !role.equalsIgnoreCase("Student")) continue;

                        studentFound = true;
                        linkedStudentUid = snapshot.getKey();

                        String name = snapshot.child("name").getValue(String.class);
                        String className = snapshot.child("className").getValue(String.class);
                        String regId = snapshot.child("registrationId").getValue(String.class);
                        String enrollDate = snapshot.child("enrollmentDate").getValue(String.class);

                        if (enrollDate == null) enrollDate = "N/A";

                        StringBuilder sb = new StringBuilder();
                        DataSnapshot subjectsSnap = snapshot.child("enrolledSubjects");
                        if (subjectsSnap.exists()) {
                            for (DataSnapshot sub : subjectsSnap.getChildren()) {
                                sb.append("• ").append(sub.getValue(String.class)).append("\n");
                            }
                        } else {
                            String singleSubject = snapshot.child("subject").getValue(String.class);
                            if (singleSubject != null && !singleSubject.isEmpty()) {
                                sb.append(singleSubject);
                            } else {
                                sb.append("No subjects found");
                            }
                        }

                        tvName.setText(name != null ? name : "N/A");
                        linkedStudentName = name;
                        tvStudentIdDisplay.setText("ID: " + regId);
                        tvClass.setText("Class: " + (className != null ? className : "N/A"));
                        tvEnrollmentDate.setText("Enrollment Date: " + enrollDate);
                        tvSubjects.setText(sb.toString());

                        String section = snapshot.child("assignedSection").getValue(String.class);
                        String trimmedBase = className != null ? className.trim() : "";
                        boolean baseIsNumberOnly = trimmedBase.matches("\\d+");
                        String studentClass = baseIsNumberOnly && section != null && !section.trim().isEmpty()
                                ? trimmedBase + section.trim()
                                : trimmedBase;

                        final List<String> enrolledSubjects = new ArrayList<>();
                        for (DataSnapshot subSnap : snapshot.child("enrolledSubjects").getChildren()) {
                            String sub = subSnap.getValue(String.class);
                            if (sub != null) enrolledSubjects.add(sub);
                        }

                        loadParentUpcomingSchedule(studentClass, enrolledSubjects);
                        break; // ✅ pehla (aur sirf) Student record mil gaya, aage loop karne ki zaroorat nahi
                    }
                    if (!studentFound) {
                        Toast.makeText(ChildDetailInfoActivity.this, "No student record found for this ID", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(ChildDetailInfoActivity.this, "No record found", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ChildDetailInfoActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };
        studentQuery.addValueEventListener(studentListener);
    }

    private void loadParentUpcomingSchedule(String studentClass, List<String> enrolledSubjects) {
        if (containerUpcomingClasses == null) return;

        loadParentLiveClassCard(studentClass, enrolledSubjects);

        FirebaseDatabase.getInstance().getReference("upcomingSchedule")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot scheduleData) {
                        List<DataSnapshot> quizItems       = new ArrayList<>();
                        List<DataSnapshot> assignmentItems = new ArrayList<>();

                        for (DataSnapshot snap : scheduleData.getChildren()) {
                            String type   = snap.child("type").getValue(String.class);
                            String target = snap.child("className").getValue(String.class);
                            if (target == null) target = snap.child("targetClass").getValue(String.class);

                            if (type == null || target == null) continue;
                            if (!target.trim().equalsIgnoreCase(studentClass.trim())) continue;

                            String itemSubject = snap.child("subject").getValue(String.class);
                            if (itemSubject != null && !itemSubject.trim().isEmpty()
                                    && !isEnrolledInSubject(enrolledSubjects, itemSubject)) {
                                continue;
                            }

                            String typeLow = type.toLowerCase();
                            if (typeLow.contains("quiz"))             quizItems.add(snap);
                            else if (typeLow.contains("assignment"))  assignmentItems.add(snap);
                        }

                        DataSnapshot earliestQuiz = pickEarliest(quizItems, "time", null);
                        showParentQuizCard(earliestQuiz);

                        DataSnapshot earliestAssignment = pickEarliest(assignmentItems, "dueDate", "dueTime");
                        showParentAssignmentCard(earliestAssignment);
                    }

                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void loadParentLiveClassCard(String studentClass, List<String> enrolledSubjects) {
        FirebaseDatabase.getInstance().getReference("Classes")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot allTeachers) {
                        String bestSubject = null, bestTime = null, bestDate = null;
                        Integer bestDuration = null;
                        long bestMillis = Long.MAX_VALUE;
                        long now = System.currentTimeMillis();

                        for (DataSnapshot teacherSnap : allTeachers.getChildren()) {
                            for (DataSnapshot classSnap : teacherSnap.getChildren()) {
                                String grade   = classSnap.child("grade").getValue(String.class);
                                String sub     = classSnap.child("subject").getValue(String.class);
                                String time    = classSnap.child("time").getValue(String.class);
                                String date    = classSnap.child("date").getValue(String.class);
                                Long durLong   = classSnap.child("duration").getValue(Long.class);
                                int duration   = (durLong != null && durLong > 0) ? durLong.intValue() : 45;

                                boolean gradeMatch = grade != null && studentClass != null &&
                                        (grade.trim().equalsIgnoreCase(studentClass.trim()) ||
                                                grade.trim().equalsIgnoreCase("Class " + studentClass.trim()));
                                if (!gradeMatch) continue;

                                if (sub != null && !sub.trim().isEmpty()
                                        && !isEnrolledInSubject(enrolledSubjects, sub)) continue;

                                long classMillis = parseScheduleMillis(date, time);
                                long windowEnd = classMillis + (duration * 60L * 1000);

                                if (classMillis != Long.MAX_VALUE && windowEnd < now) continue;

                                long sortKey = (classMillis != Long.MAX_VALUE) ? classMillis : Long.MAX_VALUE;
                                if (sortKey < bestMillis) {
                                    bestMillis   = sortKey;
                                    bestSubject  = sub;
                                    bestTime     = time;
                                    bestDate     = date;
                                    bestDuration = duration;
                                }
                            }
                        }

                        if (containerUpcomingClasses == null) return;
                        containerUpcomingClasses.removeAllViews();

                        if (bestSubject != null || bestTime != null) {
                            addParentScheduleCard(containerUpcomingClasses,
                                    "Live Class",
                                    bestSubject != null ? "📚 " + bestSubject : "Class",
                                    bestTime != null ? bestTime : "",
                                    "#E3F2FD", "#1565C0");
                        } else {
                            addParentScheduleCard(containerUpcomingClasses,
                                    "Live Class",
                                    "No Upcoming Class",
                                    "Check back later",
                                    "#E3F2FD", "#1565C0");
                        }
                    }

                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        if (containerUpcomingClasses == null) return;
                        containerUpcomingClasses.removeAllViews();
                        addParentScheduleCard(containerUpcomingClasses,
                                "Live Class", "No Upcoming Class", "Check back later",
                                "#E3F2FD", "#1565C0");
                    }
                });
    }

    private void showParentQuizCard(DataSnapshot earliestQuiz) {
        if (containerUpcomingQuizzes == null) return;
        containerUpcomingQuizzes.removeAllViews();

        if (earliestQuiz != null) {
            String title = earliestQuiz.child("title").getValue(String.class);
            String date  = earliestQuiz.child("time").getValue(String.class);
            addParentScheduleCard(containerUpcomingQuizzes,
                    "Upcoming Quiz",
                    "📝 " + (title != null ? title : "Quiz"),
                    "Date: " + (date != null ? date : "-"),
                    "#FFEBEE", "#C62828");
        } else {
            addParentScheduleCard(containerUpcomingQuizzes,
                    "Upcoming Quiz",
                    "No Upcoming Quiz",
                    "Check back later",
                    "#FFEBEE", "#C62828");
        }
    }

    private void showParentAssignmentCard(DataSnapshot earliestAssignment) {
        if (containerUpcomingAssignments == null) return;
        containerUpcomingAssignments.removeAllViews();

        if (earliestAssignment != null) {
            String msg     = earliestAssignment.child("message").getValue(String.class);
            String dueDate = earliestAssignment.child("dueDate").getValue(String.class);
            String title   = (msg != null && !msg.trim().isEmpty()) ? msg : "Assignment";
            String detail  = (dueDate != null ? "Due: " + dueDate : "");
            addParentScheduleCard(containerUpcomingAssignments,
                    "Assignment",
                    "📋 " + title,
                    detail,
                    "#E8F5E9", "#2E7D32");
        } else {
            addParentScheduleCard(containerUpcomingAssignments,
                    "Assignment",
                    "No Upcoming Assignment",
                    "Check back later",
                    "#E8F5E9", "#2E7D32");
        }
    }

    private void addParentScheduleCard(LinearLayout container, String header, String title,
                                       String detail, String bgColor, String headerColor) {
        float dp = getResources().getDisplayMetrics().density;

        CardView card = new CardView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                (int) (185 * dp), LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, (int) (12 * dp), (int) (8 * dp));
        card.setLayoutParams(params);
        card.setRadius(16 * dp);
        card.setCardElevation(3 * dp);
        card.setCardBackgroundColor(Color.parseColor(bgColor));
        card.setClickable(true);
        card.setFocusable(true);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding((int) (16 * dp), (int) (16 * dp), (int) (16 * dp), (int) (16 * dp));

        TextView tvHeader = new TextView(this);
        tvHeader.setText(header);
        tvHeader.setTextSize(14f);
        tvHeader.setTextColor(Color.parseColor(headerColor));
        tvHeader.setTypeface(null, Typeface.BOLD);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(18f);
        tvTitle.setTextColor(Color.parseColor("#212121"));
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setSingleLine(true);
        tvTitle.setEllipsize(TextUtils.TruncateAt.END);
        tvTitle.setPadding(0, (int) (8 * dp), 0, 0);

        TextView tvDetail = new TextView(this);
        tvDetail.setText(detail);
        tvDetail.setTextSize(13f);
        tvDetail.setTextColor(Color.parseColor("#5D4037"));
        tvDetail.setPadding(0, (int) (8 * dp), 0, 0);

        layout.addView(tvHeader);
        layout.addView(tvTitle);
        layout.addView(tvDetail);
        card.addView(layout);

        card.setOnClickListener(v -> {
            if (!ensureStudentLinked()) return;
            Intent intent;
            if (header.equals("Live Class")) {
                // ✅ Top Live Class card click -> ParentAttendanceActivity
                intent = new Intent(this, ParentAttendanceActivity.class);
                intent.putExtra(ParentAttendanceActivity.EXTRA_STUDENT_UID, linkedStudentUid);
            } else if (header.equals("Upcoming Quiz")) {
                intent = new Intent(this, ParentQuizReportActivity.class);
                intent.putExtra(ParentQuizReportActivity.EXTRA_STUDENT_UID, linkedStudentUid);
            } else {
                intent = new Intent(this, ParentAssignmentReportActivity.class);
                intent.putExtra(ParentAssignmentReportActivity.EXTRA_STUDENT_UID, linkedStudentUid);
            }
            startActivity(intent);
        });

        container.addView(card);
    }

    private boolean isEnrolledInSubject(List<String> enrolledSubjects, String subject) {
        for (String s : enrolledSubjects) {
            if (s != null && s.trim().equalsIgnoreCase(subject.trim())) return true;
        }
        return false;
    }

    private DataSnapshot pickEarliest(List<DataSnapshot> items, String dateField, String timeField) {
        if (items.isEmpty()) return null;
        long now = System.currentTimeMillis();
        DataSnapshot best = null;
        long bestMillis = Long.MAX_VALUE;

        for (DataSnapshot item : items) {
            String date = item.child(dateField).getValue(String.class);
            String time = (timeField != null) ? item.child(timeField).getValue(String.class) : null;
            long millis = parseScheduleMillis(date, time);
            if (millis != Long.MAX_VALUE && millis < now) continue;
            if (millis < bestMillis) {
                best = item;
                bestMillis = millis;
            }
        }
        return best;
    }

    private long parseScheduleMillis(String date, String time) {
        try {
            Calendar cal = Calendar.getInstance();

            if (date != null && !date.trim().isEmpty()) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("d/M/yyyy", Locale.getDefault());
                Date d = dateFormat.parse(date.trim());
                if (d != null) {
                    Calendar dCal = Calendar.getInstance();
                    dCal.setTime(d);
                    cal.set(Calendar.YEAR, dCal.get(Calendar.YEAR));
                    cal.set(Calendar.MONTH, dCal.get(Calendar.MONTH));
                    cal.set(Calendar.DAY_OF_MONTH, dCal.get(Calendar.DAY_OF_MONTH));
                }
            }

            if (time != null && !time.trim().isEmpty()) {
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.ENGLISH);
                Date t = sdf.parse(time.trim());
                if (t != null) {
                    Calendar tCal = Calendar.getInstance();
                    tCal.setTime(t);
                    cal.set(Calendar.HOUR_OF_DAY, tCal.get(Calendar.HOUR_OF_DAY));
                    cal.set(Calendar.MINUTE, tCal.get(Calendar.MINUTE));
                } else {
                    cal.set(Calendar.HOUR_OF_DAY, 23);
                    cal.set(Calendar.MINUTE, 59);
                }
            } else {
                cal.set(Calendar.HOUR_OF_DAY, 23);
                cal.set(Calendar.MINUTE, 59);
            }
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            return cal.getTimeInMillis();
        } catch (ParseException e) {
            return Long.MAX_VALUE;
        }
    }

    private void setupBottomNavigation() {
        llHomeTab.setOnClickListener(v -> finish());
        llProfileTab.setOnClickListener(v -> {
            if (mAuth.getCurrentUser() != null) {
                Intent intent = new Intent(ChildDetailInfoActivity.this, ParentProfileActivity.class);
                intent.putExtra("PARENT_UID", mAuth.getCurrentUser().getUid());
                intent.putExtra("STUDENT_ID", studentIdFromIntent);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Please Login Again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (studentQuery != null && studentListener != null) {
            studentQuery.removeEventListener(studentListener);
        }
    }
}