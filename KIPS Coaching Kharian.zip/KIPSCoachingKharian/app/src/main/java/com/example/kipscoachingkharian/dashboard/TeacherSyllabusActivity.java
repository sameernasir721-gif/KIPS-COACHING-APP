package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.content.res.ResourcesCompat;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TeacherSyllabusActivity extends AppCompatActivity {

    // Class tabs — 9A/9B same syllabus, so one tab per class number
    private static final String[] CLASS_TABS = {"Class 9", "Class 10", "Class 11", "Class 12"};

    private RecyclerView rvUnits;
    private UnitAdapter  adapter;
    private DatabaseReference syllabusRef;
    private String teacherUid;
    private String teacherSubject = "Subject";
    private String selectedClass   = CLASS_TABS[0];          // currently active tab
    private final List<SyllabusUnit> unitList = new ArrayList<>();
    private String searchQuery = "";

    // ── Data model ────────────────────────────────────────────────────────────
    static class SyllabusUnit {
        String key, title, status;
        List<String> chapters;
        int order;
        boolean expanded = false;

        SyllabusUnit(String key, String title, List<String> chapters, int order, String status) {
            this.key = key; this.title = title; this.chapters = chapters;
            this.order = order;
            this.status = status != null ? status : "pending";
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_syllabus);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) { finish(); return; }
        teacherUid  = FirebaseAuth.getInstance().getCurrentUser().getUid();

        rvUnits = findViewById(R.id.rvUnits);
        rvUnits.setLayoutManager(new LinearLayoutManager(this));
        rvUnits.setNestedScrollingEnabled(false);
        adapter = new UnitAdapter();
        rvUnits.setAdapter(adapter);

        loadTeacherInfo();           // loads name + subject, then calls loadSyllabus()
        setupTabs();
        setupButtons();
        setupBottomNav();

        // Search bar
        EditText etSearch = findViewById(R.id.etSearch);
        if (etSearch != null) {
            etSearch.addTextChangedListener(new android.text.TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
                @Override public void afterTextChanged(android.text.Editable s) {
                    searchQuery = s.toString().trim().toLowerCase();
                    adapter.notifyDataSetChanged();
                }
            });
        }
    }

    // ── Teacher info ──────────────────────────────────────────────────────────
    private void loadTeacherInfo() {
        FirebaseDatabase.getInstance().getReference("Users").child(teacherUid).get()
                .addOnSuccessListener(snapshot -> {
                    if (!snapshot.exists()) return;
                    TextView tvName = findViewById(R.id.tvTeacherName);
                    TextView tvId   = findViewById(R.id.tvTeacherID);
                    String subject = snapshot.child("subject").getValue(String.class);
                    if (tvName != null) tvName.setText("Syllabus");
                    if (subject != null) {
                        teacherSubject = subject;
                        updateSubjectLabel();
                    }
                    loadSyllabus();
                });
    }

    private void updateSubjectLabel() {
        TextView tv = findViewById(R.id.tvClassLabel);
        if (tv != null) tv.setText("📚  " + teacherSubject + " Syllabus  —  " + selectedClass);
    }

    // ── Class Tabs ─────────────────────────────────────────────────────────────
    private void setupTabs() {
        TabLayout tabs = findViewById(R.id.tabsClass);
        if (tabs == null) return;
        for (String cls : CLASS_TABS) tabs.addTab(tabs.newTab().setText(cls));

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab tab) {
                selectedClass = CLASS_TABS[tab.getPosition()];
                updateSubjectLabel();
                loadSyllabus();
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    // ── Firebase load/save ────────────────────────────────────────────────────
    private DatabaseReference classRef() {
        // Path: Syllabus/{teacherUid}/{selectedClass}/units
        return FirebaseDatabase.getInstance()
                .getReference("Syllabus")
                .child(teacherUid)
                .child(selectedClass.replace(" ","_"))
                .child("units");
    }

    private ValueEventListener syllabusListener;

    private void loadSyllabus() {
        if (syllabusRef != null && syllabusListener != null)
            syllabusRef.removeEventListener(syllabusListener);

        syllabusRef = classRef();
        syllabusListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                unitList.clear();
                if (!snapshot.exists()) {
                    adapter.notifyDataSetChanged();
                    return;
                }
                List<SyllabusUnit> tempUnits = new ArrayList<>();
                for (DataSnapshot us : snapshot.getChildren()) {
                    String title  = us.child("title").getValue(String.class);
                    String status = us.child("status").getValue(String.class);
                    int order = 0;
                    Object orderVal = us.child("order").getValue();
                    if (orderVal instanceof Long) order = ((Long) orderVal).intValue();
                    else if (orderVal instanceof Number) order = ((Number) orderVal).intValue();
                    List<String> chs = new ArrayList<>();
                    for (DataSnapshot ch : us.child("chapters").getChildren()) {
                        String c = ch.getValue(String.class);
                        if (c != null) chs.add(c);
                    }
                    tempUnits.add(new SyllabusUnit(
                            us.getKey(),
                            title != null ? title : "Unit",
                            chs, order, status));
                }
                // Sort by order ascending
                tempUnits.sort((a, b) -> Integer.compare(a.order, b.order));
                unitList.addAll(tempUnits);
                adapter.notifyDataSetChanged();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {
                Toast.makeText(TeacherSyllabusActivity.this,
                        "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };
        syllabusRef.addValueEventListener(syllabusListener);
    }

    // ── Buttons ───────────────────────────────────────────────────────────────
    private void setupButtons() {
        findViewById(R.id.btnAddUnit).setOnClickListener(v -> showAddUnitDialog());
    }

    // ── Bottom Nav ────────────────────────────────────────────────────────────
    private void setupBottomNav() {
        BottomNavigationView bn = findViewById(R.id.bottomNav);
        if (bn == null) return;
        bn.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                startActivity(new Intent(this, TeacherDashboardActivity.class)); finish(); return true;
            } else if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class)); finish(); return true;
            } else if (id == R.id.nav_bottom_Announcment) {
                startActivity(new Intent(this, TeacherAnnouncementsActivity.class)); finish(); return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileMenuActivity.class)); finish(); return true;
            }
            return false;
        });
    }

    // ── Dialogs ───────────────────────────────────────────────────────────────
    private void showAddUnitDialog() {
        showUnitDialog(null, null, false);
    }

    private void showEditUnitDialog(SyllabusUnit unit) {
        StringBuilder sb = new StringBuilder();
        for (String ch : unit.chapters) sb.append(ch).append("\n");
        showUnitDialog(unit, sb.toString().trim(), true);
    }

    private void showUnitDialog(SyllabusUnit existingUnit, String existingChapters, boolean isEdit) {

        // ── dp helper ─────────────────────────────────────────────────────
        float density = getResources().getDisplayMetrics().density;

        // ── Root layout ───────────────────────────────────────────────────
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(24 * density);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(Color.WHITE);

        // ── Class badge ───────────────────────────────────────────────────
        TextView tvBadge = new TextView(this);
        tvBadge.setText(selectedClass);
        tvBadge.setTextColor(Color.WHITE);
        tvBadge.setTextSize(12f);
        tvBadge.setTypeface(ResourcesCompat.getFont(this, R.font.signika));
        int hp = (int)(16 * density), vp = (int)(6 * density);
        tvBadge.setPadding(hp, vp, hp, vp);
        tvBadge.setBackgroundColor(Color.parseColor("#E53935"));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        bp.setMargins(0, 0, 0, (int)(16 * density));
        tvBadge.setLayoutParams(bp);
        root.addView(tvBadge);

        // ── Order field ───────────────────────────────────────────────────
        TextView tvOrderLabel = new TextView(this);
        tvOrderLabel.setText("Unit Order (e.g. 1, 2, 3)");
        tvOrderLabel.setTextColor(Color.parseColor("#E53935"));
        tvOrderLabel.setTextSize(12f);
        tvOrderLabel.setTypeface(ResourcesCompat.getFont(this, R.font.signika));
        LinearLayout.LayoutParams lblO = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lblO.setMargins(0, 0, 0, (int)(4 * density));
        tvOrderLabel.setLayoutParams(lblO);
        root.addView(tvOrderLabel);

        TextInputEditText etOrder = new TextInputEditText(this);
        etOrder.setHint("1");
        etOrder.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etOrder.setTextColor(Color.BLACK);
        etOrder.setTextSize(15f);
        etOrder.setTypeface(ResourcesCompat.getFont(this, R.font.signika));
        etOrder.setBackgroundResource(android.R.drawable.edit_text);
        etOrder.setSingleLine(true);
        if (existingUnit != null) etOrder.setText(String.valueOf(existingUnit.order));
        LinearLayout.LayoutParams etOrderP = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        etOrderP.setMargins(0, 0, 0, (int)(16 * density));
        etOrder.setLayoutParams(etOrderP);
        root.addView(etOrder);

        // ── Unit Title field ──────────────────────────────────────────────
        TextView tvTitleLabel = new TextView(this);
        tvTitleLabel.setText("Unit Title");
        tvTitleLabel.setTextColor(Color.parseColor("#E53935"));
        tvTitleLabel.setTextSize(12f);
        tvTitleLabel.setTypeface(ResourcesCompat.getFont(this, R.font.signika));
        LinearLayout.LayoutParams lblP = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lblP.setMargins(0, 0, 0, (int)(4 * density));
        tvTitleLabel.setLayoutParams(lblP);
        root.addView(tvTitleLabel);

        TextInputEditText etTitle = new TextInputEditText(this);
        etTitle.setHint("e.g. Unit 1: Introduction");
        etTitle.setTextColor(Color.BLACK);
        etTitle.setTextSize(15f);
        etTitle.setTypeface(ResourcesCompat.getFont(this, R.font.signika));
        etTitle.setBackgroundResource(android.R.drawable.edit_text);
        etTitle.setSingleLine(true);
        if (existingUnit != null) etTitle.setText(existingUnit.title);
        LinearLayout.LayoutParams etTitleP = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        etTitleP.setMargins(0, 0, 0, (int)(20 * density));
        etTitle.setLayoutParams(etTitleP);
        root.addView(etTitle);

        // ── Chapters field ────────────────────────────────────────────────
        TextView tvChapLabel = new TextView(this);
        tvChapLabel.setText("Chapters (one per line)");
        tvChapLabel.setTextColor(Color.parseColor("#E53935"));
        tvChapLabel.setTextSize(12f);
        tvChapLabel.setTypeface(ResourcesCompat.getFont(this, R.font.signika));
        LinearLayout.LayoutParams lblP2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lblP2.setMargins(0, 0, 0, (int)(4 * density));
        tvChapLabel.setLayoutParams(lblP2);
        root.addView(tvChapLabel);

        TextInputEditText etChapters = new TextInputEditText(this);
        etChapters.setHint("Chapter 1: Introduction\nChapter 2: Types");
        etChapters.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        etChapters.setMinLines(5);
        etChapters.setGravity(Gravity.TOP | Gravity.START);
        etChapters.setTextColor(Color.BLACK);
        etChapters.setTextSize(14f);
        etChapters.setTypeface(ResourcesCompat.getFont(this, R.font.signika));
        etChapters.setBackgroundResource(android.R.drawable.edit_text);
        if (existingChapters != null) etChapters.setText(existingChapters);
        root.addView(etChapters);

        // ── Dialog ────────────────────────────────────────────────────────
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(isEdit ? "Edit Unit" : "Add New Unit")
                .setView(root)
                .setPositiveButton(isEdit ? "Save" : "Add", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(di -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                    .setTextColor(Color.parseColor("#E53935"));
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                    .setTextColor(Color.parseColor("#888888"));

            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String titleVal = etTitle.getText().toString().trim();
                if (titleVal.isEmpty()) {
                    etTitle.setError("Title cannot be empty");
                    return;
                }
                etTitle.setError(null);
                int orderVal = 0;
                try { orderVal = Integer.parseInt(etOrder.getText().toString().trim()); } catch (Exception ignored) {}
                List<String> chs = parseChapters(etChapters.getText().toString());
                Map<String, Object> m = new HashMap<>();
                m.put("title", titleVal);
                m.put("chapters", chs);
                m.put("order", orderVal);
                m.put("status", isEdit && existingUnit != null ? existingUnit.status : "pending");
                if (isEdit && existingUnit != null) {
                    classRef().child(existingUnit.key).setValue(m)
                            .addOnSuccessListener(u -> { toast("Saved!"); dialog.dismiss(); })
                            .addOnFailureListener(e -> toast("Failed: " + e.getMessage()));
                } else {
                    classRef().push().setValue(m)
                            .addOnSuccessListener(u -> { toast("Unit added!"); dialog.dismiss(); })
                            .addOnFailureListener(e -> toast("Failed: " + e.getMessage()));
                }
            });
        });
        dialog.show();
    }


    private void confirmDeleteUnit(SyllabusUnit unit) {
        new AlertDialog.Builder(this)
                .setTitle("🗑 Delete Unit")
                .setMessage("\"" + unit.title + "\" — Are you sure?")
                .setPositiveButton("Delete", (d, w) ->
                        classRef().child(unit.key).removeValue()
                                .addOnSuccessListener(u -> toast("Deleted!"))
                                .addOnFailureListener(e -> toast("Failed: " + e.getMessage())))
                .setNegativeButton("Cancel", null).show();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private List<String> parseChapters(String raw) {
        List<String> list = new ArrayList<>();
        for (String line : raw.split("\n")) {
            String t = line.trim(); if (!t.isEmpty()) list.add(t);
        }
        return list;
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ════════════════════════════════════════════════════════════════════════
    // RecyclerView Adapter
    // ════════════════════════════════════════════════════════════════════════
    private class UnitAdapter extends RecyclerView.Adapter<UnitAdapter.UnitVH> {

        private List<SyllabusUnit> getFiltered() {
            if (searchQuery.isEmpty()) return unitList;
            List<SyllabusUnit> out = new ArrayList<>();
            for (SyllabusUnit u : unitList) {
                if (u.title.toLowerCase().contains(searchQuery)) out.add(u);
            }
            return out;
        }

        @NonNull @Override
        public UnitVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_syllabus_unit, parent, false);
            return new UnitVH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull UnitVH vh, int position) {
            SyllabusUnit unit = getFiltered().get(position);

            // Completion badge
            boolean covered = "covered".equalsIgnoreCase(unit.status);
            vh.tvTitle.setText((unit.expanded ? " ▼ " : " ▶ ") + "Unit " + unit.order + ": " + unit.title);
            if (vh.tvStatus != null) {
                vh.tvStatus.setText(covered ? "✅ Covered" : "⏳ Pending");
                vh.tvStatus.setTextColor(covered
                        ? android.graphics.Color.parseColor("#2E7D32")
                        : android.graphics.Color.parseColor("#E65100"));
                vh.tvStatus.setOnClickListener(v -> {
                    String newStatus = covered ? "pending" : "covered";
                    classRef().child(unit.key).child("status").setValue(newStatus)
                            .addOnSuccessListener(u -> toast(
                                    newStatus.equals("covered") ? "Marked as Covered ✅" : "Marked as Pending ⏳"));
                });
            }

            vh.llChapters.removeAllViews();
            for (String ch : unit.chapters) {
                LinearLayout row = new LinearLayout(TeacherSyllabusActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, 0, 0, 8);

                View bullet = new View(TeacherSyllabusActivity.this);
                LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(14, 14);
                blp.setMarginEnd(16);
                bullet.setLayoutParams(blp);
                bullet.setBackgroundResource(R.drawable.bullet_circle);
                row.addView(bullet);

                TextView tv = new TextView(TeacherSyllabusActivity.this);
                tv.setText(ch);
                tv.setTextSize(14f);
                tv.setTextColor(Color.parseColor("#444444"));
                tv.setTypeface(ResourcesCompat.getFont(TeacherSyllabusActivity.this, R.font.signika));
                row.addView(tv);

                vh.llChapters.addView(row);
            }

            vh.unitHeader.setOnClickListener(v -> {
                unit.expanded = !unit.expanded;
                vh.tvTitle.setText((unit.expanded ? " ▼ " : " ▶ ") + "Unit " + unit.order + ": " + unit.title);
                vh.divider.setVisibility(unit.expanded ? View.VISIBLE : View.GONE);
                vh.llChapters.setVisibility(unit.expanded ? View.VISIBLE : View.GONE);
            });

            vh.btnEdit.setOnClickListener(v   -> showEditUnitDialog(unit));
            vh.btnDelete.setOnClickListener(v -> confirmDeleteUnit(unit));

            vh.divider.setVisibility(unit.expanded    ? View.VISIBLE : View.GONE);
            vh.llChapters.setVisibility(unit.expanded ? View.VISIBLE : View.GONE);
        }

        @Override public int getItemCount() { return getFiltered().size(); }

        class UnitVH extends RecyclerView.ViewHolder {
            TextView     tvTitle, tvStatus;
            LinearLayout unitHeader, llChapters;
            View         divider;
            ImageView    btnEdit, btnDelete;

            UnitVH(View v) {
                super(v);
                tvTitle    = v.findViewById(R.id.tvUnitTitle);
                tvStatus   = v.findViewById(R.id.tvUnitStatus);
                unitHeader = v.findViewById(R.id.unitHeader);
                divider    = v.findViewById(R.id.unitDivider);
                llChapters = v.findViewById(R.id.llChapters);
                btnEdit    = v.findViewById(R.id.btnEditUnit);
                btnDelete  = v.findViewById(R.id.btnDeleteUnit);
            }
        }
    }
}