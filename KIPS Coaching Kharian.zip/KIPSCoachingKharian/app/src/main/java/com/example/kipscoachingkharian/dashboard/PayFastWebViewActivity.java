package com.example.kipscoachingkharian.dashboard;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class PayFastWebViewActivity extends AppCompatActivity {

    private WebView webView;
    private ProgressBar progressBar;
    private DatabaseReference mDatabase;
    private String currentUid;

    // payment ka purpose: "fee" (default) ya "wallet_topup"
    private String purpose;

    // ✅ Guard — WebView kabhi kabhi same success/cancel URL ke liye
    // shouldOverrideUrlLoading do dafa call karta hai (redirect/reload ki wajah se).
    // Is flag se hum sirf pehli call process karte hain, taake message/update 2x na ho.
    private boolean paymentResultHandled = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payfast_webview);

        mDatabase  = FirebaseDatabase.getInstance().getReference();
        currentUid = FirebaseAuth.getInstance().getUid();

        webView     = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        String htmlData = getIntent().getStringExtra("htmlData");

        // purpose read karo — default "fee"
        purpose = getIntent().getStringExtra("purpose");
        if (purpose == null || purpose.trim().isEmpty()) purpose = "fee";

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (progressBar != null) progressBar.setVisibility(View.GONE);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String currentUrl = request.getUrl().toString();

                // ── 1. SUCCESS ─────────────────────────────────────────────
                if (currentUrl.contains("payment/success")) {
                    if (paymentResultHandled) return true;   // ✅ already handled — ignore repeat call
                    paymentResultHandled = true;
                    webView.stopLoading();

                    if ("wallet_topup".equals(purpose)) {
                        // ✅ FIX: pehle Firebase update karo, phir dialog dikhao
                        // (pehle creditWalletBalance() aur showTransactionReceipt() alag
                        //  chalta tha — async race condition ki wajah se wallet update
                        //  hone se pehle hi finish() call ho jaata tha)
                        creditWalletBalance(() ->
                                showTransactionReceipt(
                                        "Wallet Top-Up Successful!",
                                        "Aapke wallet mein amount add ho gaya hai. Ab ap wallet se fee pay kar sakte hain."
                                )
                        );
                    } else {
                        // Fee payment flow — purana behavior maintain
                        updatePaymentStatusInFirebase();
                        showTransactionReceipt(
                                "Payment Successful!",
                                "Your fee has been received and your status is updated.Thankyou!"
                        );
                    }
                    return true;
                }

                // ── 2. CANCEL ──────────────────────────────────────────────
                if (currentUrl.contains("payment/cancel")) {
                    if (paymentResultHandled) return true;   // ✅ already handled — ignore repeat call
                    paymentResultHandled = true;
                    webView.stopLoading();
                    showTransactionReceipt("Payment Cancelled", "You have cancelled your payment.");
                    return true;
                }

                return false;
            }
        });

        if (htmlData != null) {
            webView.loadDataWithBaseURL(
                    "https://sandbox.payfast.co.za", htmlData, "text/html", "UTF-8", null);
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // FEE PAYMENT — Firebase update (purana behavior, as-is)
    // ──────────────────────────────────────────────────────────────────────────
    private void updatePaymentStatusInFirebase() {
        if (currentUid == null) return;

        String passedMonth = getIntent().getStringExtra("fee_month");
        String monthKey;
        if (passedMonth != null && !passedMonth.trim().isEmpty()) {
            monthKey = passedMonth.trim().replace(" ", "_");
        } else {
            monthKey = new SimpleDateFormat("MMMM_yyyy", Locale.getDefault()).format(new Date());
        }

        // A. Fee status → Paid (+ paidAt timestamp for payment history date/time)
        Map<String, Object> paidUpdate = new HashMap<>();
        paidUpdate.put("status", "Paid");
        paidUpdate.put("paidAt", System.currentTimeMillis());
        mDatabase.child("Fees").child(currentUid).child(monthKey).updateChildren(paidUpdate)
                .addOnFailureListener(e -> Toast.makeText(this,
                        "Status update failed, please contact support: " + e.getMessage(),
                        Toast.LENGTH_LONG).show());

        // B. Announcement / notification — Student
        String announceId = mDatabase.child("Announcements").child("Students").push().getKey();
        Map<String, Object> notification = new HashMap<>();
        notification.put("title",     "✅ Fee Paid Successfully");
        notification.put("message",   "You have paid your fee for "
                + monthKey.replace("_", " ") + ". Thank you!");
        notification.put("timestamp", System.currentTimeMillis());
        notification.put("type",      "fee_confirmation");
        if (announceId != null) {
            mDatabase.child("Announcements").child("Students")
                    .child(currentUid).child(announceId).setValue(notification);
        }

        // B2. ✅ Parent ko bhi announcement bhejo
        String parentAnnounceId = mDatabase.child("Announcements").child("Parents").push().getKey();
        Map<String, Object> parentNotification = new HashMap<>();
        parentNotification.put("title",     "✅ Fee Paid Successfully");
        parentNotification.put("message",   "Your child's fee for "
                + monthKey.replace("_", " ") + " has been paid. Thank you!");
        parentNotification.put("timestamp", System.currentTimeMillis());
        parentNotification.put("type",      "fee_confirmation");
        if (parentAnnounceId != null) {
            mDatabase.child("Announcements").child("Parents")
                    .child(parentAnnounceId).setValue(parentNotification);
        }

        // C. lastPayment record
        Map<String, Object> history = new HashMap<>();
        history.put("amount", "Paid");
        history.put("date",   new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        mDatabase.child("Users").child(currentUid).child("lastPayment").setValue(history);

        // D. feePaid + feeStatus
        mDatabase.child("Users").child(currentUid).child("feePaid").setValue(true);
        mDatabase.child("Users").child(currentUid).child("feeStatus").setValue("Paid");

        // E. Wallet mein PayFast transaction history (balance deduct nahi hoti)
        String today = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        String txId  = mDatabase.child("Wallets").child(currentUid).child("transactions").push().getKey();
        if (txId != null) {
            Map<String, Object> walletTx = new HashMap<>();
            walletTx.put("type",        "debit");
            walletTx.put("amount",      getIntent().getStringExtra("fee_amount") != null
                    ? getIntent().getStringExtra("fee_amount") : "0");
            walletTx.put("description", "Online Fee Paid (PayFast) - " + monthKey.replace("_", " "));
            walletTx.put("date",        today);
            mDatabase.child("Wallets").child(currentUid)
                    .child("transactions").child(txId).setValue(walletTx);
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // WALLET TOP-UP — balance add karo, PHIR callback se dialog dikhao
    //
    // ✅ FIX: onComplete (Runnable) parameter add kiya gaya hai.
    //    updateChildren().addOnSuccessListener ke andar onComplete.run() call hota hai
    //    taake dialog sirf tab dikhe jab Firebase write complete ho jaaye.
    //    Pehle creditWalletBalance() aur showTransactionReceipt() simultaneously
    //    call hote the — async race condition ki wajah se WalletPaymentActivity
    //    ka onResume() stale (purana) balance dikhata tha.
    // ──────────────────────────────────────────────────────────────────────────
    private void creditWalletBalance(Runnable onComplete) {
        if (currentUid == null) {
            if (onComplete != null) onComplete.run();
            return;
        }

        String amtStr = getIntent().getStringExtra("fee_amount");
        long topUpAmount;
        try { topUpAmount = Long.parseLong(amtStr != null ? amtStr.trim() : "0"); }
        catch (NumberFormatException e) { topUpAmount = 0; }

        if (topUpAmount <= 0) {
            if (onComplete != null) onComplete.run();
            return;
        }

        final long finalTopUpAmount = topUpAmount;
        final String today = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());

        // ✅ Fresh balance + totalTopUp paro — race condition avoid karne ke liye
        mDatabase.child("Wallets").child(currentUid).get()
                .addOnSuccessListener(snap -> {
                    long currentBalance    = 0;
                    long currentTotalTopUp = 0;

                    Object balObj   = snap.child("balance").getValue();
                    Object topUpObj = snap.child("totalTopUp").getValue();
                    if (balObj   != null) currentBalance    = Long.parseLong(balObj.toString());
                    if (topUpObj != null) currentTotalTopUp = Long.parseLong(topUpObj.toString());

                    long newBalance    = currentBalance    + finalTopUpAmount;
                    long newTotalTopUp = currentTotalTopUp + finalTopUpAmount;

                    Map<String, Object> updates = new HashMap<>();
                    updates.put("Wallets/" + currentUid + "/balance",      newBalance);
                    updates.put("Wallets/" + currentUid + "/totalTopUp",   newTotalTopUp);
                    updates.put("Wallets/" + currentUid + "/lastTopUpDate", today);

                    // Transaction entry — "credit"
                    String txId = mDatabase.child("Wallets").child(currentUid)
                            .child("transactions").push().getKey();
                    if (txId != null) {
                        updates.put("Wallets/" + currentUid + "/transactions/" + txId + "/type",        "credit");
                        updates.put("Wallets/" + currentUid + "/transactions/" + txId + "/amount",      finalTopUpAmount);
                        updates.put("Wallets/" + currentUid + "/transactions/" + txId + "/description", "Wallet Top-Up (PayFast)");
                        updates.put("Wallets/" + currentUid + "/transactions/" + txId + "/date",        today);
                        updates.put("Wallets/" + currentUid + "/transactions/" + txId + "/balanceAfter", newBalance);
                    }

                    // ✅ FIX: updateChildren ka SUCCESS callback mein onComplete chalaao
                    //    taake dialog sirf successful write ke baad dikhe
                    mDatabase.updateChildren(updates)
                            .addOnSuccessListener(unused -> {
                                // Notification
                                String announceId = mDatabase.child("Announcements")
                                        .child("Students").push().getKey();
                                if (announceId != null) {
                                    Map<String, Object> notification = new HashMap<>();
                                    notification.put("title",     "✅ Wallet Top-Up Successful");
                                    notification.put("message",   "Rs " + finalTopUpAmount
                                            + " aapke wallet mein add ho gaya. Naya balance: Rs " + newBalance);
                                    notification.put("timestamp", System.currentTimeMillis());
                                    notification.put("type",      "wallet_topup");
                                    mDatabase.child("Announcements").child("Students")
                                            .child(currentUid).child(announceId).setValue(notification);
                                }

                                // ✅ Ab dialog dikhao — Firebase write complete ho chuki hai
                                if (onComplete != null) onComplete.run();
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(PayFastWebViewActivity.this,
                                        "Wallet update failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                // Failure pe bhi dialog dikhao (cancel flow)
                                if (onComplete != null) onComplete.run();
                            });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this,
                            "Wallet read failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    if (onComplete != null) onComplete.run();
                });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Success / Cancel dialog
    // ──────────────────────────────────────────────────────────────────────────
    private void showTransactionReceipt(String title, String message) {
        // Activity already finish ho chuki ho toh dialog mat dikhao
        if (isFinishing() || isDestroyed()) return;

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Done", (dialog, which) -> {
                    if ("wallet_topup".equals(purpose)) {
                        // ✅ Wallet screen pe wapis bhejo — onResume() fresh balance dikhayega
                        finish();
                    } else {
                        Intent intent = new Intent(PayFastWebViewActivity.this,
                                StudentDashboardActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();
                    }
                })
                .show();
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Back press handler
    // ──────────────────────────────────────────────────────────────────────────
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Exit Payment")
                    .setMessage("Do you want to move back from this screen?")
                    .setPositiveButton("Yes", (d, w) -> finish())
                    .setNegativeButton("No", null)
                    .show();
        }
    }
}