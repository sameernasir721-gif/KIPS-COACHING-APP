package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class StudentProgressActivity extends AppCompatActivity {

    private RecyclerView    rvStudents;
    private LinearLayout    layoutEmpty;
    private Button          btnAllClasses, btnAllSubjects, btnSortName;
    private StudentAdapter  adapter;

    private String teacherUid;
    private String teacherSubject  = "";
    private String teacherClass    = "";
    private String teacherSection  = "";
    private final Set<String> teacherClasses  = new HashSet<>();
    private final Set<String> teacherSubjects = new HashSet<>();
    private String selectedClass   = "All Classes";
    private String selectedSubject = "All Subjects";
    private String sortOrder       = "Name";

    private final List<StudentMark> allStudents = new ArrayList<>();
    private String searchQuery = "";

    // Class order for sorting
    private static final List<String> CLASS_ORDER = Arrays.asList(
            "9A", "9B", "10A", "10B", "11A", "11B", "12A", "12B"
    );

    private static final String[] GRADES = {
            "9A", "9B", "10A", "10B",
            "11A", "11B", "12A", "12B"
    };

    // ── Model ─────────────────────────────────────────────────────────────────
    static class StudentMark {
        String uid, name, className;
        List<String> enrolledSubjects = new ArrayList<>();
        int classAttended, classTotal, assignMarks, assignTotal, quizMarks, quizTotal;

        int avgPercent() {
            int obt = assignMarks + quizMarks;
            int max = assignTotal + quizTotal;
            return max == 0 ? 0 : (int)((obt * 100.0) / max);
        }
        int attendancePercent() {
            return classTotal == 0 ? 0 : (int)((classAttended * 100.0) / classTotal);
        }
        String subjectsStr() {
            return enrolledSubjects.isEmpty() ? "No subjects" : String.join(", ", enrolledSubjects);
        }
        String classStr()  { return classAttended + "/" + classTotal; }
        String assignStr() { return assignMarks   + "/" + assignTotal; }
        String quizStr()   { return quizMarks     + "/" + quizTotal; }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_studentprogress);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) { finish(); return; }
        teacherUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        rvStudents  = findViewById(R.id.rvStudents);
        layoutEmpty = findViewById(R.id.layoutEmpty);
        rvStudents.setLayoutManager(new LinearLayoutManager(this));
        rvStudents.setNestedScrollingEnabled(false);
        adapter = new StudentAdapter();
        rvStudents.setAdapter(adapter);

        setupFilterButtons();
        setupBottomNav();

        // Search bar
        EditText etSearch = findViewById(R.id.etSearch);
        if (etSearch != null) {
            etSearch.addTextChangedListener(new android.text.TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
                @Override public void afterTextChanged(android.text.Editable s) {
                    searchQuery = s.toString().trim().toLowerCase();
                    applyFilters();
                }
            });
        }

        // Pehle teacher ka subject fetch karo, phir students load karo
        loadTeacherInfoThenStudents();
    }

    // ── Step 1: Teacher info — exactly StudentListActivity ki tarah ──────────
    private void loadTeacherInfoThenStudents() {
        FirebaseDatabase.getInstance().getReference("Users").child(teacherUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        TextView tvName = findViewById(R.id.tvTeacherName);
                        if (tvName != null) tvName.setText("Student Progress");

                        // ── Classes — StudentListActivity ki tarah ──
                        teacherClasses.clear();
                        String classesStr = snapshot.child("assignedClasses").getValue(String.class);
                        if (classesStr == null || classesStr.trim().isEmpty())
                            classesStr = snapshot.child("className").getValue(String.class);
                        if (classesStr != null && !classesStr.trim().isEmpty()) {
                            for (String c : classesStr.split(",")) {
                                String t = c.trim();
                                if (!t.isEmpty()) teacherClasses.add(normalizeClass(t));
                            }
                        }
                        for (DataSnapshot c : snapshot.child("assignedClassMap").getChildren()) {
                            if (c.getKey() != null) teacherClasses.add(normalizeClass(c.getKey()));
                        }
                        String oldClass = snapshot.child("assignedClass").getValue(String.class);
                        if (oldClass != null && !oldClass.trim().isEmpty())
                            teacherClasses.add(normalizeClass(oldClass.trim()));

                        // ── Subjects — StudentListActivity ki tarah ──
                        teacherSubjects.clear();
                        String subjectsStr = snapshot.child("subjects").getValue(String.class);
                        if (subjectsStr == null || subjectsStr.trim().isEmpty())
                            subjectsStr = snapshot.child("subject").getValue(String.class);
                        if (subjectsStr != null && !subjectsStr.trim().isEmpty()) {
                            for (String s : subjectsStr.split(",")) {
                                String t = s.trim();
                                if (!t.isEmpty()) teacherSubjects.add(t.toLowerCase());
                            }
                        }
                        for (DataSnapshot s : snapshot.child("assignedSubjects").getChildren()) {
                            if (s.getKey() != null) teacherSubjects.add(s.getKey().trim().toLowerCase());
                        }

                        // Subject button label ke liye
                        String subj = snapshot.child("subject").getValue(String.class);
                        teacherSubject = subj != null ? subj.trim() : "";
                        if (teacherSubject.isEmpty() && !teacherSubjects.isEmpty())
                            teacherSubject = teacherSubjects.iterator().next();
                        if (!teacherSubject.isEmpty()) {
                            selectedSubject = teacherSubject;
                            btnAllSubjects.setText(teacherSubject + " ▼");
                        }

                        loadStudents();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError e) { loadStudents(); }
                });
    }

    // normalizeClass — exactly StudentListActivity ki tarah
    private String normalizeClass(String raw) {
        return raw.replace("Class", "").replace(" ", "").trim().toUpperCase();
    }

    // ── Step 2: Load students with role = "Student" ───────────────────────────
    private void loadStudents() {
        FirebaseDatabase.getInstance().getReference("Users")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        allStudents.clear();
                        for (DataSnapshot snap : snapshot.getChildren()) {
                            String role = snap.child("role").getValue(String.class);
                            if (role == null || !role.trim().equalsIgnoreCase("Student")) continue;

                            String className = snap.child("className").getValue(String.class);
                            String studentClassNorm = className != null ? normalizeClass(className) : "";

                            // ✅ 1. Class match — StudentListActivity ki tarah
                            boolean classMatch = teacherClasses.isEmpty()
                                    ? false
                                    : teacherClasses.contains(studentClassNorm);
                            if (!classMatch) continue;

                            // ✅ 2. Subject match — StudentListActivity ki tarah
                            if (!teacherSubjects.isEmpty()) {
                                boolean enrolled = false;
                                for (DataSnapshot s : snap.child("enrolledSubjects").getChildren()) {
                                    String sv = s.getValue(String.class);
                                    if (sv != null && teacherSubjects.contains(sv.trim().toLowerCase())) {
                                        enrolled = true; break;
                                    }
                                }
                                if (!enrolled) continue;
                            }

                            StudentMark sm = new StudentMark();
                            sm.uid       = snap.getKey();
                            sm.name      = snap.child("name").getValue(String.class);
                            sm.className = className;
                            if (sm.name      == null) sm.name      = "Student";
                            if (sm.className == null) sm.className = "Unknown";

                            for (DataSnapshot sub : snap.child("enrolledSubjects").getChildren()) {
                                String val = sub.getValue(String.class);
                                if (val != null) sm.enrolledSubjects.add(val);
                            }

                            allStudents.add(sm);
                        }
                        loadMarksForStudents();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(StudentProgressActivity.this,
                                "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // ── Step 3: Load marks ────────────────────────────────────────────────────
    private void loadMarksForStudents() {
        FirebaseDatabase.getInstance().getReference("StudentMarks").child(teacherUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (StudentMark sm : allStudents) {
                            DataSnapshot ms = snapshot.child(sm.uid);
                            if (ms.exists()) {
                                sm.classAttended = getInt(ms, "classAttended");
                                sm.classTotal    = getInt(ms, "classTotal",   0);
                                sm.assignMarks   = getInt(ms, "assignMarks");
                                sm.assignTotal   = getInt(ms, "assignTotal", 100);
                                sm.quizMarks     = getInt(ms, "quizMarks");
                                sm.quizTotal     = getInt(ms, "quizTotal",   100);
                            } else {
                                sm.classTotal = sm.assignTotal = sm.quizTotal = 0;
                            }
                        }
                        applyFilters();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError e) { applyFilters(); }
                });
    }

    private int getInt(DataSnapshot snap, String key) { return getInt(snap, key, 0); }
    private int getInt(DataSnapshot snap, String key, int def) {
        Integer v = snap.child(key).getValue(Integer.class);
        return v != null ? v : def;
    }

    // ── Filter + sort ─────────────────────────────────────────────────────────
    private void applyFilters() {
        List<StudentMark> filtered = new ArrayList<>();
        for (StudentMark sm : allStudents) {
            boolean classOk = selectedClass.equals("All Classes")
                    || sm.className.equalsIgnoreCase(selectedClass);
            boolean subjectOk = selectedSubject.equals("All Subjects");
            if (!subjectOk) {
                for (String s : sm.enrolledSubjects) {
                    if (s.equalsIgnoreCase(selectedSubject)) { subjectOk = true; break; }
                }
            }
            boolean searchOk = searchQuery.isEmpty()
                    || sm.name.toLowerCase().contains(searchQuery)
                    || sm.className.toLowerCase().contains(searchQuery);
            if (classOk && subjectOk && searchOk) filtered.add(sm);
        }

        // Sort
        if (sortOrder.equals("Score")) {
            filtered.sort((a, b) -> b.avgPercent() - a.avgPercent());
        } else {
            filtered.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        }

        adapter.setData(filtered);
        layoutEmpty.setVisibility(filtered.isEmpty() ? View.VISIBLE : View.GONE);
        rvStudents.setVisibility(filtered.isEmpty() ? View.GONE : View.VISIBLE);
    }

    // ── Filter buttons ────────────────────────────────────────────────────────
    private void setupFilterButtons() {
        btnAllClasses  = findViewById(R.id.btnAllClasses);
        btnAllSubjects = findViewById(R.id.btnAllSubjects);
        btnSortName    = findViewById(R.id.btnSortName);

        btnAllClasses.setOnClickListener(v -> {
            // Collect unique classes from teacher's students
            List<String> classList = new ArrayList<>();
            classList.add("All Classes");
            for (StudentMark sm : allStudents) {
                if (!classList.contains(sm.className)) classList.add(sm.className);
            }
            // Sort by CLASS_ORDER
            List<String> sortable = classList.subList(1, classList.size());
            Collections.sort(sortable, (a, b) -> {
                int ia = CLASS_ORDER.indexOf(a.toUpperCase().replace("CLASS ", "").trim());
                int ib = CLASS_ORDER.indexOf(b.toUpperCase().replace("CLASS ", "").trim());
                if (ia == -1) ia = 999;
                if (ib == -1) ib = 999;
                return ia != ib ? ia - ib : a.compareToIgnoreCase(b);
            });

            String[] classArr = classList.toArray(new String[0]);
            new AlertDialog.Builder(this).setTitle("Select Class")
                    .setItems(classArr, (d, w) -> {
                        selectedClass = classArr[w];
                        btnAllClasses.setText(selectedClass + " ▼");
                        applyFilters();
                    }).show();
        });

        btnAllSubjects.setOnClickListener(v -> {
            // Teacher sirf apna subject dekh sakta hai (aur All Subjects)
            List<String> subjectList = new ArrayList<>();
            subjectList.add("All Subjects");
            if (!teacherSubject.isEmpty() && !subjectList.contains(teacherSubject))
                subjectList.add(teacherSubject);

            String[] subjectArr = subjectList.toArray(new String[0]);
            new AlertDialog.Builder(this).setTitle("Select Subject")
                    .setItems(subjectArr, (d, w) -> {
                        selectedSubject = subjectArr[w];
                        btnAllSubjects.setText(selectedSubject + " ▼");
                        applyFilters();
                    }).show();
        });

        btnSortName.setOnClickListener(v -> {
            String[] sorts = {"Name", "Score"};
            new AlertDialog.Builder(this).setTitle("Sort By")
                    .setItems(sorts, (d, w) -> {
                        sortOrder = sorts[w];
                        btnSortName.setText("Sort: " + sortOrder + " ▼");
                        applyFilters();
                    }).show();
        });
    }

    // ── Marks dialog ─────────────────────────────────────────────────────────
    private void showEnterMarksDialog(StudentMark sm) {
        // Class selection — assignment wali tarah
        final String[] selectedClassName = {sm.className};

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 24, 48, 24);

        // Class dropdown button
        layout.addView(makeLabel("🏫 Class:"));
        Button btnClass = new Button(this);
        btnClass.setText(selectedClassName[0]);
        btnClass.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Select Class")
                    .setItems(GRADES, (d, w) -> {
                        selectedClassName[0] = GRADES[w];
                        btnClass.setText(selectedClassName[0]);
                    }).show();
        });
        layout.addView(btnClass);

        layout.addView(makeLabel("🏫 Classes Attended / Total Classes:"));
        LinearLayout classRow = makeRow();
        EditText etClassAtt   = makeEditInt(String.valueOf(sm.classAttended));
        EditText etClassTotal = makeEditInt(String.valueOf(sm.classTotal));
        classRow.addView(etClassAtt); classRow.addView(makeSlash()); classRow.addView(etClassTotal);
        layout.addView(classRow);

        layout.addView(makeLabel("\n📋 Assignment Marks (Obtained / Total):"));
        LinearLayout aRow = makeRow();
        EditText etAObt   = makeEditInt(String.valueOf(sm.assignMarks));
        EditText etATotal = makeEditInt(String.valueOf(sm.assignTotal));
        aRow.addView(etAObt); aRow.addView(makeSlash()); aRow.addView(etATotal);
        layout.addView(aRow);

        layout.addView(makeLabel("\n🧠 Quiz Marks (Obtained / Total):"));
        LinearLayout qRow = makeRow();
        EditText etQObt   = makeEditInt(String.valueOf(sm.quizMarks));
        EditText etQTotal = makeEditInt(String.valueOf(sm.quizTotal));
        qRow.addView(etQObt); qRow.addView(makeSlash()); qRow.addView(etQTotal);
        layout.addView(qRow);

        new AlertDialog.Builder(this)
                .setTitle("✏️ " + sm.name + " — Enter Marks")
                .setView(layout)
                .setPositiveButton("Save", (d, w) -> {
                    try {
                        int cAtt = Integer.parseInt(etClassAtt.getText().toString().trim());
                        int cTot = Integer.parseInt(etClassTotal.getText().toString().trim());
                        int aObt = Integer.parseInt(etAObt.getText().toString().trim());
                        int aTot = Integer.parseInt(etATotal.getText().toString().trim());
                        int qObt = Integer.parseInt(etQObt.getText().toString().trim());
                        int qTot = Integer.parseInt(etQTotal.getText().toString().trim());

                        if (cAtt > cTot || aObt > aTot || qObt > qTot) {
                            Toast.makeText(StudentProgressActivity.this, "Obtained cannot exceed total!", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        DatabaseReference db = FirebaseDatabase.getInstance().getReference();
                        Map<String, Object> batch = new HashMap<>();

                        // 1. StudentMarks node mein save karo (teacher ke liye)
                        batch.put("StudentMarks/" + teacherUid + "/" + sm.uid + "/classAttended", cAtt);
                        batch.put("StudentMarks/" + teacherUid + "/" + sm.uid + "/classTotal",    cTot);
                        batch.put("StudentMarks/" + teacherUid + "/" + sm.uid + "/assignMarks",   aObt);
                        batch.put("StudentMarks/" + teacherUid + "/" + sm.uid + "/assignTotal",   aTot);
                        batch.put("StudentMarks/" + teacherUid + "/" + sm.uid + "/quizMarks",     qObt);
                        batch.put("StudentMarks/" + teacherUid + "/" + sm.uid + "/quizTotal",     qTot);
                        batch.put("StudentMarks/" + teacherUid + "/" + sm.uid + "/studentName",   sm.name);
                        batch.put("StudentMarks/" + teacherUid + "/" + sm.uid + "/className",     selectedClassName[0]);
                        batch.put("StudentMarks/" + teacherUid + "/" + sm.uid + "/subject",       teacherSubject);

                        // 2. SharedProgress node mein student ko share karo (student dashboard ke liye)
                        int avg    = (aTot + qTot) > 0 ? (int)(((aObt + qObt) * 100.0) / (aTot + qTot)) : 0;
                        int attPct = cTot > 0 ? (int)((cAtt * 100.0) / cTot) : 0;
                        Map<String, Object> shared = new HashMap<>();
                        shared.put("subject",        teacherSubject);
                        shared.put("className",      selectedClassName[0]);
                        shared.put("classAttended",  cAtt);
                        shared.put("classTotal",     cTot);
                        shared.put("attendancePct",  attPct);
                        shared.put("assignMarks",    aObt);
                        shared.put("assignTotal",    aTot);
                        shared.put("quizMarks",      qObt);
                        shared.put("quizTotal",      qTot);
                        shared.put("avgPercent",     avg);
                        shared.put("teacherUid",     teacherUid);
                        shared.put("sharedAt",       System.currentTimeMillis());
                        batch.put("SharedProgress/" + sm.uid + "/" + teacherUid, shared);

                        // 2b. ProgressHistory mein bhi ek dated entry save karo (student dashboard
                        //     ke daily progress line-chart ke liye — purani entries delete nahi hoti)
                        long historyKey = System.currentTimeMillis();
                        Map<String, Object> historyEntry = new HashMap<>();
                        historyEntry.put("subject",    teacherSubject);
                        historyEntry.put("avgPercent", avg);
                        historyEntry.put("date",       new java.text.SimpleDateFormat("dd MMM", java.util.Locale.getDefault())
                                .format(new java.util.Date(historyKey)));
                        historyEntry.put("timestamp",  historyKey);
                        batch.put("ProgressHistory/" + sm.uid + "/" + teacherUid + "/" + historyKey, historyEntry);

                        // 3. Notification bhi push karo (assignment wali tarah)
                        Map<String, Object> notif = new HashMap<>();
                        notif.put("title",     "📊 Progress Updated — " + teacherSubject);
                        notif.put("message",   "Attendance: " + cAtt + "/" + cTot + " (" + attPct + "%)"
                                + " | Assignment: " + aObt + "/" + aTot
                                + " | Quiz: " + qObt + "/" + qTot
                                + "\nOverall: " + avg + "%");
                        notif.put("timestamp", System.currentTimeMillis());
                        notif.put("read",      false);
                        notif.put("type",      "progress_marks");
                        String notifKey = db.child("Notifications").child(sm.uid).push().getKey();
                        if (notifKey != null)
                            batch.put("Notifications/" + sm.uid + "/" + notifKey, notif);

                        db.updateChildren(batch)
                                .addOnSuccessListener(u ->
                                        Toast.makeText(StudentProgressActivity.this,
                                                "✅ Progress shared with " + sm.name + "!",
                                                Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(e ->
                                        Toast.makeText(StudentProgressActivity.this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());

                    } catch (NumberFormatException ex) {
                        Toast.makeText(StudentProgressActivity.this, "Numbers only!", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private TextView makeLabel(String t) {
        TextView tv = new TextView(this); tv.setText(t); tv.setTextColor(Color.BLACK); return tv;
    }
    private LinearLayout makeRow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(android.view.Gravity.CENTER_VERTICAL);
        return r;
    }
    private TextView makeSlash() {
        TextView tv = new TextView(this); tv.setText("  /  ");
        tv.setTextColor(Color.BLACK); tv.setTextSize(16f); return tv;
    }
    private EditText makeEditInt(String val) {
        EditText et = new EditText(this);
        et.setText(val); et.setTextColor(Color.BLACK);
        et.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        et.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return et;
    }

    // ── Bottom nav ────────────────────────────────────────────────────────────
    private void setupBottomNav() {
        BottomNavigationView bn = findViewById(R.id.bottomNav);
        if (bn == null) return;
        bn.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                startActivity(new Intent(this, TeacherDashboardActivity.class)); finish(); return true;
            } else if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class)); finish(); return true;
            } else if (id == R.id.nav_bottom_Announcment) {
                startActivity(new Intent(this, TeacherAnnouncementsActivity.class)); finish(); return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileMenuActivity.class)); finish(); return true;
            }
            return false;
        });
    }

    // ════════════════════════════════════════════════════════════════════════
    // Adapter
    // ════════════════════════════════════════════════════════════════════════
    private class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.VH> {

        private List<StudentMark> list = new ArrayList<>();
        void setData(List<StudentMark> data) { this.list = data; notifyDataSetChanged(); }

        @NonNull @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_student_progress, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH vh, int pos) {
            StudentMark sm = list.get(pos);
            vh.tvName   .setText(sm.name);
            vh.tvSubject.setText(teacherSubject + " — " + sm.className);
            vh.tvTest   .setText(sm.classTotal  > 0 ? sm.classStr()  : "--");
            vh.tvAssign .setText(sm.assignMarks > 0 ? sm.assignStr() : "--");
            vh.tvQuiz   .setText(sm.quizMarks   > 0 ? sm.quizStr()   : "--");

            int avg = sm.avgPercent();
            vh.tvAvg.setText(avg > 0 ? avg + "%" : "--");
            vh.progress.setProgress(avg);

            int color;
            if      (avg >= 80) color = Color.parseColor("#388E3C");
            else if (avg >= 60) color = Color.parseColor("#FF6F00");
            else if (avg >  0)  color = Color.parseColor("#E53935");
            else                color = Color.parseColor("#999999");
            vh.tvAvg.setTextColor(color);

            vh.btnEnterMarks.setOnClickListener(v -> showEnterMarksDialog(sm));
        }

        @Override public int getItemCount() { return list.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView    tvName, tvSubject, tvTest, tvAssign, tvQuiz, tvAvg;
            ProgressBar progress;
            Button      btnEnterMarks;
            VH(View v) {
                super(v);
                tvName        = v.findViewById(R.id.tvStudentName);
                tvSubject     = v.findViewById(R.id.tvSubjectClass);
                tvTest        = v.findViewById(R.id.tvTestMarks);
                tvAssign      = v.findViewById(R.id.tvAssignmentMarks);
                tvQuiz        = v.findViewById(R.id.tvQuizMarks);
                tvAvg         = v.findViewById(R.id.tvAvgPercent);
                progress      = v.findViewById(R.id.progressStudent);
                btnEnterMarks = v.findViewById(R.id.btnEnterMarks);
            }
        }
    }
}