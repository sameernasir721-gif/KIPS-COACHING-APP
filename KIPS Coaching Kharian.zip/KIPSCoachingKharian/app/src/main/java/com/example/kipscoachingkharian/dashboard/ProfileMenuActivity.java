package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileMenuActivity extends AppCompatActivity {

    // ── Header Views ──────────────────────────────────────────────────────────
    private TextView tvName, tvRole;
    private ImageView ivAvatar;

    // ── Menu Items ────────────────────────────────────────────────────────────
    private LinearLayout itemMyProfile, itemNotifications, itemSettings, itemHelp, itemLogout;

    // ── Bottom Nav ────────────────────────────────────────────────────────────
    private BottomNavigationView bottomNav;

    // ── Notification Badge ────────────────────────────────────────────────────
    private View notificationBadge;

    // ── Firebase ──────────────────────────────────────────────────────────────
    private FirebaseAuth mAuth;
    private DatabaseReference userRef;

    // ── Teacher data (loaded once, reused in dialogs) ─────────────────────────
    private String teacherName    = "";
    private String teacherEmail   = "";
    private String teacherPhone   = "";
    private String teacherSubject = "";
    private String teacherId      = "";

    // ── SharedPreferences keys ────────────────────────────────────────────────
    private static final String PREFS_NAME    = "kips_prefs";
    private static final String KEY_LAST_SEEN = "teacher_last_seen_announcement_time";

    // ─────────────────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_menu);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser == null) {
            goToLogin();
            return;
        }

        userRef = FirebaseDatabase.getInstance()
                .getReference("Users")
                .child(currentUser.getUid());

        initViews();
        loadTeacherProfile();
        checkNewAnnouncements();
        setClickListeners();
        setupBottomNav();
    }

    // ── Views Init ────────────────────────────────────────────────────────────
    private void initViews() {
        tvName            = findViewById(R.id.tv_name);
        tvRole            = findViewById(R.id.tv_role);
        ivAvatar          = findViewById(R.id.iv_avatar);
        itemMyProfile     = findViewById(R.id.item_my_profile);
        itemNotifications = findViewById(R.id.item_notifications);
        itemSettings      = findViewById(R.id.item_settings);
        itemHelp          = findViewById(R.id.item_help);
        itemLogout        = findViewById(R.id.item_logout);
        bottomNav         = findViewById(R.id.bottomNav);
        notificationBadge = findViewById(R.id.notification_badge);
    }

    // ── Firebase: Teacher Profile Load ────────────────────────────────────────
    private void loadTeacherProfile() {
        userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    teacherName    = getStr(snapshot, "name");
                    teacherEmail   = getStr(snapshot, "email");
                    teacherPhone   = getStr(snapshot, "phone");
                    teacherSubject = getStr(snapshot, "subject");
                    teacherId      = getStr(snapshot, "teacherId");

                    tvName.setText(teacherName.isEmpty() ? "Teacher" : teacherName);

                    // Role row mein subject dikhao
                    String roleText = teacherSubject.isEmpty() ? "Teacher" : "Subject: " + teacherSubject;
                    tvRole.setText(roleText);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ProfileMenuActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String getStr(DataSnapshot snap, String key) {
        String val = snap.child(key).getValue(String.class);
        return val != null ? val : "";
    }

    // ── Click Listeners ───────────────────────────────────────────────────────
    private void setClickListeners() {

        // 1. MY PROFILE — naye dedicated page par le jao (student wale ki tarah)
        itemMyProfile.setOnClickListener(v -> startActivity(new Intent(this, TeacherProfileInfoActivity.class)));

        // 2. NOTIFICATIONS — TeacherAnnouncementsActivity kholo + badge hatao
        itemNotifications.setOnClickListener(v -> {
            if (notificationBadge != null) notificationBadge.setVisibility(View.GONE);
            saveLastSeenTime();
            startActivity(new Intent(this, TeacherAnnouncementsActivity.class));
        });

        // 3. SETTINGS — Settings page kholo (My Profile jaisa)
        itemSettings.setOnClickListener(v -> startActivity(new Intent(this, TeacherSettingActivity.class)));

        // 4. HELP — Static info
        // 4. HELP — Help & Support page kholo (My Profile/Settings jaisa)
        itemHelp.setOnClickListener(v -> startActivity(new Intent(this, TeacherHelpActivity.class)));

        // 5. LOGOUT — Confirm dialog
        itemLogout.setOnClickListener(v -> showLogoutDialog());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 1. MY PROFILE DIALOG
    // ─────────────────────────────────────────────────────────────────────────
    private void showMyProfileDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText etName = new EditText(this);
        etName.setHint("Name");
        etName.setText(teacherName);
        layout.addView(etName);

        final EditText etEmail = new EditText(this);
        etEmail.setHint("Email");
        etEmail.setText(teacherEmail);
        layout.addView(etEmail);

        final EditText etPhone = new EditText(this);
        etPhone.setHint("Phone Number");
        etPhone.setText(teacherPhone);
        layout.addView(etPhone);

        // Subject aur Teacher ID sirf dikhao (non-editable)
        TextView tvStatic = new TextView(this);
        tvStatic.setText("\nSubject: " + teacherSubject + "\nTeacher ID: " + teacherId);
        tvStatic.setPadding(10, 10, 10, 10);
        layout.addView(tvStatic);

        new AlertDialog.Builder(this)
                .setTitle("Edit Profile")
                .setView(layout)
                .setPositiveButton("Update", (dialog, which) -> {
                    String newName  = etName.getText().toString().trim();
                    String newEmail = etEmail.getText().toString().trim();
                    String newPhone = etPhone.getText().toString().trim();

                    if (newName.isEmpty() || newEmail.isEmpty() || newPhone.isEmpty()) {
                        Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    updateProfileInFirebase(newName, newEmail, newPhone);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void updateProfileInFirebase(String name, String email, String phone) {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) return;

        java.util.HashMap<String, Object> map = new java.util.HashMap<>();
        map.put("name",  name);
        map.put("email", email);
        map.put("phone", phone);

        userRef.updateChildren(map).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                if (!email.equals(teacherEmail)) {
                    user.updateEmail(email).addOnCompleteListener(authTask -> {
                        if (authTask.isSuccessful()) {
                            Toast.makeText(this, "Profile and Email updated!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this,
                                    "DB updated, but Email update failed (Re-login required)",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    Toast.makeText(this, "Profile updated successfully!", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this,
                        "Update failed: " + task.getException().getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 2. CHECK NEW ANNOUNCEMENTS — badge show/hide
    // ─────────────────────────────────────────────────────────────────────────
    private void checkNewAnnouncements() {
        long lastSeen = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getLong(KEY_LAST_SEEN, 0);

        FirebaseUser currentUser = mAuth.getCurrentUser();
        String uid = (currentUser != null) ? currentUser.getUid() : null;

        // 2 sources check karein: Announcements/Teachers + Notifications/{uid}
        int totalChecks = (uid != null) ? 2 : 1;
        java.util.concurrent.atomic.AtomicInteger pending =
                new java.util.concurrent.atomic.AtomicInteger(totalChecks);
        boolean[] hasNew = {false};

        // ── Check 1: Announcements/Teachers ──────────────────────────────────
        FirebaseDatabase.getInstance().getReference("Announcements").child("Teachers")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot child : snapshot.getChildren()) {
                            Long ts = child.child("timestamp").getValue(Long.class);
                            if (ts != null && ts > lastSeen) {
                                hasNew[0] = true;
                                break;
                            }
                        }
                        if (pending.decrementAndGet() == 0) updateBadgeVisibility(hasNew[0]);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (pending.decrementAndGet() == 0) updateBadgeVisibility(hasNew[0]);
                    }
                });

        if (uid == null) return;

        // ── Check 2: Notifications/{uid} — unread notifications ──────────────
        FirebaseDatabase.getInstance().getReference("Notifications").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot child : snapshot.getChildren()) {
                            Boolean read = child.child("read").getValue(Boolean.class);
                            Long ts      = child.child("timestamp").getValue(Long.class);
                            if (!Boolean.TRUE.equals(read)) {
                                hasNew[0] = true;
                                break;
                            }
                            if (ts != null && ts > lastSeen) {
                                hasNew[0] = true;
                                break;
                            }
                        }
                        if (pending.decrementAndGet() == 0) updateBadgeVisibility(hasNew[0]);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        if (pending.decrementAndGet() == 0) updateBadgeVisibility(hasNew[0]);
                    }
                });
    }

    /** Yellow badge show ya hide karo */
    private void updateBadgeVisibility(boolean hasNew) {
        if (notificationBadge != null) {
            notificationBadge.setVisibility(hasNew ? View.VISIBLE : View.GONE);
        }
    }

    private void saveLastSeenTime() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putLong(KEY_LAST_SEEN, System.currentTimeMillis())
                .apply();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 5. LOGOUT DIALOG
    // ─────────────────────────────────────────────────────────────────────────
    private void showLogoutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Do you want to logout?")
                .setPositiveButton("Yes, Logout", (dialog, which) -> {
                    mAuth.signOut();
                    goToLogin();
                })
                .setNegativeButton("Cancel", null)
                .setIcon(R.drawable.ic_power)
                .show();
    }

    // ── Bottom Navigation ─────────────────────────────────────────────────────
    private void setupBottomNav() {
        bottomNav.setSelectedItemId(R.id.nav_bottom_profile);

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_bottom_home) {
                Intent intent = new Intent(this, TeacherDashboardActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
                return true;

            } else if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class));
                finish();
                return true;

            } else if (id == R.id.nav_bottom_Announcment) {
                startActivity(new Intent(this, TeacherAnnouncementsActivity.class));
                finish();
                return true;

            } else if (id == R.id.nav_bottom_profile) {
                // Already here
                return true;
            }
            return false;
        });
    }

    // ── Go to Login ───────────────────────────────────────────────────────────
    private void goToLogin() {
        Intent intent = new Intent(this, LoginSelectionActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}