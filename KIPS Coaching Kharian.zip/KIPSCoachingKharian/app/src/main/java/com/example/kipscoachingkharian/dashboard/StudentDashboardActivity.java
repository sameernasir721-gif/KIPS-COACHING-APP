package com.example.kipscoachingkharian.dashboard;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Activity representing the dashboard for Students.
 * It serves as the central hub for students to view their profile,
 * and in future updates, access results, attendance, and notices specific to their class.
 */
public class StudentDashboardActivity extends AppCompatActivity {

    private TextView tvWelcome;
    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_dashboard);

        // Initialize UI components
        tvWelcome = findViewById(R.id.tvWelcome);
        btnLogout = findViewById(R.id.btnLogout);

        // Retrieve and display student profile data from Firebase
        fetchStudentDetails();

        // Handle Logout
        btnLogout.setOnClickListener(v -> {
            // 1. Sign out from Firebase
            FirebaseAuth.getInstance().signOut();

            // 2. Navigate back to the main selection screen
            Intent intent = new Intent(this, LoginSelectionActivity.class);
            // Ensure the user cannot go back to the dashboard using the back button
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finishAffinity(); // Completely clear the activity stack
        });
    }

    /**
     * Fetches the current user's profile data from the Realtime Database.
     * We specifically look for 'name' and 'className' to personalize the dashboard.
     */
    private void fetchStudentDetails() {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Access the "Users" node for the current UID
        FirebaseDatabase.getInstance().getReference("Users").child(uid).get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        // Extract data safely
                        String name = snapshot.child("name").getValue(String.class);
                        String className = snapshot.child("className").getValue(String.class);

                        // Update UI with retrieved details
                        tvWelcome.setText("Welcome " + name + "\nClass: " + className);
                    } else {
                        tvWelcome.setText("Profile not found.");
                    }
                })
                .addOnFailureListener(e -> {
                    // Handle network or permission errors
                    Toast.makeText(this, "Failed to load profile: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}