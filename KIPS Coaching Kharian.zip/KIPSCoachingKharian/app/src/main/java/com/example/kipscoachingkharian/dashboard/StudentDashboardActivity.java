package com.example.kipscoachingkharian.dashboard;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class StudentDashboardActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private TextView tvStudentName, tvStudentClass;
    private ImageView ivMenu,ivStudent;
    private EditText etSearch;

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private BottomNavigationView bottomNav;

    private LinearLayout containerUpcomingClasses;
    private LinearLayout containerUpcomingQuizzes;
    private LinearLayout containerUpcomingAssignments;

    private TextView tvClassRemindersHeader;
    private View scrollClassReminders;
    private LinearLayout containerClassReminders;

    // Grid Cards
    private CardView cardSubjects, cardClassSchedule, cardStudyMaterial, cardQuizzes;
    private CardView cardAssignments, cardReports, cardFees, cardAnnouncements;

    private List<CardView> allCards;
    private List<String> allCardLabels;

    // Handler for refreshing join button status every minute
    private Handler refreshHandler = new Handler();
    private Runnable refreshRunnable;

    // Home banner slider (auto-slides every 2.5 seconds)
    private ViewPager2 bannerSlider;
    private LinearLayout bannerDotsIndicator;
    private final Handler bannerHandler = new Handler();
    private Runnable bannerRunnable;
    private final List<ImageView> bannerDotViews = new ArrayList<>();

    private DatabaseReference feeRef;
    private ValueEventListener feeListener;
    private DataSnapshot feeSnapshot;
    private boolean feeLoaded = false;
    private AlertDialog feeDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_dashboard);

        initViews();
        setupSearchData();
        fetchStudentDetails();
        loadUpcomingSchedule();
        setupListeners();
        setupBannerSlider();
        requestNotificationPermissionIfNeeded();
        watchFeeStatus();
    }

    private String currentMonthKey() {
        SimpleDateFormat f = new SimpleDateFormat("MMMM_yyyy", Locale.ENGLISH);
        f.setTimeZone(TimeZone.getTimeZone("Asia/Karachi"));
        return f.format(new Date());
    }

    private String currentMonthLabel() {
        SimpleDateFormat f = new SimpleDateFormat("MMMM yyyy", Locale.ENGLISH);
        f.setTimeZone(TimeZone.getTimeZone("Asia/Karachi"));
        return f.format(new Date());
    }

    private void watchFeeStatus() {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        feeRef = FirebaseDatabase.getInstance().getReference("Fees").child(uid);
        feeListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                feeSnapshot = snapshot;
                feeLoaded = true;
                updateLockedUi();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                feeSnapshot = null;
                feeLoaded = true;
                updateLockedUi();
            }
        };
        feeRef.addValueEventListener(feeListener);
    }

    private boolean isFeePaidThisMonth() {
        if (feeSnapshot == null) return false;
        Object st = feeSnapshot.child(currentMonthKey()).child("status").getValue();
        return st != null && "paid".equalsIgnoreCase(String.valueOf(st).trim());
    }

    private boolean canAccessFeatures() {
        if (!feeLoaded) {
            showToast("Checking fee status, please wait...");
            return false;
        }
        if (isFeePaidThisMonth()) return true;
        showFeeLockedDialog();
        return false;
    }

    private void openFeature(Class<?> target) {
        if (canAccessFeatures()) startActivity(new Intent(this, target));
    }

    private void showFeeLockedDialog() {
        if (isFinishing() || (feeDialog != null && feeDialog.isShowing())) return;
        feeDialog = new AlertDialog.Builder(this)
                .setTitle("Fee Pending")
                .setMessage("Your fee for " + currentMonthLabel()
                        + " is not paid yet. Please pay your fee to access this feature.")
                .setPositiveButton("Pay Now", (d, w) ->
                        startActivity(new Intent(this, FeeActivity.class)))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void updateLockedUi() {
        if (allCards == null) return;
        boolean locked = !feeLoaded || !isFeePaidThisMonth();
        for (CardView card : allCards) {
            card.setAlpha(card == cardFees || !locked ? 1f : 0.45f);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (feeRef != null && feeListener != null) feeRef.removeEventListener(feeListener);
    }


    // ─── HOME BANNER SLIDER ───────────────────────────────────────────────────
    // Cards ke neeche 4 slides auto-move hote hain (har 2.5 second baad), jaise
    // "Top App Features" section mein hain waise hi colors/icons reuse kiye hain.
    private void setupBannerSlider() {
        List<BannerSlide> slides = new ArrayList<>();
        slides.add(new BannerSlide(R.drawable.ic_quiz, "#FFEBEE", "#FFCDD2", "#E53935",
                "#B71C1C", "#C62828", "Smart Quizzes",
                "Attempt timed quizzes, get instant results, track score history and improve your learning."));
        slides.add(new BannerSlide(R.drawable.ic_assignment, "#FCE4EC", "#F8BBD0", "#D81B60",
                "#AD1457", "#C2185B", "Assignments",
                "View, attempt and submit assignments shared by your teacher — all in one place."));
        slides.add(new BannerSlide(R.drawable.ic_result, "#FFE5E5", "#FFBABA", "#D32F2F",
                "#B71C1C", "#D32F2F", "Progress Report",
                "Check your marks, quiz scores and overall academic performance anytime, anywhere."));
        slides.add(new BannerSlide(R.drawable.ic_study_material, "#FDE7EE", "#F5B5C8", "#C2185B",
                "#A0153E", "#C2185B", "Study Material",
                "Access notes, PDFs and reading material uploaded by your teacher for every subject."));
        slides.add(new BannerSlide(R.drawable.ic_fee, "#FFEBEE", "#EF9A9A", "#C62828",
                "#B71C1C", "#C62828", "Fee Status",
                "View your fee details, payment history and pay outstanding dues online through payfast."));
        slides.add(new BannerSlide(R.drawable.ic_announcement, "#FCE4EC", "#F48FB1", "#D81B60",
                "#880E4F", "#AD1457", "Announcements",
                "Stay updated with the latest notices, class schedules and important messages from your teacher."));

        bannerSlider.setAdapter(new BannerAdapter(slides));

        bannerDotsIndicator.removeAllViews();
        bannerDotViews.clear();
        int dotSize = (int) (8 * getResources().getDisplayMetrics().density);
        int dotMargin = (int) (4 * getResources().getDisplayMetrics().density);
        for (int i = 0; i < slides.size(); i++) {
            ImageView dot = new ImageView(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dotSize, dotSize);
            lp.setMarginStart(dotMargin);
            lp.setMarginEnd(dotMargin);
            dot.setLayoutParams(lp);
            dot.setBackgroundResource(R.drawable.circle_bg);
            dot.setBackgroundTintList(ColorStateList.valueOf(
                    Color.parseColor(i == 0 ? "#B71C1C" : "#E0E0E0")));
            bannerDotsIndicator.addView(dot);
            bannerDotViews.add(dot);
        }

        bannerSlider.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                for (int i = 0; i < bannerDotViews.size(); i++) {
                    bannerDotViews.get(i).setBackgroundTintList(ColorStateList.valueOf(
                            Color.parseColor(i == position ? "#B71C1C" : "#E0E0E0")));
                }
            }
        });
    }

    // Ek slide ka data (color/icon/text) rakhne wali chhoti class
    private static class BannerSlide {
        final int iconRes;
        final String bgColor, blobColor, iconTint, titleColor, subtitleColor, title, subtitle;

        BannerSlide(int iconRes, String bgColor, String blobColor, String iconTint,
                    String titleColor, String subtitleColor, String title, String subtitle) {
            this.iconRes = iconRes;
            this.bgColor = bgColor;
            this.blobColor = blobColor;
            this.iconTint = iconTint;
            this.titleColor = titleColor;
            this.subtitleColor = subtitleColor;
            this.title = title;
            this.subtitle = subtitle;
        }
    }

    // ViewPager2 ke andar RecyclerView hi chalti hai, isliye adapter RecyclerView ka hi hai
    private static class BannerAdapter extends RecyclerView.Adapter<BannerAdapter.VH> {
        private final List<BannerSlide> slides;

        BannerAdapter(List<BannerSlide> slides) {
            this.slides = slides;
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_banner_slide, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH holder, int position) {
            BannerSlide s = slides.get(position);
            holder.bg.setBackgroundColor(Color.parseColor(s.bgColor));
            holder.blob.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(s.blobColor)));
            holder.icon.setImageResource(s.iconRes);
            holder.icon.setImageTintList(null); // icon apne original (multi-color) rang mein dikhe
            holder.title.setText(s.title);
            holder.title.setTextColor(Color.parseColor(s.titleColor));
            holder.subtitle.setText(s.subtitle);
            holder.subtitle.setTextColor(Color.parseColor(s.subtitleColor));
        }

        @Override
        public int getItemCount() {
            return slides.size();
        }

        static class VH extends RecyclerView.ViewHolder {
            final View bg;
            final ImageView blob, icon;
            final TextView title, subtitle;

            VH(@NonNull View itemView) {
                super(itemView);
                bg = itemView.findViewById(R.id.vSlideBg);
                blob = itemView.findViewById(R.id.ivSlideBlob);
                icon = itemView.findViewById(R.id.ivSlideIcon);
                title = itemView.findViewById(R.id.tvSlideTitle);
                subtitle = itemView.findViewById(R.id.tvSlideSubtitle);
            }
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateLockedUi();

        refreshRunnable = new Runnable() {
            @Override
            public void run() {
                loadUpcomingSchedule();
                refreshHandler.postDelayed(this, 60 * 1000);
            }
        };
        refreshHandler.postDelayed(refreshRunnable, 60 * 1000);

        bannerRunnable = new Runnable() {
            @Override
            public void run() {
                if (bannerSlider != null && bannerSlider.getAdapter() != null) {
                    int count = bannerSlider.getAdapter().getItemCount();
                    if (count > 0) {
                        int next = (bannerSlider.getCurrentItem() + 1) % count;
                        bannerSlider.setCurrentItem(next, true);
                    }
                }
                bannerHandler.postDelayed(this, 2500);
            }
        };
        bannerHandler.postDelayed(bannerRunnable, 2500);
    }

    @Override
    protected void onPause() {
        super.onPause();
        refreshHandler.removeCallbacks(refreshRunnable);
        bannerHandler.removeCallbacks(bannerRunnable);
    }

    private void initViews() {
        tvStudentName  = findViewById(R.id.tvStudentName);
        tvStudentClass = findViewById(R.id.tvStudentClass);
        ivMenu         = findViewById(R.id.ivMenu);
        ivStudent = findViewById(R.id.ivStudent);
        etSearch       = findViewById(R.id.etSearch);
        drawerLayout   = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);
        bottomNav      = findViewById(R.id.bottomNav);

        containerUpcomingClasses     = findViewById(R.id.containerUpcomingClasses);
        containerUpcomingQuizzes     = findViewById(R.id.containerUpcomingQuizzes);
        containerUpcomingAssignments = findViewById(R.id.containerUpcomingAssignments);

        tvClassRemindersHeader  = findViewById(R.id.tvClassRemindersHeader);
        scrollClassReminders    = findViewById(R.id.scrollClassReminders);
        containerClassReminders = findViewById(R.id.containerClassReminders);

        cardSubjects      = findViewById(R.id.cardSubjects);
        cardClassSchedule = findViewById(R.id.cardClassSchedule);
        cardStudyMaterial = findViewById(R.id.cardStudyMaterial);
        cardQuizzes       = findViewById(R.id.cardQuizzes);
        cardAssignments   = findViewById(R.id.cardAssignments);
        cardReports       = findViewById(R.id.cardReports);
        cardFees          = findViewById(R.id.cardFees);
        cardAnnouncements = findViewById(R.id.cardAnnouncements);

        bannerSlider         = findViewById(R.id.bannerSlider);
        bannerDotsIndicator  = findViewById(R.id.bannerDotsIndicator);
    }

    private void setupSearchData() {
        allCards = new ArrayList<>();
        allCards.add(cardSubjects);
        allCards.add(cardClassSchedule);
        allCards.add(cardStudyMaterial);
        allCards.add(cardQuizzes);
        allCards.add(cardAssignments);
        allCards.add(cardReports);
        allCards.add(cardFees);
        allCards.add(cardAnnouncements);

        allCardLabels = new ArrayList<>();
        allCardLabels.add("Subjects");
        allCardLabels.add("Class Schedule");
        allCardLabels.add("Study Material");
        allCardLabels.add("Quizzes");
        allCardLabels.add("Assignments");
        allCardLabels.add("Progress Report");
        allCardLabels.add("Fee Status");
        allCardLabels.add("Announcements");
    }

    private void setupListeners() {
        navigationView.setNavigationItemSelectedListener(this);
        ivMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
        ivStudent.setOnClickListener(v ->
                startActivity(new Intent(this, StudentProfileInfoActivity.class)));

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterCards(s.toString().trim());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                return true;
            } else if (id == R.id.nav_bottom_feedback) {
                if (!canAccessFeatures()) return false;
                startActivity(new Intent(this, FeedbackActivity.class));
                finish();
                return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                finish();
                return true;
            }
            return false;
        });

        cardSubjects.setOnClickListener(v -> openFeature(SubjectsActivity.class));
        cardClassSchedule.setOnClickListener(v -> openFeature(ClassScheduleActivity.class));
        cardStudyMaterial.setOnClickListener(v -> openFeature(StudyMaterialActivity.class));
        cardQuizzes.setOnClickListener(v -> openFeature(QuizActivity.class));
        cardAssignments.setOnClickListener(v -> openFeature(AssignmentActivity.class));
        cardReports.setOnClickListener(v -> openFeature(ProgressActivity.class));
        cardFees.setOnClickListener(v -> startActivity(new Intent(this, FeeActivity.class)));
        cardAnnouncements.setOnClickListener(v -> openFeature(AnnouncementsActivity.class));
    }

    // --- FIREBASE DATA ---

    private void fetchStudentDetails() {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            String name = snapshot.child("name").getValue(String.class);
                            String cls = snapshot.child("className").getValue(String.class);
                            tvStudentName.setText(name != null ? name : "Student");
                            tvStudentClass.setText("Grade: " + (cls != null ? cls : "-"));
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void loadUpcomingSchedule() {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot userSnap) {
                        String baseClass = userSnap.child("className").getValue(String.class);
                        String section   = userSnap.child("assignedSection").getValue(String.class);
                        if (baseClass == null) return;


                        String trimmedBase = baseClass.trim();
                        boolean baseIsNumberOnly = trimmedBase.matches("\\d+");
                        String studentClass = baseIsNumberOnly && section != null && !section.trim().isEmpty()
                                ? trimmedBase + section.trim()
                                : trimmedBase;

                        final List<String> enrolledSubjects = new ArrayList<>();
                        for (DataSnapshot subSnap : userSnap.child("enrolledSubjects").getChildren()) {
                            String sub = subSnap.getValue(String.class);
                            if (sub != null) enrolledSubjects.add(sub);
                        }

                        FirebaseDatabase.getInstance().getReference("upcomingSchedule")
                                .addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot scheduleData) {
                                        if (containerUpcomingClasses == null) return;

                                        containerUpcomingClasses.removeAllViews();
                                        containerUpcomingQuizzes.removeAllViews();
                                        containerUpcomingAssignments.removeAllViews();


                                        List<DataSnapshot> quizItems       = new ArrayList<>();
                                        List<DataSnapshot> assignmentItems = new ArrayList<>();

                                        for (DataSnapshot snap : scheduleData.getChildren()) {
                                            String type   = snap.child("type").getValue(String.class);
                                            String target = snap.child("className").getValue(String.class);
                                            if (target == null) target = snap.child("targetClass").getValue(String.class);

                                            if (type == null || target == null) continue;
                                            if (!target.trim().equalsIgnoreCase(studentClass.trim())) continue;


                                            String itemSubject = snap.child("subject").getValue(String.class);
                                            if (itemSubject != null && !itemSubject.trim().isEmpty()
                                                    && !isEnrolledInSubject(enrolledSubjects, itemSubject)) {
                                                continue;
                                            }

                                            String typeLow = type.toLowerCase();
                                            if (typeLow.contains("quiz"))       quizItems.add(snap);
                                            else if (typeLow.contains("assignment")) assignmentItems.add(snap);
                                        }


                                        loadLiveClassCard(studentClass, enrolledSubjects);


                                        filterUnattemptedQuizzesAndShow(quizItems);


                                        filterUnsubmittedAssignmentsAndShow(assignmentItems);
                                    }
                                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                                });
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }


    private void filterUnattemptedQuizzesAndShow(List<DataSnapshot> quizItems) {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        String studentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        if (quizItems.isEmpty()) {
            showQuizResult(null);
            return;
        }

        DatabaseReference attemptsRef = FirebaseDatabase.getInstance().getReference("QuizAttempts");
        final int[] pending = {quizItems.size()};
        final List<DataSnapshot> unattempted = new ArrayList<>();

        for (DataSnapshot item : quizItems) {
            String quizId = item.child("quizId").getValue(String.class);

            if (quizId == null || quizId.trim().isEmpty()) {

                unattempted.add(item);
                pending[0]--;
                if (pending[0] == 0) showQuizResult(pickEarliest(unattempted, "time", null));
                continue;
            }

            attemptsRef.child(quizId).child(studentUid)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot attemptSnap) {
                            if (!attemptSnap.exists()) {
                                unattempted.add(item);
                            }
                            pending[0]--;
                            if (pending[0] == 0) {
                                showQuizResult(pickEarliest(unattempted, "time", null));
                            }
                        }
                        @Override public void onCancelled(@NonNull DatabaseError error) {
                            unattempted.add(item);
                            pending[0]--;
                            if (pending[0] == 0) {
                                showQuizResult(pickEarliest(unattempted, "time", null));
                            }
                        }
                    });
        }
    }

    private void showQuizResult(DataSnapshot earliestQuiz) {
        if (containerUpcomingQuizzes == null) return;
        containerUpcomingQuizzes.removeAllViews();

        if (earliestQuiz != null) {
            String title = earliestQuiz.child("title").getValue(String.class);
            String date  = earliestQuiz.child("time").getValue(String.class);
            CardView quizCard = addStyledCard(containerUpcomingQuizzes, "Upcoming Quiz",
                    title, "Date: " + date,
                    "#FFEBEE", "#C62828", null);
            quizCard.setOnClickListener(v -> openFeature(QuizActivity.class));
        } else {
            CardView noQuizCard = addStyledCard(containerUpcomingQuizzes, "Upcoming Quiz",
                    "No Upcoming Quiz", "Check back later",
                    "#FFEBEE", "#C62828", null);
            noQuizCard.setOnClickListener(v -> openFeature(QuizActivity.class));
        }
    }


    private void filterUnsubmittedAssignmentsAndShow(List<DataSnapshot> assignmentItems) {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        String studentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        if (assignmentItems.isEmpty()) {
            showAssignmentResult(null);
            return;
        }

        DatabaseReference submissionsRef = FirebaseDatabase.getInstance().getReference("Submissions");
        final int[] pending = {assignmentItems.size()};
        final List<DataSnapshot> unsubmitted = new ArrayList<>();

        for (DataSnapshot item : assignmentItems) {
            String assignmentId = item.child("assignmentId").getValue(String.class);

            if (assignmentId == null || assignmentId.trim().isEmpty()) {

                unsubmitted.add(item);
                pending[0]--;
                if (pending[0] == 0) showAssignmentResult(pickEarliest(unsubmitted, "dueDate", "dueTime"));
                continue;
            }

            submissionsRef.child(assignmentId).child(studentUid)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot subSnap) {
                            if (!subSnap.exists()) {
                                unsubmitted.add(item);
                            }
                            pending[0]--;
                            if (pending[0] == 0) {
                                showAssignmentResult(pickEarliest(unsubmitted, "dueDate", "dueTime"));
                            }
                        }
                        @Override public void onCancelled(@NonNull DatabaseError error) {
                            // Error ho to bhi consider karo (filter na karein, taake data hide na ho)
                            unsubmitted.add(item);
                            pending[0]--;
                            if (pending[0] == 0) {
                                showAssignmentResult(pickEarliest(unsubmitted, "dueDate", "dueTime"));
                            }
                        }
                    });
        }
    }

    private void showAssignmentResult(DataSnapshot earliestAssignment) {
        if (containerUpcomingAssignments == null) return;
        containerUpcomingAssignments.removeAllViews();

        if (earliestAssignment != null) {
            String msg     = earliestAssignment.child("message").getValue(String.class);
            String dueDate = earliestAssignment.child("dueDate").getValue(String.class);
            String title   = (msg != null && !msg.trim().isEmpty()) ? msg : "Assignment";
            String detail  = (dueDate != null ? "Due: " + dueDate : "");
            CardView assignCard = addStyledCard(containerUpcomingAssignments, "Assignment",
                    title, detail,
                    "#E8F5E9", "#2E7D32", null);
            assignCard.setOnClickListener(v -> openFeature(AssignmentActivity.class));
        } else {
            CardView noAssignCard = addStyledCard(containerUpcomingAssignments, "Assignment",
                    "No Upcoming Assignment", "Check back later",
                    "#E8F5E9", "#2E7D32", null);
            noAssignCard.setOnClickListener(v -> openFeature(AssignmentActivity.class));
        }
    }


    private boolean isEnrolledInSubject(List<String> enrolledSubjects, String subject) {
        for (String s : enrolledSubjects) {
            if (s != null && s.trim().equalsIgnoreCase(subject.trim())) return true;
        }
        return false;
    }


    private DataSnapshot pickEarliest(List<DataSnapshot> items, String dateField, String timeField) {
        if (items.isEmpty()) return null;

        long now = System.currentTimeMillis();
        DataSnapshot best = null;
        long bestMillis = Long.MAX_VALUE;

        for (DataSnapshot item : items) {
            String date = item.child(dateField).getValue(String.class);
            String time = (timeField != null) ? item.child(timeField).getValue(String.class) : null;
            long millis = parseScheduleMillis(date, time);


            if (millis != Long.MAX_VALUE && millis < now) continue;

            if (millis < bestMillis) {
                best = item;
                bestMillis = millis;
            }
        }
        return best;
    }


    private long parseScheduleMillis(String date, String time) {
        try {
            Calendar cal = Calendar.getInstance();

            if (date != null && !date.trim().isEmpty()) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("d/M/yyyy", Locale.getDefault());
                Date d = dateFormat.parse(date.trim());
                if (d != null) {
                    Calendar dCal = Calendar.getInstance();
                    dCal.setTime(d);
                    cal.set(Calendar.YEAR, dCal.get(Calendar.YEAR));
                    cal.set(Calendar.MONTH, dCal.get(Calendar.MONTH));
                    cal.set(Calendar.DAY_OF_MONTH, dCal.get(Calendar.DAY_OF_MONTH));
                }
            }

            if (time != null && !time.trim().isEmpty()) {
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.ENGLISH);
                Date t = sdf.parse(time.trim());
                if (t != null) {
                    Calendar tCal = Calendar.getInstance();
                    tCal.setTime(t);
                    cal.set(Calendar.HOUR_OF_DAY, tCal.get(Calendar.HOUR_OF_DAY));
                    cal.set(Calendar.MINUTE, tCal.get(Calendar.MINUTE));
                } else {
                    cal.set(Calendar.HOUR_OF_DAY, 23);
                    cal.set(Calendar.MINUTE, 59);
                }
            } else {
                cal.set(Calendar.HOUR_OF_DAY, 23);
                cal.set(Calendar.MINUTE, 59);
            }
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);

            return cal.getTimeInMillis();
        } catch (ParseException e) {
            return Long.MAX_VALUE;
        }
    }


    private void loadLiveClassCard(String studentClass, List<String> enrolledSubjects) {
        FirebaseDatabase.getInstance().getReference("Classes")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot allTeachers) {
                        String bestSubject = null, bestTime = null, bestDate = null, bestLink = null;
                        Integer bestDuration = null;
                        long bestMillis = Long.MAX_VALUE;
                        long now = System.currentTimeMillis();

                        for (DataSnapshot teacherSnap : allTeachers.getChildren()) {
                            for (DataSnapshot classSnap : teacherSnap.getChildren()) {
                                String grade   = classSnap.child("grade").getValue(String.class);
                                String sub     = classSnap.child("subject").getValue(String.class);
                                String time    = classSnap.child("time").getValue(String.class);
                                String date    = classSnap.child("date").getValue(String.class);
                                String link    = classSnap.child("classLink").getValue(String.class);
                                Long durLong   = classSnap.child("duration").getValue(Long.class);
                                int duration   = (durLong != null && durLong > 0) ? durLong.intValue() : 45;


                                boolean gradeMatch = grade != null && studentClass != null &&
                                        (grade.trim().equalsIgnoreCase(studentClass.trim()) ||
                                                grade.trim().equalsIgnoreCase("Class " + studentClass.trim()));
                                if (!gradeMatch) continue;


                                if (sub != null && !sub.trim().isEmpty()
                                        && !isEnrolledInSubject(enrolledSubjects, sub)) continue;

                                long classMillis = parseScheduleMillis(date, time);
                                long windowEnd = classMillis + (duration * 60L * 1000);

                                if (classMillis != Long.MAX_VALUE && windowEnd < now) continue;

                                long sortKey = (classMillis != Long.MAX_VALUE) ? classMillis : Long.MAX_VALUE;
                                if (sortKey < bestMillis) {
                                    bestMillis   = sortKey;
                                    bestSubject  = sub;
                                    bestTime     = time;
                                    bestDate     = date;
                                    bestLink     = link;
                                    bestDuration = duration;
                                }
                            }
                        }

                        if (bestSubject != null || bestTime != null) {

                            boolean canJoin = bestLink != null && !bestLink.trim().isEmpty();
                            addClassCard(containerUpcomingClasses,
                                    bestSubject != null ? bestSubject : "Class",
                                    bestTime, bestLink, canJoin);


                            if (canJoin) {
                                hideClassReminders();
                            } else {
                                loadClassReminders();
                            }
                        } else {
                            addNoUpcomingClassCard(containerUpcomingClasses);
                            loadClassReminders();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        addNoUpcomingClassCard(containerUpcomingClasses);
                    }
                });
    }


    private void fetchClassLinkAndAddCard(String subject, String classTime, String date, String studentClass) {
        FirebaseDatabase.getInstance().getReference("Classes")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot allTeachers) {
                        String foundLink = null;
                        String foundTime = classTime;
                        String foundDate = date;
                        String foundSubject = subject;
                        Integer foundDuration = null;


                        outer:
                        for (DataSnapshot teacherSnap : allTeachers.getChildren()) {
                            for (DataSnapshot classSnap : teacherSnap.getChildren()) {
                                String grade = classSnap.child("grade").getValue(String.class);
                                String sub   = classSnap.child("subject").getValue(String.class);


                                boolean gradeMatch = grade != null &&
                                        (grade.trim().equalsIgnoreCase(studentClass.trim()) ||
                                                grade.trim().equalsIgnoreCase("Class " + studentClass.trim()));


                                boolean subMatch = (subject == null || subject.isEmpty()) ||
                                        (sub != null && sub.trim().equalsIgnoreCase(subject.trim()));

                                if (gradeMatch && subMatch) {
                                    foundLink    = classSnap.child("classLink").getValue(String.class);
                                    String t     = classSnap.child("time").getValue(String.class);
                                    String d     = classSnap.child("date").getValue(String.class);
                                    Long durLong = classSnap.child("duration").getValue(Long.class);
                                    if (t != null) foundTime = t;
                                    if (d != null) foundDate = d;
                                    if (sub != null) foundSubject = sub;
                                    if (durLong != null) foundDuration = durLong.intValue();
                                    break outer;
                                }
                            }
                        }


                        boolean canJoin = isClassTimeNow(foundTime, foundDate, foundDuration);
                        addClassCard(containerUpcomingClasses,
                                foundSubject != null ? foundSubject : "Class",
                                foundTime,
                                foundLink,
                                canJoin);
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {

                        addClassCard(containerUpcomingClasses,
                                subject != null ? subject : "Class",
                                classTime, null, false);
                    }
                });
    }


    private boolean isClassTimeNow(String classTime, String classDate, Integer durationMinutes) {
        if (classTime == null || classTime.isEmpty()) return false;

        try {

            SimpleDateFormat dateFormat = new SimpleDateFormat("d/M/yyyy", Locale.getDefault());
            String todayStr = dateFormat.format(new Date());


            if (classDate != null && !classDate.isEmpty()) {
                if (!classDate.equalsIgnoreCase(todayStr)) return false;
            }


            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.ENGLISH);
            Date classDateTime = sdf.parse(classTime.trim());
            if (classDateTime == null) return false;

            Calendar classCal = Calendar.getInstance();
            Calendar parsedCal = Calendar.getInstance();
            parsedCal.setTime(classDateTime);

            classCal.set(Calendar.HOUR_OF_DAY, parsedCal.get(Calendar.HOUR_OF_DAY));
            classCal.set(Calendar.MINUTE, parsedCal.get(Calendar.MINUTE));
            classCal.set(Calendar.SECOND, 0);

            long classMillis = classCal.getTimeInMillis();
            long nowMillis   = System.currentTimeMillis();

            int duration = (durationMinutes != null && durationMinutes > 0) ? durationMinutes : 45;

            long windowStart = classMillis - (10 * 60 * 1000);
            long windowEnd   = classMillis + (duration * 60 * 1000);

            return nowMillis >= windowStart && nowMillis <= windowEnd;

        } catch (ParseException e) {
            return false;
        }
    }

    // --- UI HELPERS ---

    private void loadClassReminders() {
        String uid = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : null;
        if (uid == null) return;

        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot userSnap) {
                        String baseClass = userSnap.child("className").getValue(String.class);
                        String section   = userSnap.child("assignedSection").getValue(String.class);
                        if (baseClass == null) { hideClassReminders(); return; }

                        String trimmedBase = baseClass.trim();
                        boolean baseIsNumberOnly = trimmedBase.matches("\\d+");
                        String studentClass = baseIsNumberOnly && section != null && !section.trim().isEmpty()
                                ? trimmedBase + section.trim()
                                : trimmedBase;

                        fetchClassReminders(uid, studentClass);
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) { hideClassReminders(); }
                });
    }

    private void fetchClassReminders(String uid, String studentClass) {
        FirebaseDatabase.getInstance().getReference("Announcements").child("Students")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        List<DataSnapshot> reminders = new ArrayList<>();

                        for (DataSnapshot snap : snapshot.getChildren()) {
                            if (snap.getKey() != null && snap.getKey().equals(uid)) {

                                for (DataSnapshot child : snap.getChildren()) {
                                    String type = child.child("type").getValue(String.class);
                                    if ("new_class".equals(type)) reminders.add(child);
                                }
                            } else {

                                String type = snap.child("type").getValue(String.class);
                                if (!"new_class".equals(type)) continue;
                                String target = snap.child("targetClass").getValue(String.class);
                                if (target == null || target.trim().equalsIgnoreCase(studentClass)) {
                                    reminders.add(snap);
                                }
                            }
                        }


                        reminders.sort((a, b) -> {
                            Long ta = a.child("timestamp").getValue(Long.class);
                            Long tb = b.child("timestamp").getValue(Long.class);
                            long va = ta != null ? ta : 0;
                            long vb = tb != null ? tb : 0;
                            return Long.compare(vb, va);
                        });

                        containerClassReminders.removeAllViews();


                        DataSnapshot nearest = null;
                        long nearestMillis = Long.MAX_VALUE;
                        for (DataSnapshot r : reminders) {
                            Long classMillis = getClassStartMillisIfInReminderWindow(r);
                            if (classMillis == null) continue;
                            if (classMillis < nearestMillis) {
                                nearestMillis = classMillis;
                                nearest = r;
                            }
                        }

                        if (nearest != null) {
                            addClassReminderCard(nearest);
                            tvClassRemindersHeader.setVisibility(View.VISIBLE);
                            scrollClassReminders.setVisibility(View.VISIBLE);
                        } else {
                            hideClassReminders();
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) { hideClassReminders(); }
                });
    }


    private Long getClassStartMillisIfInReminderWindow(DataSnapshot snap) {
        try {
            String message = snap.child("message").getValue(String.class);
            if (message == null || !message.contains(" at ")) return null;

            String[] parts = message.split("\\|");
            String rightPart = parts.length > 1 ? parts[1].trim() : parts[0].trim();
            String[] dateTimeParts = rightPart.split(" at ");
            if (dateTimeParts.length < 2) return null;

            String datePart = dateTimeParts[0].trim();
            String timePart = dateTimeParts[1].trim();

            SimpleDateFormat sdf = new SimpleDateFormat("d/M/yyyy hh:mm a", Locale.getDefault());
            Date classDateTime = sdf.parse(datePart + " " + timePart);
            if (classDateTime == null) return null;

            long classMillis = classDateTime.getTime();
            long reminderStart = classMillis - (15 * 60 * 1000);

            long now = System.currentTimeMillis();

            if (now >= reminderStart && now < classMillis) {
                return classMillis;
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    private void hideClassReminders() {
        tvClassRemindersHeader.setVisibility(View.GONE);
        scrollClassReminders.setVisibility(View.GONE);
    }


    private void addClassReminderCard(DataSnapshot snap) {
        float dp = getResources().getDisplayMetrics().density;

        String title   = snap.child("title").getValue(String.class);
        String message = snap.child("message").getValue(String.class);
        String link    = snap.child("classLink").getValue(String.class);

        CardView card = new CardView(this);
        int cardWidth  = (int) (200 * dp);
        int cardHeight = (int) (90 * dp);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(cardWidth, cardHeight);
        params.setMargins(0, 0, (int) (12 * dp), (int) (8 * dp));
        card.setLayoutParams(params);
        card.setRadius(15 * dp);
        card.setCardElevation(6 * dp);
        card.setCardBackgroundColor(Color.parseColor("#FFF3E0"));

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding((int) (15 * dp), (int) (12 * dp), (int) (15 * dp), (int) (12 * dp));

        TextView tvHeader = new TextView(this);
        tvHeader.setText(title != null ? title : "🔔 New Class");
        tvHeader.setTextSize(13f);
        tvHeader.setTextColor(Color.parseColor("#E65100"));
        tvHeader.setTypeface(null, Typeface.BOLD);
        tvHeader.setSingleLine(true);
        tvHeader.setEllipsize(TextUtils.TruncateAt.END);

        TextView tvMsg = new TextView(this);
        tvMsg.setText(message != null ? message : "");
        tvMsg.setTextSize(12f);
        tvMsg.setTextColor(Color.parseColor("#5D4037"));
        tvMsg.setMaxLines(2);
        tvMsg.setEllipsize(TextUtils.TruncateAt.END);
        tvMsg.setPadding(0, (int) (4 * dp), 0, 0);

        layout.addView(tvHeader);
        layout.addView(tvMsg);
        card.addView(layout);

        if (link != null && !link.trim().isEmpty()) {
            card.setOnClickListener(v -> {
                if (!canAccessFeatures()) return;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link)));
                } catch (Exception e) {
                    Toast.makeText(this, "Link cannot open: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        containerClassReminders.addView(card);
    }


    private void addClassCard(LinearLayout container, String subject, String time,
                              String classLink, boolean canJoin) {
        float dp = getResources().getDisplayMetrics().density;

        CardView card = new CardView(this);
        int cardWidth = (int) (180 * dp);
        int cardHeight = (int) (105 * dp);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(cardWidth, cardHeight);
        params.setMargins(0, 0, (int) (12 * dp), (int) (8 * dp));
        card.setLayoutParams(params);
        card.setRadius(15 * dp);
        card.setCardElevation(6 * dp);
        card.setCardBackgroundColor(Color.parseColor("#E3F2FD"));

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding((int) (15 * dp), (int) (12 * dp), (int) (15 * dp), (int) (12 * dp));
        layout.setClickable(false);
        layout.setFocusable(false);


        TextView tvHeader = new TextView(this);
        tvHeader.setText("Live Class");
        tvHeader.setTextSize(13f);
        tvHeader.setTextColor(Color.parseColor("#1565C0"));
        tvHeader.setTypeface(null, Typeface.BOLD);


        TextView tvTitle = new TextView(this);
        tvTitle.setText(subject);
        tvTitle.setTextSize(15f);
        tvTitle.setTextColor(Color.parseColor("#212121"));
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setSingleLine(true);
        tvTitle.setEllipsize(TextUtils.TruncateAt.END);
        tvTitle.setPadding(0, (int) (4 * dp), 0, 0);

        layout.addView(tvHeader);
        layout.addView(tvTitle);


        if (canJoin) {
            Button btnJoin = new Button(this);
            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (int) (28 * dp));
            btnParams.setMargins(0, (int) (6 * dp), 0, 0);
            btnJoin.setLayoutParams(btnParams);
            btnJoin.setText("🟢 Join Class");
            btnJoin.setTextSize(10f);
            btnJoin.setTextColor(Color.WHITE);
            btnJoin.setTypeface(null, Typeface.BOLD);
            btnJoin.setPadding(0, 0, 0, 0);
            btnJoin.setMinHeight(0);
            btnJoin.setMinimumHeight(0);
            btnJoin.setStateListAnimator(null);


            android.graphics.drawable.GradientDrawable btnBg = new android.graphics.drawable.GradientDrawable();
            btnBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
            btnBg.setCornerRadius(20 * dp);
            btnBg.setColor(Color.parseColor("#D50000"));
            btnJoin.setBackground(btnBg);

            final String link = classLink;
            btnJoin.setOnClickListener(v -> {
                if (!canAccessFeatures()) return;
                if (link != null && !link.isEmpty()) {
                    openClassLink(link);
                } else {
                    Toast.makeText(this,
                            "Class link not available. Contact to teacher.",
                            Toast.LENGTH_LONG).show();
                }
            });

            layout.addView(btnJoin);
        }

        card.addView(layout);


        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v -> {
            if (!canAccessFeatures()) return;
            Intent intent = new Intent(this, AttendanceActivity.class);
            intent.putExtra(AttendanceActivity.EXTRA_SUBJECT, subject);
            startActivity(intent);
        });

        container.addView(card);
    }


    private void openClassLink(String link) {
        try {
            if (!link.startsWith("http://") && !link.startsWith("https://")) {
                link = "https://" + link;
            }
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Link cannot open: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private CardView addStyledCard(LinearLayout container, String header, String title,
                                   String detail, String bgColor, String headerColor, String link) {
        float dp = getResources().getDisplayMetrics().density;

        CardView card = new CardView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int) (180 * dp), (int) (105 * dp));
        params.setMargins(0, 0, (int) (12 * dp), (int) (8 * dp));
        card.setLayoutParams(params);
        card.setRadius(15 * dp);
        card.setCardElevation(6 * dp);
        card.setCardBackgroundColor(Color.parseColor(bgColor));

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding((int) (15 * dp), (int) (12 * dp), (int) (15 * dp), (int) (12 * dp));

        TextView tvHeader = new TextView(this);
        tvHeader.setText(header);
        tvHeader.setTextSize(13f);
        tvHeader.setTextColor(Color.parseColor(headerColor));
        tvHeader.setTypeface(null, Typeface.BOLD);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(17f);
        tvTitle.setTextColor(Color.parseColor("#212121"));
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setSingleLine(true);
        tvTitle.setEllipsize(TextUtils.TruncateAt.END);
        tvTitle.setPadding(0, (int) (4 * dp), 0, 0);

        TextView tvDetail = new TextView(this);
        tvDetail.setText(detail);
        tvDetail.setTextSize(12f);
        tvDetail.setTextColor(Color.parseColor("#616161"));

        layout.addView(tvHeader);
        layout.addView(tvTitle);
        layout.addView(tvDetail);
        card.addView(layout);
        container.addView(card);
        return card;
    }


    private void addNoUpcomingClassCard(LinearLayout container) {
        float dp = getResources().getDisplayMetrics().density;

        CardView card = new CardView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                (int) (180 * dp), (int) (105 * dp));
        params.setMargins(0, 0, (int) (12 * dp), (int) (8 * dp));
        card.setLayoutParams(params);
        card.setRadius(15 * dp);
        card.setCardElevation(6 * dp);
        card.setCardBackgroundColor(Color.parseColor("#E3F2FD"));

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding((int) (12 * dp), (int) (10 * dp), (int) (12 * dp), (int) (10 * dp));


        TextView tvHeader = new TextView(this);
        tvHeader.setText("Live Class");
        tvHeader.setTextSize(12f);
        tvHeader.setTextColor(Color.parseColor("#1565C0"));
        tvHeader.setTypeface(null, Typeface.BOLD);

        // Title
        TextView tvTitle = new TextView(this);
        tvTitle.setText("No Upcoming Class");
        tvTitle.setTextSize(15f);
        tvTitle.setTextColor(Color.parseColor("#212121"));
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setSingleLine(true);
        tvTitle.setEllipsize(TextUtils.TruncateAt.END);
        tvTitle.setPadding(0, (int) (3 * dp), 0, 0);

        // Detail
        TextView tvDetail = new TextView(this);
        tvDetail.setText("Check back later");
        tvDetail.setTextSize(11f);
        tvDetail.setTextColor(Color.parseColor("#616161"));

        layout.addView(tvHeader);
        layout.addView(tvTitle);
        layout.addView(tvDetail);

        card.addView(layout);


        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v -> openFeature(AttendanceActivity.class));

        container.addView(card);
    }

    private void filterCards(String query) {
        if (query.isEmpty()) {
            for (CardView card : allCards) card.setVisibility(View.VISIBLE);
            return;
        }
        String lowerQuery = query.toLowerCase();
        for (int i = 0; i < allCards.size(); i++) {
            String label = allCardLabels.get(i).toLowerCase();
            allCards.get(i).setVisibility(label.contains(lowerQuery) ? View.VISIBLE : View.GONE);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_logout) {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(this, LoginSelectionActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}