package com.example.kipscoachingkharian.dashboard;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class CreateQuizActivity extends AppCompatActivity {

    private TextInputEditText etQuizTitle, etTimeLimit, etQuizDescription;
    private AutoCompleteTextView spinnerSubject, spinnerClass, spinnerQuestionType;
    private TextView tvStartDate, tvEndDate, tvStartTime, tvEndTime, tvQuestionCount;
    private LinearLayout layoutQuestionsContainer;
    private Button btnAddQuestion, btnSaveDraft, btnShareQuiz;
    private ImageView ivBack;

    private DatabaseReference dbRef;
    private String teacherUid;

    private String selectedStartDate = "", selectedEndDate = "";
    private String selectedStartTime = "", selectedEndTime = "";
    private String currentQuestionType = "MCQs"; // default
    private final List<View> questionViews = new ArrayList<>();
    private int questionCount = 0;

    private boolean isEditMode = false;
    private String editQuizId = "";

    private final String[] SUBJECTS = {"Physics", "Chemistry", "Mathematics", "Biology",
            "English", "Computer", "Urdu", "Islamiyat", "Pak study"};
    private final String[] GRADES = {"9A", "9B", "10A", "10B", "11A", "11B", "12A", "12B"};
    private final String[] QUESTION_TYPES = {"MCQs", "Short Questions", "MCQs + Short Questions"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_quiz);

        teacherUid = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : "";
        dbRef = FirebaseDatabase.getInstance().getReference();

        initViews();
        setupDropdowns();
        setupDatePickers();
        setupButtons();
        setupBottomNav();
        loadEditDataIfNeeded();
    }

    private void loadEditDataIfNeeded() {
        Intent intent = getIntent();
        isEditMode = intent.getBooleanExtra("EDIT_MODE", false);
        if (!isEditMode) return;

        editQuizId = intent.getStringExtra("QUIZ_ID") != null ? intent.getStringExtra("QUIZ_ID") : "";

        etQuizTitle.setText(intent.getStringExtra("QUIZ_TITLE"));
        spinnerSubject.setText(intent.getStringExtra("QUIZ_SUBJECT"), false);
        spinnerClass.setText(intent.getStringExtra("QUIZ_CLASS"), false);
        etTimeLimit.setText(intent.getStringExtra("QUIZ_TIME"));
        etQuizDescription.setText(intent.getStringExtra("QUIZ_DESC"));

        currentQuestionType = intent.getStringExtra("QUIZ_TYPE") != null ? intent.getStringExtra("QUIZ_TYPE") : "MCQs";
        spinnerQuestionType.setText(currentQuestionType, false);

        selectedStartDate = intent.getStringExtra("QUIZ_START");
        if (selectedStartDate != null) tvStartDate.setText(selectedStartDate);

        selectedEndDate = intent.getStringExtra("QUIZ_END");
        if (selectedEndDate != null) tvEndDate.setText(selectedEndDate);

        btnSaveDraft.setText("Save Changes");
        if ("active".equals(intent.getStringExtra("QUIZ_STATUS"))) {
            btnShareQuiz.setVisibility(View.VISIBLE);
            btnShareQuiz.setText("Update & Re-share");
        }

        dbRef.child("Quizzes").child(teacherUid).child(editQuizId).child("questions").get()
                .addOnSuccessListener(snap -> {
                    if (!snap.exists()) return;
                    for (com.google.firebase.database.DataSnapshot ds : snap.getChildren()) {
                        addQuestionView();
                        View card = questionViews.get(questionViews.size() - 1);
                        Object[] refs = (Object[]) card.getTag();

                        ((EditText) refs[0]).setText(ds.child("question").getValue(String.class));

                        String qType = ds.child("type").getValue(String.class);
                        if (qType == null) qType = "MCQs";

                        if (refs[4] instanceof AutoCompleteTextView) {
                            AutoCompleteTextView sp = (AutoCompleteTextView) refs[4];
                            sp.setText(qType.toLowerCase().contains("short") ? "Short Question" : "MCQ", false);
                        }

                        if (qType.toLowerCase().contains("short")) {
                            ((EditText) refs[3]).setText(ds.child("answer").getValue(String.class));
                            Integer marks = ds.child("marks").getValue(Integer.class);
                            ((EditText) refs[5]).setText(marks != null ? String.valueOf(marks) : "1");
                        } else {
                            EditText[] optionFields = (EditText[]) refs[1];
                            String[] optionKeys = {"optionA", "optionB", "optionC", "optionD"};

                            if (ds.hasChild("options")) {
                                // Legacy format: options stored as a list
                                int i = 0;
                                for (com.google.firebase.database.DataSnapshot optSnap : ds.child("options").getChildren()) {
                                    if (i < optionFields.length) {
                                        optionFields[i].setText(optSnap.getValue(String.class));
                                    }
                                    i++;
                                }
                            } else {
                                for (int oi = 0; oi < optionFields.length && oi < optionKeys.length; oi++) {
                                    optionFields[oi].setText(ds.child(optionKeys[oi]).getValue(String.class));
                                }
                            }

                            RadioButton[] radioButtons = (RadioButton[]) refs[2];
                            String[] labels = {"A", "B", "C", "D"};
                            Object correctVal = ds.child("correctAnswer").getValue();
                            if (correctVal instanceof Long || correctVal instanceof Integer) {
                                // Legacy format: numeric index
                                int correctIdx = ((Number) correctVal).intValue();
                                if (correctIdx >= 0 && correctIdx < radioButtons.length) {
                                    radioButtons[correctIdx].setChecked(true);
                                }
                            } else if (correctVal != null) {
                                // New format: letter label (A/B/C/D)
                                String correctLabel = correctVal.toString().trim();
                                for (int ri = 0; ri < labels.length && ri < radioButtons.length; ri++) {
                                    if (labels[ri].equalsIgnoreCase(correctLabel)) {
                                        radioButtons[ri].setChecked(true);
                                        break;
                                    }
                                }
                            }
                        }

                        // Re-apply visibility based on loaded type
                        boolean isShort = qType.toLowerCase().contains("short");
                        ((LinearLayout) refs[7]).setVisibility(isShort ? View.GONE : View.VISIBLE);
                        ((LinearLayout) refs[8]).setVisibility(isShort ? View.VISIBLE : View.GONE);
                    }
                });
    }

    private void initViews() {
        etQuizTitle = findViewById(R.id.etQuizTitle);
        etTimeLimit = findViewById(R.id.etTimeLimit);
        etQuizDescription = findViewById(R.id.etQuizDescription);
        spinnerSubject = findViewById(R.id.spinnerSubject);
        spinnerClass = findViewById(R.id.spinnerClass);
        spinnerQuestionType = findViewById(R.id.spinnerQuestionType);
        tvStartDate = findViewById(R.id.tvStartDate);
        tvEndDate   = findViewById(R.id.tvEndDate);
        tvStartTime = findViewById(R.id.tvStartTime);
        tvEndTime   = findViewById(R.id.tvEndTime);
        tvQuestionCount = findViewById(R.id.tvQuestionCount);
        layoutQuestionsContainer = findViewById(R.id.layoutQuestionsContainer);
        btnAddQuestion = findViewById(R.id.btnAddQuestion);
        btnSaveDraft = findViewById(R.id.btnSaveDraft);
        btnShareQuiz = findViewById(R.id.btnShareQuiz);
        ivBack = findViewById(R.id.ivBack);
    }

    private void setupDropdowns() {
        spinnerSubject.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, SUBJECTS));
        spinnerClass.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, GRADES));
        spinnerQuestionType.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, QUESTION_TYPES));
        spinnerQuestionType.setOnItemClickListener((p, v, pos, id) -> currentQuestionType = QUESTION_TYPES[pos]);
    }

    private void setupDatePickers() {
        ivBack.setOnClickListener(v -> finish());
        findViewById(R.id.layoutStartDate).setOnClickListener(v -> showDatePicker(true));
        findViewById(R.id.layoutEndDate).setOnClickListener(v -> showDatePicker(false));
        findViewById(R.id.layoutStartTime).setOnClickListener(v -> showTimePicker(true));
        findViewById(R.id.layoutEndTime).setOnClickListener(v -> showTimePicker(false));
    }

    private void showDatePicker(boolean isStart) {
        Calendar cal = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, day) -> {
            String formatted = day + "/" + (month + 1) + "/" + year;
            if (isStart) { selectedStartDate = formatted; tvStartDate.setText(formatted); tvStartDate.setTextColor(0xFF1E2A3B); }
            else         { selectedEndDate   = formatted; tvEndDate.setText(formatted);   tvEndDate.setTextColor(0xFF1E2A3B); }
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showTimePicker(boolean isStart) {
        Calendar cal = Calendar.getInstance();
        new TimePickerDialog(this, (view, hour, minute) -> {
            String amPm  = hour >= 12 ? "PM" : "AM";
            int h12      = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
            String formatted = String.format(java.util.Locale.getDefault(), "%02d:%02d %s", h12, minute, amPm);
            if (isStart) { selectedStartTime = formatted; tvStartTime.setText(formatted); tvStartTime.setTextColor(0xFF1E2A3B); }
            else         { selectedEndTime   = formatted; tvEndTime.setText(formatted);   tvEndTime.setTextColor(0xFF1E2A3B); }
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show();
    }

    private void setupButtons() {
        btnAddQuestion.setOnClickListener(v -> addQuestionView());
        btnSaveDraft.setOnClickListener(v -> { if (validateForm()) saveQuiz("draft"); });
        btnShareQuiz.setOnClickListener(v -> { if (validateForm()) saveQuiz("active"); });
    }

    private void addQuestionView() {
        questionCount++;
        CardView card = new CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, 16);
        card.setLayoutParams(cp);
        card.setRadius(16f);
        card.setCardBackgroundColor(0xFFFFFFFF);
        card.setCardElevation(2f);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(32, 28, 32, 28);

        // ── Question type per question (only relevant when "MCQs + Short Questions") ──
        AutoCompleteTextView spinnerQType = null;
        if ("MCQs + Short Questions".equals(currentQuestionType)) {
            spinnerQType = new AutoCompleteTextView(this);
            spinnerQType.setHint("Question type");
            spinnerQType.setBackground(getDrawable(R.drawable.bg_input_field));
            spinnerQType.setPadding(20, 20, 20, 20);
            spinnerQType.setAdapter(new ArrayAdapter<>(this,
                    android.R.layout.simple_dropdown_item_1line,
                    new String[]{"MCQ", "Short Question"}));
            spinnerQType.setText("MCQ", false);
            LinearLayout.LayoutParams typeLp = new LinearLayout.LayoutParams(-1, -2);
            typeLp.setMargins(0, 0, 0, 16);
            spinnerQType.setLayoutParams(typeLp);
            inner.addView(spinnerQType);
        }

        // ── Question label + text ──
        TextView tvQNum = new TextView(this);
        tvQNum.setText("Question " + questionCount);
        tvQNum.setTextSize(13f);
        tvQNum.setTextColor(0xFF888888);
        tvQNum.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams qNumLp = new LinearLayout.LayoutParams(-1, -2);
        qNumLp.setMargins(0, 0, 0, 8);
        tvQNum.setLayoutParams(qNumLp);
        inner.addView(tvQNum);

        EditText etQuestion = new EditText(this);
        etQuestion.setHint("Enter question " + questionCount);
        etQuestion.setBackground(getDrawable(R.drawable.bg_input_field));
        etQuestion.setPadding(20, 20, 20, 20);
        etQuestion.setTextSize(15f);
        LinearLayout.LayoutParams qLp = new LinearLayout.LayoutParams(-1, -2);
        qLp.setMargins(0, 0, 0, 16);
        etQuestion.setLayoutParams(qLp);
        inner.addView(etQuestion);

        // ── MCQ options container (4 options + manual single-select radio buttons) ──
        LinearLayout mcqContainer = new LinearLayout(this);
        mcqContainer.setOrientation(LinearLayout.VERTICAL);

        EditText[] optionFields = new EditText[4];
        RadioButton[] radioButtons = new RadioButton[4];

        char[] optionLetters = {'A', 'B', 'C', 'D'};
        for (int i = 0; i < 4; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
            rowLp.setMargins(0, 0, 0, 10);
            row.setLayoutParams(rowLp);

            RadioButton rb = new RadioButton(this);
            rb.setId(View.generateViewId());
            rb.setButtonTintList(android.content.res.ColorStateList.valueOf(0xFFD2192B));
            radioButtons[i] = rb;

            EditText etOption = new EditText(this);
            etOption.setHint("Option " + optionLetters[i]);
            etOption.setBackground(getDrawable(R.drawable.bg_input_field));
            etOption.setPadding(20, 14, 20, 14);
            etOption.setTextSize(14f);
            LinearLayout.LayoutParams optLp = new LinearLayout.LayoutParams(-1, -2);
            optLp.setMarginStart(4);
            etOption.setLayoutParams(optLp);
            optionFields[i] = etOption;

            row.addView(rb);
            row.addView(etOption);
            mcqContainer.addView(row);
        }

        // Manual single-select: clicking one unchecks the others
        for (int i = 0; i < radioButtons.length; i++) {
            final int idx = i;
            radioButtons[i].setOnClickListener(v -> {
                for (int j = 0; j < radioButtons.length; j++) {
                    if (j != idx) radioButtons[j].setChecked(false);
                }
            });
        }

        TextView tvCorrectHint = new TextView(this);
        tvCorrectHint.setText("⬅ Select the radio button next to the correct answer");
        tvCorrectHint.setTextSize(11f);
        tvCorrectHint.setTextColor(0xFF888888);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, -2);
        hintLp.setMargins(0, 0, 0, 8);
        tvCorrectHint.setLayoutParams(hintLp);
        mcqContainer.addView(tvCorrectHint, 0);

        inner.addView(mcqContainer);

        // ── Short answer field + marks input ──
        LinearLayout shortContainer = new LinearLayout(this);
        shortContainer.setOrientation(LinearLayout.VERTICAL);

        EditText etShortAnswer = new EditText(this);
        etShortAnswer.setHint("Model / sample answer (optional)");
        etShortAnswer.setBackground(getDrawable(R.drawable.bg_input_field));
        etShortAnswer.setPadding(20, 20, 20, 20);
        etShortAnswer.setMinLines(2);
        LinearLayout.LayoutParams shortLp = new LinearLayout.LayoutParams(-1, -2);
        shortLp.setMargins(0, 0, 0, 12);
        etShortAnswer.setLayoutParams(shortLp);
        shortContainer.addView(etShortAnswer);

        TextView tvMarksLabel = new TextView(this);
        tvMarksLabel.setText("Marks for this question");
        tvMarksLabel.setTextSize(12f);
        tvMarksLabel.setTextColor(0xFF888888);
        LinearLayout.LayoutParams marksLabelLp = new LinearLayout.LayoutParams(-1, -2);
        marksLabelLp.setMargins(0, 0, 0, 6);
        tvMarksLabel.setLayoutParams(marksLabelLp);
        shortContainer.addView(tvMarksLabel);

        EditText etMarks = new EditText(this);
        etMarks.setHint("e.g. 5");
        etMarks.setBackground(getDrawable(R.drawable.bg_input_field));
        etMarks.setPadding(20, 16, 20, 16);
        etMarks.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etMarks.setText("1");
        shortContainer.addView(etMarks);

        inner.addView(shortContainer);

        // ── Divider ──
        View divider = new View(this);
        LinearLayout.LayoutParams dividerLp = new LinearLayout.LayoutParams(-1, 1);
        dividerLp.setMargins(0, 16, 0, 8);
        divider.setLayoutParams(dividerLp);
        divider.setBackgroundColor(0xFFEEEEEE);
        inner.addView(divider);

        // ── Remove question button ──
        TextView tvRemove = new TextView(this);
        tvRemove.setText("✕  Remove Question");
        tvRemove.setTextColor(0xFFD32F2F);
        tvRemove.setTextSize(13f);
        tvRemove.setTypeface(null, Typeface.BOLD);
        tvRemove.setPadding(8, 6, 8, 6);
        tvRemove.setGravity(Gravity.END);
        inner.addView(tvRemove);

        card.addView(inner);

        // ── Type-dependent visibility ──
        final AutoCompleteTextView spinnerQTypeFinal = spinnerQType;
        Runnable applyVisibility = () -> {
            String qType;
            if (spinnerQTypeFinal != null) {
                String sel = spinnerQTypeFinal.getText().toString();
                qType = sel.toLowerCase().contains("short") ? "Short Questions" : "MCQs";
            } else {
                qType = currentQuestionType;
            }
            boolean isShort = "Short Questions".equals(qType);
            mcqContainer.setVisibility(isShort ? View.GONE : View.VISIBLE);
            shortContainer.setVisibility(isShort ? View.VISIBLE : View.GONE);
        };
        applyVisibility.run();

        if (spinnerQType != null) {
            final AutoCompleteTextView spinnerRef = spinnerQType;
            spinnerQType.setOnItemClickListener((p, v, pos, id) -> {
                spinnerRef.setText(pos == 0 ? "MCQ" : "Short Question", false);
                applyVisibility.run();
            });
        }

        // [0]=etQuestion, [1]=optionFields, [2]=radioButtons, [3]=etShortAnswer,
        // [4]=questionType-string-or-spinner, [5]=etMarks, [6]=unused,
        // [7]=mcqContainer, [8]=shortContainer
        Object[] tag = new Object[]{etQuestion, optionFields, radioButtons, etShortAnswer,
                spinnerQType != null ? spinnerQType : currentQuestionType, etMarks, null,
                mcqContainer, shortContainer};
        card.setTag(tag);

        tvRemove.setOnClickListener(v -> {
            layoutQuestionsContainer.removeView(card);
            questionViews.remove(card);
            updateCount();
        });

        layoutQuestionsContainer.addView(card);
        questionViews.add(card);
        updateCount();
    }

    private void updateCount() {
        tvQuestionCount.setText(questionViews.size() + " Question" + (questionViews.size() == 1 ? "" : "s"));
    }

    private boolean validateForm() {
        if (TextUtils.isEmpty(etQuizTitle.getText())) {
            Toast.makeText(this, "Please enter a quiz title", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (TextUtils.isEmpty(spinnerSubject.getText())) {
            Toast.makeText(this, "Please select a subject", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (TextUtils.isEmpty(spinnerClass.getText())) {
            Toast.makeText(this, "Please select a class", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (questionViews.isEmpty()) {
            Toast.makeText(this, "Please add at least one question", Toast.LENGTH_SHORT).show();
            return false;
        }
        for (View v : questionViews) {
            Object[] refs = (Object[]) v.getTag();
            EditText etQuestion = (EditText) refs[0];
            if (TextUtils.isEmpty(etQuestion.getText())) {
                Toast.makeText(this, "Please fill in all question fields", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        return true;
    }

    private void saveQuiz(String status) {
        String quizId = isEditMode ? editQuizId : dbRef.child("Quizzes").push().getKey();
        if (quizId == null) {
            Toast.makeText(this, "Error: could not generate quiz ID", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> data = new HashMap<>();
        data.put("quizId", quizId);
        data.put("title", etQuizTitle.getText().toString().trim());
        data.put("subject", spinnerSubject.getText().toString().trim());
        data.put("className", spinnerClass.getText().toString().trim());
        data.put("status", status);
        data.put("timeLimit", etTimeLimit.getText() != null ? etTimeLimit.getText().toString().trim() : "30");
        data.put("startDate",      selectedStartDate);
        data.put("startTime",      selectedStartTime);
        data.put("startTimestamp", calcTimestamp(selectedStartDate, selectedStartTime));
        data.put("endDate",        selectedEndDate);
        data.put("endTime",        selectedEndTime);
        data.put("endTimestamp",   calcTimestamp(selectedEndDate, selectedEndTime));
        data.put("teacherUid", teacherUid);
        data.put("questions", collectQuestions());

        btnShareQuiz.setEnabled(false);
        btnSaveDraft.setEnabled(false);

        dbRef.child("Quizzes").child(teacherUid).child(quizId).setValue(data)
                .addOnSuccessListener(u -> {
                    if ("active".equals(status)) {
                        // ✅ Schedule mein save karein
                        saveToUpcomingSchedule(data);
                        shareQuizToStudents(quizId, data, (String)data.get("title"), (String)data.get("subject"), (String)data.get("className"));
                    } else {
                        Toast.makeText(this, "Quiz saved as Draft!", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(e -> {
                    btnShareQuiz.setEnabled(true);
                    btnSaveDraft.setEnabled(true);
                    Toast.makeText(this, "Failed to save quiz: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }

    // 🔥 NEW METHOD: Quiz ko Student Dashboard ke Schedule mein add karne ke liye
    private void saveToUpcomingSchedule(Map<String, Object> quizData) {
        DatabaseReference scheduleRef = dbRef.child("upcomingSchedule").push();
        Map<String, Object> scheduleMap = new HashMap<>();
        scheduleMap.put("type", "quiz");
        scheduleMap.put("className", quizData.get("className"));
        scheduleMap.put("title", quizData.get("title"));
        scheduleMap.put("subject", quizData.get("subject"));
        scheduleMap.put("time", quizData.get("startDate")); // Start date ko time ke taur pe show karega
        scheduleMap.put("endDate", quizData.get("endDate"));
        scheduleMap.put("quizId", quizData.get("quizId")); // Submission check ke liye
        scheduleMap.put("timestamp", System.currentTimeMillis());
        scheduleRef.setValue(scheduleMap);
    }

    private List<Map<String, Object>> collectQuestions() {
        List<Map<String, Object>> list = new ArrayList<>();
        for (View v : questionViews) {
            Object[] refs = (Object[]) v.getTag();
            Map<String, Object> q = new HashMap<>();

            EditText etQuestion        = (EditText) refs[0];
            EditText[] optionFields    = (EditText[]) refs[1];
            RadioButton[] radioButtons = (RadioButton[]) refs[2];
            EditText etShortAnswer     = (EditText) refs[3];
            EditText etMarks           = (EditText) refs[5];

            // Determine type for this question
            String type;
            if (refs[4] instanceof AutoCompleteTextView) {
                String sel = ((AutoCompleteTextView) refs[4]).getText().toString();
                type = sel.toLowerCase().contains("short") ? "Short Questions" : "MCQs";
            } else {
                type = (String) refs[4];
            }

            q.put("question", etQuestion.getText().toString().trim());
            q.put("type", type);

            if ("Short Questions".equals(type)) {
                q.put("answer", etShortAnswer.getText().toString().trim());
                int marks = 1;
                try { marks = Integer.parseInt(etMarks.getText().toString().trim()); } catch (Exception ignored) {}
                q.put("marks", marks);
            } else {
                String[] optionKeys = {"optionA", "optionB", "optionC", "optionD"};
                for (int i = 0; i < optionFields.length && i < optionKeys.length; i++) {
                    q.put(optionKeys[i], optionFields[i].getText().toString().trim());
                }

                int correctIndex = -1;
                for (int i = 0; i < radioButtons.length; i++) {
                    if (radioButtons[i].isChecked()) { correctIndex = i; break; }
                }
                String[] labels = {"A", "B", "C", "D"};
                q.put("correctAnswer", (correctIndex >= 0 && correctIndex < labels.length) ? labels[correctIndex] : "");
            }

            list.add(q);
        }
        return list;
    }

    private void shareQuizToStudents(String quizId, Map<String, Object> quizData, String quizTitle, String subject, String className) {
        // Pehle teacher ka assignedClass + assignedSection fetch karo
        FirebaseDatabase.getInstance().getReference("Users").child(teacherUid)
                .addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot teacherSnap) {
                        String tClassRaw = teacherSnap.child("assignedClass").getValue(String.class);
                        String tSec      = teacherSnap.child("assignedSection").getValue(String.class);
                        if (tClassRaw != null && tSec != null && !tSec.trim().isEmpty()
                                && !tClassRaw.trim().toUpperCase().contains(tSec.trim().toUpperCase())) {
                            tClassRaw = tClassRaw.trim() + tSec.trim().toUpperCase();
                        }
                        final String tClass = tClassRaw;

                        FirebaseDatabase.getInstance().getReference("Users")
                                .addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                                        int[] count = {0};
                                        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
                                        Map<String, Object> childUpdates = new HashMap<>();

                                        for (com.google.firebase.database.DataSnapshot userSnap : snapshot.getChildren()) {
                                            String role = userSnap.child("role").getValue(String.class);
                                            if (role == null || !role.equalsIgnoreCase("Student")) continue;

                                            String status = userSnap.child("status").getValue(String.class);
                                            if (status != null && !status.equalsIgnoreCase("Approved")) continue;

                                            // ✅ Subject match — enrolledSubjects mein teacher ka subject hona chahiye
                                            boolean subjectMatch = subject == null || subject.isEmpty();
                                            if (!subjectMatch) {
                                                for (com.google.firebase.database.DataSnapshot s : userSnap.child("enrolledSubjects").getChildren()) {
                                                    String sv = s.getValue(String.class);
                                                    if (sv != null && sv.trim().equalsIgnoreCase(subject.trim())) { subjectMatch = true; break; }
                                                }
                                            }
                                            if (!subjectMatch) continue;

                                            // ✅ Class match — quiz ke apne className (spinner se selected) se match karo
                                            String matchClass = (className != null && !className.trim().isEmpty())
                                                    ? className.trim() : tClass;
                                            String matchClassNum = matchClass != null
                                                    ? matchClass.replaceAll("[^0-9]", "") : "";

                                            if (!matchClassNum.isEmpty()) {
                                                String studentClass = userSnap.child("className").getValue(String.class);
                                                if (studentClass == null) continue;
                                                String sClassNum = studentClass.trim().replaceAll("[^0-9]", "");
                                                if (!matchClassNum.equals(sClassNum)) continue;

                                                // Section check sirf tab jab quiz className mein section letter ho
                                                String matchSecUpper = matchClass.replaceAll("[0-9]", "").trim().toUpperCase();
                                                if (!matchSecUpper.isEmpty()
                                                        && !studentClass.trim().toUpperCase().contains(matchSecUpper)) continue;
                                            }

                                            String studentUid = userSnap.getKey();
                                            if (studentUid == null) continue;

                                            Map<String, Object> sharedData = new HashMap<>(quizData);
                                            sharedData.put("status",   "active");
                                            sharedData.put("sharedAt", System.currentTimeMillis());
                                            childUpdates.put("SharedQuizzes/" + studentUid + "/" + quizId, sharedData);

                                            Map<String, Object> announcement = new HashMap<>();
                                            announcement.put("title",     "📝 New Quiz: " + quizTitle + " (" + subject + ")");
                                            announcement.put("message",   "Class: " + className);
                                            announcement.put("timestamp", System.currentTimeMillis());
                                            announcement.put("pdfUrl",    "");
                                            childUpdates.put("Announcements/Students/" + studentUid + "/" + quizId, announcement);

                                            count[0]++;
                                        }

                                        rootRef.updateChildren(childUpdates).addOnCompleteListener(task -> {
                                            String msg = count[0] > 0
                                                    ? "✅ Quiz shared with students of Class " + className
                                                    : "⚠️ No approved students found for class: " + className;
                                            Toast.makeText(CreateQuizActivity.this, msg, Toast.LENGTH_SHORT).show();
                                            setResult(RESULT_OK);
                                            finish();
                                        });
                                    }
                                    @Override public void onCancelled(@NonNull com.google.firebase.database.DatabaseError e) {
                                        Toast.makeText(CreateQuizActivity.this, "Quiz saved, but sharing failed.", Toast.LENGTH_SHORT).show();
                                        setResult(RESULT_OK);
                                        finish();
                                    }
                                });
                    }
                    @Override public void onCancelled(@NonNull com.google.firebase.database.DatabaseError e) {
                        Toast.makeText(CreateQuizActivity.this, "Quiz saved, but sharing failed.", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_OK);
                        finish();
                    }
                });
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_bottom_home) {
                startActivity(new Intent(this, TeacherDashboardActivity.class));
                finish();
                return true;
            }
            return false;
        });
    }

    // ── Date ("d/M/yyyy") + Time ("hh:mm a") ko milliseconds mein convert karo ──
    private long calcTimestamp(String date, String time) {
        try {
            if (date == null || date.trim().isEmpty()) return 0L;
            String t = (time == null || time.trim().isEmpty()) ? "11:59 PM" : time.trim();
            java.text.SimpleDateFormat sdf =
                    new java.text.SimpleDateFormat("d/M/yyyy hh:mm a", java.util.Locale.getDefault());
            return sdf.parse(date + " " + t).getTime();
        } catch (Exception e) {
            return 0L;
        }
    }
}