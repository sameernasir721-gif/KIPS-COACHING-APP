package com.example.kipscoachingkharian.dashboard;

public class Conversation {
    private String conversationId;
    private String otherUserId;
    private String otherUserName;
    private String otherUserRole;
    private String lastMessage;
    private long lastTimestamp;
    private int unreadCount;
    private String otherUserDetail; // Naya variable Subject/Student info ke liye

    public Conversation() {}

    public Conversation(String conversationId, String otherUserId, String otherUserName,
                        String otherUserRole, String lastMessage, long lastTimestamp, String otherUserDetail) {
        this.conversationId = conversationId;
        this.otherUserId = otherUserId;
        this.otherUserName = otherUserName;
        this.otherUserRole = otherUserRole;
        this.lastMessage = lastMessage;
        this.lastTimestamp = lastTimestamp;
        this.unreadCount = 0;
        this.otherUserDetail = otherUserDetail;
    }

    public String getConversationId() { return conversationId; }
    public void setConversationId(String conversationId) { this.conversationId = conversationId; }

    public String getOtherUserId() { return otherUserId; }
    public void setOtherUserId(String otherUserId) { this.otherUserId = otherUserId; }

    public String getOtherUserName() { return otherUserName; }
    public void setOtherUserName(String otherUserName) { this.otherUserName = otherUserName; }

    public String getOtherUserRole() { return otherUserRole; }
    public void setOtherUserRole(String otherUserRole) { this.otherUserRole = otherUserRole; }

    public String getLastMessage() { return lastMessage; }
    public void setLastMessage(String lastMessage) { this.lastMessage = lastMessage; }

    public long getLastTimestamp() { return lastTimestamp; }
    public void setLastTimestamp(long lastTimestamp) { this.lastTimestamp = lastTimestamp; }

    public int getUnreadCount() { return unreadCount; }
    public void setUnreadCount(int unreadCount) { this.unreadCount = unreadCount; }

    public String getOtherUserDetail() { return otherUserDetail; }
    public void setOtherUserDetail(String otherUserDetail) { this.otherUserDetail = otherUserDetail; }
}