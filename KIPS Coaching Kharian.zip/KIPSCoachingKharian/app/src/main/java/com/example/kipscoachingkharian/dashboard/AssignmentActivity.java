package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.example.kipscoachingkharian.model.Assignment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AssignmentActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    // Views
    private RecyclerView         rvAssignments;
    private LinearLayout         layoutEmpty;
    private TextView             tvStudentInfo;
    private DrawerLayout         drawerLayout;
    private ImageView            ivMenu;
    private NavigationView       navigationView;
    private BottomNavigationView bottomNav;
    private EditText             etSearch;

    // Filter chips
    private MaterialButton chipAll, chipMath, chipPhysics, chipChemistry, chipEnglish,
            chipBiology, chipComputer,chipUrdu, chipIslamiyat, chipPakstudy;
    private String activeChip = "All";

    // Enrolled subjects
    private List<String> enrolledSubjects = new ArrayList<>();

    // Data
    private final List<Assignment> allAssignments      = new ArrayList<>();
    private final List<Assignment> filteredAssignments = new ArrayList<>();
    private AssignmentCardAdapter  adapter;

    private String studentUid,studentClass;


    // Card colors — tumhara existing design
    private final int[] CARD_COLORS = {
            0xFFEDDCE1,   // pink
            0xFFDBDFED,   // blue
            0xFFBED9C3,   // green
            0xFFFFF9C4,   // yellow
            0xFFE8EAF6    // lavender
    };

    // Subject icons — subject name se match hoga
    private static final String[] SUBJECTS = {
            "Physics", "Chemistry", "Mathematics", "Biology", "English", "Computer","Urdu","Islmaiyat","Pakstudy"
    };
    private static final int[] SUBJECT_ICONS = {
            R.drawable.ic_physics,
            R.drawable.ic_chemistry,
            R.drawable.ic_mathematics,
            R.drawable.ic_biology,
            R.drawable.ic_english,
            R.drawable.ic_computer,
            R.drawable.ic_urdu,
            R.drawable.ic_islamiyat,
            R.drawable.ic_pakstudy,
            R.drawable.ic_subject

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, LoginSelectionActivity.class));
            finish();
            return;
        }
        studentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Init views
        rvAssignments  = findViewById(R.id.rvAssignments);
        layoutEmpty    = findViewById(R.id.layoutEmpty);
        drawerLayout   = findViewById(R.id.drawerLayout);
        tvStudentInfo   = findViewById(R.id.tvStudentInfo);
        ivMenu         = findViewById(R.id.ivMenu);
        navigationView = findViewById(R.id.navigationView);
        bottomNav      = findViewById(R.id.bottomNav);
        etSearch       = findViewById(R.id.etSearch);

        // Filter chips
        chipAll       = findViewById(R.id.chipAll);
        chipMath      = findViewById(R.id.chipMath);
        chipPhysics   = findViewById(R.id.chipPhysics);
        chipChemistry = findViewById(R.id.chipChemistry);
        chipEnglish   = findViewById(R.id.chipEnglish);
        chipBiology   = findViewById(R.id.chipBiology);
        chipComputer  = findViewById(R.id.chipComputer);
        chipUrdu = findViewById(R.id.chipUrdu);
        chipIslamiyat = findViewById(R.id.chipIslamiyat);
        chipPakstudy  = findViewById(R.id.chipPakstudy);


        // RecyclerView
        rvAssignments.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AssignmentCardAdapter(filteredAssignments);
        rvAssignments.setAdapter(adapter);

        // Listeners
        ivMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
        navigationView.setNavigationItemSelectedListener(this);
        setupBottomNav();
        setupChips();
        setupSearch();

        // Data load
        fetchStudentAndAssignments();
    }

    // ── Firebase: student info fetch, phir assignments ───────────────────────
    private void fetchStudentAndAssignments() {
        FirebaseDatabase.getInstance().getReference("Users").child(studentUid)
                .get()
                .addOnSuccessListener(snap -> {
                    if (snap.exists()) {
                        String name  = snap.child("name").getValue(String.class);
                        studentClass = snap.child("className").getValue(String.class);
                        String roll  = snap.child("rollNo").getValue(String.class);

                        String info = (studentClass != null) ? "Grade: " + studentClass : "Grade: --";
                        tvStudentInfo.setText(info);

                        // Enrolled subjects fetch karo
                        enrolledSubjects.clear();
                        for (DataSnapshot subSnap : snap.child("enrolledSubjects").getChildren()) {
                            String sub = subSnap.getValue(String.class);
                            if (sub != null) enrolledSubjects.add(sub);
                        }
                        // Chips sirf enrolled subjects ki show karo
                        showEnrolledChips();
                    }
                    loadAssignments();
                })
                .addOnFailureListener(e -> loadAssignments());
    }

    // ── Sirf enrolled subjects ki chips visible karo ─────────────────────────
    private void showEnrolledChips() {
        // Pehle sab subject chips hide karo
        chipMath.setVisibility(View.GONE);
        chipPhysics.setVisibility(View.GONE);
        chipChemistry.setVisibility(View.GONE);
        chipEnglish.setVisibility(View.GONE);
        chipBiology.setVisibility(View.GONE);
        chipComputer.setVisibility(View.GONE);
        chipUrdu.setVisibility(View.GONE);
        chipIslamiyat.setVisibility(View.GONE);
        chipPakstudy.setVisibility(View.GONE);

        // Sirf enrolled wali chips show karo
        for (String subject : enrolledSubjects) {
            if (subject.equalsIgnoreCase("Mathematics"))
                chipMath.setVisibility(View.VISIBLE);
            else if (subject.equalsIgnoreCase("Physics"))
                chipPhysics.setVisibility(View.VISIBLE);
            else if (subject.equalsIgnoreCase("Chemistry"))
                chipChemistry.setVisibility(View.VISIBLE);
            else if (subject.equalsIgnoreCase("English"))
                chipEnglish.setVisibility(View.VISIBLE);
            else if (subject.equalsIgnoreCase("Biology"))
                chipBiology.setVisibility(View.VISIBLE);
            else if (subject.equalsIgnoreCase("Computer"))
                chipComputer.setVisibility(View.VISIBLE);
            else if (subject.equalsIgnoreCase("Urdu"))
                chipUrdu.setVisibility(View.VISIBLE);
            else if (subject.equalsIgnoreCase("Islamiyat"))
                chipIslamiyat.setVisibility(View.VISIBLE);
            else if (subject.equalsIgnoreCase("Pakstudy") || subject.equalsIgnoreCase("Pak Study"))
                chipPakstudy.setVisibility(View.VISIBLE);
        }
    }

    private void loadAssignments() {
        FirebaseDatabase.getInstance().getReference("SharedAssignments").child(studentUid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        allAssignments.clear();
                        for (DataSnapshot aSnap : snapshot.getChildren()) {
                            String status = aSnap.child("status").getValue(String.class);
                            if (!"Active".equalsIgnoreCase(status)) continue;

                            Assignment a = new Assignment();
                            a.setAssignmentId(aSnap.getKey());
                            a.setTeacherId(str(aSnap, "teacherId"));
                            a.setTitle(str(aSnap, "title"));
                            a.setSubject(str(aSnap, "subject"));
                            a.setGrade(str(aSnap, "grade"));
                            a.setMarks(str(aSnap, "marks"));
                            a.setDueDate(str(aSnap, "dueDate"));
                            a.setDueTime(str(aSnap, "dueTime")); // ← CHANGE 1: dueTime load karo
                            a.setPostedDate(str(aSnap, "postedDate"));
                            a.setDescription(str(aSnap, "description"));
                            a.setStatus(status);
                            a.setPdfUrl(str(aSnap, "pdfUrl"));
                            Long ts = aSnap.child("createdAt").getValue(Long.class);
                            if (ts != null) a.setCreatedAt(ts);
                            allAssignments.add(a);
                        }
                        applyFilter();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(AssignmentActivity.this,
                                "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // ── Filter: chip + search dono apply hote hain ───────────────────────────
    private void applyFilter() {
        String searchText = etSearch.getText().toString().trim().toLowerCase();
        filteredAssignments.clear();

        for (Assignment a : allAssignments) {
            String subjectNorm = a.getSubject() == null ? "" : a.getSubject().replaceAll("\\s+", "").toLowerCase();
            String chipNorm    = activeChip.replaceAll("\\s+", "").toLowerCase();
            boolean chipMatch = activeChip.equals("All") || subjectNorm.equals(chipNorm);
            boolean searchMatch = searchText.isEmpty()
                    || a.getTitle().toLowerCase().contains(searchText)
                    || a.getSubject().toLowerCase().contains(searchText);
            if (chipMatch && searchMatch) filteredAssignments.add(a);
        }

        adapter.notifyDataSetChanged();
        boolean empty = filteredAssignments.isEmpty();
        layoutEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        rvAssignments.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    // ── Chips setup ──────────────────────────────────────────────────────────
    private void setupChips() {
        View.OnClickListener cl = v -> {
            resetChips();
            MaterialButton btn = (MaterialButton) v;
            btn.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(0xFFD2192B));
            btn.setTextColor(0xFFFFFFFF);
            activeChip = btn.getText().toString();
            applyFilter();
        };
        chipAll.setOnClickListener(cl);
        chipMath.setOnClickListener(cl);
        chipPhysics.setOnClickListener(cl);
        chipChemistry.setOnClickListener(cl);
        chipEnglish.setOnClickListener(cl);
        chipBiology.setOnClickListener(cl);
        chipComputer.setOnClickListener(cl);
        chipUrdu.setOnClickListener(cl);
        chipIslamiyat.setOnClickListener(cl);
        chipPakstudy.setOnClickListener(cl);
    }

    private void resetChips() {
        int grey = 0xFFE0E0E0;
        for (MaterialButton c : new MaterialButton[]{chipAll, chipMath, chipPhysics,
                chipChemistry, chipEnglish, chipBiology, chipComputer,chipUrdu,chipIslamiyat,chipPakstudy}) {
            c.setBackgroundTintList(android.content.res.ColorStateList.valueOf(grey));
            c.setTextColor(0xFF333333);
        }
    }

    // ── Search setup ─────────────────────────────────────────────────────────
    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c)   { applyFilter(); }
            public void afterTextChanged(Editable s) {}
        });
    }

    // ── Bottom nav ───────────────────────────────────────────────────────────
    private void setupBottomNav() {
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) { finish(); return true; }
            else if (id == R.id.nav_bottom_feedback) {
                startActivity(new Intent(this, FeedbackActivity.class)); return true; }
            else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileActivity.class)); return true; }
            return false;
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.nav_logout) {
            FirebaseAuth.getInstance().signOut();
            Intent i = new Intent(this, LoginSelectionActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finishAffinity();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private String str(DataSnapshot snap, String key) {
        String v = snap.child(key).getValue(String.class);
        return v != null ? v : "";
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  ADAPTER
    // ═════════════════════════════════════════════════════════════════════════
    private class AssignmentCardAdapter
            extends RecyclerView.Adapter<AssignmentCardAdapter.VH> {

        private final List<Assignment> list;
        AssignmentCardAdapter(List<Assignment> list) { this.list = list; }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_assignment_card, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Assignment a = list.get(position);

            // Card color — cycle through CARD_COLORS
            int color = CARD_COLORS[position % CARD_COLORS.length];
            h.cardRoot.setCardBackgroundColor(color);

            // Subject icon
            h.imgSubjectIcon.setImageResource(getSubjectIcon(a.getSubject()));

            // Text
            h.tvSubjectName.setText(a.getSubject());
            h.tvAssignmentTitle.setText("Assignment: " + a.getTitle());
            // ← CHANGE 2: due date ke saath time bhi dikhao
            String dueTimeVal = a.getDueTime();
            h.tvDueDate.setText("Due: " + a.getDueDate() +
                    (dueTimeVal == null || dueTimeVal.isEmpty() ? "" : "  " + dueTimeVal));
            h.tvMarks.setText("Marks: " + a.getMarks());

            // ── Obtained marks Firebase se fetch karo ───────────────
            h.tvObtainedMarks.setVisibility(View.GONE);
            FirebaseDatabase.getInstance()
                    .getReference("Submissions")
                    .child(a.getAssignmentId())
                    .child(studentUid)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snap) {
                            String obtained = snap.child("obtainedMarks").getValue(String.class);
                            String status   = snap.child("status").getValue(String.class);
                            if (obtained != null && !obtained.isEmpty() && !"0".equals(obtained)) {
                                h.tvObtainedMarks.setText("✅ Obtained: " + obtained + " / " + a.getMarks());
                                h.tvObtainedMarks.setTextColor(0xFF2E7D32);
                                h.tvObtainedMarks.setVisibility(View.VISIBLE);
                            } else if ("Submitted".equalsIgnoreCase(status)) {
                                h.tvObtainedMarks.setText("⏳ Submitted — awaiting marks");
                                h.tvObtainedMarks.setTextColor(0xFFF57F17);
                                h.tvObtainedMarks.setVisibility(View.VISIBLE);
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError e) {}
                    });

            // ── VIEW button: assignment detail dialog dikhao ──────────────
            h.btnView.setOnClickListener(v -> showViewDialog(a));

            // ── SUBMIT button: SubmitAssignmentActivity kholo ────────────
            boolean isActive = "Active".equalsIgnoreCase(a.getStatus());
            if (isActive) {
                h.btnSubmit.setBackgroundTintList(
                        android.content.res.ColorStateList.valueOf(0xFFC62828));
                h.btnSubmit.setText("Submit");
                h.btnSubmit.setOnClickListener(v -> openSubmitScreen(a));
            } else {
                h.btnSubmit.setBackgroundTintList(
                        android.content.res.ColorStateList.valueOf(0xFF9E9E9E));
                h.btnSubmit.setText("Closed");
                h.btnSubmit.setOnClickListener(null);
            }
        }

        @Override
        public int getItemCount() { return list.size(); }

        // ── VIEW Dialog ───────────────────────────────────────────────────
        private void showViewDialog(Assignment a) {
            View dialogView = LayoutInflater.from(AssignmentActivity.this)
                    .inflate(R.layout.dialog_view_assignment, null);

            TextView tvTitle       = dialogView.findViewById(R.id.tvDialogTitle);
            TextView tvSubject     = dialogView.findViewById(R.id.tvDialogSubject);
            TextView tvGrade       = dialogView.findViewById(R.id.tvDialogGrade);
            TextView tvMarks       = dialogView.findViewById(R.id.tvDialogMarks);
            TextView tvDueDate     = dialogView.findViewById(R.id.tvDialogDueDate);
            TextView tvPostedDate  = dialogView.findViewById(R.id.tvDialogPostedDate);
            TextView tvDescription = dialogView.findViewById(R.id.tvDialogDescription);
            TextView tvStatus      = dialogView.findViewById(R.id.tvDialogStatus);

            tvTitle.setText(a.getTitle());
            tvSubject.setText("📚 Subject: " + a.getSubject());
            tvGrade.setText("🏫 Class: " + a.getGrade());
            tvMarks.setText("⭐ Total Marks: " + a.getMarks());
            // ← CHANGE 3: dialog mein bhi time dikhao
            String dueTimeVal = a.getDueTime();
            tvDueDate.setText("⏰ Due Date: " + a.getDueDate() +
                    (dueTimeVal == null || dueTimeVal.isEmpty() ? "" : "  " + dueTimeVal));
            tvPostedDate.setText("📅 Posted: " + a.getPostedDate());
            tvDescription.setText(a.getDescription());
            tvStatus.setText(a.getStatus());

            boolean isActive = "Active".equalsIgnoreCase(a.getStatus());
            tvStatus.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(
                            isActive ? 0xFF4CAF50 : 0xFF9E9E9E));

            // PDF button agar teacher ne attach ki ho
            String pdfUrl = a.getPdfUrl();
            Button btnViewPdf = dialogView.findViewById(R.id.btnViewAssignmentPdf);
            if (btnViewPdf != null) {
                if (pdfUrl != null && !pdfUrl.isEmpty()) {
                    btnViewPdf.setVisibility(android.view.View.VISIBLE);
                    btnViewPdf.setOnClickListener(v -> {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW,
                                    android.net.Uri.parse(pdfUrl)));
                        } catch (Exception e) {
                            Toast.makeText(AssignmentActivity.this,
                                    "Cannot open PDF", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    btnViewPdf.setVisibility(android.view.View.GONE);
                }
            }

            new AlertDialog.Builder(AssignmentActivity.this)
                    .setView(dialogView)
                    .setPositiveButton("Submit Now", (d, w) -> openSubmitScreen(a))
                    .setNegativeButton("Close", null)
                    .show();
        }

        // ── Open Submit Screen ────────────────────────────────────────────
        private void openSubmitScreen(Assignment a) {
            Intent intent = new Intent(AssignmentActivity.this,
                    SubmitAssignmentActivity.class);
            intent.putExtra(SubmitAssignmentActivity.EXTRA_ASSIGNMENT_ID,  a.getAssignmentId());
            intent.putExtra(SubmitAssignmentActivity.EXTRA_TEACHER_ID,     a.getTeacherId());
            intent.putExtra(SubmitAssignmentActivity.EXTRA_TITLE,          a.getTitle());
            intent.putExtra(SubmitAssignmentActivity.EXTRA_SUBJECT,        a.getSubject());
            intent.putExtra(SubmitAssignmentActivity.EXTRA_MARKS,          a.getMarks());
            intent.putExtra(SubmitAssignmentActivity.EXTRA_DUE_DATE,       a.getDueDate());
            intent.putExtra(SubmitAssignmentActivity.EXTRA_DUE_TIME,       a.getDueTime()); // ← CHANGE 3b
            intent.putExtra(SubmitAssignmentActivity.EXTRA_DESCRIPTION,    a.getDescription());
            startActivity(intent);
        }

        // ── Subject → Icon ────────────────────────────────────────────────
        private int getSubjectIcon(String subject) {
            if (subject == null) return R.drawable.ic_subject;
            for (int i = 0; i < SUBJECTS.length; i++) {
                if (SUBJECTS[i].equalsIgnoreCase(subject)) return SUBJECT_ICONS[i];
            }
            return R.drawable.ic_subject;
        }

        class VH extends RecyclerView.ViewHolder {
            CardView  cardRoot;
            ImageView imgSubjectIcon;
            TextView  tvSubjectName, tvAssignmentTitle, tvDueDate, tvMarks, tvObtainedMarks;
            TextView  btnView, btnSubmit;

            VH(@NonNull View v) {
                super(v);
                cardRoot          = v.findViewById(R.id.cardRoot);
                imgSubjectIcon    = v.findViewById(R.id.imgSubjectIcon);
                tvSubjectName     = v.findViewById(R.id.tvSubjectName);
                tvAssignmentTitle = v.findViewById(R.id.tvAssignmentTitle);
                tvDueDate         = v.findViewById(R.id.tvDueDate);
                tvMarks           = v.findViewById(R.id.tvMarks);
                tvObtainedMarks   = v.findViewById(R.id.tvObtainedMarks);
                btnView           = v.findViewById(R.id.btnView);
                btnSubmit         = v.findViewById(R.id.btnSubmit);
            }
        }
    }
}