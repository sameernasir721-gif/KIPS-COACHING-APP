package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuizActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private BottomNavigationView bottomNav;
    private EditText etSearch;
    private LinearLayout layoutChips, layoutQuizCards;
    private TextView tvStudentInfo, tvNoQuiz;
    private LinearLayout layoutEmpty;

    private String studentUid, studentClass;
    private List<String> enrolledSubjects = new ArrayList<>();
    private List<Map<String, Object>> allQuizzes = new ArrayList<>();
    private String activeChip = "All";

    private final Map<String, MaterialButton> chipMap = new HashMap<>();
    private MaterialButton chipAll;

    // ── Option colors: attempt waqt sirf blue selected, correct reveal nahi ──
    private static final int CLR_DEFAULT  = android.graphics.Color.parseColor("#F5F5F5");
    private static final int CLR_SELECTED = android.graphics.Color.parseColor("#E3F2FD"); // light blue
    private static final int CLR_TEXT_DEF = android.graphics.Color.parseColor("#333333");
    private static final int CLR_TEXT_SEL = android.graphics.Color.parseColor("#1565C0"); // blue

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        drawerLayout    = findViewById(R.id.drawerLayout);
        navigationView  = findViewById(R.id.navigationView);
        bottomNav       = findViewById(R.id.bottomNav);
        etSearch        = findViewById(R.id.etSearch);
        layoutChips     = findViewById(R.id.layoutChips);
        layoutQuizCards = findViewById(R.id.layoutQuizCards);
        tvStudentInfo   = findViewById(R.id.tvStudentInfo);
        tvNoQuiz        = findViewById(R.id.tvNoQuiz);
        layoutEmpty     = findViewById(R.id.layoutEmpty);
        chipAll         = findViewById(R.id.chipAll);

        findViewById(R.id.ivMenu).setOnClickListener(
                v -> drawerLayout.openDrawer(GravityCompat.START));

        setupBottomNav();

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) { renderCards(); }
        });

        chipAll.setOnClickListener(v -> { activeChip = "All"; highlightChip(chipAll); renderCards(); });

        studentUid = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : "";
        fetchStudentThenQuizzes();
    }

    private void fetchStudentThenQuizzes() {
        if (studentUid.isEmpty()) return;
        FirebaseDatabase.getInstance().getReference("Users").child(studentUid).get()
                .addOnSuccessListener(snap -> {
                    if (!snap.exists()) return;
                    String name  = snap.child("name").getValue(String.class);
                    studentClass = snap.child("className").getValue(String.class);
                    String roll  = snap.child("rollNo").getValue(String.class);

                    String info = (studentClass != null) ? "Grade: " + studentClass : "Grade: --";
                    tvStudentInfo.setText(info);

                    enrolledSubjects.clear();
                    for (DataSnapshot s : snap.child("enrolledSubjects").getChildren()) {
                        String sub = s.getValue(String.class);
                        if (sub != null) enrolledSubjects.add(sub);
                    }
                    buildSubjectChips();
                    loadSharedQuizzes();
                });
    }

    private void buildSubjectChips() {
        int childCount = layoutChips.getChildCount();
        if (childCount > 1) layoutChips.removeViews(1, childCount - 1);
        chipMap.clear();

        for (String subject : enrolledSubjects) {
            MaterialButton chip = new MaterialButton(this);
            chip.setText(subject);
            chip.setAllCaps(false);
            chip.setTextSize(14f);
            chip.setTextColor(0xFF333333);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(40));
            lp.setMarginEnd(dpToPx(8));
            chip.setLayoutParams(lp);
            chip.setCornerRadius(dpToPx(20));
            chip.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(0xFFE0E0E0));
            chip.setPadding(dpToPx(16), 0, dpToPx(16), 0);

            chip.setOnClickListener(v -> {
                activeChip = subject;
                highlightChip(chip);
                renderCards();
            });

            layoutChips.addView(chip);
            chipMap.put(subject, chip);
        }
        highlightChip(chipAll);
    }

    private void highlightChip(MaterialButton selected) {
        chipAll.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFE0E0E0));
        chipAll.setTextColor(0xFF333333);
        for (MaterialButton c : chipMap.values()) {
            c.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFE0E0E0));
            c.setTextColor(0xFF333333);
        }
        selected.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFD2192B));
        selected.setTextColor(0xFFFFFFFF);
    }

    private void loadSharedQuizzes() {
        if (studentUid.isEmpty()) return;
        FirebaseDatabase.getInstance().getReference("SharedQuizzes").child(studentUid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        allQuizzes.clear();
                        for (DataSnapshot ds : snapshot.getChildren()) {
                            Map<String, Object> quiz = new HashMap<>();
                            for (DataSnapshot field : ds.getChildren())
                                quiz.put(field.getKey(), field.getValue());
                            if (!quiz.containsKey("quizId")) quiz.put("quizId", ds.getKey());
                            allQuizzes.add(quiz);
                        }
                        allQuizzes.sort((a, b) -> {
                            long ta = a.containsKey("sharedAt") ? ((Number) a.get("sharedAt")).longValue() : 0;
                            long tb = b.containsKey("sharedAt") ? ((Number) b.get("sharedAt")).longValue() : 0;
                            return Long.compare(tb, ta);
                        });
                        renderCards();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {
                        Toast.makeText(QuizActivity.this, "Load failed", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void renderCards() {
        layoutQuizCards.removeAllViews();
        String q = etSearch.getText().toString().trim().toLowerCase();

        List<Map<String, Object>> filtered = new ArrayList<>();
        for (Map<String, Object> quiz : allQuizzes) {
            if (!"All".equals(activeChip)) {
                String sub = s(quiz, "subject");
                if (!sub.equalsIgnoreCase(activeChip)) continue;
            }
            if (!q.isEmpty()) {
                if (!s(quiz, "title").toLowerCase().contains(q)
                        && !s(quiz, "subject").toLowerCase().contains(q)) continue;
            }
            filtered.add(quiz);
        }

        tvNoQuiz.setVisibility(filtered.isEmpty() ? View.VISIBLE : View.GONE);
        layoutEmpty.setVisibility(filtered.isEmpty() ? View.VISIBLE : View.GONE);

        for (Map<String, Object> quiz : filtered) layoutQuizCards.addView(buildCard(quiz));
    }

    private View buildCard(Map<String, Object> quiz) {
        String quizId    = s(quiz, "quizId");
        String title     = s(quiz, "title");
        String subject   = s(quiz, "subject");
        String cls       = s(quiz, "className").isEmpty() ? s(quiz, "grade") : s(quiz, "className");
        String endDate   = s(quiz, "endDate");
        String timeLimit = s(quiz, "timeLimit");

        androidx.cardview.widget.CardView card = new androidx.cardview.widget.CardView(this);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8));
        card.setLayoutParams(cardLp);
        card.setRadius(dpToPx(12));
        card.setCardElevation(dpToPx(4));
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dpToPx(14), dpToPx(14), dpToPx(14), dpToPx(14));
        card.addView(inner);

        TextView tvSubject = new TextView(this);
        tvSubject.setText(subject);
        tvSubject.setTextColor(0xFFD2192B);
        tvSubject.setTextSize(12f);
        tvSubject.setTypeface(null, android.graphics.Typeface.BOLD);
        inner.addView(tvSubject);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextColor(0xFF1A1A2E);
        tvTitle.setTextSize(16f);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setPadding(0, dpToPx(4), 0, 0);
        inner.addView(tvTitle);

        TextView tvMeta = new TextView(this);
        tvMeta.setText("Class: " + cls + (endDate.isEmpty() ? "" : "  •  Due: " + endDate)
                + (timeLimit.isEmpty() ? "" : "  •  Time: " + timeLimit + " min"));
        tvMeta.setTextColor(0xFF757575);
        tvMeta.setTextSize(13f);
        tvMeta.setPadding(0, dpToPx(4), 0, dpToPx(8));
        inner.addView(tvMeta);

        checkAttemptAndAddButton(inner, quiz, quizId, title, subject, timeLimit);

        return card;
    }

    private void checkAttemptAndAddButton(LinearLayout parent, Map<String, Object> quiz,
                                          String quizId, String title, String subject,
                                          String timeLimit) {
        FirebaseDatabase.getInstance().getReference("QuizAttempts")
                .child(quizId).child(studentUid).get()
                .addOnSuccessListener(snap -> {
                    Button btn = new Button(this);
                    btn.setAllCaps(false);
                    btn.setTextColor(0xFFFFFFFF);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(42));
                    lp.setMargins(0, dpToPx(4), 0, 0);
                    btn.setLayoutParams(lp);

                    // ── Start / End timestamp check ───────────────────────
                    long now           = System.currentTimeMillis();
                    long startTs       = getLong(quiz, "startTimestamp");
                    long endTs         = getLong(quiz, "endTimestamp");
                    boolean notStarted = startTs > 0 && now < startTs;
                    boolean expired    = endTs   > 0 && now > endTs;

                    if (snap.exists()) {
                        // Already attempted — show result (same as before)
                        Object scoreObj = snap.child("score").getValue();
                        int score = scoreObj != null ? ((Number) scoreObj).intValue() : 0;
                        Object mcqTotalObj = snap.child("mcqTotal").getValue();
                        int mcqTotal = mcqTotalObj != null ? ((Number) mcqTotalObj).intValue() : 0;
                        Object shortTotalObj = snap.child("shortTotal").getValue();
                        int shortTotal = shortTotalObj != null ? ((Number) shortTotalObj).intValue() : 0;
                        Object shortMarksObj = snap.child("shortMarks").getValue();
                        int shortMarks = shortMarksObj != null ? ((Number) shortMarksObj).intValue() : 0;
                        Object shortStatus = snap.child("shortMarksStatus").getValue();
                        boolean pending = shortStatus != null && shortStatus.toString().equals("pending");

                        if (mcqTotal == 0 && shortTotal == 0) {
                            int calcMcq = 0, calcShort = 0;
                            boolean hasShortQ = false;
                            DataSnapshot answersSnap = snap.child("answers");
                            for (DataSnapshot ans : answersSnap.getChildren()) {
                                String tp = ans.child("type").getValue(String.class);
                                boolean isMcqQ = tp == null || tp.toLowerCase().contains("mcq") || tp.isEmpty();
                                Object m = ans.child("marks").getValue();
                                int qm = m != null ? ((Number) m).intValue() : 1;
                                if (isMcqQ) calcMcq += qm;
                                else { calcShort += qm; hasShortQ = true; }
                            }
                            String txt;
                            if (calcMcq == 0 && calcShort == 0) {
                                txt = "✓ Attempted  |  Score: " + score;
                            } else if (hasShortQ && calcMcq > 0 && pending) {
                                txt = "✓ Attempted  |  MCQ: " + score + "/" + calcMcq + "  |  Score: Pending";
                            } else if (hasShortQ && calcMcq > 0) {
                                txt = "✓ Attempted  |  MCQ: " + score + "/" + calcMcq + "  |  Score: " + shortMarks + "/" + calcShort;
                            } else if (hasShortQ && pending) {
                                txt = "✓ Attempted  |  Score: Pending";
                            } else if (hasShortQ) {
                                txt = "✓ Attempted  |  Score: " + shortMarks + "/" + calcShort;
                            } else {
                                txt = "✓ Attempted  |  Score: " + score + "/" + calcMcq;
                            }
                            btn.setText(txt);
                        } else if (shortTotal > 0 && mcqTotal > 0 && pending) {
                            btn.setText("✓ Attempted  |  MCQ: " + score + "/" + mcqTotal + "  |  Score: Pending");
                        } else if (shortTotal > 0 && mcqTotal > 0) {
                            btn.setText("✓ Attempted  |  MCQ: " + score + "/" + mcqTotal + "  |  Score: " + shortMarks + "/" + shortTotal);
                        } else if (shortTotal > 0 && pending) {
                            btn.setText("✓ Attempted  |  Score: Pending");
                        } else if (shortTotal > 0) {
                            btn.setText("✓ Attempted  |  Score: " + shortMarks + "/" + shortTotal);
                        } else {
                            btn.setText("✓ Attempted  |  Score: " + score + "/" + mcqTotal);
                        }
                        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF4CAF50));
                        btn.setEnabled(false);
                    } else if (notStarted) {
                        // Quiz abhi shuru nahi hua — button lock
                        btn.setText("Not Started Yet");
                        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF9E9E9E));
                        btn.setAlpha(0.5f);
                        btn.setEnabled(false);
                    } else if (expired) {
                        // Deadline guzar gayi — blur/disabled
                        btn.setText("Time Over");
                        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF9E9E9E));
                        btn.setAlpha(0.5f);
                        btn.setEnabled(false);
                    } else {
                        // Available — Start Quiz
                        btn.setText("Start Quiz");
                        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFD2192B));
                        btn.setAlpha(1f);
                        btn.setEnabled(true);
                        btn.setOnClickListener(v ->
                                openAttemptDialog(quiz, quizId, title, subject, timeLimit, getLong(quiz, "sharedAt")));
                    }
                    parent.addView(btn);
                });
    }

    private void openAttemptDialog(Map<String, Object> quiz, String quizId,
                                   String title, String subject, String timeLimitStr, long sharedAt) {
        FirebaseDatabase.getInstance().getReference("Quizzes")
                .child(s(quiz, "teacherUid")).child(quizId).child("questions").get()
                .addOnSuccessListener(qSnap -> {
                    List<Map<String, Object>> questions = new ArrayList<>();
                    if (qSnap.exists()) {
                        for (DataSnapshot ds : qSnap.getChildren()) {
                            Map<String, Object> qMap = new HashMap<>();
                            for (DataSnapshot f : ds.getChildren()) qMap.put(f.getKey(), f.getValue());
                            questions.add(qMap);
                        }
                    }
                    if (questions.isEmpty()) {
                        Toast.makeText(this, "No questions found for this quiz.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    showQuizScreen(quizId, title, subject, timeLimitStr, sharedAt, questions, s(quiz, "teacherUid"));
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to load questions: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show());
    }

    /**
     * Jab student quiz attempt submit kare, us teacher ko announcement bhejo
     * jisne yeh quiz banaya tha. Yeh Announcements/Teachers node mein push
     * hota hai with targetTeacherId field, taake TeacherAnnouncementsActivity
     * usay filter kar ke sirf relevant teacher ko dikha sake.
     */
    private void notifyTeacherOfQuizSubmission(String teacherUid, String studentName,
                                               String studentClass, String quizTitle) {
        if (teacherUid == null || teacherUid.trim().isEmpty()) return;

        Map<String, Object> announcement = new HashMap<>();
        announcement.put("title", "📝 Quiz Submitted");
        announcement.put("message", (studentName != null && !studentName.isEmpty() ? studentName : "A student")
                + (studentClass != null && !studentClass.isEmpty() ? " (" + studentClass + ")" : "")
                + " submitted \"" + (quizTitle != null ? quizTitle : "a quiz") + "\"");
        announcement.put("targetGroup", "Submission");
        announcement.put("targetClass", studentClass);
        announcement.put("targetTeacherId", teacherUid);
        announcement.put("timestamp", System.currentTimeMillis());
        announcement.put("type", "quiz_submission");

        FirebaseDatabase.getInstance().getReference("Announcements")
                .child("Teachers").push().setValue(announcement);
    }

    private void showQuizScreen(String quizId, String title, String subject,
                                String timeLimitStr, long sharedAt, List<Map<String, Object>> questions,
                                String teacherUid) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this,
                android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen);

        View view = LayoutInflater.from(this).inflate(R.layout.dialog_quiz_attempt, null);
        builder.setView(view);
        AlertDialog dialog = builder.create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(
                    android.view.WindowManager.LayoutParams.MATCH_PARENT,
                    android.view.WindowManager.LayoutParams.MATCH_PARENT);
        }

        TextView tvQuizTitle = view.findViewById(R.id.tvDialogQuizTitle);
        TextView tvTimer     = view.findViewById(R.id.tvQuizTimer);
        TextView tvProgress  = view.findViewById(R.id.tvQuizProgress);
        LinearLayout layoutQ = view.findViewById(R.id.layoutQuestions);
        Button btnSubmit     = view.findViewById(R.id.btnSubmitQuiz);

        tvQuizTitle.setText(title + " (" + subject + ")");

        int timeMins = 30;
        try { timeMins = Integer.parseInt(timeLimitStr.trim()); } catch (Exception ignored) {}
        long totalTimeMs = timeMins * 60 * 1000L;

        // SharedAt se ab tak kitna time guzra — bacha hua time calculate karo
        long elapsed   = sharedAt > 0 ? (System.currentTimeMillis() - sharedAt) : 0;
        long timeMs    = Math.max(totalTimeMs - elapsed, 0);

        // Agar time already khatam ho gaya to quiz band kar do
        if (timeMs == 0) {
            Toast.makeText(this, "Quiz ka time khatam ho chuka hai!", Toast.LENGTH_LONG).show();
            return;
        }

        final CountDownTimer[] timer  = {null};
        final boolean[]        submitted = {false};
        final int total = questions.size();
        tvProgress.setText("Questions: " + total);

        // Timer — bacha hua time show karo (Start dabane se pehle bhi)
        int remMins = (int)(timeMs / 60000);
        int remSecs = (int)((timeMs % 60000) / 1000);
        tvTimer.setText(String.format("⏱ %02d:%02d", remMins, remSecs));
        tvTimer.setTextColor(0xFF1E2A3B);

        final String[]  selectedLabels = new String[total];
        for (int x = 0; x < total; x++) selectedLabels[x] = "";

        @SuppressWarnings("unchecked")
        final Button[][] optButtons = new Button[total][];
        final EditText[] shortEdits = new EditText[total];

        // ── Build question views ─────────────────────────────────────────────
        for (int i = 0; i < questions.size(); i++) {
            Map<String, Object> qMap = questions.get(i);
            String qText = qMap.containsKey("question") ? qMap.get("question").toString() : "";
            String type  = qMap.containsKey("type")     ? qMap.get("type").toString()     : "MCQs";
            boolean isMCQ = type.contains("MCQ") || type.contains("mcq") || type.isEmpty();

            androidx.cardview.widget.CardView qCard = new androidx.cardview.widget.CardView(this);
            LinearLayout.LayoutParams qcLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            qcLp.setMargins(0, dpToPx(10), 0, 0);
            qCard.setLayoutParams(qcLp);
            qCard.setRadius(dpToPx(10));
            qCard.setCardElevation(dpToPx(2));
            qCard.setCardBackgroundColor(0xFFFFFFFF);

            LinearLayout qBlock = new LinearLayout(this);
            qBlock.setOrientation(LinearLayout.VERTICAL);
            qBlock.setPadding(dpToPx(14), dpToPx(12), dpToPx(14), dpToPx(12));

            TextView tvQ = new TextView(this);
            tvQ.setText((i + 1) + ".  " + qText);
            tvQ.setTextColor(0xFF1A1A2E);
            tvQ.setTextSize(15f);
            tvQ.setTypeface(null, android.graphics.Typeface.BOLD);
            LinearLayout.LayoutParams tvQLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            tvQLp.setMargins(0, 0, 0, dpToPx(10));
            tvQ.setLayoutParams(tvQLp);
            qBlock.addView(tvQ);

            if (isMCQ) {
                String[] optLabels   = {"A", "B", "C", "D"};
                List<String> optionsList = getOptionsList(qMap);

                Button[] opts = new Button[4];
                optButtons[i] = opts;
                final int idx = i;

                for (int j = 0; j < 4; j++) {
                    String optVal = optionsList.get(j);
                    if (optVal.isEmpty()) continue;

                    Button btn = new Button(this);
                    btn.setText(optLabels[j] + ".  " + optVal);
                    btn.setTextSize(14f);
                    btn.setTextColor(CLR_TEXT_DEF);
                    btn.setAllCaps(false);
                    btn.setGravity(android.view.Gravity.START | android.view.Gravity.CENTER_VERTICAL);
                    btn.setPadding(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8));
                    btn.setBackgroundColor(CLR_DEFAULT);
                    LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    btnLp.setMargins(0, dpToPx(4), 0, dpToPx(4));
                    btn.setLayoutParams(btnLp);

                    opts[j] = btn;
                    final String chosenLabel = optLabels[j];
                    final int chosenIdx = j;

                    btn.setOnClickListener(bv -> {
                        // Already answered — ignore
                        if (!selectedLabels[idx].isEmpty()) return;

                        // Save answer
                        selectedLabels[idx] = chosenLabel;

                        // ── SIRF selected option blue — correct reveal nahi ──
                        for (int k = 0; k < 4; k++) {
                            if (opts[k] == null) continue;
                            if (k == chosenIdx) {
                                opts[k].setBackgroundColor(CLR_SELECTED);
                                opts[k].setTextColor(CLR_TEXT_SEL);
                            }
                            opts[k].setClickable(false);
                            opts[k].setFocusable(false);
                        }
                    });

                    qBlock.addView(btn);
                }
            } else {
                EditText etShort = new EditText(this);
                etShort.setHint("Write your answer here...");
                etShort.setTextColor(0xFF333333);
                etShort.setTextSize(14f);
                etShort.setMinLines(2);
                etShort.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                        | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
                LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                etLp.setMargins(0, dpToPx(4), 0, 0);
                etShort.setLayoutParams(etLp);
                etShort.setBackground(
                        androidx.core.content.ContextCompat.getDrawable(this, android.R.drawable.edit_text));
                shortEdits[i] = etShort;
                qBlock.addView(etShort);
            }

            qCard.addView(qBlock);
            layoutQ.addView(qCard);
        }

        // ── Submit logic ─────────────────────────────────────────────────────
        Runnable doSubmit = () -> {
            if (submitted[0]) return;
            submitted[0] = true;
            if (timer[0] != null) timer[0].cancel();
            btnSubmit.setEnabled(false);

            for (EditText et : shortEdits) {
                if (et != null) { et.setEnabled(false); et.setFocusable(false); }
            }

            int score = 0, mcqTotal = 0;
            boolean hasShortQ = false;
            Map<String, Object> answersMap = new HashMap<>();

            for (int i = 0; i < questions.size(); i++) {
                Map<String, Object> qMap = questions.get(i);
                String type = qMap.containsKey("type") ? qMap.get("type").toString() : "MCQs";
                boolean isMCQ = type.contains("MCQ") || type.contains("mcq") || type.isEmpty();

                Map<String, Object> entry = new HashMap<>();
                entry.put("question", qMap.containsKey("question") ? qMap.get("question") : "");
                entry.put("type",     type);
                entry.put("marks",    qMap.containsKey("marks") ? qMap.get("marks") : 1);

                if (isMCQ) {
                    int qMarks = 1;
                    try {
                        if (qMap.containsKey("marks") && qMap.get("marks") != null)
                            qMarks = Integer.parseInt(qMap.get("marks").toString());
                    } catch (Exception ignored) {}
                    mcqTotal += qMarks;

                    String correctLabel = getCorrectLabel(qMap);
                    String studentAns   = selectedLabels[i].trim().toUpperCase();
                    boolean isCorrect   = !studentAns.isEmpty() && !correctLabel.isEmpty()
                            && studentAns.equals(correctLabel);
                    if (isCorrect) score += qMarks;

                    entry.put("answer",        selectedLabels[i]);
                    entry.put("correctAnswer", correctLabel);
                    entry.put("isCorrect",     isCorrect);
                    entry.put("optionA", qMap.containsKey("optionA") ? qMap.get("optionA") : "");
                    entry.put("optionB", qMap.containsKey("optionB") ? qMap.get("optionB") : "");
                    entry.put("optionC", qMap.containsKey("optionC") ? qMap.get("optionC") : "");
                    entry.put("optionD", qMap.containsKey("optionD") ? qMap.get("optionD") : "");
                    // options list format bhi save karo
                    List<String> optsList = getOptionsList(qMap);
                    entry.put("options", optsList);
                } else {
                    hasShortQ = true;
                    String ans = shortEdits[i] != null
                            ? shortEdits[i].getText().toString().trim() : "";
                    entry.put("answer",       ans);
                    entry.put("isCorrect",    false);
                    entry.put("teacherMarks", -1);
                }
                answersMap.put("q" + (i + 1), entry);
            }

            final int     finalScore    = score;
            final int     finalMcqTotal = mcqTotal;
            final boolean finalHasShort = hasShortQ;
            final Map<String, Object> finalAnswersMap = answersMap;
            // Snapshot of questions for dialog
            final List<Map<String, Object>> finalQuestions = new ArrayList<>(questions);
            final String[] finalSelectedLabels = selectedLabels.clone();

            FirebaseDatabase.getInstance().getReference("Users").child(studentUid).get()
                    .addOnCompleteListener(task -> {
                        String studentName = "", rollNo = "";
                        if (task.isSuccessful() && task.getResult() != null && task.getResult().exists()) {
                            String n = task.getResult().child("name").getValue(String.class);
                            String r = task.getResult().child("registrationId").getValue(String.class);
                            if (n != null) studentName = n;
                            if (r != null) rollNo = r;
                        }
                        final String finalStudentName = studentName;

                        Map<String, Object> attemptData = new HashMap<>();
                        attemptData.put("studentUid",        studentUid);
                        attemptData.put("studentName",       studentName);
                        attemptData.put("studentId",         rollNo);
                        attemptData.put("quizId",            quizId);
                        attemptData.put("score",             finalScore);
                        attemptData.put("mcqTotal",          finalMcqTotal);
                        attemptData.put("totalQuestions",    total);
                        attemptData.put("hasShortQuestions", finalHasShort);
                        attemptData.put("shortMarksStatus",  finalHasShort ? "pending" : "done");
                        attemptData.put("answers",           finalAnswersMap);
                        attemptData.put("submittedAt",       new java.text.SimpleDateFormat(
                                "dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(new java.util.Date()));
                        attemptData.put("timestamp",         System.currentTimeMillis());

                        FirebaseDatabase.getInstance().getReference("QuizAttempts")
                                .child(quizId).child(studentUid)
                                .setValue(attemptData)
                                .addOnSuccessListener(u -> {
                                    FirebaseDatabase.getInstance().getReference()
                                            .child("SharedQuizzes").child(studentUid).child(quizId)
                                            .child("attemptStatus").setValue("attempted");

                                    // Teacher ko notify karo jisne yeh quiz banaya tha
                                    notifyTeacherOfQuizSubmission(teacherUid, finalStudentName, studentClass, title);

                                    dialog.dismiss();
                                    // ── Submit ke baad result dialog ──
                                    showResultDialog(finalScore, finalMcqTotal,
                                            finalHasShort, finalQuestions, finalSelectedLabels);
                                    loadSharedQuizzes();
                                })
                                .addOnFailureListener(e ->
                                        Toast.makeText(QuizActivity.this,
                                                "Submit failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                    });
        };

        // ── Timer seedha shuru — koi Start button nahi ──────────────────────
        layoutQ.setAlpha(1f);
        btnSubmit.setEnabled(true);
        btnSubmit.setAlpha(1f);

        final long finalTimeMs = timeMs;
        timer[0] = new CountDownTimer(finalTimeMs, 1000) {
            public void onTick(long ms) {
                int tl = (int)(ms / 1000);
                int m = tl / 60, sec = tl % 60;
                tvTimer.setText(String.format("⏱ %02d:%02d", m, sec));
                if (tl <= 60) tvTimer.setTextColor(0xFFD2192B);
            }
            public void onFinish() {
                tvTimer.setText("⏱ 00:00");
                Toast.makeText(QuizActivity.this, "Time up! Auto-submitting...", Toast.LENGTH_SHORT).show();
                doSubmit.run();
            }
        }.start();

        btnSubmit.setOnClickListener(v -> doSubmit.run());
        dialog.show();
    }

    // ── Submit ke baad: Score + har question ka correct answer dialog ─────────
    private void showResultDialog(int finalScore, int mcqTotal, boolean hasShort,
                                  List<Map<String, Object>> questions,
                                  String[] selectedLabels) {
        ScrollView sv = new ScrollView(this);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        sv.addView(container);

        // ── Score card ───────────────────────────────────────────────────────
        LinearLayout scoreCard = new LinearLayout(this);
        scoreCard.setOrientation(LinearLayout.VERTICAL);
        scoreCard.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        android.graphics.drawable.GradientDrawable scoreBg = new android.graphics.drawable.GradientDrawable();
        scoreBg.setColor(android.graphics.Color.parseColor("#1E2A3B"));
        scoreBg.setCornerRadius(dpToPx(12));
        scoreCard.setBackground(scoreBg);
        LinearLayout.LayoutParams scoreCardLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        scoreCardLp.setMargins(0, 0, 0, dpToPx(16));
        scoreCard.setLayoutParams(scoreCardLp);

        TextView tvScore = new TextView(this);
        tvScore.setText("🏆  Score: " + finalScore + " / " + mcqTotal);
        tvScore.setTextSize(20f);
        tvScore.setTextColor(android.graphics.Color.WHITE);
        tvScore.setTypeface(null, android.graphics.Typeface.BOLD);
        tvScore.setGravity(android.view.Gravity.CENTER);
        scoreCard.addView(tvScore);
        container.addView(scoreCard);

        // ── Heading ──────────────────────────────────────────────────────────
        TextView tvHeading = new TextView(this);
        tvHeading.setText("📋  Question Review");
        tvHeading.setTextSize(16f);
        tvHeading.setTextColor(android.graphics.Color.parseColor("#1E2A3B"));
        tvHeading.setTypeface(null, android.graphics.Typeface.BOLD);
        tvHeading.setPadding(0, 0, 0, dpToPx(12));
        container.addView(tvHeading);

        int correct = 0, wrong = 0;

        for (int i = 0; i < questions.size(); i++) {
            Map<String, Object> q = questions.get(i);
            String type   = q.containsKey("type") ? q.get("type").toString() : "MCQs";
            boolean isMCQ = type.contains("MCQ") || type.contains("mcq") || type.isEmpty();

            String questionText  = q.containsKey("question") ? q.get("question").toString() : "";
            String studentAnswer = selectedLabels[i];
            String correctAnswer = getCorrectLabel(q);
            List<String> optsList = getOptionsList(q);

            boolean isCorrect = false;
            if (isMCQ) {
                isCorrect = !studentAnswer.isEmpty()
                        && studentAnswer.trim().toUpperCase().equals(correctAnswer);
                if (isCorrect) correct++;
                else if (!studentAnswer.isEmpty()) wrong++;
            }

            // ── Review card ──────────────────────────────────────────────────
            LinearLayout reviewCard = new LinearLayout(this);
            reviewCard.setOrientation(LinearLayout.VERTICAL);
            reviewCard.setPadding(dpToPx(14), dpToPx(14), dpToPx(14), dpToPx(14));
            android.graphics.drawable.GradientDrawable rBg = new android.graphics.drawable.GradientDrawable();
            rBg.setColor(android.graphics.Color.WHITE);
            rBg.setCornerRadius(dpToPx(10));
            int borderColor = !isMCQ          ? android.graphics.Color.parseColor("#90CAF9")
                    : isCorrect               ? android.graphics.Color.parseColor("#A5D6A7")
                    : studentAnswer.isEmpty() ? android.graphics.Color.parseColor("#BDBDBD")
                    :                           android.graphics.Color.parseColor("#EF9A9A");
            rBg.setStroke(dpToPx(2), borderColor);
            reviewCard.setBackground(rBg);
            LinearLayout.LayoutParams rLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rLp.setMargins(0, 0, 0, dpToPx(10));
            reviewCard.setLayoutParams(rLp);

            // Q text
            TextView tvQText = new TextView(this);
            tvQText.setText("Q" + (i + 1) + ". " + questionText);
            tvQText.setTextSize(14f);
            tvQText.setTextColor(android.graphics.Color.parseColor("#1E2A3B"));
            tvQText.setTypeface(null, android.graphics.Typeface.BOLD);
            tvQText.setPadding(0, 0, 0, dpToPx(8));
            reviewCard.addView(tvQText);

            if (isMCQ) {
                String[] optLabels = {"A", "B", "C", "D"};

                // Correct answer text
                String correctText = correctAnswer;
                int cIdx = correctAnswer.length() == 1
                        ? (correctAnswer.charAt(0) - 'A') : -1;
                if (cIdx >= 0 && cIdx < optsList.size() && !optsList.get(cIdx).isEmpty()) {
                    correctText = correctAnswer + ". " + optsList.get(cIdx);
                }

                TextView tvCorrect = new TextView(this);
                tvCorrect.setText("✅  Correct Answer: " + correctText);
                tvCorrect.setTextSize(13f);
                tvCorrect.setTextColor(android.graphics.Color.parseColor("#2E7D32"));
                tvCorrect.setPadding(0, 0, 0, dpToPx(4));
                reviewCard.addView(tvCorrect);

                // Your answer text
                String yourText = studentAnswer.isEmpty() ? "Not attempted" : studentAnswer;
                if (!studentAnswer.isEmpty()) {
                    int sIdx = studentAnswer.length() == 1
                            ? (studentAnswer.charAt(0) - 'A') : -1;
                    if (sIdx >= 0 && sIdx < optsList.size() && !optsList.get(sIdx).isEmpty()) {
                        yourText = studentAnswer + ". " + optsList.get(sIdx);
                    }
                }
                TextView tvYours = new TextView(this);
                tvYours.setText("📝  Your Answer: " + yourText);
                tvYours.setTextSize(13f);
                tvYours.setTextColor(isCorrect
                        ? android.graphics.Color.parseColor("#2E7D32")
                        : studentAnswer.isEmpty()
                        ? android.graphics.Color.parseColor("#757575")
                        : android.graphics.Color.parseColor("#C62828"));
                reviewCard.addView(tvYours);

                // Result badge
                TextView tvResult = new TextView(this);
                if (studentAnswer.isEmpty()) {
                    tvResult.setText("⚪  Skipped");
                    tvResult.setTextColor(android.graphics.Color.parseColor("#757575"));
                } else if (isCorrect) {
                    tvResult.setText("✅  Correct");
                    tvResult.setTextColor(android.graphics.Color.parseColor("#2E7D32"));
                } else {
                    tvResult.setText("❌  Wrong");
                    tvResult.setTextColor(android.graphics.Color.parseColor("#C62828"));
                }
                tvResult.setTextSize(13f);
                tvResult.setTypeface(null, android.graphics.Typeface.BOLD);
                tvResult.setPadding(0, dpToPx(4), 0, 0);
                reviewCard.addView(tvResult);

            } else {
                // Short answer — sirf jawab aur teacher note, kuch nahi
                String ans = selectedLabels[i];
                TextView tvYours = new TextView(this);
                tvYours.setText(ans.isEmpty() ? "📝  No answer written" : "📝  Your Answer: " + ans);
                tvYours.setTextSize(13f);
                tvYours.setTextColor(android.graphics.Color.parseColor("#1565C0"));
                reviewCard.addView(tvYours);

                TextView tvNote = new TextView(this);
                tvNote.setText("⏳  Teacher will check and assign marks");
                tvNote.setTextSize(12f);
                tvNote.setTextColor(android.graphics.Color.parseColor("#757575"));
                tvNote.setPadding(0, dpToPx(4), 0, 0);
                reviewCard.addView(tvNote);
            }

            container.addView(reviewCard);
        }

        // ── Summary — sirf MCQ ke liye ───────────────────────────────────────
        if (mcqTotal > 0) {
            int skipped = mcqTotal - correct - wrong;
            TextView tvSummary = new TextView(this);
            tvSummary.setText("✅ Correct: " + correct + "   ❌ Wrong: " + wrong
                    + "   ⚪ Skipped: " + skipped);
            tvSummary.setTextSize(13f);
            tvSummary.setTextColor(android.graphics.Color.parseColor("#1E2A3B"));
            tvSummary.setTypeface(null, android.graphics.Typeface.BOLD);
            tvSummary.setPadding(0, dpToPx(8), 0, 0);
            container.addView(tvSummary);
        }

        if (hasShort) {
            TextView tvShortNote = new TextView(this);
            tvShortNote.setText("📌  Short questions will be checked by teacher.");
            tvShortNote.setTextSize(12f);
            tvShortNote.setTextColor(android.graphics.Color.parseColor("#F57F17"));
            tvShortNote.setPadding(0, dpToPx(6), 0, 0);
            container.addView(tvShortNote);
        }

        new AlertDialog.Builder(this)
                .setTitle("🎉  Quiz Submitted!")
                .setView(sv)
                .setCancelable(false)
                .setPositiveButton("Done", null)
                .show();
    }

    private void setupBottomNav() {
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                Intent i = new Intent(this, StudentDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i); finish(); return true;
            } else if (id == R.id.nav_bottom_feedback) {
                startActivity(new Intent(this, FeedbackActivity.class)); finish(); return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileActivity.class)); finish(); return true;
            }
            return false;
        });
    }

    private String s(Map<String, Object> map, String key) {
        Object val = map.get(key); return val != null ? val.toString() : "";
    }

    // ── Quiz timestamp fields ko long mein safely read karo ────────────────
    private long getLong(Map<String, Object> map, String key) {
        Object v = map.get(key);
        if (v instanceof Number) return ((Number) v).longValue();
        if (v instanceof String) {
            try { return Long.parseLong((String) v); } catch (Exception ignored) {}
        }
        return 0L;
    }

    private List<String> getOptionsList(Map<String, Object> qMap) {
        List<String> opts = new ArrayList<>();
        Object rawOptions = qMap.get("options");
        if (rawOptions instanceof List) {
            for (Object o : (List<?>) rawOptions) opts.add(o != null ? o.toString() : "");
        } else {
            String[] optKeys = {"optionA", "optionB", "optionC", "optionD"};
            for (String k : optKeys) {
                opts.add(qMap.containsKey(k) && qMap.get(k) != null ? qMap.get(k).toString() : "");
            }
        }
        while (opts.size() < 4) opts.add("");
        return opts;
    }

    private String getCorrectLabel(Map<String, Object> qMap) {
        Object c = qMap.containsKey("correct") && qMap.get("correct") != null
                ? qMap.get("correct") : qMap.get("correctAnswer");
        if (c == null) return "";
        String cs = c.toString().trim();
        try {
            int idx = Integer.parseInt(cs);
            if (idx >= 0 && idx < 4) return new String[]{"A", "B", "C", "D"}[idx];
        } catch (NumberFormatException ignored) {}
        return cs.toUpperCase();
    }

    private int dpToPx(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }
}