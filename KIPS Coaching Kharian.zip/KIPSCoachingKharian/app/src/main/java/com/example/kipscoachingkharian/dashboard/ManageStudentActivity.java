package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ManageStudentActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private LinearLayout containerRequests;
    private TextView tvLoading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_students_requests);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        containerRequests = findViewById(R.id.containerStudentRequests);
        tvLoading = findViewById(R.id.tvStudentLoading);

        loadAllStudentsData();
    }

    private void loadAllStudentsData() {
        mDatabase.child("Users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                containerRequests.removeAllViews();
                tvLoading.setVisibility(View.GONE);
                boolean found = false;

                for (DataSnapshot userSnap : snapshot.getChildren()) {
                    String role = userSnap.child("role").getValue(String.class);
                    if (role == null || !"Student".equalsIgnoreCase(role)) continue;

                    String currentStatus = userSnap.child("status").getValue(String.class);
                    if (currentStatus == null) currentStatus = "Pending";

                    // ✅ Sirf Approved students show karo — Pending skip
                    if (!"Approved".equalsIgnoreCase(currentStatus)) continue;

                    found = true;
                    String uid   = userSnap.getKey();
                    String name  = userSnap.child("name").getValue(String.class);
                    String email = userSnap.child("email").getValue(String.class);
                    String cls   = userSnap.child("className").getValue(String.class);

                    // Phone fallback
                    Object phoneObj = userSnap.child("phone").getValue();
                    if (phoneObj == null) phoneObj = userSnap.child("phoneNumber").getValue();
                    if (phoneObj == null) phoneObj = userSnap.child("username").getValue();
                    String phone = phoneObj != null ? String.valueOf(phoneObj).trim() : "-";

                    // Subjects
                    StringBuilder subjectsBuilder = new StringBuilder();
                    DataSnapshot subjectsSnap = userSnap.child("enrolledSubjects");
                    if (!subjectsSnap.exists()) subjectsSnap = userSnap.child("subjects");

                    if (subjectsSnap.exists()) {
                        List<String> subjectList = new ArrayList<>();
                        for (DataSnapshot sub : subjectsSnap.getChildren()) {
                            if (sub.getValue() instanceof Boolean) {
                                if (Boolean.TRUE.equals(sub.getValue(Boolean.class)))
                                    subjectList.add(sub.getKey());
                            } else {
                                String s = sub.getValue(String.class);
                                if (s == null) {
                                    Object rawSub = sub.child("name").getValue();
                                    if (rawSub != null) s = rawSub.toString();
                                }
                                if (s != null && !s.isEmpty()) subjectList.add(s);
                            }
                        }
                        if (subjectList.isEmpty() && subjectsSnap.getValue(String.class) != null)
                            subjectsBuilder.append(subjectsSnap.getValue(String.class));
                        else
                            subjectsBuilder.append(android.text.TextUtils.join(", ", subjectList));
                    }

                    String subjectsStr = subjectsBuilder.length() > 0 ? subjectsBuilder.toString() : "Not Selected";

                    if (name == null || name.isEmpty())   name  = "-";
                    if (email == null || email.isEmpty()) email = "-";
                    if (cls == null || cls.isEmpty())     cls   = "-";

                    createModernStudentRow(uid, name, phone, email, cls, subjectsStr, currentStatus);
                }

                if (!found) showEmptyState("No approved students found.");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ManageStudentActivity.this,
                        "Firebase Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void createModernStudentRow(String uid, String name, String phone, String email,
                                        String cls, String subjects, String status) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setBackgroundColor(0xFFFFFFFF);
        card.setPadding(24, 24, 24, 24);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, 16);
        card.setLayoutParams(lp);
        card.setElevation(2f);

        LinearLayout detailsLayout = new LinearLayout(this);
        detailsLayout.setOrientation(LinearLayout.VERTICAL);
        detailsLayout.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvName = new TextView(this);
        tvName.setText(name);
        tvName.setTextSize(16);
        tvName.setTextColor(0xFF222222);
        detailsLayout.addView(tvName);

        TextView tvMetadata = new TextView(this);
        tvMetadata.setText("Phone: " + phone
                + "\nEmail: " + email
                + "\nClass: " + cls
                + "\nSubjects: " + subjects
                + "\nStatus: " + status.toUpperCase());
        tvMetadata.setTextSize(14);
        tvMetadata.setTextColor(0xFF666666);
        tvMetadata.setLineSpacing(4, 1);
        tvMetadata.setPadding(0, 6, 0, 0);
        detailsLayout.addView(tvMetadata);

        card.addView(detailsLayout);

        TextView tvThreeDots = new TextView(this);
        tvThreeDots.setText("⋮");
        tvThreeDots.setTextSize(26);
        tvThreeDots.setPadding(20, 10, 20, 10);
        tvThreeDots.setTextColor(0xFF777777);
        tvThreeDots.setGravity(Gravity.CENTER);
        tvThreeDots.setOnClickListener(v -> showActionPopupMenu(v, uid, name, email, cls));
        card.addView(tvThreeDots);

        containerRequests.addView(card);
    }

    private void showActionPopupMenu(View anchor, String uid, String name, String email, String currentClass) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add("Approve Account");
        popup.getMenu().add("Update Details");
        popup.getMenu().add("Delete Record");

        popup.setOnMenuItemClickListener(item -> {
            String title = item.getTitle().toString();
            if (title.equals("Approve Account")) {
                generateStudentIdFirst(uid, name, email, currentClass);
            } else if (title.equals("Update Details")) {
                showUpdateStudentFormDialog(uid, name, email, currentClass);
            } else if (title.equals("Delete Record")) {
                promptRejectOrDelete(uid, name);
            }
            return true;
        });
        popup.show();
    }

    private void generateStudentIdFirst(String uid, String name, String studentEmail, String className) {
        mDatabase.child("Metadata").child("studentCounter").runTransaction(new Transaction.Handler() {
            @NonNull @Override
            public Transaction.Result doTransaction(@NonNull MutableData mutableData) {
                Long v = mutableData.getValue(Long.class);
                mutableData.setValue(v == null ? 1 : v + 1);
                return Transaction.success(mutableData);
            }
            @Override
            public void onComplete(DatabaseError error, boolean committed, DataSnapshot snap) {
                if (committed && snap.getValue() != null) {
                    long count = (long) snap.getValue();
                    String uniqueId = "student" + String.format("%03d", count);
                    showSectionSelectionForm(uid, name, studentEmail, className, uniqueId);
                } else {
                    Toast.makeText(ManageStudentActivity.this,
                            "Transaction failure. Retry.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showSectionSelectionForm(String uid, String name, String email,
                                          String className, String uniqueId) {
        String rawClass    = (className != null && !className.isEmpty() && !className.equals("-")) ? className : "9th";
        String classDigit  = rawClass.replaceAll("[^0-9]", "");
        String searchDigit = classDigit.isEmpty() ? "9" : classDigit;
        String[] sections  = {"A", "B"};

        new AlertDialog.Builder(this)
                .setTitle("Select Section for " + name)
                .setCancelable(false)
                .setItems(sections, (dialog, which) -> {
                    String sel = sections[which];
                    saveApprovedDataToFirebase(uid, name, email, sel, searchDigit + sel, uniqueId);
                }).show();
    }

    private void saveApprovedDataToFirebase(String uid, String name, String email,
                                            String section, String formattedClass, String uniqueId) {
        Map<String, Object> updates = new HashMap<>();
        updates.put("status", "Approved");
        updates.put("registrationId", uniqueId);
        updates.put("assignedSection", section);
        updates.put("className", formattedClass);

        mDatabase.child("Users").child(uid).updateChildren(updates)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        showIdGeneratedDialog(name, uniqueId, formattedClass);
                        if (email != null && !email.isEmpty() && !email.equals("-"))
                            sendEmailToStudent(email, name, uniqueId, formattedClass);
                    }
                });
    }

    private void showUpdateStudentFormDialog(String uid, String currentName,
                                             String currentEmail, String currentClass) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Student Profile");

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_student, null);
        builder.setView(dialogView);

        EditText etName  = dialogView.findViewById(R.id.etEditStudentName);
        EditText etEmail = dialogView.findViewById(R.id.etEditStudentEmail);
        EditText etClass = dialogView.findViewById(R.id.etEditStudentClass);

        etName.setText(currentName);
        etEmail.setText(currentEmail);
        etClass.setText(currentClass);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String updatedName  = etName.getText().toString().trim();
            String updatedEmail = etEmail.getText().toString().trim();
            String updatedClass = etClass.getText().toString().trim();

            if (updatedName.isEmpty()) {
                Toast.makeText(this, "Name cannot be blank!", Toast.LENGTH_SHORT).show();
                return;
            }

            Map<String, Object> childUpdates = new HashMap<>();
            childUpdates.put("name",      updatedName);
            childUpdates.put("email",     updatedEmail.isEmpty() ? "-" : updatedEmail);
            childUpdates.put("className", updatedClass.isEmpty() ? "-" : updatedClass);

            mDatabase.child("Users").child(uid).updateChildren(childUpdates)
                    .addOnCompleteListener(task -> Toast.makeText(this,
                            "Student profile updated.", Toast.LENGTH_SHORT).show());
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void promptRejectOrDelete(String uid, String name) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Student?")
                .setMessage("Permanently delete " + name + " from the system?")
                .setPositiveButton("Delete", (d, w) -> mDatabase.child("Users").child(uid).removeValue()
                        .addOnCompleteListener(task -> Toast.makeText(this,
                                "Student deleted.", Toast.LENGTH_SHORT).show()))
                .setNegativeButton("Cancel", null).show();
    }

    private void sendEmailToStudent(String email, String name, String id, String cls) {
        Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
        intent.putExtra(Intent.EXTRA_SUBJECT, "Registration Approved - KIPS");
        intent.putExtra(Intent.EXTRA_TEXT, "Dear " + name + ",\nYour account is approved.\nID: " + id + "\nClass: " + cls);
        try { startActivity(Intent.createChooser(intent, "Send Email...")); } catch (Exception ignored) {}
    }

    private void showIdGeneratedDialog(String name, String id, String cls) {
        new AlertDialog.Builder(this)
                .setTitle("✅ Approved!")
                .setMessage("Name: " + name + "\nID: " + id + "\nClass: " + cls)
                .setPositiveButton("OK", null).show();
    }

    private void showEmptyState(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(14);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, 50, 0, 0);
        containerRequests.addView(tv);
    }
}