package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TeacherAssignmentActivity extends AppCompatActivity {

    private RecyclerView rvAssignments;
    private LinearLayout layoutEmpty;
    private AssignmentAdapter adapter;
    private TextView chipAll, chipDraft, chipPending, chipDueToday;
    private View indicatorAll, indicatorDraft, indicatorPending, indicatorDueToday;
    private final java.util.Set<String> pendingKeys = new java.util.HashSet<>();
    private String activeFilter = "all";

    private final List<Map<String, Object>> assignmentList = new ArrayList<>();
    private final List<String> assignmentKeys = new ArrayList<>();
    private String searchQuery = "";

    private String teacherUid;
    private DatabaseReference dbRef;
    private DatabaseReference assignmentsRef;
    private ValueEventListener assignmentsListener;


    private final ActivityResultLauncher<Intent> createLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    r -> { /* onResume automatically refresh  */ });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_assignment);
        TeacherDrawerHelper.attach(this);
        android.view.View ivTeacherProfileIcon = findViewById(R.id.ivStudent);
        if (ivTeacherProfileIcon != null) ivTeacherProfileIcon.setOnClickListener(v ->
                startActivity(new android.content.Intent(this, com.example.kipscoachingkharian.dashboard.TeacherProfileInfoActivity.class)));

        if (FirebaseAuth.getInstance().getCurrentUser() == null) { finish(); return; }
        teacherUid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        dbRef = FirebaseDatabase.getInstance().getReference();

        rvAssignments = findViewById(R.id.rvAssignments);
        layoutEmpty   = findViewById(R.id.layoutEmpty);

        rvAssignments.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AssignmentAdapter(assignmentList, assignmentKeys);
        rvAssignments.setAdapter(adapter);

        loadTeacherInfo();
        loadAssignments();

        // Filter chips (All / Draft)
        chipAll       = findViewById(R.id.chipAll);
        chipDraft     = findViewById(R.id.chipDraft);
        indicatorAll  = findViewById(R.id.indicatorAll);
        indicatorDraft = findViewById(R.id.indicatorDraft);
        chipPending   = findViewById(R.id.chipPending);
        indicatorPending = findViewById(R.id.indicatorPending);
        chipDueToday  = findViewById(R.id.chipDueToday);
        indicatorDueToday = findViewById(R.id.indicatorDueToday);
        if (chipAll != null && chipDraft != null && chipPending != null && chipDueToday != null) {
            chipAll.setOnClickListener(v   -> setFilter("all",   chipAll));
            chipDraft.setOnClickListener(v -> setFilter("draft", chipDraft));
            chipPending.setOnClickListener(v -> setFilter("pending", chipPending));
            chipDueToday.setOnClickListener(v -> setFilter("duetoday", chipDueToday));
            String openFilter = getIntent().getStringExtra("OPEN_FILTER");
            if ("pending".equals(openFilter))
                setFilter("pending", chipPending);
            else if ("duetoday".equals(openFilter))
                setFilter("duetoday", chipDueToday);
            else
                setFilter("all", chipAll);
        }

        // Search bar
        EditText etSearch = findViewById(R.id.etSearch);
        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
                @Override public void afterTextChanged(Editable s) {
                    searchQuery = s.toString().trim().toLowerCase();
                    adapter.filter(searchQuery, activeFilter);
                }
            });
        }

        findViewById(R.id.btnCreateNew).setOnClickListener(v ->
                createLauncher.launch(new Intent(this, CreateAssignmentActivity.class)));

        final View btnCreateNew = findViewById(R.id.btnCreateNew);
        final com.google.android.material.floatingactionbutton.FloatingActionButton fabCreateNew =
                findViewById(R.id.fabCreateNew);
        final androidx.core.widget.NestedScrollView scrollRoot = findViewById(R.id.scrollRoot);
        fabCreateNew.setOnClickListener(v ->
                createLauncher.launch(new Intent(this, CreateAssignmentActivity.class)));
        scrollRoot.setOnScrollChangeListener(
                (androidx.core.widget.NestedScrollView.OnScrollChangeListener)
                        (v, scrollX, scrollY, oldX, oldY) -> updateFabVisibility(btnCreateNew, fabCreateNew));

        scrollRoot.post(() -> updateFabVisibility(btnCreateNew, fabCreateNew));

        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                startActivity(new Intent(this, TeacherDashboardActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_Announcment) {
                startActivity(new Intent(this, TeacherAnnouncementsActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileMenuActivity.class));
                finish(); return true;
            }
            return false;
        });
    }

    private void updateFabVisibility(View btnCreateNew,
                                     com.google.android.material.floatingactionbutton.FloatingActionButton fab) {
        boolean btnVisible = btnCreateNew.getGlobalVisibleRect(new android.graphics.Rect());
        if (btnVisible) fab.hide(); else fab.show();
    }

    private void setFilter(String f, TextView chip) {
        activeFilter = f;
        indicatorAll.setVisibility(chip == chipAll ? View.VISIBLE : View.GONE);
        indicatorDraft.setVisibility(chip == chipDraft ? View.VISIBLE : View.GONE);
        indicatorPending.setVisibility(chip == chipPending ? View.VISIBLE : View.GONE);
        indicatorDueToday.setVisibility(chip == chipDueToday ? View.VISIBLE : View.GONE);
        adapter.filter(searchQuery, activeFilter);
    }

    private boolean isDueToday(String dueDate) {
        java.util.Date now = new java.util.Date();
        String shortFmt = new java.text.SimpleDateFormat("d/M/yyyy", java.util.Locale.getDefault()).format(now);
        String fullFmt  = new java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(now);
        return dueDate.equals(shortFmt) || dueDate.equals(fullFmt);
    }

    private void loadPendingKeys() {
        if (assignmentKeys.isEmpty()) return;
        final List<String> keysToCheck = new ArrayList<>(assignmentKeys);
        final java.util.concurrent.atomic.AtomicInteger remaining =
                new java.util.concurrent.atomic.AtomicInteger(keysToCheck.size());
        for (String k : keysToCheck) {
            dbRef.child("Submissions").child(k)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snap) {
                            boolean pending = false;
                            for (DataSnapshot sub : snap.getChildren()) {
                                if (sub.child("obtainedMarks").getValue() == null) {
                                    pending = true;
                                    break;
                                }
                            }
                            if (pending) pendingKeys.add(k); else pendingKeys.remove(k);
                            if (remaining.decrementAndGet() == 0) {
                                adapter.filter(searchQuery, activeFilter);
                                openNotificationItem();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError e) {
                            if (remaining.decrementAndGet() == 0) {
                                adapter.filter(searchQuery, activeFilter);
                                openNotificationItem();
                            }
                        }
                    });
        }
    }

    private void loadTeacherInfo() {

    }

    private void loadAssignments() {
        if (teacherUid == null || teacherUid.isEmpty()) return;

        if (assignmentsRef != null && assignmentsListener != null) {
            assignmentsRef.removeEventListener(assignmentsListener);
        }
        assignmentsRef = dbRef.child("Assignments").child(teacherUid);
        assignmentsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                assignmentList.clear();
                assignmentKeys.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Map<String, Object> q = new HashMap<>();
                    for (DataSnapshot f : child.getChildren()) q.put(f.getKey(), f.getValue());
                    if (!q.containsKey("_key")) q.put("_key", child.getKey());
                    assignmentList.add(q);
                    assignmentKeys.add(child.getKey());
                }

                java.util.Collections.reverse(assignmentList);
                java.util.Collections.reverse(assignmentKeys);
                adapter.notifyDataSetChanged();
                adapter.filter(searchQuery, activeFilter);
                loadPendingKeys();
                boolean empty = assignmentList.isEmpty();
                rvAssignments.setVisibility(empty ? View.GONE    : View.VISIBLE);
                layoutEmpty.setVisibility(  empty ? View.VISIBLE : View.GONE);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(TeacherAssignmentActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };
        assignmentsRef.addValueEventListener(assignmentsListener);
    }

    private boolean deepLinkDone = false;

    private void flashAssignment(final int pos, int tries) {
        RecyclerView.ViewHolder vh = rvAssignments.findViewHolderForAdapterPosition(pos);
        if (vh != null && vh.itemView.getHeight() > 0) {
            flashItem(vh.itemView);
        } else if (tries < 20) {
            rvAssignments.postDelayed(() -> flashAssignment(pos, tries + 1), 100);
        }
    }


    private void openNotificationItem() {
        if (deepLinkDone) return;
        String wanted = getIntent().getStringExtra("dl_title");
        if (wanted == null || wanted.trim().isEmpty()) return;
        for (int i = 0; i < adapter.list.size(); i++) {
            if (wanted.trim().equalsIgnoreCase(getVal(adapter.list.get(i), "title").trim())) {
                deepLinkDone = true;
                flashAssignment(i, 0);
                return;
            }
        }
    }



    private void flashItem(View v) { flashItem(v, 0); }

    private void flashItem(final View v, int tries) {
        if ((v.getHeight() == 0 || !v.isAttachedToWindow()) && tries < 10) {
            v.postDelayed(() -> flashItem(v, tries + 1), 150);
            return;
        }

        View scroller = null;
        android.view.ViewParent p = v.getParent();
        while (p instanceof View) {
            if (p instanceof androidx.core.widget.NestedScrollView || p instanceof android.widget.ScrollView) {
                scroller = (View) p;
                break;
            }
            p = p.getParent();
        }
        if (scroller != null) {
            android.graphics.Rect r = new android.graphics.Rect();
            v.getDrawingRect(r);
            ((ViewGroup) scroller).offsetDescendantRectToMyCoords(v, r);
            int y = Math.max(0, r.top - Math.round(90 * getResources().getDisplayMetrics().density));
            if (scroller instanceof androidx.core.widget.NestedScrollView)
                ((androidx.core.widget.NestedScrollView) scroller).smoothScrollTo(0, y);
            else
                ((android.widget.ScrollView) scroller).smoothScrollTo(0, y);
        }
        v.postDelayed(() -> {
            final float oldZ = v.getTranslationZ();
            v.animate().scaleX(1.03f).scaleY(1.03f)
                    .translationZ(oldZ + 10 * getResources().getDisplayMetrics().density)
                    .setDuration(250).start();
            v.postDelayed(() -> {
                v.animate().scaleX(1f).scaleY(1f).translationZ(oldZ).setDuration(250).start();
            }, 3500);
        }, scroller != null ? 400 : 0);
    }

    private void showPopupMenu(View anchor, Map<String, Object> a, String key) {
        PopupMenu popup = new PopupMenu(this, anchor);
        boolean isDraft = "draft".equalsIgnoreCase(getVal(a, "status"));
        if (isDraft) {
            popup.getMenu().add(0, 2, 1, "✏  Edit");
        }
        popup.getMenu().add(0, 3, 2, "🗑  Delete");
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 2: openEdit(a, key);  return true;
                case 3: confirmDelete(key, getVal(a, "title")); return true;
            }
            return false;
        });
        popup.show();
    }

    private void openEdit(Map<String, Object> a, String key) {
        Intent i = new Intent(this, CreateAssignmentActivity.class);
        i.putExtra(CreateAssignmentActivity.EXTRA_EDIT_MODE,      true);
        i.putExtra(CreateAssignmentActivity.EXTRA_ASSIGNMENT_KEY,  key);
        i.putExtra(CreateAssignmentActivity.EXTRA_TITLE,       getVal(a, "title"));
        i.putExtra(CreateAssignmentActivity.EXTRA_SUBJECT,     getVal(a, "subject"));
        i.putExtra(CreateAssignmentActivity.EXTRA_GRADE,       getVal(a, "grade"));
        i.putExtra(CreateAssignmentActivity.EXTRA_MARKS,       getVal(a, "marks"));
        i.putExtra(CreateAssignmentActivity.EXTRA_DUE_DATE,    getVal(a, "dueDate"));
        i.putExtra(CreateAssignmentActivity.EXTRA_DUE_TIME,    getVal(a, "dueTime"));
        i.putExtra(CreateAssignmentActivity.EXTRA_DESCRIPTION, getVal(a, "description"));
        createLauncher.launch(i);
    }

    private void confirmDelete(String key, String title) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Assignment")
                .setMessage("\"" + title + "\" Are you sure you want to delete?")
                .setPositiveButton("Delete", (d, w) ->
                        dbRef.child("Assignments").child(teacherUid).child(key)
                                .removeValue()
                                .addOnSuccessListener(u ->
                                        Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(e ->
                                        Toast.makeText(this, "Failed: " + e.getMessage(),
                                                Toast.LENGTH_SHORT).show()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String getVal(Map<String, Object> map, String key) {
        Object v = map.get(key);
        return v != null ? v.toString() : "";
    }

    private void shareAssignmentToStudents(Map<String, Object> assignment, String assignmentKey) {
        String grade       = getVal(assignment, "grade");
        String title       = getVal(assignment, "title");
        String description = getVal(assignment, "description");
        String subject     = getVal(assignment, "subject");

        FirebaseDatabase.getInstance().getReference("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        int[] count = {0};
                        Map<String, Object> childUpdates = new HashMap<>();

                        for (DataSnapshot userSnap : snapshot.getChildren()) {
                            String role = userSnap.child("role").getValue(String.class);
                            if (role == null || !role.equalsIgnoreCase("Student")) continue;
                            String studentClass = userSnap.child("className").getValue(String.class);
                            if (studentClass == null) continue;

                            if (!grade.isEmpty()) {
                                String gradeNorm = grade.replaceAll("[^0-9A-Za-z]", "").toUpperCase();
                                String classNorm = studentClass.trim().replaceAll("[^0-9A-Za-z]", "").toUpperCase();
                                String gradeNum  = grade.replaceAll("[^0-9]", "");
                                String classNum  = studentClass.trim().replaceAll("[^0-9]", "");
                                boolean match = gradeNorm.equals(classNorm)
                                        || (!gradeNum.isEmpty() && gradeNum.equals(classNum));
                                if (!match) continue;
                            }


                            if (!subject.isEmpty()) {
                                boolean enrolled = false;
                                for (DataSnapshot sub : userSnap.child("enrolledSubjects").getChildren()) {
                                    String val = sub.getValue(String.class);
                                    if (val != null && val.equalsIgnoreCase(subject)) { enrolled = true; break; }
                                }
                                if (!enrolled) continue;
                            }

                            String studentUid = userSnap.getKey();

                            Map<String, Object> sharedData = new HashMap<>();
                            sharedData.put("assignmentKey", assignmentKey);
                            sharedData.put("teacherUid",    teacherUid);
                            sharedData.put("title",         title);
                            sharedData.put("subject",       subject);
                            sharedData.put("grade",         grade);
                            sharedData.put("marks",         getVal(assignment, "marks"));
                            sharedData.put("dueDate",       getVal(assignment, "dueDate"));
                            sharedData.put("dueTime",       getVal(assignment, "dueTime"));
                            sharedData.put("description",   description);
                            sharedData.put("status",        "Active");
                            sharedData.put("sharedAt",      System.currentTimeMillis());
                            sharedData.put("pdfUrl",        getVal(assignment, "pdfUrl")); // teacher ki attached PDF
                            childUpdates.put("/SharedAssignments/" + studentUid + "/" + assignmentKey, sharedData);


                            Map<String, Object> notif = new HashMap<>();
                            notif.put("title",     "📝 New Assignment: " + title + " (" + subject + ")");
                            notif.put("message",   description + "\nClass: " + grade);
                            notif.put("timestamp", System.currentTimeMillis());
                            notif.put("read",      false);
                            notif.put("type",      "assignment");
                            String notifKey = FirebaseDatabase.getInstance().getReference()
                                    .child("Notifications").child(studentUid).push().getKey();
                            if (notifKey != null)
                                childUpdates.put("/Notifications/" + studentUid + "/" + notifKey, notif);

                            count[0]++;
                        }

                        if (count[0] > 0) {

                            Map<String, Object> ann = new HashMap<>();
                            ann.put("title",       "📝 New Assignment: " + title + " (" + subject + ")");
                            ann.put("message",     description + "\nClass: " + grade);
                            ann.put("timestamp",   System.currentTimeMillis());
                            ann.put("pdfUrl",      "");
                            ann.put("targetClass", grade);
                            ann.put("type",        "assignment");
                            childUpdates.put("/Announcements/Students/" + assignmentKey, ann);


                            Map<String, Object> schedule = new HashMap<>();
                            schedule.put("type",        "assignment");
                            schedule.put("title",       title);
                            schedule.put("subject",     subject);
                            schedule.put("className",   grade);
                            schedule.put("dueDate",     getVal(assignment, "dueDate"));
                            schedule.put("dueTime",     getVal(assignment, "dueTime"));
                            schedule.put("description", description);
                            schedule.put("assignmentId", assignmentKey);
                            schedule.put("teacherUid",  teacherUid);
                            schedule.put("timestamp",   System.currentTimeMillis());
                            childUpdates.put("/upcomingSchedule/" + assignmentKey, schedule);

                            dbRef.updateChildren(childUpdates).addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    Toast.makeText(TeacherAssignmentActivity.this,
                                            "✅ Assignment shared!", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(TeacherAssignmentActivity.this,
                                            "Database Write Error", Toast.LENGTH_SHORT).show();
                                }
                            });
                        } else {
                            Toast.makeText(TeacherAssignmentActivity.this,
                                    "⚠️ No approved students found for class: " + grade, Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(TeacherAssignmentActivity.this,
                                "Share failed: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void showExtendDueDateDialog(String assignmentKey, String currentDueDate, String title, String grade) {
        new AlertDialog.Builder(this)
                .setTitle("📅 Extend Due Date")
                .setMessage("Current due date: " + (currentDueDate.isEmpty() ? "None" : currentDueDate)
                        + "\n\nPlease select New due date:")
                .setPositiveButton("Pick New Date", (dialog, which) -> {
                    java.util.Calendar cal = java.util.Calendar.getInstance();
                    new android.app.DatePickerDialog(this, (dv, y, m, d) -> {
                        String newDate = d + "/" + (m + 1) + "/" + y;
                        new AlertDialog.Builder(this)
                                .setTitle("Confirm Date Extension")
                                .setMessage("New due date: " + newDate + "\n\nAre you sure?")
                                .setPositiveButton("Yes, Extend", (d2, w2) -> {
                                    Map<String, Object> upd = new HashMap<>();
                                    upd.put("dueDate", newDate);
                                    dbRef.child("Assignments").child(teacherUid).child(assignmentKey)
                                            .updateChildren(upd)
                                            .addOnSuccessListener(u ->
                                                    updateSharedAssignmentDueDate(assignmentKey, newDate, title, grade))
                                            .addOnFailureListener(e ->
                                                    Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                                })
                                .setNegativeButton("Cancel", null).show();
                    }, cal.get(java.util.Calendar.YEAR),
                            cal.get(java.util.Calendar.MONTH),
                            cal.get(java.util.Calendar.DAY_OF_MONTH)).show();
                })
                .setNegativeButton("Cancel", null).show();
    }

    private void updateSharedAssignmentDueDate(String assignmentKey, String newDate, String title, String grade) {
        FirebaseDatabase.getInstance().getReference("SharedAssignments")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Map<String, Object> batchUpdates = new HashMap<>();
                        for (DataSnapshot studentSnap : snapshot.getChildren()) {
                            if (studentSnap.hasChild(assignmentKey)) {
                                String studentUid = studentSnap.getKey();
                                batchUpdates.put("SharedAssignments/" + studentUid + "/" + assignmentKey + "/dueDate", newDate);
                            }
                        }
                        if (!batchUpdates.isEmpty()) {
                            String announceKey = assignmentKey + "_ext_" + System.currentTimeMillis();
                            Map<String, Object> announcement = new HashMap<>();
                            announcement.put("title",     "📅 Assignment Due Date Extended: " + title);
                            announcement.put("message",   "New due date: " + newDate + "\nClass: " + grade);
                            announcement.put("timestamp", System.currentTimeMillis());
                            announcement.put("pdfUrl",    "");
                            announcement.put("targetClass", grade);
                            batchUpdates.put("Announcements/Students/" + announceKey, announcement);
                            FirebaseDatabase.getInstance().getReference()
                                    .updateChildren(batchUpdates)
                                    .addOnSuccessListener(u ->
                                            Toast.makeText(TeacherAssignmentActivity.this,
                                                    "✅ Due date extended!", Toast.LENGTH_SHORT).show())
                                    .addOnFailureListener(e ->
                                            Toast.makeText(TeacherAssignmentActivity.this,
                                                    "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    // ════════════════════════════════════════════════════════════════════
    // Adapter
    // ════════════════════════════════════════════════════════════════════
    private class AssignmentAdapter extends RecyclerView.Adapter<AssignmentAdapter.ViewHolder> {

        private final List<Map<String, Object>> allList;
        private final List<String> allKeys;
        private List<Map<String, Object>> list;
        private List<String> keys;

        AssignmentAdapter(List<Map<String, Object>> list, List<String> keys) {
            this.allList = list; this.allKeys = keys;
            this.list = list; this.keys = keys;
        }

        void filter(String query, String statusFilter) {
            list = new ArrayList<>(); keys = new ArrayList<>();
            for (int i = 0; i < allList.size(); i++) {
                Map<String, Object> a = allList.get(i);

                if ("draft".equals(statusFilter) && !"draft".equalsIgnoreCase(getVal(a, "status"))) continue;
                if ("pending".equals(statusFilter) && !pendingKeys.contains(allKeys.get(i))) continue;
                if ("duetoday".equals(statusFilter) && !isDueToday(getVal(a, "dueDate"))) continue;

                if (!query.isEmpty()) {
                    String title   = getVal(a, "title").toLowerCase();
                    String subject = getVal(a, "subject").toLowerCase();
                    String grade   = getVal(a, "grade").toLowerCase();
                    if (!title.contains(query) && !subject.contains(query) && !grade.contains(query)) continue;
                }

                list.add(a); keys.add(allKeys.get(i));
            }
            layoutEmpty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
            rvAssignments.setVisibility(list.isEmpty() ? View.GONE : View.VISIBLE);
            notifyDataSetChanged();
        }

        @NonNull @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_teacher_assignment, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder h, int position) {
            Map<String, Object> a = list.get(position);
            String key = keys.get(position);

            h.tvTitle.setText(getVal(a, "title"));
            h.tvSubject.setText(getVal(a, "subject"));
            h.tvGrade.setText(getVal(a, "grade"));
            h.tvMarks.setText(getVal(a, "marks") + " Marks");
            String dueTimeVal = getVal(a, "dueTime");
            h.tvDueDate.setText("Due: " + getVal(a, "dueDate") + (dueTimeVal.isEmpty() ? "" : "  " + dueTimeVal));
            h.tvPostedDate.setText("Posted: " + getVal(a, "postedDate"));
            h.tvDescription.setText(getVal(a, "description"));

            h.btnMenu.setImageResource(android.R.drawable.ic_menu_more);
            h.btnMenu.setColorFilter(0xFF555555);
            h.btnMenu.setOnClickListener(v -> showPopupMenu(h.btnMenu, a, key));

            android.graphics.drawable.GradientDrawable circle =
                    new android.graphics.drawable.GradientDrawable();
            circle.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            circle.setColor(0xFFD2192B);
            h.tvBadge.setBackground(circle);


            FirebaseDatabase.getInstance()
                    .getReference("Submissions").child(key)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot s) {
                            long count = s.getChildrenCount();
                            h.btnSubmissions.setText(count > 0
                                    ? "📄 SUBMISSIONS  (" + count + ")"
                                    : "📄 SUBMISSIONS");
                            h.tvBadge.setVisibility(View.GONE);
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError e) {
                            h.tvBadge.setVisibility(View.GONE);
                        }
                    });

            h.btnSubmissions.setOnClickListener(v -> {
                Intent i = new Intent(TeacherAssignmentActivity.this, AllSubmissionsActivity.class);
                i.putExtra(AllSubmissionsActivity.EXTRA_ASSIGNMENT_ID,    key);
                i.putExtra(AllSubmissionsActivity.EXTRA_TEACHER_ID,       teacherUid);
                i.putExtra(AllSubmissionsActivity.EXTRA_ASSIGNMENT_TITLE, getVal(a, "title"));
                i.putExtra(AllSubmissionsActivity.EXTRA_TOTAL_MARKS,      getVal(a, "marks"));
                i.putExtra(AllSubmissionsActivity.EXTRA_DUE_DATE,         getVal(a, "dueDate"));
                startActivity(i);
            });


            h.btnShare.setText("Share");
            h.btnShare.setOnClickListener(v -> shareAssignmentToStudents(a, key));

            FirebaseDatabase.getInstance().getReference("SharedAssignments")
                    .orderByChild(key).limitToFirst(50)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snap) {
                            boolean alreadyShared = false;
                            for (DataSnapshot sSnap : snap.getChildren()) {
                                if (sSnap.hasChild(key)) { alreadyShared = true; break; }
                            }
                            if (alreadyShared) {
                                h.btnShare.setText("Extend Due Date");
                                h.btnShare.setOnClickListener(v ->
                                        showExtendDueDateDialog(key, getVal(a, "dueDate"), getVal(a, "title"), getVal(a, "grade")));
                            } else {
                                h.btnShare.setText("Share");
                                h.btnShare.setOnClickListener(v -> shareAssignmentToStudents(a, key));
                            }
                        }
                        @Override public void onCancelled(@NonNull DatabaseError e) {
                            h.btnShare.setOnClickListener(v -> shareAssignmentToStudents(a, key));
                        }
                    });
        }

        @Override
        public int getItemCount() { return list.size(); }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView  tvTitle, tvSubject, tvGrade, tvMarks,
                    tvDueDate, tvPostedDate, tvDescription, tvBadge;
            ImageView btnMenu;
            Button    btnSubmissions, btnShare;

            ViewHolder(@NonNull View v) {
                super(v);
                tvTitle        = v.findViewById(R.id.tvTitle);
                tvSubject      = v.findViewById(R.id.tvSubject);
                tvGrade        = v.findViewById(R.id.tvGrade);
                tvMarks        = v.findViewById(R.id.tvMarks);
                tvDueDate      = v.findViewById(R.id.tvDueDate);
                tvPostedDate   = v.findViewById(R.id.tvPostedDate);
                tvDescription  = v.findViewById(R.id.tvDescription);
                tvBadge        = v.findViewById(R.id.tvSubmissionBadge);
                btnMenu        = v.findViewById(R.id.btnMenu);
                btnSubmissions = v.findViewById(R.id.btnViewSubmissions);
                btnShare       = v.findViewById(R.id.btnShare);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onResume() {
        super.onResume();
        loadPendingKeys();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (assignmentsRef != null && assignmentsListener != null)
            assignmentsRef.removeEventListener(assignmentsListener);
    }
}