package com.example.kipscoachingkharian.dashboard;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class StudentReportDetailActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private TextView tvTitle, tvEmpty;
    private List<DataSnapshot> dataList = new ArrayList<>();
    private GenericReportAdapter adapter;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_report_detail);

        // Intent se data lena
        String node = getIntent().getStringExtra("NODE"); // StudentMarks, StudentProgress, Submissions
        String title = getIntent().getStringExtra("TITLE");
        String studentId = getIntent().getStringExtra("STUDENT_ID");

        tvTitle = findViewById(R.id.tvHeaderTitle);
        tvTitle.setText(title);

        recyclerView = findViewById(R.id.rvReportList);
        progressBar = findViewById(R.id.progressBar);
        tvEmpty = findViewById(R.id.tvEmpty);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new GenericReportAdapter(dataList, node);
        recyclerView.setAdapter(adapter);

        dbRef = FirebaseDatabase.getInstance().getReference(node);
        loadData(node, studentId);
    }

    private void loadData(String node, String studentId) {
        Query query;

        // Submissions mein studentId andar hota hai, isliye Query use hogi
        if (node.equals("Submissions")) {
            query = dbRef.orderByChild("studentId").equalTo(studentId);
        } else {
            // StudentMarks aur StudentProgress mein ID hi main key hai
            query = dbRef.child(studentId);
        }

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dataList.clear();
                progressBar.setVisibility(View.GONE);

                if (snapshot.exists()) {
                    // Agar StudentMarks ya Progress hai, to uske children (Quizzes) uthao
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        dataList.add(ds);
                    }
                }

                if (dataList.isEmpty()) {
                    tvEmpty.setVisibility(View.VISIBLE);
                    tvEmpty.setText("No data found for ID: " + studentId);
                } else {
                    tvEmpty.setVisibility(View.GONE);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
            }
        });
    }
}