package com.example.kipscoachingkharian.auth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.AdminDashboardActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.regex.Pattern;

public class AdminLoginActivity extends AppCompatActivity {

    private FirebaseAuth      mAuth;
    private DatabaseReference mDatabase;

    private TextInputEditText etAdminEmail, etAdminPassword;
    private MaterialButton    btnAdminLogin;
    private TextView          tvForgotPassword;

    // ── Validation patterns ───────────────────────────────────────────────────
    // Email: standard format
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    // Password: min 8 chars, at least 1 special character
    private static final Pattern SPECIAL_CHAR_PATTERN =
            Pattern.compile(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        mAuth     = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        etAdminEmail    = findViewById(R.id.etAdminEmail);
        etAdminPassword = findViewById(R.id.etAdminPassword);
        btnAdminLogin   = findViewById(R.id.btnAdminLogin);
        tvForgotPassword = findViewById(R.id.tvForgotPassword); // XML mein add karein

        btnAdminLogin.setOnClickListener(v -> loginAdmin());

        // ✅ Forgot Password
        if (tvForgotPassword != null) {
            tvForgotPassword.setOnClickListener(v -> showForgotPasswordDialog());
        }
    }

    // ── Login ─────────────────────────────────────────────────────────────────
    private void loginAdmin() {
        String email    = etAdminEmail.getText().toString().trim();
        String password = etAdminPassword.getText().toString().trim();

        // ── Validation ────────────────────────────────────────────────────────
        if (TextUtils.isEmpty(email)) {
            etAdminEmail.setError("Email zaroor likhein");
            etAdminEmail.requestFocus();
            return;
        }
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            etAdminEmail.setError("Email format sahi nahi — example@domain.com");
            etAdminEmail.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etAdminPassword.setError("Password zaroor likhein");
            etAdminPassword.requestFocus();
            return;
        }
        if (password.length() < 8) {
            etAdminPassword.setError("Password kam az kam 8 characters ka hona chahiye");
            etAdminPassword.requestFocus();
            return;
        }
        if (!SPECIAL_CHAR_PATTERN.matcher(password).matches()) {
            etAdminPassword.setError("Password mein kam az kam ek special character hona chahiye (!@#$%...)");
            etAdminPassword.requestFocus();
            return;
        }

        btnAdminLogin.setEnabled(false);
        btnAdminLogin.setText("Logging in...");

        // ── Firebase Auth ─────────────────────────────────────────────────────
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(authTask -> {
                    if (!authTask.isSuccessful()) {
                        String err = authTask.getException() != null
                                ? getFriendlyError(authTask.getException().getMessage())
                                : "Login failed";
                        Toast.makeText(this, err, Toast.LENGTH_LONG).show();
                        btnAdminLogin.setEnabled(true);
                        btnAdminLogin.setText("Login");
                        return;
                    }

                    // ── Role check ────────────────────────────────────────────
                    mDatabase.child("Users")
                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    String foundRole = null;

                                    for (DataSnapshot user : snapshot.getChildren()) {
                                        String emailInDB = user.child("email").getValue(String.class);
                                        if (emailInDB != null
                                                && emailInDB.trim().equalsIgnoreCase(email)) {
                                            foundRole = user.child("role").getValue(String.class);
                                            break;
                                        }
                                    }

                                    if (!"Admin".equals(foundRole)) {
                                        Toast.makeText(AdminLoginActivity.this,
                                                "Access Denied: Sirf Admin login kar sakta hai.",
                                                Toast.LENGTH_SHORT).show();
                                        mAuth.signOut();
                                        btnAdminLogin.setEnabled(true);
                                        btnAdminLogin.setText("Login");
                                        return;
                                    }

                                    // Save credentials
                                    AdminDashboardActivity.saveAdminCredentials(
                                            AdminLoginActivity.this, email, password);

                                    Toast.makeText(AdminLoginActivity.this,
                                            "✅ Admin Login Successful!", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(AdminLoginActivity.this,
                                            AdminDashboardActivity.class));
                                    finishAffinity();
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
                                    Toast.makeText(AdminLoginActivity.this,
                                            "Database error: " + error.getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                    btnAdminLogin.setEnabled(true);
                                    btnAdminLogin.setText("Login");
                                }
                            });
                });
    }

    // ── Forgot Password Dialog ────────────────────────────────────────────────
    private void showForgotPasswordDialog() {
        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(16), dp(24), dp(8));

        // Info text
        TextView tvInfo = new TextView(this);
        tvInfo.setText("Apna registered email likhein — reset link bheja jayega.");
        tvInfo.setTextSize(13f);
        tvInfo.setTextColor(0xFF555555);
        android.widget.LinearLayout.LayoutParams ip =
                new android.widget.LinearLayout.LayoutParams(-1, -2);
        ip.bottomMargin = dp(12);
        tvInfo.setLayoutParams(ip);
        layout.addView(tvInfo);

        // Email field — pre-fill agar pehle se likha ho
        TextInputEditText etEmail = new TextInputEditText(this);
        etEmail.setHint("Admin Email");
        String existingEmail = etAdminEmail.getText().toString().trim();
        if (!existingEmail.isEmpty()) etEmail.setText(existingEmail);
        layout.addView(etEmail);

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("🔑 Forgot Password")
                .setView(layout)
                .setPositiveButton("Send Reset Link", (d, w) -> {
                    String email = etEmail.getText().toString().trim();

                    if (email.isEmpty()) {
                        Toast.makeText(this, "Email likhein", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (!EMAIL_PATTERN.matcher(email).matches()) {
                        Toast.makeText(this, "Email format sahi nahi", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    sendPasswordResetEmail(email);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Firebase password reset email ─────────────────────────────────────────
    private void sendPasswordResetEmail(String email) {
        mAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(this,
                                "✅ Reset link " + email + " par bhej diya gaya!\nApna inbox check karein.",
                                Toast.LENGTH_LONG).show();
                    } else {
                        String err = task.getException() != null
                                ? getFriendlyError(task.getException().getMessage())
                                : "Email send nahi ho saka";
                        Toast.makeText(this, "❌ " + err, Toast.LENGTH_LONG).show();
                    }
                });
    }

    // ── Friendly error messages ───────────────────────────────────────────────
    private String getFriendlyError(String error) {
        if (error == null) return "Kuch masla aa gaya — dobara try karein";
        if (error.contains("no user record") || error.contains("user-not-found"))
            return "❌ Ye email registered nahi hai";
        if (error.contains("wrong-password") || error.contains("invalid-credential"))
            return "❌ Email ya password galat hai";
        if (error.contains("too-many-requests"))
            return "❌ Boht zyada attempts — thodi der baad try karein";
        if (error.contains("network"))
            return "❌ Internet connection check karein";
        return "❌ " + error;
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}