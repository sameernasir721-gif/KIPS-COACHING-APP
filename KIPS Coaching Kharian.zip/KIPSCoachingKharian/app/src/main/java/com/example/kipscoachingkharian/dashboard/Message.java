package com.example.kipscoachingkharian.dashboard;

import java.util.Map;

public class Message {
    private String messageId;
    private String senderId;
    private String senderName;
    private String senderRole;
    private String receiverId;
    private String receiverName;
    private String text;
    private long   timestamp;
    private boolean read;


    private String type;
    private String fileUrl;
    private String fileName;
    private String fileSize;


    private Map<String, Boolean> deletedFor;


    private boolean deletedForEveryone;


    public Message() {}

    public Message(String messageId, String senderId, String senderName, String senderRole,
                   String receiverId, String receiverName, String text, long timestamp) {
        this.messageId          = messageId;
        this.senderId           = senderId;
        this.senderName         = senderName;
        this.senderRole         = senderRole;
        this.receiverId         = receiverId;
        this.receiverName       = receiverName;
        this.text               = text;
        this.timestamp          = timestamp;
        this.read               = false;
        this.deletedForEveryone = false;
    }

    public String  getMessageId()                     { return messageId; }
    public void    setMessageId(String v)             { this.messageId = v; }

    public String  getSenderId()                      { return senderId; }
    public void    setSenderId(String v)              { this.senderId = v; }

    public String  getSenderName()                    { return senderName; }
    public void    setSenderName(String v)            { this.senderName = v; }

    public String  getSenderRole()                    { return senderRole; }
    public void    setSenderRole(String v)            { this.senderRole = v; }

    public String  getReceiverId()                    { return receiverId; }
    public void    setReceiverId(String v)            { this.receiverId = v; }

    public String  getReceiverName()                  { return receiverName; }
    public void    setReceiverName(String v)          { this.receiverName = v; }

    public String  getText()                          { return text; }
    public void    setText(String v)                  { this.text = v; }

    public long    getTimestamp()                     { return timestamp; }
    public void    setTimestamp(long v)               { this.timestamp = v; }

    public boolean isRead()                           { return read; }
    public void    setRead(boolean v)                 { this.read = v; }

    public Map<String, Boolean> getDeletedFor()       { return deletedFor; }
    public void setDeletedFor(Map<String, Boolean> v) { this.deletedFor = v; }

    public boolean isDeletedForEveryone()             { return deletedForEveryone; }
    public void    setDeletedForEveryone(boolean v)   { this.deletedForEveryone = v; }


    public String  getType()                          { return type; }
    public void    setType(String v)                  { this.type = v; }

    public String  getFileUrl()                       { return fileUrl; }
    public void    setFileUrl(String v)               { this.fileUrl = v; }

    public String  getFileName()                      { return fileName; }
    public void    setFileName(String v)              { this.fileName = v; }

    public String  getFileSize()                      { return fileSize; }
    public void    setFileSize(String v)              { this.fileSize = v; }


    public String getEffectiveType() {
        return (type == null || type.isEmpty()) ? "text" : type;
    }
    public boolean isImage() { return "image".equalsIgnoreCase(getEffectiveType()); }
    public boolean isPdf()   { return "pdf".equalsIgnoreCase(getEffectiveType());   }


    public boolean isDeletedFor(String uid) {
        return deletedFor != null && Boolean.TRUE.equals(deletedFor.get(uid));
    }
}