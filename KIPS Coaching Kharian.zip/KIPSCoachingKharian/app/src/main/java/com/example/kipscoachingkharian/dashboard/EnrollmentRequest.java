package com.example.kipscoachingkharian.dashboard;

public class EnrollmentRequest {
    private final String requestId;   // Firebase key (subject name, e.g. "Biology")
    private final String subjectName;
    private final String className;

    public EnrollmentRequest(String requestId, String subjectName, String className) {
        this.requestId = requestId;
        this.subjectName = subjectName;
        this.className = className;
    }

    public String getRequestId() { return requestId; }
    public String getSubjectName() { return subjectName; }
    public String getClassName() { return className; }
}