package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TeacherStudyMaterialActivity extends AppCompatActivity {

    private RecyclerView rvStudyMaterial;
    private LinearLayout layoutEmpty;
    private MaterialAdapter adapter;

    private final List<Map<String, Object>> materialList = new ArrayList<>();
    private final List<String> materialKeys = new ArrayList<>();

    private DatabaseReference materialRef;
    private ValueEventListener materialListener;
    private String teacherUid;
    private String searchQuery = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_studymaterial);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) { finish(); return; }
        teacherUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        rvStudyMaterial = findViewById(R.id.rvStudyMaterial);
        layoutEmpty     = findViewById(R.id.layoutEmpty);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        rvStudyMaterial.setLayoutManager(layoutManager);
        rvStudyMaterial.setNestedScrollingEnabled(false);
        adapter = new MaterialAdapter(materialList, materialKeys);
        rvStudyMaterial.setAdapter(adapter);

        loadTeacherInfo();
        attachMaterialListener();
        setupFilterChips();

        // Search bar
        EditText etSearch = findViewById(R.id.etSearch);
        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
                @Override public void afterTextChanged(Editable s) {
                    searchQuery = s.toString().trim().toLowerCase();
                    adapter.setSearchQuery(searchQuery);
                }
            });
        }

        // Upload button
        findViewById(R.id.btnUpload).setOnClickListener(v ->
                startActivity(new Intent(this, UploadStudyMaterialActivity.class)));

        // Bottom Navigation
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                startActivity(new Intent(this, TeacherDashboardActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_Announcment) {
                startActivity(new Intent(this, TeacherAnnouncementsActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileMenuActivity.class));
                finish(); return true;
            }
            return false;
        });
    }

    private void loadTeacherInfo() {
        // Header shows static page title "Study Material" — no overwrite needed
    }

    private void attachMaterialListener() {
        materialRef = FirebaseDatabase.getInstance()
                .getReference("StudyMaterials").child(teacherUid);

        materialListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                materialList.clear();
                materialKeys.clear();
                List<Map<String, Object>> tempList = new ArrayList<>();
                List<String> tempKeys = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> item = (Map<String, Object>) child.getValue();
                    if (item != null) {
                        tempList.add(new HashMap<>(item));
                        tempKeys.add(child.getKey());
                    }
                }
                // Sort by createdAt descending (newest first)
                for (int ii = 0; ii < tempList.size() - 1; ii++) {
                    for (int jj = ii + 1; jj < tempList.size(); jj++) {
                        long t1 = 0, t2 = 0;
                        Object c1 = tempList.get(ii).get("createdAt");
                        Object c2 = tempList.get(jj).get("createdAt");
                        if (c1 instanceof Long) t1 = (Long) c1;
                        else if (c1 instanceof Number) t1 = ((Number) c1).longValue();
                        if (c2 instanceof Long) t2 = (Long) c2;
                        else if (c2 instanceof Number) t2 = ((Number) c2).longValue();
                        if (t2 > t1) {
                            Map<String, Object> tmpM = tempList.get(ii);
                            String tmpK = tempKeys.get(ii);
                            tempList.set(ii, tempList.get(jj));
                            tempKeys.set(ii, tempKeys.get(jj));
                            tempList.set(jj, tmpM);
                            tempKeys.set(jj, tmpK);
                        }
                    }
                }
                materialList.addAll(tempList);
                materialKeys.addAll(tempKeys);
                adapter.refreshList();
                boolean empty = materialList.isEmpty();
                rvStudyMaterial.setVisibility(empty ? View.GONE    : View.VISIBLE);
                layoutEmpty.setVisibility(    empty ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(TeacherStudyMaterialActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };
        materialRef.addValueEventListener(materialListener);
    }

    private void setupFilterChips() {
        TextView chipAll   = findViewById(R.id.chipAll);
        TextView chipPdf   = findViewById(R.id.chipPdf);
        TextView chipImage = findViewById(R.id.chipImage);
        if (chipAll == null || chipPdf == null || chipImage == null) return;

        // Default highlight — inline background color, no drawable needed
        setChipSelected(chipAll);
        setChipUnselected(chipPdf);
        setChipUnselected(chipImage);

        chipAll.setOnClickListener(v -> {
            adapter.setFilter("all");
            setChipSelected(chipAll);
            setChipUnselected(chipPdf);
            setChipUnselected(chipImage);
        });
        chipPdf.setOnClickListener(v -> {
            adapter.setFilter("pdf");
            setChipSelected(chipPdf);
            setChipUnselected(chipAll);
            setChipUnselected(chipImage);
        });
        chipImage.setOnClickListener(v -> {
            adapter.setFilter("image");
            setChipSelected(chipImage);
            setChipUnselected(chipAll);
            setChipUnselected(chipPdf);
        });
    }

    // Chip highlight — pure Java, no drawable file needed
    private void setChipSelected(TextView chip) {
        chip.setBackgroundColor(0xFFE53935);
        chip.setTextColor(0xFFFFFFFF);
    }

    private void setChipUnselected(TextView chip) {
        chip.setBackgroundColor(0xFFF0F0F0);
        chip.setTextColor(0xFF333333);
    }

    private void showPopupMenu(View anchor, Map<String, Object> m, String key) {
        PopupMenu popup = new PopupMenu(this, anchor);
        String st = getVal(m, "status");
        String fu = getVal(m, "fileUrl");
        boolean isDraft = "draft".equalsIgnoreCase(st) || (st.isEmpty() && fu.isEmpty());
        if (isDraft) popup.getMenu().add(0, 1, 0, "✏  Edit");
        popup.getMenu().add(0, 2, 1, "🗑  Delete");
        popup.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == 1) { openEdit(m, key); return true; }
            if (item.getItemId() == 2) { confirmDelete(key, getVal(m, "title")); return true; }
            return false;
        });
        popup.show();
    }

    private void openEdit(Map<String, Object> m, String key) {
        Intent i = new Intent(this, UploadStudyMaterialActivity.class);
        i.putExtra(UploadStudyMaterialActivity.EXTRA_EDIT_MODE,    true);
        i.putExtra(UploadStudyMaterialActivity.EXTRA_MATERIAL_KEY, key);
        i.putExtra(UploadStudyMaterialActivity.EXTRA_TITLE,        getVal(m, "title"));
        i.putExtra(UploadStudyMaterialActivity.EXTRA_SUBJECT,      getVal(m, "subject"));
        i.putExtra(UploadStudyMaterialActivity.EXTRA_GRADE,        getVal(m, "grade"));
        i.putExtra(UploadStudyMaterialActivity.EXTRA_DESCRIPTION,  getVal(m, "description"));
        i.putExtra(UploadStudyMaterialActivity.EXTRA_FILE_URL,     getVal(m, "fileUrl"));
        i.putExtra(UploadStudyMaterialActivity.EXTRA_FILE_TYPE,    getVal(m, "type"));
        startActivity(i);
    }

    private void confirmDelete(String key, String title) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Material")
                .setMessage("\"" + title + "\" Are you sure you want to Delete?")
                .setPositiveButton("Delete", (d, w) ->
                        FirebaseDatabase.getInstance()
                                .getReference("StudyMaterials")
                                .child(teacherUid).child(key)
                                .removeValue()
                                .addOnSuccessListener(u ->
                                        Toast.makeText(this, "Deleted",
                                                Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(e ->
                                        Toast.makeText(this, "Failed: " + e.getMessage(),
                                                Toast.LENGTH_SHORT).show()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void shareWithStudents(Map<String, Object> m, String materialKey) {
        String grade   = getVal(m, "grade");
        String subject = getVal(m, "subject");

        if (grade.isEmpty()) {
            Toast.makeText(this, "Grade not set for this material", Toast.LENGTH_SHORT).show();
            return;
        }
        if (subject.isEmpty()) {
            Toast.makeText(this, "Subject not set for this material", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("Users");
        usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean anyFound = false;
                String gradeNum = grade.replaceAll("[^0-9]", "");
                String gradeSec = grade.replaceAll(".*[0-9]", "").trim().toUpperCase();

                for (DataSnapshot userSnap : snapshot.getChildren()) {
                    String role     = userSnap.child("role").getValue(String.class);
                    String status   = userSnap.child("status").getValue(String.class);
                    String classVal = userSnap.child("className").getValue(String.class);

                    if (!"student".equalsIgnoreCase(role)) continue;
                    if (status != null && !status.equalsIgnoreCase("Approved")) continue;
                    if (classVal == null) continue;

                    // Class number + section check
                    String sClassNum = classVal.trim().replaceAll("[^0-9]", "");
                    if (!gradeNum.equals(sClassNum)) continue;
                    String studentSec = classVal.trim().replaceAll(".*[0-9]", "").trim().toUpperCase();
                    if (!gradeSec.isEmpty() && !studentSec.equals(gradeSec)) continue;

                    // enrolledSubjects check
                    DataSnapshot enrolledSnap = userSnap.child("enrolledSubjects");
                    boolean subjectMatch = false;
                    for (DataSnapshot subSnap : enrolledSnap.getChildren()) {
                        String enrolledSubject = subSnap.getValue(String.class);
                        if (enrolledSubject != null &&
                                enrolledSubject.trim().equalsIgnoreCase(subject.trim())) {
                            subjectMatch = true;
                            break;
                        }
                    }
                    if (!subjectMatch) continue;

                    String studentUid = userSnap.getKey();
                    if (studentUid == null) continue;
                    anyFound = true;

                    // SharedStudyMaterials/{studentUid}/{materialKey}
                    Map<String, Object> shared = new HashMap<>(m);
                    shared.put("sharedAt", System.currentTimeMillis());
                    shared.put("teacherUid", teacherUid);
                    FirebaseDatabase.getInstance().getReference("SharedStudyMaterials")
                            .child(studentUid).child(materialKey).setValue(shared);
                }

                String msg = anyFound
                        ? "✅ Shared with " + subject + " students of " + grade
                        : "No " + subject + " students found in " + grade;
                Toast.makeText(TeacherStudyMaterialActivity.this, msg, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(TeacherStudyMaterialActivity.this,
                        "Share failed: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String getVal(Map<String, Object> map, String key) {
        Object v = map.get(key);
        return v != null ? v.toString() : "";
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (materialRef != null && materialListener != null)
            materialRef.removeEventListener(materialListener);
    }

    // ════════════════════════════════════════════════════════════════
    // Adapter
    // ════════════════════════════════════════════════════════════════
    private class MaterialAdapter extends RecyclerView.Adapter<MaterialAdapter.ViewHolder> {

        private final List<Map<String, Object>> fullList;
        private final List<String>              fullKeys;
        private List<Map<String, Object>> filteredList = new ArrayList<>();
        private List<String>              filteredKeys = new ArrayList<>();
        private String currentFilter = "all";
        private String searchQuery   = "";

        MaterialAdapter(List<Map<String, Object>> list, List<String> keys) {
            this.fullList = list;
            this.fullKeys = keys;
        }

        // Called from Firebase listener — no override conflict
        void refreshList() {
            rebuildFiltered();
            super.notifyDataSetChanged();
        }

        void setFilter(String filter) {
            currentFilter = filter;
            rebuildFiltered();
            super.notifyDataSetChanged();
        }

        void setSearchQuery(String query) {
            searchQuery = query;
            rebuildFiltered();
            super.notifyDataSetChanged();
        }

        private void rebuildFiltered() {
            filteredList = new ArrayList<>();
            filteredKeys = new ArrayList<>();
            for (int i = 0; i < fullList.size(); i++) {
                Map<String, Object> m = fullList.get(i);
                String type  = getVal(m, "type");
                String title = getVal(m, "title").toLowerCase();
                String desc  = getVal(m, "description").toLowerCase();
                boolean typeOk  = currentFilter.equals("all") || currentFilter.equalsIgnoreCase(type);
                boolean queryOk = searchQuery.isEmpty()
                        || title.contains(searchQuery) || desc.contains(searchQuery);
                if (typeOk && queryOk) {
                    filteredList.add(m);
                    filteredKeys.add(fullKeys.get(i));
                }
            }
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_teacher_studymaterial, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder h, int position) {
            Map<String, Object> m   = filteredList.get(position);
            String              key = filteredKeys.get(position);

            h.tvTitle.setText(getVal(m, "title"));
            h.tvSubject.setText(getVal(m, "subject"));
            h.tvGrade.setText(getVal(m, "grade"));
            h.tvDescription.setText(getVal(m, "description"));
            h.tvPostedDate.setText("Uploaded: " + getVal(m, "uploadedDate"));
            h.tvUploadTime.setText("");
            h.tvFileType.setText(getVal(m, "fileSize") + " • " + getVal(m, "type").toUpperCase());

            // File icon
            if ("pdf".equalsIgnoreCase(getVal(m, "type"))) {
                h.ivFileIcon.setImageResource(R.drawable.ic_pdf1);
            } else {
                h.ivFileIcon.setImageResource(R.drawable.ic_image);
            }

            // 3-dot menu
            h.btnMenu.setImageResource(android.R.drawable.ic_menu_more);
            h.btnMenu.setColorFilter(0xFF555555);
            h.btnMenu.setOnClickListener(v -> showPopupMenu(h.btnMenu, m, key));

            // Status label
            String status = getVal(m, "status");
            String fileUrl = getVal(m, "fileUrl");
            boolean isDraft = "draft".equalsIgnoreCase(status) || (status.isEmpty() && fileUrl.isEmpty());
            h.tvPostedDate.setText((isDraft ? "Draft • " : "Uploaded: ") + getVal(m, "uploadedDate"));

            // VIEW button — open URL in browser
            h.btnView.setOnClickListener(v -> {
                String url = getVal(m, "fileUrl");
                if (!url.isEmpty()) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception e) {
                        Toast.makeText(TeacherStudyMaterialActivity.this,
                                "No app found to open file", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(TeacherStudyMaterialActivity.this,
                            "File not available", Toast.LENGTH_SHORT).show();
                }
            });

            // SHARE button — share to students
            h.btnShare.setVisibility(View.VISIBLE);
            h.btnShare.setOnClickListener(v -> shareWithStudents(m, key));
        }

        @Override
        public int getItemCount() {
            return filteredList != null ? filteredList.size() : 0;
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView  tvTitle, tvSubject, tvGrade, tvDescription,
                    tvFileType, tvUploadTime, tvPostedDate;
            ImageView ivFileIcon, btnMenu;
            Button    btnView, btnShare;

            ViewHolder(@NonNull View v) {
                super(v);
                tvTitle       = v.findViewById(R.id.tvTitle);
                tvSubject     = v.findViewById(R.id.tvSubject);
                tvGrade       = v.findViewById(R.id.tvGrade);
                tvDescription = v.findViewById(R.id.tvDescription);
                tvFileType    = v.findViewById(R.id.tvFileType);
                tvUploadTime  = v.findViewById(R.id.tvUploadTime);
                tvPostedDate  = v.findViewById(R.id.tvPostedDate);
                ivFileIcon    = v.findViewById(R.id.ivFileIcon);
                btnMenu       = v.findViewById(R.id.btnMenu);
                btnView       = v.findViewById(R.id.btnView);
                btnShare      = v.findViewById(R.id.btnShare);
            }
        }
    }
}