package com.example.kipscoachingkharian.dashboard;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class QuizAttemptActivity extends AppCompatActivity {

    public static final String EXTRA_QUIZ_ID      = "QUIZ_ID";
    public static final String EXTRA_TEACHER_UID  = "TEACHER_UID";
    public static final String EXTRA_QUIZ_TITLE   = "QUIZ_TITLE";
    public static final String EXTRA_TIME_LIMIT   = "TIME_LIMIT";
    public static final String EXTRA_SCORE        = "SCORE";
    public static final String EXTRA_CORRECT      = "CORRECT";
    public static final String EXTRA_WRONG        = "WRONG";
    public static final String EXTRA_TOTAL_MCQ    = "TOTAL_MCQ";
    public static final String EXTRA_ANSWERS_JSON = "ANSWERS_JSON";

    private TextView      tvQuizTitle, tvTimer, tvProgress;
    private ProgressBar   progressBar;
    private LinearLayout  layoutQuestions;
    private Button        btnSubmit;
    private ScrollView    scrollView;

    private String quizId, teacherUid, studentUid, quizTitle;
    private int    timeLimitMinutes = 30;

    private final List<Map<String, Object>> questions  = new ArrayList<>();
    private final List<String>              answers    = new ArrayList<>();
    private final List<Button[]>            optionBtns = new ArrayList<>();
    private final List<EditText>            shortEdits = new ArrayList<>();

    private CountDownTimer countDownTimer;
    private boolean        submitted = false;
    private int            score     = 0;

    // ── SIRF selected option highlight (green = selected, no correct reveal) ──
    private static final int CLR_DEFAULT    = Color.parseColor("#F5F5F5");
    private static final int CLR_SELECTED   = Color.parseColor("#E3F2FD"); // light blue
    private static final int CLR_TEXT_DEF   = Color.parseColor("#333333");
    private static final int CLR_TEXT_SEL   = Color.parseColor("#1565C0"); // blue

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_attempt);

        quizId          = getIntent().getStringExtra(EXTRA_QUIZ_ID);
        teacherUid      = getIntent().getStringExtra(EXTRA_TEACHER_UID);
        quizTitle       = getIntent().getStringExtra(EXTRA_QUIZ_TITLE);
        String tlStr    = getIntent().getStringExtra(EXTRA_TIME_LIMIT);
        if (tlStr != null && !tlStr.isEmpty()) {
            try { timeLimitMinutes = Integer.parseInt(tlStr); } catch (Exception ignored) {}
        }

        studentUid = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : "";

        tvQuizTitle     = findViewById(R.id.tvQuizTitle);
        tvTimer         = findViewById(R.id.tvTimer);
        tvProgress      = findViewById(R.id.tvProgress);
        progressBar     = findViewById(R.id.progressBar);
        layoutQuestions = findViewById(R.id.layoutQuestions);
        btnSubmit       = findViewById(R.id.btnSubmit);
        scrollView      = findViewById(R.id.scrollView);

        tvQuizTitle.setText(quizTitle != null ? quizTitle : "Quiz");
        btnSubmit.setOnClickListener(v -> confirmSubmit());

        loadQuestions();
    }

    private void loadQuestions() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference()
                .child("Quizzes").child(teacherUid).child(quizId).child("questions");

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snap) {
                questions.clear(); answers.clear(); optionBtns.clear(); shortEdits.clear();
                for (DataSnapshot ds : snap.getChildren()) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> q = (Map<String, Object>) ds.getValue();
                    if (q != null) { questions.add(q); answers.add(""); }
                }
                if (questions.isEmpty()) {
                    Toast.makeText(QuizAttemptActivity.this, "No questions found.", Toast.LENGTH_SHORT).show();
                    finish(); return;
                }
                progressBar.setMax(questions.size());
                buildQuestionViews();
                startTimer();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(QuizAttemptActivity.this, "Failed to load quiz.", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private void buildQuestionViews() {
        layoutQuestions.removeAllViews();
        optionBtns.clear(); shortEdits.clear();

        for (int i = 0; i < questions.size(); i++) {
            Map<String, Object> q = questions.get(i);
            String type  = q.containsKey("type") ? q.get("type").toString().toLowerCase() : "";
            boolean isMcq = type.contains("mcq") || type.contains("multiple");

            // Card
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(16), dp(16), dp(16), dp(16));
            android.graphics.drawable.GradientDrawable cardBg = new android.graphics.drawable.GradientDrawable();
            cardBg.setColor(Color.WHITE);
            cardBg.setCornerRadius(dp(12));
            cardBg.setStroke(dp(1), Color.parseColor("#E0E0E0"));
            card.setBackground(cardBg);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            cardParams.setMargins(dp(12), dp(8), dp(12), dp(8));
            card.setLayoutParams(cardParams);

            // Question text
            TextView tvQ = new TextView(this);
            tvQ.setText("Q" + (i + 1) + ". " + q.get("question"));
            tvQ.setTextSize(16);
            tvQ.setTextColor(Color.parseColor("#1E2A3B"));
            tvQ.setTypeface(null, Typeface.BOLD);
            tvQ.setPadding(0, 0, 0, dp(10));
            card.addView(tvQ);

            // Marks badge
            if (q.containsKey("marks")) {
                TextView tvMarks = new TextView(this);
                tvMarks.setText("Marks: " + q.get("marks"));
                tvMarks.setTextSize(12);
                tvMarks.setTextColor(Color.parseColor("#D2192B"));
                tvMarks.setPadding(0, 0, 0, dp(8));
                card.addView(tvMarks);
            }

            final int idx = i;

            if (isMcq) {
                Button[] opts = new Button[4];
                String[] optionKeys   = {"optionA", "optionB", "optionC", "optionD"};
                String[] optionLabels = {"A", "B", "C", "D"};

                for (int j = 0; j < 4; j++) {
                    String optKey = optionKeys[j];
                    String label  = optionLabels[j];
                    if (!q.containsKey(optKey)) continue;

                    Button btn = new Button(this);
                    btn.setText(label + ". " + q.get(optKey));
                    btn.setTextSize(14);
                    btn.setTextColor(CLR_TEXT_DEF);
                    btn.setAllCaps(false);
                    btn.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                    btn.setPadding(dp(12), dp(8), dp(12), dp(8));
                    btn.setBackgroundColor(CLR_DEFAULT);

                    LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    btnParams.setMargins(0, dp(4), 0, dp(4));
                    btn.setLayoutParams(btnParams);

                    opts[j] = btn;
                    final int optIdx = j;
                    final String finalLabel = label;

                    btn.setOnClickListener(v -> {
                        // Already answered — ignore
                        if (!answers.get(idx).isEmpty()) return;

                        // Save answer
                        answers.set(idx, finalLabel);

                        // ── Sirf selected option ko highlight karo (blue) — correct reveal nahi ──
                        for (int k = 0; k < 4; k++) {
                            if (opts[k] == null) continue;
                            if (k == optIdx) {
                                opts[k].setBackgroundColor(CLR_SELECTED);
                                opts[k].setTextColor(CLR_TEXT_SEL);
                            }
                            // Lock all options
                            opts[k].setClickable(false);
                            opts[k].setFocusable(false);
                        }

                        updateProgress();
                    });

                    card.addView(btn);
                }
                optionBtns.add(opts);
                shortEdits.add(null);

            } else {
                // Short Answer
                EditText et = new EditText(this);
                et.setHint("Type your answer here...");
                et.setTextSize(14);
                et.setTextColor(Color.parseColor("#333333"));
                et.setMinLines(2);
                et.setMaxLines(5);
                et.setPadding(dp(8), dp(8), dp(8), dp(8));
                et.setBackgroundColor(CLR_DEFAULT);
                LinearLayout.LayoutParams etParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                etParams.setMargins(0, dp(4), 0, dp(4));
                et.setLayoutParams(etParams);

                et.addTextChangedListener(new TextWatcher() {
                    public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
                    public void onTextChanged(CharSequence s, int a, int b, int c) {
                        answers.set(idx, s.toString().trim());
                        updateProgress();
                    }
                    public void afterTextChanged(Editable s) {}
                });

                optionBtns.add(null);
                shortEdits.add(et);
                card.addView(et);
            }

            layoutQuestions.addView(card);
        }

        updateProgress();
    }

    private void updateProgress() {
        int answered = 0;
        for (String a : answers) if (!a.isEmpty()) answered++;
        tvProgress.setText(answered + "/" + questions.size() + " answered");
        progressBar.setProgress(answered);
    }

    private void startTimer() {
        long millis = (long) timeLimitMinutes * 60 * 1000;
        countDownTimer = new CountDownTimer(millis, 1000) {
            @Override public void onTick(long ms) {
                long min = ms / 60000, sec = (ms % 60000) / 1000;
                tvTimer.setText(String.format(Locale.getDefault(), "%02d:%02d", min, sec));
                tvTimer.setTextColor(ms <= 60000
                        ? Color.parseColor("#D2192B") : Color.parseColor("#1E2A3B"));
            }
            @Override public void onFinish() {
                tvTimer.setText("00:00");
                tvTimer.setTextColor(Color.parseColor("#D2192B"));
                disableAllInputs();
                Toast.makeText(QuizAttemptActivity.this,
                        "⏰ Time's up! Submitting your quiz...", Toast.LENGTH_SHORT).show();
                submitQuiz();
            }
        }.start();
    }

    private void disableAllInputs() {
        for (Button[] opts : optionBtns) {
            if (opts == null) continue;
            for (Button b : opts) if (b != null) { b.setClickable(false); b.setFocusable(false); }
        }
        for (EditText et : shortEdits) {
            if (et != null) { et.setEnabled(false); et.setFocusable(false); }
        }
        btnSubmit.setEnabled(false);
    }

    private void confirmSubmit() {
        int answered  = 0;
        for (String a : answers) if (!a.isEmpty()) answered++;
        int unanswered = questions.size() - answered;

        String msg = answered + " of " + questions.size() + " questions answered.";
        if (unanswered > 0) msg += "\n" + unanswered + " question(s) left unanswered.";
        msg += "\n\nAre you sure you want to submit?";

        new AlertDialog.Builder(this)
                .setTitle("Submit Quiz")
                .setMessage(msg)
                .setPositiveButton("Yes, Submit", (d, w) -> submitQuiz())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void submitQuiz() {
        if (submitted) return;
        submitted = true;
        if (countDownTimer != null) countDownTimer.cancel();
        disableAllInputs();

        // MCQ score calculate karo
        score = 0;
        for (int i = 0; i < questions.size(); i++) {
            Map<String, Object> q = questions.get(i);
            String type   = q.containsKey("type") ? q.get("type").toString().toLowerCase() : "";
            boolean isMcq = type.contains("mcq") || type.contains("multiple");
            if (isMcq) {
                String studentAns = answers.get(i).trim().toUpperCase();
                String correctAns = getCorrectAnswer(q);
                if (!studentAns.isEmpty() && !correctAns.isEmpty() && studentAns.equals(correctAns)) {
                    int qMarks = 1;
                    try { if (q.containsKey("marks")) qMarks = Integer.parseInt(q.get("marks").toString()); }
                    catch (Exception ignored) {}
                    score += qMarks;
                }
            }
        }

        // Answers map build karo
        Map<String, Object> answersMap = new HashMap<>();
        for (int i = 0; i < questions.size(); i++) {
            Map<String, Object> q = questions.get(i);
            String type   = q.containsKey("type") ? q.get("type").toString().toLowerCase() : "";
            boolean isMcq = type.contains("mcq") || type.contains("multiple");
            Map<String, Object> entry = new HashMap<>();
            entry.put("question", q.containsKey("question") ? q.get("question") : "");
            entry.put("type",     type);
            entry.put("answer",   answers.get(i));
            entry.put("marks",    q.containsKey("marks") ? q.get("marks") : 1);
            if (isMcq) {
                String correctAns = getCorrectAnswer(q);
                entry.put("correctAnswer", correctAns);
                boolean correct = !answers.get(i).isEmpty() && !correctAns.isEmpty()
                        && answers.get(i).trim().toUpperCase().equals(correctAns);
                entry.put("isCorrect", correct);
            }
            answersMap.put("q" + (i + 1), entry);
        }

        final int finalScore = score;
        final Map<String, Object> finalAnswersMap = answersMap;

        FirebaseDatabase.getInstance().getReference("Users").child(studentUid).get()
                .addOnCompleteListener(task -> {
                    String studentName = "", rollNo = "", studentClass = "";
                    if (task.isSuccessful() && task.getResult() != null && task.getResult().exists()) {
                        DataSnapshot snap = task.getResult();
                        String n = snap.child("name").getValue(String.class);
                        String r = snap.child("rollNo").getValue(String.class);
                        String c = snap.child("className").getValue(String.class);
                        if (n != null) studentName = n;
                        if (r != null) rollNo = r;
                        if (c != null) studentClass = c;
                    }
                    final String finalStudentName = studentName;
                    final String finalStudentClass = studentClass;

                    int mcqTotalMarks = 0, shortTotalMarks = 0;
                    boolean hasShort = false;
                    for (Map<String, Object> q : questions) {
                        String tp = q.containsKey("type") ? q.get("type").toString().toLowerCase() : "";
                        boolean isMcqQ = tp.contains("mcq") || tp.contains("multiple");
                        int qM = 1;
                        try { if (q.containsKey("marks")) qM = Integer.parseInt(q.get("marks").toString()); }
                        catch (Exception ignored) {}
                        if (isMcqQ) mcqTotalMarks += qM;
                        else { shortTotalMarks += qM; hasShort = true; }
                    }
                    final int finalMcqTotal = mcqTotalMarks;

                    Map<String, Object> attempt = new HashMap<>();
                    attempt.put("studentUid",     studentUid);
                    attempt.put("studentName",    studentName);
                    attempt.put("studentId",      rollNo);
                    attempt.put("quizId",         quizId);
                    attempt.put("teacherId",      teacherUid);
                    attempt.put("score",          finalScore);
                    attempt.put("mcqTotal",       finalMcqTotal);
                    attempt.put("shortTotal",     shortTotalMarks);
                    attempt.put("totalQuestions", questions.size());
                    attempt.put("submittedAt",    new SimpleDateFormat("dd/MM/yyyy HH:mm",
                            Locale.getDefault()).format(new Date()));
                    attempt.put("timestamp",      System.currentTimeMillis());
                    attempt.put("answers",        finalAnswersMap);
                    if (hasShort) attempt.put("shortMarksStatus", "pending");

                    FirebaseDatabase.getInstance().getReference()
                            .child("QuizAttempts").child(quizId).child(studentUid)
                            .setValue(attempt)
                            .addOnSuccessListener(u -> {
                                FirebaseDatabase.getInstance().getReference()
                                        .child("SharedQuizzes").child(studentUid).child(quizId)
                                        .child("attemptStatus").setValue("attempted");

                                // Teacher ko notify karo jisne yeh quiz banaya tha
                                notifyTeacherOfQuizSubmission(finalStudentName, finalStudentClass);

                                // ── Submit ke baad Result Dialog dikhao ──
                                showResultDialog(finalScore, finalMcqTotal);
                            })
                            .addOnFailureListener(e ->
                                    Toast.makeText(QuizAttemptActivity.this,
                                            "Submit failed: " + e.getMessage(),
                                            Toast.LENGTH_LONG).show());
                });
    }

    /**
     * Jab student quiz attempt submit kare, us teacher ko announcement bhejo
     * jisne yeh quiz banaya tha. Yeh Announcements/Teachers node mein push
     * hota hai with targetTeacherId field, taake TeacherAnnouncementsActivity
     * usay filter kar ke sirf relevant teacher ko dikha sake.
     */
    private void notifyTeacherOfQuizSubmission(String studentName, String studentClass) {
        if (teacherUid == null || teacherUid.trim().isEmpty()) return;

        Map<String, Object> announcement = new HashMap<>();
        announcement.put("title", "📝 Quiz Submitted");
        announcement.put("message", (studentName != null && !studentName.isEmpty() ? studentName : "A student")
                + (studentClass != null && !studentClass.isEmpty() ? " (" + studentClass + ")" : "")
                + " submitted \"" + (quizTitle != null ? quizTitle : "a quiz") + "\"");
        announcement.put("targetGroup", "Submission");
        announcement.put("targetClass", studentClass);
        announcement.put("targetTeacherId", teacherUid);
        announcement.put("timestamp", System.currentTimeMillis());
        announcement.put("type", "quiz_submission");

        FirebaseDatabase.getInstance().getReference("Announcements")
                .child("Teachers").push().setValue(announcement);
    }

    // ── Submit ke baad Dialog: score + har question ka correct answer ────────
    private void showResultDialog(int finalScore, int mcqTotal) {
        int correct = 0, wrong = 0;

        // ── Dialog layout build karo programmatically ────────────────────────
        ScrollView sv = new ScrollView(this);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(16), dp(16), dp(16), dp(16));
        sv.addView(container);

        // Score card
        LinearLayout scoreCard = new LinearLayout(this);
        scoreCard.setOrientation(LinearLayout.VERTICAL);
        scoreCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        android.graphics.drawable.GradientDrawable scoreBg = new android.graphics.drawable.GradientDrawable();
        scoreBg.setColor(Color.parseColor("#1E2A3B"));
        scoreBg.setCornerRadius(dp(12));
        scoreCard.setBackground(scoreBg);
        LinearLayout.LayoutParams scoreCardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        scoreCardParams.setMargins(0, 0, 0, dp(16));
        scoreCard.setLayoutParams(scoreCardParams);

        TextView tvScore = new TextView(this);
        tvScore.setText("🏆  Score: " + finalScore + " / " + mcqTotal);
        tvScore.setTextSize(20);
        tvScore.setTextColor(Color.WHITE);
        tvScore.setTypeface(null, Typeface.BOLD);
        tvScore.setGravity(Gravity.CENTER);
        scoreCard.addView(tvScore);

        container.addView(scoreCard);

        // Heading
        TextView tvHeading = new TextView(this);
        tvHeading.setText("📋  Question Review");
        tvHeading.setTextSize(16);
        tvHeading.setTextColor(Color.parseColor("#1E2A3B"));
        tvHeading.setTypeface(null, Typeface.BOLD);
        tvHeading.setPadding(0, 0, 0, dp(12));
        container.addView(tvHeading);

        // Har question ka review card
        for (int i = 0; i < questions.size(); i++) {
            Map<String, Object> q = questions.get(i);
            String type   = q.containsKey("type") ? q.get("type").toString().toLowerCase() : "";
            boolean isMcq = type.contains("mcq") || type.contains("multiple");

            String questionText  = q.containsKey("question") ? q.get("question").toString() : "";
            String studentAnswer = answers.get(i);
            String correctAnswer = getCorrectAnswer(q);

            boolean isCorrect = false;
            if (isMcq) {
                isCorrect = !studentAnswer.isEmpty() && studentAnswer.trim().toUpperCase().equals(correctAnswer);
                if (isCorrect) correct++;
                else if (!studentAnswer.isEmpty()) wrong++;
            }

            // Review card
            LinearLayout reviewCard = new LinearLayout(this);
            reviewCard.setOrientation(LinearLayout.VERTICAL);
            reviewCard.setPadding(dp(14), dp(14), dp(14), dp(14));
            android.graphics.drawable.GradientDrawable rBg = new android.graphics.drawable.GradientDrawable();
            rBg.setColor(Color.WHITE);
            rBg.setCornerRadius(dp(10));
            int borderColor = !isMcq ? Color.parseColor("#90CAF9")  // blue for short
                    : isCorrect      ? Color.parseColor("#A5D6A7")   // green for correct
                    : studentAnswer.isEmpty() ? Color.parseColor("#BDBDBD") // grey for skipped
                    :                           Color.parseColor("#EF9A9A"); // red for wrong
            rBg.setStroke(dp(2), borderColor);
            reviewCard.setBackground(rBg);
            LinearLayout.LayoutParams rParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rParams.setMargins(0, 0, 0, dp(10));
            reviewCard.setLayoutParams(rParams);

            // Q number + text
            TextView tvQText = new TextView(this);
            tvQText.setText("Q" + (i + 1) + ". " + questionText);
            tvQText.setTextSize(14);
            tvQText.setTextColor(Color.parseColor("#1E2A3B"));
            tvQText.setTypeface(null, Typeface.BOLD);
            tvQText.setPadding(0, 0, 0, dp(8));
            reviewCard.addView(tvQText);

            if (isMcq) {
                // Correct answer
                String[] optionKeys   = {"optionA", "optionB", "optionC", "optionD"};
                String[] optionLabels = {"A", "B", "C", "D"};
                String correctText = correctAnswer;
                for (int k = 0; k < 4; k++) {
                    if (optionLabels[k].equals(correctAnswer) && q.containsKey(optionKeys[k])) {
                        correctText = correctAnswer + ". " + q.get(optionKeys[k]).toString();
                        break;
                    }
                }

                TextView tvCorrect = new TextView(this);
                tvCorrect.setText("✅  Correct Answer: " + correctText);
                tvCorrect.setTextSize(13);
                tvCorrect.setTextColor(Color.parseColor("#2E7D32"));
                tvCorrect.setPadding(0, 0, 0, dp(4));
                reviewCard.addView(tvCorrect);

                // Student answer
                String yourText = studentAnswer.isEmpty() ? "Not attempted" : studentAnswer;
                if (!studentAnswer.isEmpty()) {
                    for (int k = 0; k < 4; k++) {
                        if (optionLabels[k].equals(studentAnswer) && q.containsKey(optionKeys[k])) {
                            yourText = studentAnswer + ". " + q.get(optionKeys[k]).toString();
                            break;
                        }
                    }
                }
                TextView tvYours = new TextView(this);
                tvYours.setText("📝  Your Answer: " + yourText);
                tvYours.setTextSize(13);
                tvYours.setTextColor(isCorrect
                        ? Color.parseColor("#2E7D32")
                        : studentAnswer.isEmpty() ? Color.parseColor("#757575")
                        : Color.parseColor("#C62828"));
                reviewCard.addView(tvYours);

                // Result badge
                TextView tvResult = new TextView(this);
                if (studentAnswer.isEmpty()) {
                    tvResult.setText("⚪  Skipped");
                    tvResult.setTextColor(Color.parseColor("#757575"));
                } else if (isCorrect) {
                    tvResult.setText("✅  Correct");
                    tvResult.setTextColor(Color.parseColor("#2E7D32"));
                } else {
                    tvResult.setText("❌  Wrong");
                    tvResult.setTextColor(Color.parseColor("#C62828"));
                }
                tvResult.setTextSize(13);
                tvResult.setTypeface(null, Typeface.BOLD);
                tvResult.setPadding(0, dp(4), 0, 0);
                reviewCard.addView(tvResult);

            } else {
                // Short answer — sirf student ka jawab dikhao
                TextView tvYours = new TextView(this);
                tvYours.setText("📝  Your Answer: " + (studentAnswer.isEmpty() ? "Not attempted" : studentAnswer));
                tvYours.setTextSize(13);
                tvYours.setTextColor(Color.parseColor("#1565C0"));
                reviewCard.addView(tvYours);

                TextView tvNote = new TextView(this);
                tvNote.setText("⏳  Teacher will check and assign marks");
                tvNote.setTextSize(12);
                tvNote.setTextColor(Color.parseColor("#757575"));
                tvNote.setPadding(0, dp(4), 0, 0);
                reviewCard.addView(tvNote);
            }

            container.addView(reviewCard);
        }

        // Summary: correct / wrong
        int finalCorrect = correct, finalWrong = wrong;
        TextView tvSummary = new TextView(this);
        tvSummary.setText("✅ Correct: " + finalCorrect + "   ❌ Wrong: " + finalWrong +
                "   ⚪ Skipped: " + (mcqTotal - finalCorrect - finalWrong));
        tvSummary.setTextSize(13);
        tvSummary.setTextColor(Color.parseColor("#1E2A3B"));
        tvSummary.setTypeface(null, Typeface.BOLD);
        tvSummary.setPadding(0, dp(8), 0, 0);
        container.addView(tvSummary);

        // ── Dialog dikhao ────────────────────────────────────────────────────
        new AlertDialog.Builder(this)
                .setTitle("🎉  Quiz Submitted!")
                .setView(sv)
                .setCancelable(false)
                .setPositiveButton("Done", (d, w) -> {
                    // Result Activity pe bhi jao
                    goToResultActivity(finalScore, finalCorrect, finalWrong, mcqTotal);
                })
                .show();
    }

    private void goToResultActivity(int finalScore, int correct, int wrong, int mcqTotal) {
        StringBuilder json = new StringBuilder("[");
        for (int i = 0; i < questions.size(); i++) {
            Map<String, Object> q = questions.get(i);
            String type  = q.containsKey("type") ? q.get("type").toString().toLowerCase() : "";
            String qText = q.containsKey("question") ? q.get("question").toString() : "";
            String sAns  = answers.get(i);
            String cAns  = getCorrectAnswer(q);
            String optA  = q.containsKey("optionA") ? q.get("optionA").toString() : "";
            String optB  = q.containsKey("optionB") ? q.get("optionB").toString() : "";
            String optC  = q.containsKey("optionC") ? q.get("optionC").toString() : "";
            String optD  = q.containsKey("optionD") ? q.get("optionD").toString() : "";
            int marks = 1;
            try { if (q.containsKey("marks")) marks = Integer.parseInt(q.get("marks").toString()); }
            catch (Exception ignored) {}
            if (i > 0) json.append(",");
            json.append("{")
                    .append("\"q\":\"").append(escJson(qText)).append("\",")
                    .append("\"type\":\"").append(type).append("\",")
                    .append("\"ans\":\"").append(escJson(sAns)).append("\",")
                    .append("\"correct\":\"").append(escJson(cAns)).append("\",")
                    .append("\"optA\":\"").append(escJson(optA)).append("\",")
                    .append("\"optB\":\"").append(escJson(optB)).append("\",")
                    .append("\"optC\":\"").append(escJson(optC)).append("\",")
                    .append("\"optD\":\"").append(escJson(optD)).append("\",")
                    .append("\"marks\":").append(marks)
                    .append("}");
        }
        json.append("]");

        boolean hasShortQ = false, hasMcqQ = false;
        for (Map<String, Object> q : questions) {
            String t = q.containsKey("type") ? q.get("type").toString().toLowerCase() : "";
            if (t.contains("short")) hasShortQ = true; else hasMcqQ = true;
        }
        String qType = (hasMcqQ && hasShortQ) ? "MCQs + Short Questions"
                : hasShortQ ? "Short Questions" : "MCQs";

        android.content.Intent intent = new android.content.Intent(this, QuizResultActivity.class);
        intent.putExtra(QuizResultActivity.EXTRA_QUIZ_TITLE,    quizTitle != null ? quizTitle : "Quiz");
        intent.putExtra(QuizResultActivity.EXTRA_SCORE,         finalScore);
        intent.putExtra(QuizResultActivity.EXTRA_CORRECT,       correct);
        intent.putExtra(QuizResultActivity.EXTRA_WRONG,         wrong);
        intent.putExtra(QuizResultActivity.EXTRA_TOTAL_MCQ,     mcqTotal);
        intent.putExtra(QuizResultActivity.EXTRA_ANSWERS_JSON,  json.toString());
        intent.putExtra(QuizResultActivity.EXTRA_QUESTION_TYPE, qType);
        startActivity(intent);
        finish();
    }

    private String escJson(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ");
    }

    private String getCorrectAnswer(Map<String, Object> q) {
        if (q.containsKey("correct") && q.get("correct") != null)
            return q.get("correct").toString().trim().toUpperCase();
        if (q.containsKey("correctAnswer") && q.get("correctAnswer") != null)
            return q.get("correctAnswer").toString().trim().toUpperCase();
        return "";
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) countDownTimer.cancel();
    }

    @Override
    public void onBackPressed() {
        if (!submitted) {
            new AlertDialog.Builder(this)
                    .setTitle("Leave Quiz?")
                    .setMessage("Your progress will be lost. Are you sure you want to leave?")
                    .setPositiveButton("Leave", (d, w) -> { if (countDownTimer != null) countDownTimer.cancel(); finish(); })
                    .setNegativeButton("Stay", null)
                    .show();
        } else {
            super.onBackPressed();
        }
    }
}