package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;

import org.json.JSONArray;
import org.json.JSONObject;

public class QuizResultActivity extends AppCompatActivity {

    public static final String EXTRA_QUIZ_TITLE   = "QUIZ_TITLE";
    public static final String EXTRA_SCORE        = "SCORE";
    public static final String EXTRA_CORRECT      = "CORRECT";
    public static final String EXTRA_WRONG        = "WRONG";
    public static final String EXTRA_TOTAL_MCQ       = "TOTAL_MCQ";
    public static final String EXTRA_QUESTION_TYPE   = "QUESTION_TYPE";
    public static final String EXTRA_ANSWERS_JSON = "ANSWERS_JSON";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ── Root layout (no XML needed) ───────────────────────────────────
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F5F5F5"));
        setContentView(root);

        // ── Get data ──────────────────────────────────────────────────────
        String title       = getIntent().getStringExtra(EXTRA_QUIZ_TITLE);
        int    score       = getIntent().getIntExtra(EXTRA_SCORE, 0);
        int    correct     = getIntent().getIntExtra(EXTRA_CORRECT, 0);
        int    wrong       = getIntent().getIntExtra(EXTRA_WRONG, 0);
        int    totalMcq    = getIntent().getIntExtra(EXTRA_TOTAL_MCQ, 0);
        String answersJson = getIntent().getStringExtra(EXTRA_ANSWERS_JSON);
        String questionType = getIntent().getStringExtra(EXTRA_QUESTION_TYPE);
        if (questionType == null) questionType = "";
        boolean hasMcq   = totalMcq > 0;
        boolean hasShort = questionType.toLowerCase().contains("short");

        // ── Header ────────────────────────────────────────────────────────
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setBackgroundColor(Color.parseColor("#D2192B"));
        header.setPadding(dp(20), dp(24), dp(20), dp(24));
        header.setGravity(Gravity.CENTER);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title != null ? title : "Quiz");
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTextSize(20);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setGravity(Gravity.CENTER);
        header.addView(tvTitle);

        TextView tvDone = new TextView(this);

        // Score-based result message
        String resultMsg;
        int    headerColor;
        if (totalMcq == 0) {
            resultMsg   = "📋 Quiz Submitted!";
            headerColor = Color.parseColor("#D2192B");
        } else {
            int pct = (score * 100) / totalMcq;
            if (pct >= 80) {
                resultMsg   = "🎉 Excellent! Outstanding performance!";
                headerColor = Color.parseColor("#1B5E20"); // dark green
            } else if (pct >= 60) {
                resultMsg   = "👍 Good Job! Keep it up!";
                headerColor = Color.parseColor("#2E7D32"); // green
            } else if (pct >= 40) {
                resultMsg   = "📚 Average. Try to improve!";
                headerColor = Color.parseColor("#E65100"); // orange
            } else {
                resultMsg   = "😔 Poor result. Work harder next time!";
                headerColor = Color.parseColor("#B71C1C"); // dark red
            }
        }

        // Update header background to match result
        header.setBackgroundColor(headerColor);

        tvDone.setText(resultMsg);
        tvDone.setTextColor(Color.WHITE);
        tvDone.setTextSize(14);
        tvDone.setGravity(Gravity.CENTER);
        tvDone.setPadding(0, dp(4), 0, dp(16));
        header.addView(tvDone);

        // ── Score row: Correct | Wrong | Score ───────────────────────────
        LinearLayout scoreRow = new LinearLayout(this);
        scoreRow.setOrientation(LinearLayout.HORIZONTAL);
        scoreRow.setGravity(Gravity.CENTER);
        scoreRow.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // MCQ score row — sirf tab show karo jab MCQ questions hon
        if (hasMcq) {
            scoreRow.addView(scoreBadge("✅ Correct", String.valueOf(correct), "#E8F5E9", "#2E7D32"));
            scoreRow.addView(scoreBadge("❌ Wrong",   String.valueOf(wrong),   "#FFEBEE", "#C62828"));
            scoreRow.addView(scoreBadge("⭐ Score",   score + "/" + totalMcq,  "#FFF8E1", "#F57F17"));
            header.addView(scoreRow);
        }

        // Short answer note — sirf tab show karo jab short questions hon
        if (hasShort) {
            TextView tvShortNote = new TextView(this);
            tvShortNote.setText("Short answers will be reviewed by your teacher.");
            tvShortNote.setTextColor(Color.parseColor("#FFEEEE"));
            tvShortNote.setTextSize(12);
            tvShortNote.setGravity(Gravity.CENTER);
            tvShortNote.setPadding(0, dp(10), 0, 0);
            header.addView(tvShortNote);
        }

        root.addView(header);

        // ── Section label ─────────────────────────────────────────────────
        TextView tvReview = new TextView(this);
        tvReview.setText("Question Review");
        tvReview.setTextSize(16);
        tvReview.setTypeface(null, Typeface.BOLD);
        tvReview.setTextColor(Color.parseColor("#1E2A3B"));
        tvReview.setPadding(dp(16), dp(14), dp(16), dp(4));
        root.addView(tvReview);

        // ── Scrollable question review ────────────────────────────────────
        ScrollView sv = new ScrollView(this);
        LinearLayout.LayoutParams svParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        sv.setLayoutParams(svParams);

        LinearLayout listLayout = new LinearLayout(this);
        listLayout.setOrientation(LinearLayout.VERTICAL);
        listLayout.setPadding(dp(10), dp(4), dp(10), dp(16));
        sv.addView(listLayout);

        // ── Parse JSON and build cards ────────────────────────────────────
        try {
            JSONArray arr = new JSONArray(answersJson != null ? answersJson : "[]");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj    = arr.getJSONObject(i);
                String qText      = obj.optString("q", "");
                String type       = obj.optString("type", "mcq");
                String studentAns = obj.optString("ans", "");
                String correctAns = obj.optString("correct", "").toUpperCase();
                String optA       = obj.optString("optA", "");
                String optB       = obj.optString("optB", "");
                String optC       = obj.optString("optC", "");
                String optD       = obj.optString("optD", "");
                int    marks      = obj.optInt("marks", 1);
                boolean isMcq     = type.contains("mcq") || type.contains("multiple");

                boolean isCorrect = isMcq && !studentAns.isEmpty()
                        && studentAns.toUpperCase().equals(correctAns);
                boolean unanswered = studentAns.isEmpty();

                // Card
                CardView card = new CardView(this);
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                cp.setMargins(dp(4), dp(6), dp(4), dp(6));
                card.setLayoutParams(cp);
                card.setRadius(dp(10));
                card.setCardElevation(dp(2));
                // Card background: green=correct, red=wrong, grey=short/unanswered
                if (!isMcq)        card.setCardBackgroundColor(Color.parseColor("#F3F3F3"));
                else if (unanswered) card.setCardBackgroundColor(Color.parseColor("#FFF8E1"));
                else if (isCorrect)  card.setCardBackgroundColor(Color.parseColor("#E8F5E9"));
                else                 card.setCardBackgroundColor(Color.parseColor("#FFEBEE"));

                LinearLayout inner = new LinearLayout(this);
                inner.setOrientation(LinearLayout.VERTICAL);
                inner.setPadding(dp(14), dp(12), dp(14), dp(12));

                // Q number + text
                TextView tvQ = new TextView(this);
                tvQ.setText("Q" + (i + 1) + ". " + qText);
                tvQ.setTextSize(14);
                tvQ.setTypeface(null, Typeface.BOLD);
                tvQ.setTextColor(Color.parseColor("#1E2A3B"));
                inner.addView(tvQ);

                if (isMcq) {
                    // Show all options with correct/wrong highlight
                    String[] labels  = {"A", "B", "C", "D"};
                    String[] options = {optA, optB, optC, optD};
                    for (int j = 0; j < 4; j++) {
                        if (options[j].isEmpty()) continue;
                        String lbl = labels[j];

                        TextView tvOpt = new TextView(this);
                        boolean isThisCorrect = lbl.equals(correctAns);
                        boolean isChosen      = lbl.equals(studentAns.toUpperCase());

                        String prefix = "  ";
                        if (isChosen && isThisCorrect)       prefix = "✅ ";
                        else if (isThisCorrect)              prefix = "✅ ";
                        else if (isChosen)                   prefix = "❌ ";

                        tvOpt.setText(prefix + lbl + ". " + options[j]);
                        tvOpt.setTextSize(13);
                        tvOpt.setPadding(dp(4), dp(3), dp(4), dp(3));

                        if (isThisCorrect)              tvOpt.setTextColor(Color.parseColor("#2E7D32"));
                        else if (isChosen)              tvOpt.setTextColor(Color.parseColor("#C62828"));
                        else                            tvOpt.setTextColor(Color.parseColor("#555555"));

                        if (isThisCorrect) tvOpt.setTypeface(null, Typeface.BOLD);
                        inner.addView(tvOpt);
                    }

                    // Status line
                    TextView tvStatus = new TextView(this);
                    if (unanswered)  tvStatus.setText("⚠️ Not attempted  |  Marks: 0/" + marks);
                    else if (isCorrect) tvStatus.setText("✅ Correct  |  Marks: " + marks + "/" + marks);
                    else             tvStatus.setText("❌ Wrong  |  Marks: 0/" + marks);
                    tvStatus.setTextSize(12);
                    tvStatus.setTypeface(null, Typeface.BOLD);
                    tvStatus.setPadding(0, dp(6), 0, 0);
                    tvStatus.setTextColor(unanswered ? Color.parseColor("#F57F17")
                            : isCorrect ? Color.parseColor("#2E7D32") : Color.parseColor("#C62828"));
                    inner.addView(tvStatus);

                } else {
                    // Short answer
                    TextView tvAns = new TextView(this);
                    tvAns.setText("Your answer: " + (studentAns.isEmpty() ? "(not answered)" : studentAns));
                    tvAns.setTextSize(13);
                    tvAns.setTextColor(Color.parseColor("#555555"));
                    tvAns.setPadding(0, dp(6), 0, 0);
                    inner.addView(tvAns);

                    TextView tvPending = new TextView(this);
                    tvPending.setText("📋 Teacher will review this answer");
                    tvPending.setTextSize(12);
                    tvPending.setTextColor(Color.parseColor("#1565C0"));
                    tvPending.setPadding(0, dp(4), 0, 0);
                    inner.addView(tvPending);
                }

                card.addView(inner);
                listLayout.addView(card);
            }
        } catch (Exception e) {
            TextView tvErr = new TextView(this);
            tvErr.setText("Could not load review.");
            tvErr.setPadding(dp(16), dp(16), dp(16), dp(16));
            listLayout.addView(tvErr);
        }

        root.addView(sv);

        // ── Done button ───────────────────────────────────────────────────
        Button btnDone = new Button(this);
        btnDone.setText("Done");
        btnDone.setAllCaps(false);
        btnDone.setTextSize(16);
        btnDone.setTextColor(Color.WHITE);
        btnDone.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        btnParams.setMargins(dp(16), dp(8), dp(16), dp(16));
        btnDone.setLayoutParams(btnParams);
        btnDone.setBackgroundColor(headerColor);
        btnDone.setOnClickListener(v -> finish());
        root.addView(btnDone);
    }

    // ── Score badge helper ────────────────────────────────────────────────
    private LinearLayout scoreBadge(String label, String value, String bgColor, String textColor) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.parseColor(bgColor));

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        box.setLayoutParams(p);
        box.setPadding(dp(8), dp(10), dp(8), dp(10));

        // Rounded corners via code
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(Color.parseColor(bgColor));
        bg.setCornerRadius(dp(10));
        box.setBackground(bg);

        TextView tvVal = new TextView(this);
        tvVal.setText(value);
        tvVal.setTextSize(22);
        tvVal.setTypeface(null, Typeface.BOLD);
        tvVal.setTextColor(Color.parseColor(textColor));
        tvVal.setGravity(Gravity.CENTER);
        box.addView(tvVal);

        TextView tvLbl = new TextView(this);
        tvLbl.setText(label);
        tvLbl.setTextSize(11);
        tvLbl.setTextColor(Color.parseColor(textColor));
        tvLbl.setGravity(Gravity.CENTER);
        box.addView(tvLbl);

        return box;
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}