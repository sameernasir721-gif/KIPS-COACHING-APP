package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ManageParentRequestsActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private LinearLayout containerRequests;
    private TextView tvLoading;
    private TextView tvPendingCount, tvApprovedCount, tvRejectedCount, tvTotalCount;
    private TextView tvSectionLabel;

    private String currentFilter = "Pending";

    private final List<ParentItem> allParentsList = new ArrayList<>();
    private int totalCount = 0, pendingCount = 0, approvedCount = 0, rejectedCount = 0;

    // Real-time listener (list refreshes automatically on any change)
    private ValueEventListener usersListener;

    // Pull down to refresh
    private SwipeRefreshLayout swipeRefresh;

    // ── Simple model ──────────────────────────────────────────────────────────
    private static class ParentItem {
        String uid, name, email, regId, phone, status, reason;
        boolean emailVerified;
        long sortNum = Long.MAX_VALUE; // no number -> goes to the end
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_parents_requests);

        setupBackButton();

        mDatabase          = FirebaseDatabase.getInstance().getReference();
        containerRequests  = findViewById(R.id.containerParentRequests);
        tvLoading          = findViewById(R.id.tvParentLoading);
        tvPendingCount     = findViewById(R.id.tvParentPendingCount);
        tvApprovedCount    = findViewById(R.id.tvParentApprovedCount);
        tvRejectedCount    = findViewById(R.id.tvParentRejectedCount);
        tvTotalCount       = findViewById(R.id.tvParentTotalCount);
        tvSectionLabel     = findViewById(R.id.tvParentSectionLabel);

        // Click on the whole box (number + label), not just the number
        View boxTotal    = findViewById(R.id.boxTotal);
        View boxPending  = findViewById(R.id.boxPending);
        View boxApproved = findViewById(R.id.boxApproved);
        View boxRejected = findViewById(R.id.boxRejected);

        if (boxTotal    != null) boxTotal.setOnClickListener(v    -> switchFilter("All"));
        if (boxPending  != null) boxPending.setOnClickListener(v  -> switchFilter("Pending"));
        if (boxApproved != null) boxApproved.setOnClickListener(v -> switchFilter("Approved"));
        if (boxRejected != null) boxRejected.setOnClickListener(v -> switchFilter("Rejected"));

        updateSectionLabel();
        setupPullToRefresh();
        fetchData();
    }

    // ── Back button (already in XML, only logic here) ─────────────────────────
    private void setupBackButton() {
        // Replace with your real id, e.g. R.id.btnBack, and delete the loop below
        // View btnBack = findViewById(R.id.btnBack);

        // Tries common ids automatically, so it works even if the name differs
        String[] ids = {"btnBack", "backButton", "btnBackParent", "ivBack",
                "imgBack", "back_button", "btn_back", "ibBack"};
        View btnBack = null;
        for (String name : ids) {
            int resId = getResources().getIdentifier(name, "id", getPackageName());
            if (resId != 0) {
                btnBack = findViewById(resId);
                if (btnBack != null) break;
            }
        }
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());
    }

    // Wraps the ScrollView in a SwipeRefreshLayout from code (no XML change needed)
    private void setupPullToRefresh() {
        View scroll = containerRequests;
        while (scroll != null && !(scroll instanceof ScrollView) && !(scroll instanceof NestedScrollView)) {
            ViewParent p = scroll.getParent();
            scroll = (p instanceof View) ? (View) p : null;
        }
        if (scroll == null || !(scroll.getParent() instanceof ViewGroup)) return;

        ViewGroup parent = (ViewGroup) scroll.getParent();
        int index = parent.indexOfChild(scroll);
        ViewGroup.LayoutParams lp = scroll.getLayoutParams();
        int oldId = scroll.getId();

        parent.removeView(scroll);
        scroll.setId(View.generateViewId());

        swipeRefresh = new SwipeRefreshLayout(this);
        swipeRefresh.setId(oldId);
        swipeRefresh.setColorSchemeColors(0xFF1565C0);
        swipeRefresh.addView(scroll, new ViewGroup.LayoutParams(-1, -1));
        parent.addView(swipeRefresh, index, lp);

        swipeRefresh.setOnRefreshListener(() -> {
            // Remove the old listener and load fresh data
            if (usersListener != null) {
                mDatabase.child("Users").removeEventListener(usersListener);
                usersListener = null;
            }
            fetchData();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (usersListener != null) {
            mDatabase.child("Users").removeEventListener(usersListener);
        }
    }

    private void switchFilter(String filter) {
        currentFilter = filter;
        updateSectionLabel();
        updateUI(); // uses cached data, instant
    }

    private void updateSectionLabel() {
        if (tvSectionLabel == null) return;
        String label;
        switch (currentFilter) {
            case "Approved": label = "✅ Approved Requests"; break;
            case "Rejected": label = "❌ Rejected Requests"; break;
            case "All":      label = "📋 All Requests"; break;
            default:         label = "⏳ Pending Requests";
        }
        tvSectionLabel.setText(label);
    }

    private void fetchData() {
        if (tvLoading != null) tvLoading.setVisibility(View.VISIBLE);

        // Don't attach the listener twice
        if (usersListener != null) return;

        usersListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                allParentsList.clear();
                totalCount = 0; pendingCount = 0; approvedCount = 0; rejectedCount = 0;

                for (DataSnapshot userSnap : snapshot.getChildren()) {
                    String role = userSnap.child("role").getValue(String.class);
                    if (role == null || !"Parent".equalsIgnoreCase(role)) continue;

                    // Hide test accounts
                    if (isTestAccount(userSnap)) continue;

                    ParentItem it = new ParentItem();
                    it.uid    = userSnap.getKey();
                    it.name   = userSnap.child("name").getValue(String.class);
                    it.email  = userSnap.child("email").getValue(String.class);
                    it.reason = userSnap.child("rejectionReason").getValue(String.class);
                    it.status = userSnap.child("status").getValue(String.class);
                    if (it.status == null) it.status = "Pending";

                    Boolean ev = userSnap.child("emailVerified").getValue(Boolean.class);
                    it.emailVerified = ev != null && ev;

                    String regId = userSnap.child("registrationId").getValue(String.class);
                    if (regId == null) regId = userSnap.child("studentId").getValue(String.class);
                    if (regId == null) regId = userSnap.child("childId").getValue(String.class);
                    it.regId = regId;
                    it.sortNum = extractNumber(regId);

                    Object phoneObj = userSnap.child("phone").getValue();
                    if (phoneObj == null) phoneObj = userSnap.child("phoneNumber").getValue();
                    it.phone = phoneObj != null ? String.valueOf(phoneObj).trim() : "-";

                    totalCount++;
                    if (it.status.equalsIgnoreCase("Pending"))       pendingCount++;
                    else if (it.status.equalsIgnoreCase("Approved")) approvedCount++;
                    else if (it.status.equalsIgnoreCase("Rejected")) rejectedCount++;

                    allParentsList.add(it);
                }

                // Approved first, then Pending, then Rejected.
                // Inside each group: numeric order of Reg ID (latest / highest on top).
                Collections.sort(allParentsList, (a, b) -> {
                    int ra = statusRank(a.status);
                    int rb = statusRank(b.status);
                    if (ra != rb) return Integer.compare(ra, rb);

                    boolean hasA = a.sortNum != Long.MAX_VALUE;
                    boolean hasB = b.sortNum != Long.MAX_VALUE;
                    if (hasA != hasB) return hasA ? -1 : 1; // no number -> last
                    if (hasA) {
                        int c = Long.compare(b.sortNum, a.sortNum); // 10 above 2
                        if (c != 0) return c;
                    }
                    String na = a.name != null ? a.name : "";
                    String nb = b.name != null ? b.name : "";
                    return na.compareToIgnoreCase(nb);
                });

                updateUI();
                if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (tvLoading != null) tvLoading.setVisibility(View.GONE);
                if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
                Toast.makeText(ManageParentRequestsActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };

        mDatabase.child("Users").addValueEventListener(usersListener);
    }

    private int statusRank(String status) {
        if (status == null) return 1;                       // Pending
        if (status.equalsIgnoreCase("Approved")) return 0;
        if (status.equalsIgnoreCase("Pending"))  return 1;
        return 2;                                           // Rejected
    }

    // "KIPS-0012" -> 12,  "45" -> 45,  null / no digits -> Long.MAX_VALUE
    private long extractNumber(String s) {
        if (s == null) return Long.MAX_VALUE;
        Matcher m = Pattern.compile("\\d+").matcher(s);
        if (m.find()) {
            String digits = m.group();
            if (digits.length() > 18) digits = digits.substring(0, 18);
            try {
                return Long.parseLong(digits);
            } catch (NumberFormatException ignored) { }
        }
        return Long.MAX_VALUE;
    }

    private boolean isTestAccount(DataSnapshot userSnap) {
        String name  = userSnap.child("name").getValue(String.class);
        String email = userSnap.child("email").getValue(String.class);
        return (name != null && name.toLowerCase().contains("test"))
                || (email != null && email.toLowerCase().contains("test"));
    }

    private void updateUI() {
        containerRequests.removeAllViews();
        if (tvLoading != null) tvLoading.setVisibility(View.GONE);

        updateSummary(pendingCount, approvedCount, rejectedCount, totalCount);

        boolean hasData = false;
        for (ParentItem it : allParentsList) {
            boolean matches = currentFilter.equalsIgnoreCase("All")
                    || currentFilter.equalsIgnoreCase(it.status);
            if (!matches) continue;

            hasData = true;
            createRequestCard(it.uid, it.name, it.email, it.regId, it.phone,
                    it.status, it.reason, it.emailVerified);
        }
        if (!hasData) showEmptyState();
    }

    private void updateSummary(int pending, int approved, int rejected, int total) {
        if (tvPendingCount  != null) tvPendingCount.setText(String.valueOf(pending));
        if (tvApprovedCount != null) tvApprovedCount.setText(String.valueOf(approved));
        if (tvRejectedCount != null) tvRejectedCount.setText(String.valueOf(rejected));
        if (tvTotalCount    != null) tvTotalCount.setText(String.valueOf(total));
    }

    // ── Request Card ──────────────────────────────────────────────────────────
    private void createRequestCard(String uid, String name, String email,
                                   String regId, String phone,
                                   String status, String rejectionReason,
                                   boolean emailVerified) {

        int cardBg;
        switch (status.toLowerCase()) {
            case "approved": cardBg = 0xFFF1FFF1; break;
            case "rejected": cardBg = 0xFFFFF1F1; break;
            default:         cardBg = 0xFFFFFFFF; break;
        }

        androidx.cardview.widget.CardView card = new androidx.cardview.widget.CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(cp);
        card.setRadius(dp(12));
        card.setCardElevation(dp(4));
        card.setCardBackgroundColor(cardBg);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView tvInfo = new TextView(this);
        tvInfo.setText(
                "👤 Name:   " + (name  != null ? name  : "-")
                        + "\n🏷️ Role:   Parent"
                        + "\n📧 Email:  " + (email != null ? email : "-")
                        + "\n🆔 Reg ID: " + (regId != null ? regId : "N/A")
                        + "\n📞 Phone:  " + phone);
        tvInfo.setTextSize(14f);
        tvInfo.setTextColor(0xFF333333);
        tvInfo.setLineSpacing(dp(3), 1f);
        tvInfo.setPadding(0, 0, 0, dp(10));
        inner.addView(tvInfo);

        // Email verification badge
        TextView tvEmailStatus = new TextView(this);
        tvEmailStatus.setText(emailVerified ? "✅ Email Verified" : "⚠️ Email Not Verified");
        tvEmailStatus.setTextSize(13f);
        tvEmailStatus.setTypeface(null, Typeface.BOLD);
        tvEmailStatus.setTextColor(emailVerified ? 0xFF2E7D32 : 0xFFB71C1C);
        tvEmailStatus.setPadding(dp(10), dp(6), dp(10), dp(6));
        tvEmailStatus.setBackgroundColor(emailVerified ? 0xFFE8F5E9 : 0xFFFFEBEE);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-2, -2);
        ep.bottomMargin = dp(10);
        tvEmailStatus.setLayoutParams(ep);
        inner.addView(tvEmailStatus);

        // Status badge
        TextView tvStatus = new TextView(this);
        tvStatus.setText(getStatusEmoji(status) + " " + status);
        tvStatus.setTextSize(13f);
        tvStatus.setTypeface(null, Typeface.BOLD);
        tvStatus.setTextColor(getStatusColor(status));
        tvStatus.setPadding(dp(10), dp(6), dp(10), dp(6));
        tvStatus.setBackgroundColor(getStatusBgColor(status));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.bottomMargin = dp(10);
        tvStatus.setLayoutParams(sp);
        inner.addView(tvStatus);

        // Rejected: tap to see the reason
        if ("Rejected".equalsIgnoreCase(status)) {
            TextView tvBanner = new TextView(this);
            tvBanner.setText("❌ Rejected — Tap to see reason");
            tvBanner.setTextSize(12f);
            tvBanner.setTextColor(0xFFB71C1C);
            tvBanner.setTypeface(null, Typeface.BOLD);
            tvBanner.setPadding(dp(10), dp(8), dp(10), dp(8));
            tvBanner.setBackgroundColor(0xFFFFEBEE);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
            bp.bottomMargin = dp(6);
            tvBanner.setLayoutParams(bp);
            inner.addView(tvBanner);

            tvBanner.setOnClickListener(v -> fetchReasonAndShow(uid, name));
            card.setOnClickListener(v    -> fetchReasonAndShow(uid, name));
        }

        // Pending: Approve + Reject buttons
        if ("Pending".equalsIgnoreCase(status)) {
            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(-1, -2);
            brp.topMargin = dp(4);
            btnRow.setLayoutParams(brp);

            Button btnApprove = new Button(this);
            btnApprove.setText("✅ Approve");
            btnApprove.setBackgroundColor(emailVerified ? 0xFF388E3C : 0xFF9E9E9E); // grey if not verified
            btnApprove.setTextColor(0xFFFFFFFF);
            LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, -2, 1f);
            p1.setMarginEnd(dp(8));
            btnApprove.setLayoutParams(p1);
            btnApprove.setOnClickListener(v -> {
                if (!emailVerified) {
                    new AlertDialog.Builder(this)
                            .setTitle("Email Not Verified")
                            .setMessage((name != null ? name : "This parent")
                                    + " has not verified their email (" + email + ") yet. "
                                    + "The request cannot be approved until the email is verified. "
                                    + "Ask the parent to verify their email, then pull down to refresh the list.")
                            .setPositiveButton("OK", null)
                            .show();
                } else {
                    handleApproval(uid, name, email);
                }
            });

            Button btnReject = new Button(this);
            btnReject.setText("❌ Reject");
            btnReject.setBackgroundColor(0xFFB71C1C);
            btnReject.setTextColor(0xFFFFFFFF);
            btnReject.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
            btnReject.setOnClickListener(v -> handleRejection(uid, name, email));

            btnRow.addView(btnApprove);
            btnRow.addView(btnReject);
            inner.addView(btnRow);
        }

        card.addView(inner);
        containerRequests.addView(card);
    }

    // ── Rejection reason dialog ───────────────────────────────────────────────
    private void fetchReasonAndShow(String uid, String name) {
        mDatabase.child("Users").child(uid).child("rejectionReason")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        showRejectionReasonDialog(name, snapshot.getValue(String.class));
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        showRejectionReasonDialog(name, null);
                    }
                });
    }

    private void showRejectionReasonDialog(String name, String reason) {
        String displayReason = (reason != null && !reason.trim().isEmpty())
                ? reason : "No reason provided.";

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(20), dp(24), dp(16));

        TextView tvTitle = new TextView(this);
        tvTitle.setText("❌  Request Rejected");
        tvTitle.setTextSize(17f);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setTextColor(0xFFB71C1C);
        tvTitle.setPadding(0, 0, 0, dp(8));
        layout.addView(tvTitle);

        TextView tvName = new TextView(this);
        tvName.setText("Parent: " + (name != null ? name : "-"));
        tvName.setTextSize(14f);
        tvName.setTextColor(0xFF555555);
        tvName.setPadding(0, 0, 0, dp(12));
        layout.addView(tvName);

        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        divider.setBackgroundColor(0xFFEEEEEE);
        layout.addView(divider);

        TextView tvLabel = new TextView(this);
        tvLabel.setText("Reason for Rejection:");
        tvLabel.setTextSize(13f);
        tvLabel.setTextColor(0xFF888888);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-1, -2);
        llp.topMargin = dp(12); llp.bottomMargin = dp(6);
        tvLabel.setLayoutParams(llp);
        layout.addView(tvLabel);

        TextView tvReason = new TextView(this);
        tvReason.setText(displayReason);
        tvReason.setTextSize(15f);
        tvReason.setTextColor(0xFFB71C1C);
        tvReason.setTypeface(null, Typeface.BOLD);
        tvReason.setPadding(dp(14), dp(12), dp(14), dp(12));
        tvReason.setBackgroundColor(0xFFFFEBEE);
        tvReason.setLineSpacing(dp(3), 1f);
        layout.addView(tvReason);

        new AlertDialog.Builder(this)
                .setView(layout)
                .setPositiveButton("OK", null)
                .show();
    }

    // ── Approve (the listener refreshes the list automatically) ───────────────
    private void handleApproval(String uid, String name, String email) {
        mDatabase.child("Users").child(uid).child("status").setValue("Approved")
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "✅ " + name + " Approved!", Toast.LENGTH_SHORT).show();
                    sendEmail(email,
                            "Account Approved - KIPS Coaching Kharian",
                            "Dear " + name + ",\n\nYour Parent Account has been APPROVED. You can now login.\n\nRegards,\nAdmin Team");
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    // ── Reject ────────────────────────────────────────────────────────────────
    private void handleRejection(String uid, String name, String email) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(24), dp(16), dp(24), dp(8));

        EditText input = new EditText(this);
        input.setHint("Enter reason for rejection...");
        input.setMinLines(2);
        layout.addView(input);

        new AlertDialog.Builder(this)
                .setTitle("Reject Request")
                .setView(layout)
                .setPositiveButton("Reject & Notify", (dialog, which) -> {
                    String reason = input.getText().toString().trim();
                    if (reason.isEmpty()) reason = "No reason provided.";
                    final String finalReason = reason;

                    Map<String, Object> rejectMap = new HashMap<>();
                    rejectMap.put("status", "Rejected");
                    rejectMap.put("rejectionReason", finalReason);

                    mDatabase.child("Users").child(uid).updateChildren(rejectMap)
                            .addOnSuccessListener(unused -> {
                                Toast.makeText(this, "❌ " + name + " Rejected.", Toast.LENGTH_SHORT).show();
                                sendEmail(email,
                                        "Account Request Rejected - KIPS Coaching Kharian",
                                        "Dear " + name + ",\n\nYour request has been rejected.\nReason: "
                                                + finalReason + "\n\nPlease contact the office for details.");
                            })
                            .addOnFailureListener(e ->
                                    Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Email ─────────────────────────────────────────────────────────────────
    private void sendEmail(String to, String subject, String body) {
        if (to == null || to.isEmpty()) return;
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL,   new String[]{to});
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT,    body);
        try {
            startActivity(Intent.createChooser(intent, "Choose Email App:"));
        } catch (Exception e) {
            Toast.makeText(this, "No email app found.", Toast.LENGTH_SHORT).show();
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private void showEmptyState() {
        TextView tv = new TextView(this);
        tv.setText("No " + currentFilter.toLowerCase() + " parent requests.");
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(60), 0, 0);
        containerRequests.addView(tv);
    }

    private String getStatusEmoji(String status) {
        if (status == null) return "⏳";
        switch (status.toLowerCase()) {
            case "approved": return "✅";
            case "rejected": return "❌";
            default:         return "⏳";
        }
    }

    private int getStatusColor(String status) {
        if (status == null) return 0xFFE65100;
        switch (status.toLowerCase()) {
            case "approved": return 0xFF2E7D32;
            case "rejected": return 0xFFB71C1C;
            default:         return 0xFFE65100;
        }
    }

    private int getStatusBgColor(String status) {
        if (status == null) return 0xFFFFF3E0;
        switch (status.toLowerCase()) {
            case "approved": return 0xFFE8F5E9;
            case "rejected": return 0xFFFFEBEE;
            default:         return 0xFFFFF3E0;
        }
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}