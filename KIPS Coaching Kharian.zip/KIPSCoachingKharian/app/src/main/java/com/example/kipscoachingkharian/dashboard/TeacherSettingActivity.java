package com.example.kipscoachingkharian.dashboard;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class TeacherSettingActivity extends AppCompatActivity {

    private static final String PREFS_NAME    = "kips_prefs";
    private static final String KEY_FONT_SIZE = "teacher_font_size";
    private static final String KEY_THEME     = "teacher_theme";     // 0 = White, 1 = Black

    private ImageView btnBack;
    private LinearLayout itemFontSize, itemTheme, itemPrivacy;
    private TextView tvFontSizeValue, tvThemeValue;

    private SharedPreferences prefs;
    private FirebaseAuth mAuth;
    private DatabaseReference userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_setting);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mAuth = FirebaseAuth.getInstance();

        if (mAuth.getCurrentUser() != null) {
            userRef = FirebaseDatabase.getInstance()
                    .getReference("Users")
                    .child(mAuth.getCurrentUser().getUid());
        }

        initViews();
        loadCurrentSettings();
        setListeners();
    }

    private void initViews() {
        btnBack            = findViewById(R.id.btnBack);
        itemFontSize       = findViewById(R.id.itemFontSize);
        itemTheme          = findViewById(R.id.itemTheme);
        itemPrivacy        = findViewById(R.id.itemPrivacy);
        tvFontSizeValue    = findViewById(R.id.tvFontSizeValue);
        tvThemeValue       = findViewById(R.id.tvThemeValue);
    }

    private void loadCurrentSettings() {
        int fontSize = prefs.getInt(KEY_FONT_SIZE, 1);
        tvFontSizeValue.setText(fontSizeLabel(fontSize));

        int theme = prefs.getInt(KEY_THEME, 0); // 0 = White, 1 = Black
        tvThemeValue.setText(theme == 1 ? "Black" : "White");
    }

    private String fontSizeLabel(int size) {
        switch (size) {
            case 0: return "Small";
            case 2: return "Large";
            default: return "Medium";
        }
    }

    private void setListeners() {
        btnBack.setOnClickListener(v -> finish());

        itemFontSize.setOnClickListener(v -> showFontSizeDialog());
        itemTheme.setOnClickListener(v -> showThemeDialog());
        itemPrivacy.setOnClickListener(v -> showPrivacyDialog());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // FONT SIZE DIALOG
    // ─────────────────────────────────────────────────────────────────────────
    private void showFontSizeDialog() {
        int savedSize = prefs.getInt(KEY_FONT_SIZE, 1); // 0=Small, 1=Medium, 2=Large
        String[] options = {"Small", "Medium", "Large"};

        new AlertDialog.Builder(this)
                .setTitle("Font Size")
                .setSingleChoiceItems(options, savedSize, null)
                .setPositiveButton("Apply", (dialog, which) -> {
                    android.widget.ListView lv = ((AlertDialog) dialog).getListView();
                    int selected = lv.getCheckedItemPosition();
                    prefs.edit().putInt(KEY_FONT_SIZE, selected).apply();
                    tvFontSizeValue.setText(fontSizeLabel(selected));
                    Toast.makeText(this, "Font size updated!", Toast.LENGTH_SHORT).show();
                    recreate(); // apply new font scale
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // THEME DIALOG (White / Black)
    // ─────────────────────────────────────────────────────────────────────────
    private void showThemeDialog() {
        int savedTheme = prefs.getInt(KEY_THEME, 0); // 0 = White, 1 = Black
        String[] options = {"White", "Black"};

        new AlertDialog.Builder(this)
                .setTitle("Theme")
                .setSingleChoiceItems(options, savedTheme, null)
                .setPositiveButton("Apply", (dialog, which) -> {
                    android.widget.ListView lv = ((AlertDialog) dialog).getListView();
                    int selected = lv.getCheckedItemPosition();
                    prefs.edit().putInt(KEY_THEME, selected).apply();
                    tvThemeValue.setText(selected == 1 ? "Black" : "White");

                    AppCompatDelegate.setDefaultNightMode(
                            selected == 1 ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
                    );

                    Toast.makeText(this, "Theme set to " + (selected == 1 ? "Black" : "White"), Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Font size apply karo — BaseContext mein call karo
    @Override
    protected void attachBaseContext(android.content.Context newBase) {
        SharedPreferences p = newBase.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Font scale
        int size = p.getInt(KEY_FONT_SIZE, 1);
        float scale;
        switch (size) {
            case 0: scale = 0.85f; break;
            case 2: scale = 1.15f; break;
            default: scale = 1.0f;
        }

        android.content.res.Configuration config = new android.content.res.Configuration();
        config.fontScale = scale;

        android.content.Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVACY DIALOG
    // ─────────────────────────────────────────────────────────────────────────
    private void showPrivacyDialog() {
        String privacyText =
                "Privacy Policy\n\n" +
                        "• Your personal information (name, email, phone number) is used only for account management within KIPS Coaching Kharian.\n\n" +
                        "• Student data such as marks and submissions is only visible to the relevant teacher and the student.\n\n" +
                        "• Your password is stored securely and is never shared with other users.\n\n" +
                        "• We do not share your data with any third party.\n\n" +
                        "• You can update or remove your information at any time from 'My Profile'.";

        new AlertDialog.Builder(this)
                .setTitle("Privacy")
                .setMessage(privacyText)
                .setPositiveButton("OK", null)
                .show();
    }
}