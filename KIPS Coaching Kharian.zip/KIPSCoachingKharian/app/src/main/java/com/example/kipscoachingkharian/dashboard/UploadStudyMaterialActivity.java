package com.example.kipscoachingkharian.dashboard;

import android.app.Activity;
import androidx.annotation.NonNull;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class UploadStudyMaterialActivity extends AppCompatActivity {

    // Cloudinary config
    private static final String CLOUDINARY_CLOUD_NAME = "dzxkjbtfb";
    private static final String CLOUDINARY_UPLOAD_PRESET = "kips_unsigned";

    // Intent keys
    public static final String EXTRA_EDIT_MODE    = "edit_mode";
    public static final String EXTRA_MATERIAL_KEY = "material_key";
    public static final String EXTRA_TITLE        = "title";
    public static final String EXTRA_SUBJECT      = "subject";
    public static final String EXTRA_GRADE        = "grade";
    public static final String EXTRA_DESCRIPTION  = "description";
    public static final String EXTRA_FILE_URL     = "file_url";
    public static final String EXTRA_FILE_TYPE    = "file_type";

    // Views
    private CardView            cardFilePicker, cardSelectedFile;
    private TextView            tvFilePickerLabel, tvSelectedFileName, tvSelectedFileSize;
    private ImageView           ivSelectedFileIcon, btnRemoveFile, ivBack;
    private TextInputEditText   etTitle, etDescription;
    private AutoCompleteTextView spinnerSubject, spinnerGrade;
    private Button              btnSave, btnUploadAndShare;

    // Firebase
    private FirebaseAuth      mAuth;
    private DatabaseReference mDatabase;

    // State
    private Uri    selectedFileUri  = null;
    private String selectedFileType = "";
    private String selectedFileName = "";
    private String selectedFileSize = "";
    private boolean isEditMode      = false;
    private String  editMaterialKey = "";
    private String  existingFileUrl = "";

    private final String[] SUBJECTS = {
            "Physics", "Chemistry", "Mathematics",
            "Biology", "English", "Computer", "Urdu", "Islamiyat", "Pak Study"
    };
    private final String[] GRADES = {
            "Class 9A", "Class 9B", "Class 10A", "Class 10B",
            "Class 11A", "Class 11B", "Class 12A", "Class 12B"
    };

    private final ActivityResultLauncher<Intent> filePickerLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == Activity.RESULT_OK
                                && result.getData() != null) {
                            Uri uri = result.getData().getData();
                            if (uri != null) handleSelectedFile(uri);
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_study_material);

        mAuth     = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        isEditMode      = getIntent().getBooleanExtra(EXTRA_EDIT_MODE, false);
        editMaterialKey = getIntent().getStringExtra(EXTRA_MATERIAL_KEY) != null
                ? getIntent().getStringExtra(EXTRA_MATERIAL_KEY) : "";
        existingFileUrl = getIntent().getStringExtra(EXTRA_FILE_URL) != null
                ? getIntent().getStringExtra(EXTRA_FILE_URL) : "";

        cardFilePicker     = findViewById(R.id.cardFilePicker);
        cardSelectedFile   = findViewById(R.id.cardSelectedFile);
        tvFilePickerLabel  = findViewById(R.id.tvFilePickerLabel);
        tvSelectedFileName = findViewById(R.id.tvSelectedFileName);
        tvSelectedFileSize = findViewById(R.id.tvSelectedFileSize);
        ivSelectedFileIcon = findViewById(R.id.ivSelectedFileIcon);
        btnRemoveFile      = findViewById(R.id.btnRemoveFile);
        etTitle            = findViewById(R.id.etTitle);
        etDescription      = findViewById(R.id.etDescription);
        spinnerSubject     = findViewById(R.id.spinnerSubject);
        spinnerGrade       = findViewById(R.id.spinnerGrade);
        btnSave            = findViewById(R.id.btnSave);
        btnUploadAndShare  = findViewById(R.id.btnUploadAndShare);
        ivBack             = findViewById(R.id.ivBack);

        if (isEditMode) {
            prefillData();
            btnUploadAndShare.setText(" Update & Share");
            btnSave.setText("💾 Update");
        }

        ivBack.setOnClickListener(v -> finish());

        spinnerSubject.setAdapter(new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, SUBJECTS));
        spinnerSubject.setOnItemClickListener((p, v, pos, id) ->
                spinnerSubject.setText(SUBJECTS[pos], false));

        spinnerGrade.setAdapter(new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, GRADES));
        spinnerGrade.setOnItemClickListener((p, v, pos, id) ->
                spinnerGrade.setText(GRADES[pos], false));

        cardFilePicker.setOnClickListener(v -> openFilePicker());
        btnRemoveFile.setOnClickListener(v -> clearSelectedFile());

        btnSave.setOnClickListener(v -> {
            if (validateFormDraft()) saveDraft();
        });

        btnUploadAndShare.setOnClickListener(v -> {
            if (validateForm()) uploadFile(true);
        });

        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                startActivity(new Intent(this, TeacherDashboardActivity.class));
                finish(); return true;
            }
            return false;
        });
    }

    private void prefillData() {
        String title   = getIntent().getStringExtra(EXTRA_TITLE);
        String subject = getIntent().getStringExtra(EXTRA_SUBJECT);
        String grade   = getIntent().getStringExtra(EXTRA_GRADE);
        String desc    = getIntent().getStringExtra(EXTRA_DESCRIPTION);
        String type    = getIntent().getStringExtra(EXTRA_FILE_TYPE);

        if (title   != null) etTitle.setText(title);
        if (desc    != null) etDescription.setText(desc);
        if (subject != null) spinnerSubject.setText(subject, false);
        if (grade   != null) spinnerGrade.setText(grade, false);

        if (existingFileUrl != null && !existingFileUrl.isEmpty()) {
            selectedFileType = type != null ? type : "pdf";
            tvFilePickerLabel.setText("📎 Existing file attached (tap to replace)");
            showExistingFilePreview(type);
        }
    }

    private void showExistingFilePreview(String type) {
        cardSelectedFile.setVisibility(View.VISIBLE);
        tvSelectedFileName.setText("Existing file");
        tvSelectedFileSize.setText("(already uploaded)");
        if ("pdf".equalsIgnoreCase(type)) {
            ivSelectedFileIcon.setImageResource(R.drawable.ic_pdf1);
        } else {
            ivSelectedFileIcon.setImageResource(R.drawable.ic_image);
        }
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        filePickerLauncher.launch(Intent.createChooser(intent, "Select PDF or Image"));
    }

    private void handleSelectedFile(Uri uri) {
        String mimeType = getContentResolver().getType(uri);
        if (mimeType == null ||
                (!mimeType.equals("application/pdf") && !mimeType.startsWith("image/"))) {
            Toast.makeText(this, "❌ Only PDF and Image files allowed", Toast.LENGTH_LONG).show();
            return;
        }
        selectedFileUri  = uri;
        selectedFileType = mimeType.equals("application/pdf") ? "pdf" : "image";
        selectedFileName = getFileName(uri);
        selectedFileSize = getFileSize(uri);

        cardSelectedFile.setVisibility(View.VISIBLE);
        tvSelectedFileName.setText(selectedFileName);
        tvSelectedFileSize.setText(selectedFileSize);

        if ("pdf".equals(selectedFileType)) {
            ivSelectedFileIcon.setImageResource(R.drawable.ic_pdf1);
        } else {
            ivSelectedFileIcon.setImageResource(R.drawable.ic_image);
        }
        tvFilePickerLabel.setText("📎 " + selectedFileName + " (tap to change)");
    }

    private void clearSelectedFile() {
        selectedFileUri  = null;
        selectedFileType = "";
        selectedFileName = "";
        selectedFileSize = "";
        existingFileUrl  = "";
        cardSelectedFile.setVisibility(View.GONE);
        tvFilePickerLabel.setText("Tap to select PDF or Image");
    }

    private boolean validateFormDraft() {
        String title   = Objects.requireNonNull(etTitle.getText()).toString().trim();
        String subject = spinnerSubject.getText().toString().trim();
        String grade   = spinnerGrade.getText().toString().trim();
        if (TextUtils.isEmpty(title)) {
            etTitle.setError("Enter a title"); etTitle.requestFocus(); return false;
        }
        if (TextUtils.isEmpty(subject)) {
            Toast.makeText(this, "Please select a subject", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (TextUtils.isEmpty(grade)) {
            Toast.makeText(this, "Please select a grade", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private boolean validateForm() {
        if (!validateFormDraft()) return false;
        if (selectedFileUri == null && existingFileUrl.isEmpty()) {
            Toast.makeText(this, "Please select a file (PDF or Image)", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    // ── Save as Draft (no file upload) ────────────────────────────────────────
    private void saveDraft() {
        if (mAuth.getCurrentUser() == null) return;
        String uid = mAuth.getCurrentUser().getUid();
        String title   = Objects.requireNonNull(etTitle.getText()).toString().trim();
        String subject = spinnerSubject.getText().toString().trim();
        String grade   = spinnerGrade.getText().toString().trim();
        String desc    = etDescription.getText() != null ? etDescription.getText().toString().trim() : "";
        String date    = new java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault()).format(java.util.Calendar.getInstance().getTime());

        String fileType = selectedFileType.isEmpty() ? "" : selectedFileType;
        String fileUrl  = existingFileUrl;
        String fileSize = selectedFileSize.isEmpty() ? "" : selectedFileSize;

        StudyMaterial draft = new StudyMaterial(
                title, fileType, subject, grade, desc,
                fileUrl, fileSize, date, uid, System.currentTimeMillis(), "draft");

        DatabaseReference ref = mDatabase.child("StudyMaterials").child(uid);
        if (isEditMode && !editMaterialKey.isEmpty()) {
            ref.child(editMaterialKey).setValue(draft)
                    .addOnSuccessListener(u -> {
                        Toast.makeText(this, "Draft updated!", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        } else {
            ref.push().setValue(draft)
                    .addOnSuccessListener(u -> {
                        Toast.makeText(this, "Saved as draft!", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        }
    }

    // ── Upload to Cloudinary, then save metadata to Firebase ─────────────────
    private void uploadFile(boolean shareAfter) {
        if (mAuth.getCurrentUser() == null) return;

        btnSave.setEnabled(false);
        btnUploadAndShare.setEnabled(false);
        btnUploadAndShare.setText("Uploading...");

        // Edit mode mein agar file nahi badli
        if (selectedFileUri == null && !existingFileUrl.isEmpty()) {
            saveToDatabase(existingFileUrl, selectedFileType, selectedFileSize, shareAfter);
            return;
        }

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            try {
                // File bytes read karo
                InputStream inputStream = getContentResolver().openInputStream(selectedFileUri);
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                byte[] temp = new byte[8192];
                int bytesRead;
                while ((bytesRead = inputStream.read(temp)) != -1) {
                    buffer.write(temp, 0, bytesRead);
                }
                inputStream.close();
                byte[] fileBytes = buffer.toByteArray();

                // MIME type
                String mimeType = getContentResolver().getType(selectedFileUri);
                if (mimeType == null) mimeType = "application/octet-stream";

                // Resource type
                String resourceType = "pdf".equals(selectedFileType) ? "raw" : "image";

                // Cloudinary upload URL
                String uploadUrl = "https://api.cloudinary.com/v1_1/"
                        + CLOUDINARY_CLOUD_NAME + "/" + resourceType + "/upload";

                // Multipart request build karo
                RequestBody fileBody = RequestBody.create(fileBytes,
                        MediaType.parse(mimeType));

                MultipartBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("file", selectedFileName, fileBody)
                        .addFormDataPart("upload_preset", CLOUDINARY_UPLOAD_PRESET)
                        .build();

                Request request = new Request.Builder()
                        .url(uploadUrl)
                        .post(requestBody)
                        .build();

                OkHttpClient client = new OkHttpClient();
                Response response = client.newCall(request).execute();
                String responseBody = response.body() != null ? response.body().string() : "";

                if (response.isSuccessful()) {
                    JSONObject json = new JSONObject(responseBody);
                    String fileUrl = json.getString("secure_url");
                    handler.post(() ->
                            saveToDatabase(fileUrl, selectedFileType, selectedFileSize, shareAfter));
                } else {
                    handler.post(() -> {
                        Toast.makeText(this,
                                "Upload failed: " + responseBody, Toast.LENGTH_LONG).show();
                        resetButtons(shareAfter);
                    });
                }
            } catch (Exception e) {
                handler.post(() -> {
                    Toast.makeText(this,
                            "Upload error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    resetButtons(shareAfter);
                });
            }
        });
    }

    private void saveToDatabase(String fileUrl, String fileType,
                                String fileSize, boolean shareAfter) {
        if (mAuth.getCurrentUser() == null) return;
        String uid = mAuth.getCurrentUser().getUid();

        String title   = Objects.requireNonNull(etTitle.getText()).toString().trim();
        String subject = spinnerSubject.getText().toString().trim();
        String grade   = spinnerGrade.getText().toString().trim();
        String desc    = etDescription.getText() != null
                ? etDescription.getText().toString().trim() : "";
        String date    = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                .format(Calendar.getInstance().getTime());

        StudyMaterial material = new StudyMaterial(
                title, fileType, subject, grade, desc,
                fileUrl, fileSize, date, uid, System.currentTimeMillis(), "uploaded");

        DatabaseReference ref = mDatabase.child("StudyMaterials").child(uid);

        if (isEditMode && !editMaterialKey.isEmpty()) {
            ref.child(editMaterialKey).setValue(material)
                    .addOnSuccessListener(u -> {
                        // Explicitly update status to "uploaded"
                        ref.child(editMaterialKey).child("status").setValue("uploaded");
                        onSaveSuccess(material, editMaterialKey, shareAfter, "updated");
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        resetButtons(shareAfter);
                    });
        } else {
            DatabaseReference newRef = ref.push();
            String newKey = newRef.getKey();
            newRef.setValue(material)
                    .addOnSuccessListener(u -> onSaveSuccess(material, newKey != null ? newKey : "", shareAfter, "uploaded"))
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        resetButtons(shareAfter);
                    });
        }
    }

    private void onSaveSuccess(StudyMaterial m, String materialKey,
                               boolean shareAfter, String action) {
        Toast.makeText(this, "Material " + action + "!", Toast.LENGTH_SHORT).show();
        if (shareAfter) {
            shareToStudents(m, materialKey);
        } else {
            finish();
        }
    }

    private void shareToStudents(StudyMaterial m, String materialKey) {
        String grade   = m.getGrade()   != null ? m.getGrade().trim()   : "";
        String subject = m.getSubject() != null ? m.getSubject().trim() : "";

        if (grade.isEmpty() || subject.isEmpty()) {
            Toast.makeText(this, "Grade or subject missing", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        FirebaseDatabase.getInstance().getReference("Users")
                .addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                        int[] count = {0};
                        java.util.Map<String, Object> childUpdates = new HashMap<>();

                        String gradeNum = grade.replaceAll("[^0-9]", "");
                        String gradeSec = grade.replaceAll(".*[0-9]", "").trim().toUpperCase(); // Only letter after digit e.g. "A" from "Class 9A"

                        for (com.google.firebase.database.DataSnapshot userSnap : snapshot.getChildren()) {
                            String role   = userSnap.child("role").getValue(String.class);
                            String status = userSnap.child("status").getValue(String.class);

                            if (role == null || !role.equalsIgnoreCase("student")) continue;
                            if (status != null && !status.equalsIgnoreCase("Approved")) continue;

                            // Subject check
                            boolean subjectMatch = false;
                            for (com.google.firebase.database.DataSnapshot s : userSnap.child("enrolledSubjects").getChildren()) {
                                String sv = s.getValue(String.class);
                                if (sv != null && sv.trim().equalsIgnoreCase(subject)) { subjectMatch = true; break; }
                            }
                            if (!subjectMatch) continue;

                            // Class + section check
                            String studentClass = userSnap.child("className").getValue(String.class);
                            if (studentClass == null) continue;
                            String sClassNum = studentClass.trim().replaceAll("[^0-9]", "");
                            if (!gradeNum.equals(sClassNum)) continue;
                            String studentSec = studentClass.trim().replaceAll(".*[0-9]", "").trim().toUpperCase();
                            if (!gradeSec.isEmpty() && !studentSec.equals(gradeSec)) continue;

                            String studentUid = userSnap.getKey();
                            if (studentUid == null) continue;

                            java.util.Map<String, Object> shared = new HashMap<>();
                            shared.put("title",        m.getTitle());
                            shared.put("type",         m.getType());
                            shared.put("subject",      m.getSubject());
                            shared.put("grade",        m.getGrade());
                            shared.put("description",  m.getDescription());
                            shared.put("fileUrl",      m.getFileUrl());
                            shared.put("fileSize",     m.getFileSize());
                            shared.put("uploadedDate", m.getUploadedDate());
                            shared.put("teacherUid",   mAuth.getCurrentUser().getUid());
                            shared.put("sharedAt",     System.currentTimeMillis());
                            childUpdates.put("SharedStudyMaterials/" + studentUid + "/" + materialKey, shared);

                            java.util.Map<String, Object> announcement = new HashMap<>();
                            announcement.put("title",     "📚 New Study Material: " + m.getTitle() + " (" + subject + ")");
                            announcement.put("message",   "Class: " + grade);
                            announcement.put("timestamp", System.currentTimeMillis());
                            announcement.put("pdfUrl",    m.getFileUrl());
                            childUpdates.put("Announcements/Students/" + studentUid + "/" + materialKey, announcement);

                            count[0]++;
                        }

                        FirebaseDatabase.getInstance().getReference()
                                .updateChildren(childUpdates).addOnCompleteListener(task -> {
                                    String msg = count[0] > 0
                                            ? "✅ Shared with " + count[0] + " students of " + grade
                                            : "⚠️ No approved students found for " + subject + " - " + grade;
                                    Toast.makeText(UploadStudyMaterialActivity.this, msg, Toast.LENGTH_LONG).show();
                                    finish();
                                });
                    }

                    @Override
                    public void onCancelled(@NonNull com.google.firebase.database.DatabaseError e) {
                        Toast.makeText(UploadStudyMaterialActivity.this,
                                "Saved but sharing failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
    }

    private void resetButtons(boolean shareAfter) {
        btnSave.setEnabled(true);
        btnUploadAndShare.setEnabled(true);
        btnUploadAndShare.setText(isEditMode ? "✅ Update & Share" : "🔗 Upload & Share");
    }

    private String getFileName(Uri uri) {
        String result = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) result = cursor.getString(idx);
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            if (result != null) {
                int cut = result.lastIndexOf('/');
                if (cut != -1) result = result.substring(cut + 1);
            }
        }
        return result != null ? result : "file";
    }

    private String getFileSize(Uri uri) {
        long size = 0;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.SIZE);
                    if (idx >= 0 && !cursor.isNull(idx))
                        size = cursor.getLong(idx);
                }
            }
        }
        if (size <= 0) return "Unknown size";
        if (size < 1024)        return size + " B";
        if (size < 1024 * 1024) return (size / 1024) + " KB";
        return String.format(Locale.getDefault(), "%.1f MB", size / (1024.0 * 1024));
    }
}