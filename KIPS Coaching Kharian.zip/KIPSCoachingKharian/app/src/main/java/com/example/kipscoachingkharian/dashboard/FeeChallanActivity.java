package com.example.kipscoachingkharian.dashboard;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class FeeChallanActivity extends AppCompatActivity {

    private EditText etSearch;
    private ListView lvResults;
    private LinearLayout challanContainer;

    private final List<String> allNames     = new ArrayList<>();
    private final List<String> allUids      = new ArrayList<>();
    private final List<String> allClasses   = new ArrayList<>();
    private final List<List<String>> allSubjects = new ArrayList<>();
    private final List<String> allUsernames = new ArrayList<>();

    private long feePerSubject = 3000L;
    private long feeSpecial    = 2500L;

    private static final long LATE_FINE_AMOUNT = 200L;

    private static final java.util.Set<String> SPECIAL_SUBJECTS = new java.util.HashSet<>(
            java.util.Arrays.asList(
                    "urdu",
                    "pakistan studies", "pak studies", "pak study", "pakistan study", "p.st", "pst",
                    "islamiat", "islamic studies", "islamiyat", "islamiyat studies"
            ));

    private long getFeeForSubject(String subject) {
        if (subject == null) return feePerSubject;
        return SPECIAL_SUBJECTS.contains(subject.trim().toLowerCase()) ? feeSpecial : feePerSubject;
    }

    private boolean isPastDueDate(String dueDateStr) {
        if (dueDateStr == null || dueDateStr.isEmpty()) return false;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date dueDate = sdf.parse(dueDateStr);
            if (dueDate == null) return false;
            Calendar dueCal = Calendar.getInstance();
            dueCal.setTime(dueDate);
            dueCal.set(Calendar.HOUR_OF_DAY, 23);
            dueCal.set(Calendar.MINUTE, 59);
            dueCal.set(Calendar.SECOND, 59);
            return new Date().after(dueCal.getTime());
        } catch (ParseException e) {
            return false;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF4F6FA);

        // Toolbar
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setBackgroundColor(0xFF2E7D32);
        toolbar.setPadding(dp(16), dp(14), dp(16), dp(14));

        ImageView ivBack = new ImageView(this);
        ivBack.setImageResource(android.R.drawable.ic_menu_revert);
        ivBack.setColorFilter(0xFFFFFFFF);
        ivBack.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(dp(24), dp(24));
        bLp.setMarginEnd(dp(14));
        ivBack.setLayoutParams(bLp);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Fee Challan Generator");
        tvTitle.setTextSize(18f);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        toolbar.addView(ivBack);
        toolbar.addView(tvTitle);

        // Search Bar
        LinearLayout searchBar = new LinearLayout(this);
        searchBar.setBackgroundColor(0xFFFFFFFF);
        searchBar.setPadding(dp(14), dp(10), dp(14), dp(0));

        etSearch = new EditText(this);
        etSearch.setHint("🔍  Search student name...");
        etSearch.setTextSize(14f);
        etSearch.setTextColor(0xFF333333);
        etSearch.setHintTextColor(0xFF999999);
        etSearch.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        etSearch.setSingleLine(true);
        etSearch.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        searchBar.addView(etSearch);

        lvResults = new ListView(this);
        lvResults.setBackgroundColor(0xFFFFFFFF);
        lvResults.setVisibility(View.GONE);
        lvResults.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(180)));

        ScrollView sv = new ScrollView(this);
        challanContainer = new LinearLayout(this);
        challanContainer.setOrientation(LinearLayout.VERTICAL);
        challanContainer.setPadding(dp(14), dp(14), dp(14), dp(24));

        TextView tvHint = new TextView(this);
        tvHint.setText("Search a student above to generate fee challan.");
        tvHint.setTextSize(13f);
        tvHint.setTextColor(0xFF999999);
        tvHint.setGravity(Gravity.CENTER);
        tvHint.setPadding(0, dp(60), 0, 0);
        challanContainer.addView(tvHint);
        sv.addView(challanContainer);

        root.addView(toolbar);
        root.addView(searchBar);
        root.addView(lvResults);
        root.addView(sv);
        setContentView(root);

        loadFeePerSubject();
        loadStudents();
        setupSearch();
    }

    private void loadFeePerSubject() {
        FirebaseDatabase.getInstance().getReference("payment_config")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snap) {
                        if (snap.hasChild("fee_per_subject")) {
                            Long f = snap.child("fee_per_subject").getValue(Long.class);
                            if (f != null) feePerSubject = f;
                        }
                        if (snap.hasChild("fee_special_subject")) {
                            Long f = snap.child("fee_special_subject").getValue(Long.class);
                            if (f != null) feeSpecial = f;
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    private void loadStudents() {
        FirebaseDatabase.getInstance().getReference("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        allNames.clear(); allUids.clear();
                        allClasses.clear(); allSubjects.clear();
                        allUsernames.clear();

                        for (DataSnapshot snap : snapshot.getChildren()) {
                            String role   = snap.child("role").getValue(String.class);
                            String status = snap.child("status").getValue(String.class);
                            if (!"Student".equalsIgnoreCase(role)) continue;
                            if (!"Approved".equalsIgnoreCase(status)) continue;

                            String name     = snap.child("name").getValue(String.class);
                            String cls      = snap.child("className").getValue(String.class);
                            String username = snap.child("username").getValue(String.class);
                            if (name == null) continue;

                            List<String> subs = new ArrayList<>();
                            for (DataSnapshot s : snap.child("enrolledSubjects").getChildren()) {
                                String sub = s.getValue(String.class);
                                if (sub != null) subs.add(sub);
                            }

                            allNames.add(name);
                            allUids.add(snap.getKey());
                            allClasses.add(cls != null ? cls : "");
                            allSubjects.add(subs);
                            allUsernames.add(username != null ? username : "");
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                String q = s.toString().trim().toLowerCase();
                if (q.isEmpty()) { lvResults.setVisibility(View.GONE); return; }

                List<String> filtered = new ArrayList<>();
                List<Integer> indices = new ArrayList<>();
                for (int i = 0; i < allNames.size(); i++) {
                    if (allNames.get(i).toLowerCase().contains(q)) {
                        filtered.add(allNames.get(i) + " — Class " + allClasses.get(i));
                        indices.add(i);
                    }
                }
                if (filtered.isEmpty()) { lvResults.setVisibility(View.GONE); return; }

                lvResults.setAdapter(new ArrayAdapter<>(FeeChallanActivity.this,
                        android.R.layout.simple_list_item_1, filtered));
                lvResults.setVisibility(View.VISIBLE);

                lvResults.setOnItemClickListener((parent, view, pos, id) -> {
                    int idx = indices.get(pos);
                    etSearch.setText(allNames.get(idx));
                    lvResults.setVisibility(View.GONE);
                    generateChallan(idx);
                });
            }
        });
    }

    private void generateChallan(int idx) {
        String name            = allNames.get(idx);
        String cls             = allClasses.get(idx);
        String uid             = allUids.get(idx);
        List<String> subjects  = allSubjects.get(idx);
        String studentUsername = allUsernames.get(idx);

        challanContainer.removeAllViews();

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, 15);
        String dueDate  = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(cal.getTime());
        String month    = new SimpleDateFormat("MMMM yyyy",  Locale.getDefault()).format(cal.getTime());
        String monthKey = month.replace(" ", "_");

        long baseFee = 0;
        for (String sub : subjects) baseFee += getFeeForSubject(sub);
        final long finalBaseFee = baseFee;

        boolean isLate           = isPastDueDate(dueDate);
        final long fineAmount    = isLate ? LATE_FINE_AMOUNT : 0L;
        final long totalWithFine = finalBaseFee + fineAmount;

        Map<String, Object> challanData = new HashMap<>();
        challanData.put("studentName",   name);
        challanData.put("className",     cls);
        challanData.put("month",         month);
        challanData.put("dueDate",       dueDate);
        challanData.put("subjects",      subjects);
        challanData.put("feePerSubject", feePerSubject);
        challanData.put("totalSubjects", subjects.size());
        challanData.put("baseFee",       String.valueOf(finalBaseFee));
        challanData.put("lateFine",      String.valueOf(fineAmount));
        challanData.put("amount",        String.valueOf(totalWithFine));
        challanData.put("generatedAt",   System.currentTimeMillis());

        FirebaseDatabase.getInstance().getReference("Fees").child(uid).child(monthKey)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snap) {
                        String existingStatus = snap.exists()
                                ? snap.child("status").getValue(String.class) : null;
                        boolean alreadyPaid = "Paid".equalsIgnoreCase(existingStatus);

                        Long paidAt = snap.child("paidAt").getValue(Long.class);
                        if (paidAt == null) paidAt = snap.child("savedAt").getValue(Long.class);

                        long displayTotal = totalWithFine;
                        long displayFine  = fineAmount;
                        boolean displayLate = isLate;

                        if (alreadyPaid) {
                            String savedAmount = snap.child("amount").getValue(String.class);
                            if (savedAmount != null) {
                                try { displayTotal = Long.parseLong(savedAmount); } catch (Exception ignored) {}
                            }
                            String savedFineStr = snap.child("lateFine").getValue(String.class);
                            if (savedFineStr != null) {
                                try { displayFine = Long.parseLong(savedFineStr); } catch (Exception ignored) {}
                            }
                            displayLate = displayFine > 0;
                            challanData.put("amount",   String.valueOf(displayTotal));
                            challanData.put("lateFine", String.valueOf(displayFine));

                            Toast.makeText(FeeChallanActivity.this,
                                    "✅ " + name + " ki fee already Paid hai.", Toast.LENGTH_SHORT).show();
                            FirebaseDatabase.getInstance().getReference("Fees")
                                    .child(uid).child(monthKey).updateChildren(challanData);

                        } else {
                            // ── Fee unpaid hai — student + parent dono ko notify karo ──
                            challanData.put("status", "Unpaid");
                            FirebaseDatabase.getInstance().getReference("Fees")
                                    .child(uid).child(monthKey)
                                    .setValue(challanData)
                                    .addOnSuccessListener(u -> {
                                        Toast.makeText(FeeChallanActivity.this,
                                                isLate
                                                        ? "✅ Challan saved for " + name + " (Late fine: Rs. " + fineAmount + ")"
                                                        : "✅ Challan saved for " + name,
                                                Toast.LENGTH_SHORT).show();

                                        // ✅ Student ko notification
                                        sendNotificationToStudent(uid, name, month, totalWithFine, dueDate, isLate, fineAmount);

                                        // ✅ Parent ko notification
                                        sendNotificationToParent(studentUsername, name, month, totalWithFine, dueDate, isLate, fineAmount);
                                    })
                                    .addOnFailureListener(e ->
                                            Toast.makeText(FeeChallanActivity.this,
                                                    "❌ Save failed: " + e.getMessage(),
                                                    Toast.LENGTH_SHORT).show());
                        }

                        buildChallanUI(name, cls, month, dueDate, subjects, finalBaseFee,
                                displayFine, displayTotal, displayLate, alreadyPaid, paidAt);
                        loadPaymentHistory(uid, challanContainer);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError e) {
                        Map<String, Object> safeUpdate = new HashMap<>();
                        safeUpdate.put("studentName",   name);
                        safeUpdate.put("className",     cls);
                        safeUpdate.put("month",         month);
                        safeUpdate.put("dueDate",       dueDate);
                        safeUpdate.put("subjects",      subjects);
                        safeUpdate.put("feePerSubject", feePerSubject);
                        safeUpdate.put("totalSubjects", subjects.size());
                        safeUpdate.put("baseFee",       String.valueOf(finalBaseFee));
                        safeUpdate.put("generatedAt",   System.currentTimeMillis());
                        FirebaseDatabase.getInstance().getReference("Fees")
                                .child(uid).child(monthKey).updateChildren(safeUpdate);

                        buildChallanUI(name, cls, month, dueDate, subjects, finalBaseFee,
                                fineAmount, totalWithFine, isLate, false, null);
                        loadPaymentHistory(uid, challanContainer);
                    }
                });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ✅ STUDENT ko directly uske UID par notification bhejo
    // Firebase path: Notifications/{studentUid}/push()
    // ─────────────────────────────────────────────────────────────────────────
    private void sendNotificationToStudent(String studentUid, String studentName,
                                           String month, long amount, String dueDate,
                                           boolean isLate, long fineAmount) {

        String message = isLate
                ? studentName + " ki " + month + " ki fee pending hai. Amount: Rs. " + amount
                + " (Late fine Rs. " + fineAmount + " included). Due Date: " + dueDate
                : studentName + " ki " + month + " ki fee challan generate hui hai. "
                + "Amount: Rs. " + amount + ". Due Date: " + dueDate;

        Map<String, Object> notif = new HashMap<>();
        notif.put("title",       isLate ? "⚠️ Fee Overdue!" : "📋 Fee Challan Generated");
        notif.put("message",     message);
        notif.put("type",        "fee_pending");
        notif.put("studentName", studentName);
        notif.put("amount",      String.valueOf(amount));
        notif.put("dueDate",     dueDate);
        notif.put("month",       month);
        notif.put("isLate",      isLate);
        notif.put("lateFine",    String.valueOf(fineAmount));
        notif.put("timestamp",   System.currentTimeMillis());
        notif.put("isRead",      false);

        FirebaseDatabase.getInstance()
                .getReference("Notifications")
                .child(studentUid)
                .push()
                .setValue(notif);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ✅ PARENT ko notification — Users mein "linkedChildUsername" se match karo
    // Firebase path: Notifications/{parentUid}/push()
    // ─────────────────────────────────────────────────────────────────────────
    private void sendNotificationToParent(String studentUsername, String studentName,
                                          String month, long amount, String dueDate,
                                          boolean isLate, long fineAmount) {

        if (studentUsername == null || studentUsername.trim().isEmpty()) return;

        FirebaseDatabase.getInstance().getReference("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot userSnap : snapshot.getChildren()) {
                            String role = userSnap.child("role").getValue(String.class);
                            if (!"Parent".equalsIgnoreCase(role)) continue;

                            String linkedUsername = userSnap.child("linkedChildUsername")
                                    .getValue(String.class);
                            if (linkedUsername == null) continue;

                            if (!linkedUsername.trim().equalsIgnoreCase(studentUsername.trim())) continue;

                            String parentUid = userSnap.getKey();

                            String message = isLate
                                    ? "Aapke bachay " + studentName + " ki " + month
                                    + " ki fee abhi tak pending hai. Amount: Rs. " + amount
                                    + " (Late fine Rs. " + fineAmount + " included). Due Date: " + dueDate
                                    : "Aapke bachay " + studentName + " ki " + month
                                    + " ki fee challan generate hui hai. "
                                    + "Amount: Rs. " + amount + ". Due Date: " + dueDate;

                            Map<String, Object> notif = new HashMap<>();
                            notif.put("title",       isLate ? "⚠️ Fee Overdue!" : "📋 Fee Challan Generated");
                            notif.put("message",     message);
                            notif.put("type",        "fee_pending");
                            notif.put("studentName", studentName);
                            notif.put("amount",      String.valueOf(amount));
                            notif.put("dueDate",     dueDate);
                            notif.put("month",       month);
                            notif.put("isLate",      isLate);
                            notif.put("lateFine",    String.valueOf(fineAmount));
                            notif.put("timestamp",   System.currentTimeMillis());
                            notif.put("isRead",      false);

                            FirebaseDatabase.getInstance()
                                    .getReference("Notifications")
                                    .child(parentUid)
                                    .push()
                                    .setValue(notif);
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    // ── Build Challan UI ──────────────────────────────────────────────────
    private void buildChallanUI(String name, String cls, String month, String dueDate,
                                List<String> subjects, long baseFee, long fineAmount,
                                long totalFee, boolean isLate, boolean isPaid, Long paidAt) {

        CardView card = new CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, 0, 0, dp(16));
        card.setLayoutParams(cp);
        card.setRadius(dp(14));
        card.setCardElevation(dp(4));
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(18), dp(18), dp(18), dp(18));

        addRow(inner, "🏫 KIPS Coaching Kharian", null, 16f, Typeface.BOLD, 0xFF1565C0, 0xFF1565C0);
        addDivider(inner);
        addRow(inner, "FEE CHALLAN", null, 14f, Typeface.BOLD, 0xFF333333, 0xFF333333);
        addSpacer(inner, dp(10));

        addRow(inner, "Student Name:", name,                      13f, Typeface.NORMAL, 0xFF555555, 0xFF222222);
        addRow(inner, "Class:",        cls.isEmpty() ? "—" : cls, 13f, Typeface.NORMAL, 0xFF555555, 0xFF222222);
        addRow(inner, "Month:",        month,                     13f, Typeface.NORMAL, 0xFF555555, 0xFF222222);
        addRow(inner, "Due Date:",     dueDate,                   13f, Typeface.BOLD,   0xFFE53935, 0xFFE53935);
        addSpacer(inner, dp(12));

        TextView tvHeader = new TextView(this);
        tvHeader.setText("Subject-wise Fee Breakdown");
        tvHeader.setTextSize(13f);
        tvHeader.setTypeface(null, Typeface.BOLD);
        tvHeader.setTextColor(0xFF1565C0);
        LinearLayout.LayoutParams thp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        thp.setMargins(0, 0, 0, dp(8));
        tvHeader.setLayoutParams(thp);
        inner.addView(tvHeader);
        addDivider(inner);

        if (subjects.isEmpty()) {
            TextView tvNoSub = new TextView(this);
            tvNoSub.setText("No subjects enrolled.");
            tvNoSub.setTextSize(13f);
            tvNoSub.setTextColor(0xFF888888);
            tvNoSub.setPadding(0, dp(4), 0, dp(4));
            inner.addView(tvNoSub);
        } else {
            for (String sub : subjects) {
                addRow(inner, sub, "Rs. " + getFeeForSubject(sub), 13f, Typeface.NORMAL, 0xFF333333, 0xFF1976D2);
            }
        }

        addDivider(inner);
        addSpacer(inner, dp(4));
        addRow(inner, "Total Subjects:", String.valueOf(subjects.size()), 13f, Typeface.BOLD,   0xFF333333, 0xFF333333);
        addRow(inner, "Subject Fee:",    "Rs. " + baseFee,                13f, Typeface.NORMAL, 0xFF555555, 0xFF333333);

        if (fineAmount > 0) {
            addRow(inner, "⚠ Late Fine:", "Rs. " + fineAmount, 13f, Typeface.BOLD, 0xFFE53935, 0xFFE53935);
        }

        addDivider(inner);
        addRow(inner, "Total Fee:", "Rs. " + totalFee, 15f, Typeface.BOLD, 0xFF222222, 0xFF2E7D32);
        addSpacer(inner, dp(12));
        addDivider(inner);

        // Status badge
        LinearLayout badgeRow = new LinearLayout(this);
        badgeRow.setOrientation(LinearLayout.HORIZONTAL);
        badgeRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        brp.setMargins(0, dp(10), 0, 0);
        badgeRow.setLayoutParams(brp);

        TextView tvStatusLabel = new TextView(this);
        tvStatusLabel.setText("Payment Status:");
        tvStatusLabel.setTextSize(13f);
        tvStatusLabel.setTextColor(0xFF555555);
        tvStatusLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvBadge = new TextView(this);
        tvBadge.setText(isPaid ? "✓ Paid" : (isLate ? "⏰ Unpaid (Overdue)" : "⏳ Unpaid"));
        tvBadge.setTextSize(12f);
        tvBadge.setTextColor(0xFFFFFFFF);
        tvBadge.setTypeface(null, Typeface.BOLD);
        tvBadge.setPadding(dp(14), dp(6), dp(14), dp(6));
        android.graphics.drawable.GradientDrawable badgeBg =
                new android.graphics.drawable.GradientDrawable();
        badgeBg.setColor(isPaid ? 0xFF43A047 : 0xFFE53935);
        badgeBg.setCornerRadius(dp(20));
        tvBadge.setBackground(badgeBg);
        badgeRow.addView(tvStatusLabel);
        badgeRow.addView(tvBadge);
        inner.addView(badgeRow);

        if (isPaid && paidAt != null && paidAt > 0) {
            TextView tvPaidOn = new TextView(this);
            tvPaidOn.setText("Paid on: " + new SimpleDateFormat(
                    "dd MMM yyyy, hh:mm a", Locale.getDefault()).format(new Date(paidAt)));
            tvPaidOn.setTextSize(12f);
            tvPaidOn.setTypeface(null, Typeface.BOLD);
            tvPaidOn.setTextColor(0xFF2E7D32);
            tvPaidOn.setPadding(0, dp(8), 0, 0);
            inner.addView(tvPaidOn);
        }

        TextView tvFooter = new TextView(this);
        if (isPaid) {
            tvFooter.setText("Fee per subject: Rs. " + feePerSubject + "  |  Thank you for your payment!");
        } else if (isLate) {
            tvFooter.setText("Fee per subject: Rs. " + feePerSubject
                    + "  |  Due date guzar gayi hai — Rs. " + LATE_FINE_AMOUNT + " fine laga di gayi hai.");
        } else {
            tvFooter.setText("Fee per subject: Rs. " + feePerSubject + "  |  Please pay by " + dueDate);
        }
        tvFooter.setTextSize(11f);
        tvFooter.setTextColor(0xFF888888);
        tvFooter.setPadding(0, dp(10), 0, 0);
        inner.addView(tvFooter);

        card.addView(inner);
        challanContainer.addView(card);
    }

    // ── Payment History ───────────────────────────────────────────────────
    private void loadPaymentHistory(String uid, LinearLayout container) {
        FirebaseDatabase.getInstance().getReference("Fees").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (!snapshot.exists()) return;

                        CardView histCard = new CardView(FeeChallanActivity.this);
                        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        histCard.setLayoutParams(cp);
                        histCard.setRadius(dp(14));
                        histCard.setCardElevation(dp(2));
                        histCard.setCardBackgroundColor(0xFFFFFFFF);

                        LinearLayout inner2 = new LinearLayout(FeeChallanActivity.this);
                        inner2.setOrientation(LinearLayout.VERTICAL);
                        inner2.setPadding(dp(16), dp(14), dp(16), dp(14));

                        TextView tvHdr = new TextView(FeeChallanActivity.this);
                        tvHdr.setText("Payment History");
                        tvHdr.setTextSize(14f);
                        tvHdr.setTypeface(null, Typeface.BOLD);
                        tvHdr.setTextColor(0xFF333333);
                        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        hp.setMargins(0, 0, 0, dp(8));
                        tvHdr.setLayoutParams(hp);
                        inner2.addView(tvHdr);

                        for (DataSnapshot record : snapshot.getChildren()) {
                            String month  = record.child("month").getValue(String.class);
                            String amount = record.child("amount").getValue(String.class);
                            String status = record.child("status").getValue(String.class);
                            String due    = record.child("dueDate").getValue(String.class);
                            String fine   = record.child("lateFine").getValue(String.class);
                            if (month == null) continue;

                            boolean isPaid     = "Paid".equalsIgnoreCase(status);
                            int badgeColor     = isPaid ? 0xFF43A047 : 0xFFE53935;
                            boolean hasFine    = fine != null && !fine.equals("0");

                            LinearLayout row = new LinearLayout(FeeChallanActivity.this);
                            row.setOrientation(LinearLayout.VERTICAL);
                            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                            rp.setMargins(0, 0, 0, dp(10));
                            row.setLayoutParams(rp);
                            row.setBackgroundColor(0xFFF9F9F9);
                            row.setPadding(dp(10), dp(8), dp(10), dp(8));

                            LinearLayout topRow = new LinearLayout(FeeChallanActivity.this);
                            topRow.setOrientation(LinearLayout.HORIZONTAL);
                            topRow.setGravity(Gravity.CENTER_VERTICAL);

                            TextView tvMonth = new TextView(FeeChallanActivity.this);
                            tvMonth.setText(month);
                            tvMonth.setTextSize(13f);
                            tvMonth.setTypeface(null, Typeface.BOLD);
                            tvMonth.setTextColor(0xFF333333);
                            tvMonth.setLayoutParams(new LinearLayout.LayoutParams(0,
                                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

                            TextView tvBadge2 = new TextView(FeeChallanActivity.this);
                            tvBadge2.setText(isPaid ? "✓ Paid" : "✗ Unpaid");
                            tvBadge2.setTextSize(11f);
                            tvBadge2.setTextColor(0xFFFFFFFF);
                            tvBadge2.setTypeface(null, Typeface.BOLD);
                            tvBadge2.setPadding(dp(10), dp(4), dp(10), dp(4));
                            android.graphics.drawable.GradientDrawable bg2 =
                                    new android.graphics.drawable.GradientDrawable();
                            bg2.setColor(badgeColor);
                            bg2.setCornerRadius(dp(20));
                            tvBadge2.setBackground(bg2);

                            topRow.addView(tvMonth);
                            topRow.addView(tvBadge2);

                            TextView tvDetail = new TextView(FeeChallanActivity.this);
                            Long paidAt = record.child("paidAt").getValue(Long.class);
                            if (paidAt == null) paidAt = record.child("savedAt").getValue(Long.class);
                            String paidDateStr = "";
                            if (isPaid && paidAt != null && paidAt > 0) {
                                paidDateStr = "  |  Paid: " + new SimpleDateFormat(
                                        "dd/MM/yyyy hh:mm a", Locale.getDefault())
                                        .format(new Date(paidAt));
                            }
                            String fineStr = hasFine ? "  |  Fine: Rs. " + fine : "";
                            tvDetail.setText("Amount: Rs. " + (amount != null ? amount : "—")
                                    + "   |   Due: " + (due != null ? due : "—")
                                    + fineStr + paidDateStr);
                            tvDetail.setTextSize(11f);
                            tvDetail.setTextColor(hasFine && !isPaid ? 0xFFE53935 : 0xFF666666);
                            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                            dlp.topMargin = dp(4);
                            tvDetail.setLayoutParams(dlp);

                            row.addView(topRow);
                            row.addView(tvDetail);
                            inner2.addView(row);
                        }

                        histCard.addView(inner2);
                        runOnUiThread(() -> container.addView(histCard));
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    // ── UI Helpers ────────────────────────────────────────────────────────
    private void addRow(LinearLayout parent, String label, String value,
                        float textSize, int style, int labelColor, int valueColor) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.setMargins(0, 0, 0, dp(4));
        row.setLayoutParams(rp);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(textSize);
        tvLabel.setTypeface(null, style);
        tvLabel.setTextColor(labelColor);
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(tvLabel);

        if (value != null) {
            TextView tvValue = new TextView(this);
            tvValue.setText(value);
            tvValue.setTextSize(textSize);
            tvValue.setTypeface(null, style);
            tvValue.setTextColor(valueColor);
            tvValue.setGravity(Gravity.END);
            row.addView(tvValue);
        }
        parent.addView(row);
    }

    private void addDivider(LinearLayout parent) {
        View v = new View(this);
        v.setBackgroundColor(0xFFEEEEEE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(0, dp(6), 0, dp(6));
        v.setLayoutParams(lp);
        parent.addView(v);
    }

    private void addSpacer(LinearLayout parent, int height) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, height));
        parent.addView(v);
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density);
    }
}