package com.example.kipscoachingkharian.dashboard;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class FeeChallanActivity extends AppCompatActivity {

    private EditText etSearch;
    private ListView lvResults;
    private LinearLayout challanContainer;

    private final List<String> allNames     = new ArrayList<>();
    private final List<String> allUids      = new ArrayList<>();
    private final List<String> allClasses   = new ArrayList<>();
    private final List<List<String>> allSubjects = new ArrayList<>();
    private final List<String> allUsernames = new ArrayList<>();

    private long feePerSubject = 3000L;
    private long feeSpecial    = 2500L;

    // Tracks which student's challan is currently on screen, so we can
    // regenerate it automatically if admin changes the fee amounts.
    private int currentStudentIdx = -1;

    // Kept so we can detach the real-time listener in onDestroy() and avoid leaks.
    private DatabaseReference paymentConfigRef;
    private ValueEventListener paymentConfigListener;

    private static final long LATE_FINE_AMOUNT = 200L;

    private static final java.util.Set<String> SPECIAL_SUBJECTS = new java.util.HashSet<>(
            java.util.Arrays.asList(
                    "urdu",
                    "pakistan studies", "pak studies", "pak study", "pakistan study", "p.st", "pst",
                    "islamiat", "islamic studies", "islamiyat", "islamiyat studies"
            ));

    private long getFeeForSubject(String subject) {
        if (subject == null) return feePerSubject;
        return SPECIAL_SUBJECTS.contains(subject.trim().toLowerCase()) ? feeSpecial : feePerSubject;
    }

    // ── Safely reads a Firebase value as String, whatever its actual type
    //    (String / Long / Double / Boolean). Prevents:
    //    "Failed to convert value of type java.lang.Long to String" crashes
    //    when a field was saved elsewhere as a number instead of a String.
    private String safeString(DataSnapshot snap) {
        if (snap == null || !snap.exists()) return null;
        Object v = snap.getValue();
        return v != null ? String.valueOf(v) : null;
    }

    private boolean isPastDueDate(String dueDateStr) {
        if (dueDateStr == null || dueDateStr.isEmpty()) return false;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date dueDate = sdf.parse(dueDateStr);
            if (dueDate == null) return false;
            Calendar dueCal = Calendar.getInstance();
            dueCal.setTime(dueDate);
            dueCal.set(Calendar.HOUR_OF_DAY, 23);
            dueCal.set(Calendar.MINUTE, 59);
            dueCal.set(Calendar.SECOND, 59);
            return new Date().after(dueCal.getTime());
        } catch (ParseException e) {
            return false;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fee_challan);

        etSearch         = findViewById(R.id.etSearch);
        lvResults        = findViewById(R.id.lvResults);
        challanContainer = findViewById(R.id.challanContainer);
        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        loadFeePerSubject();
        loadStudents();
        setupSearch();
    }

    /**
     * Listens LIVE to payment_config so that when the admin changes
     * fee_per_subject / fee_special_subject, the values here update
     * immediately — and if a challan is currently open on screen, it is
     * regenerated with the new fee.
     */
    private void loadFeePerSubject() {
        paymentConfigRef = FirebaseDatabase.getInstance().getReference("payment_config");

        paymentConfigListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snap) {
                boolean changed = false;

                if (snap.hasChild("fee_per_subject")) {
                    Long f = snap.child("fee_per_subject").getValue(Long.class);
                    if (f != null && f != feePerSubject) {
                        feePerSubject = f;
                        changed = true;
                    }
                }
                if (snap.hasChild("fee_special_subject")) {
                    Long f = snap.child("fee_special_subject").getValue(Long.class);
                    if (f != null && f != feeSpecial) {
                        feeSpecial = f;
                        changed = true;
                    }
                }

                // Agar admin ne fee structure change ki hai, to:
                // 1) tamam students ke is mahine ke "Unpaid" challans (jo
                //    Firebase mein pehle se saved hain) naye rate ke sath
                //    update kar dein — chahe unka page abhi open na ho.
                // 2) agar koi challan currently screen par khula hai,
                //    usay bhi turant refresh kar dein.
                if (changed) {
                    updateAllUnpaidChallansWithNewFee();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError e) {}
        };

        paymentConfigRef.addValueEventListener(paymentConfigListener);
    }

    /**
     * Fee structure change hone par, har approved student ke is mahine
     * ke ABHI TAK "Unpaid" challan ko naye fee ke sath Firebase mein
     * update kar deta hai. Jo challans already "Paid" ho chuke hain,
     * unhein chhoda jata hai — taake purani receipt ka record safe rahe.
     */
    private void updateAllUnpaidChallansWithNewFee() {
        if (allUids.isEmpty()) return; // student list abhi load nahi hui

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, 15);
        final String dueDate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(cal.getTime());
        final String month   = new SimpleDateFormat("MMMM yyyy",  Locale.getDefault()).format(cal.getTime());
        final String monthKey = month.replace(" ", "_");
        final boolean isLateNow = isPastDueDate(dueDate);

        int updatedCount = 0;

        for (int i = 0; i < allUids.size(); i++) {
            String uid = allUids.get(i);
            List<String> subjects = allSubjects.get(i);
            if (uid == null) continue;

            long newBaseFee = 0;
            // Subject-wise fee snapshot recompute karo taake
            // "Unpaid" challan ki subject-wise breakdown bhi naye
            // rate ke sath Firebase mein save ho (consistency ke liye).
            Map<String, Long> newSubjectFeeMap = new HashMap<>();
            for (String sub : subjects) {
                long f = getFeeForSubject(sub);
                newSubjectFeeMap.put(sub, f);
                newBaseFee += f;
            }
            final long finalNewBaseFee = newBaseFee;

            DatabaseReference feeRef = FirebaseDatabase.getInstance()
                    .getReference("Fees").child(uid).child(monthKey);

            feeRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snap) {
                    if (!snap.exists()) return; // is student ka challan abhi generate hi nahi hua

                    String status = safeString(snap.child("status"));
                    if ("Paid".equalsIgnoreCase(status)) return; // paid challan ko touch nahi karna

                    long newFine  = isLateNow ? LATE_FINE_AMOUNT : 0L;
                    long newTotal = finalNewBaseFee + newFine;

                    Map<String, Object> update = new HashMap<>();
                    update.put("feePerSubject", feePerSubject);
                    update.put("baseFee",       String.valueOf(finalNewBaseFee));
                    update.put("lateFine",      String.valueOf(newFine));
                    update.put("amount",        String.valueOf(newTotal));
                    update.put("subjectFees",   newSubjectFeeMap);

                    feeRef.updateChildren(update);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError e) {}
            });

            updatedCount++;
        }

        if (updatedCount > 0) {
            Toast.makeText(this,
                    "ℹ️ Fee structure update hui — sab pending challans naye rate ke sath refresh ho rahe hain.",
                    Toast.LENGTH_SHORT).show();
        }

        // Agar koi challan currently screen par khula hai, usay bhi
        // turant naye rate ke sath dobara build kar dein.
        if (currentStudentIdx != -1 && currentStudentIdx < allNames.size()) {
            generateChallan(currentStudentIdx);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Detach the real-time listener so it doesn't keep firing after
        // this screen is closed.
        if (paymentConfigRef != null && paymentConfigListener != null) {
            paymentConfigRef.removeEventListener(paymentConfigListener);
        }
    }

    private void loadStudents() {
        FirebaseDatabase.getInstance().getReference("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        allNames.clear(); allUids.clear();
                        allClasses.clear(); allSubjects.clear();
                        allUsernames.clear();

                        for (DataSnapshot snap : snapshot.getChildren()) {
                            String role   = safeString(snap.child("role"));
                            String status = safeString(snap.child("status"));
                            if (!"Student".equalsIgnoreCase(role)) continue;
                            if (!"Approved".equalsIgnoreCase(status)) continue;

                            String name     = safeString(snap.child("name"));
                            String cls      = safeString(snap.child("className"));
                            String username = safeString(snap.child("username"));
                            if (name == null) continue;

                            List<String> subs = new ArrayList<>();
                            for (DataSnapshot s : snap.child("enrolledSubjects").getChildren()) {
                                String sub = safeString(s);
                                if (sub != null) subs.add(sub);
                            }

                            allNames.add(name);
                            allUids.add(snap.getKey());
                            allClasses.add(cls != null ? cls : "");
                            allSubjects.add(subs);
                            allUsernames.add(username != null ? username : "");
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                String q = s.toString().trim().toLowerCase();
                if (q.isEmpty()) { lvResults.setVisibility(View.GONE); return; }

                List<String> filtered = new ArrayList<>();
                List<Integer> indices = new ArrayList<>();
                for (int i = 0; i < allNames.size(); i++) {
                    if (allNames.get(i).toLowerCase().contains(q)) {
                        filtered.add(allNames.get(i) + " — Class " + allClasses.get(i));
                        indices.add(i);
                    }
                }
                if (filtered.isEmpty()) { lvResults.setVisibility(View.GONE); return; }

                lvResults.setAdapter(new ArrayAdapter<>(FeeChallanActivity.this,
                        android.R.layout.simple_list_item_1, filtered));
                lvResults.setVisibility(View.VISIBLE);

                lvResults.setOnItemClickListener((parent, view, pos, id) -> {
                    int idx = indices.get(pos);
                    etSearch.setText(allNames.get(idx));
                    lvResults.setVisibility(View.GONE);
                    generateChallan(idx);
                });
            }
        });
    }

    private void generateChallan(int idx) {
        // Remember which student is currently displayed so that if the
        // admin changes the fee later, this challan can auto-refresh.
        currentStudentIdx = idx;

        String name            = allNames.get(idx);
        String cls              = allClasses.get(idx);
        String uid              = allUids.get(idx);
        List<String> subjects  = allSubjects.get(idx);
        String studentUsername = allUsernames.get(idx);

        challanContainer.removeAllViews();

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, 15);
        String dueDate  = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(cal.getTime());
        String month    = new SimpleDateFormat("MMMM yyyy",  Locale.getDefault()).format(cal.getTime());
        String monthKey = month.replace(" ", "_");

        long baseFee = 0;
        // Subject-wise fee ka snapshot — isi ko Firebase mein save karenge
        // taake baad mein rate change hone par is challan ki breakdown
        // na badle (freeze at generation time).
        Map<String, Long> subjectFeeMap = new HashMap<>();
        for (String sub : subjects) {
            long f = getFeeForSubject(sub);
            subjectFeeMap.put(sub, f);
            baseFee += f;
        }
        final long finalBaseFee = baseFee;

        boolean isLate           = isPastDueDate(dueDate);
        final long fineAmount    = isLate ? LATE_FINE_AMOUNT : 0L;
        final long totalWithFine = finalBaseFee + fineAmount;

        Map<String, Object> challanData = new HashMap<>();
        challanData.put("studentName",   name);
        challanData.put("className",     cls);
        challanData.put("month",         month);
        challanData.put("dueDate",       dueDate);
        challanData.put("subjects",      subjects);
        challanData.put("feePerSubject", feePerSubject);
        challanData.put("totalSubjects", subjects.size());
        challanData.put("baseFee",       String.valueOf(finalBaseFee));
        challanData.put("lateFine",      String.valueOf(fineAmount));
        challanData.put("amount",        String.valueOf(totalWithFine));
        challanData.put("generatedAt",   System.currentTimeMillis());
        challanData.put("subjectFees",   subjectFeeMap);

        FirebaseDatabase.getInstance().getReference("Fees").child(uid).child(monthKey)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snap) {
                        String existingStatus = safeString(snap.child("status"));
                        boolean alreadyPaid = "Paid".equalsIgnoreCase(existingStatus);

                        Long paidAt = snap.child("paidAt").getValue(Long.class);
                        if (paidAt == null) paidAt = snap.child("savedAt").getValue(Long.class);

                        long displayTotal = totalWithFine;
                        long displayFine  = fineAmount;
                        boolean displayLate = isLate;

                        // Default breakdown = abhi ka live-computed map;
                        // agar challan pehle se Paid hai to neeche isay
                        // Firebase mein saved (purani) breakdown se replace
                        // kar denge, taake Paid challan ka display kabhi na badle.
                        Map<String, Long> displaySubjectFees = subjectFeeMap;

                        if (alreadyPaid) {
                            String savedAmount = safeString(snap.child("amount"));
                            if (savedAmount != null) {
                                try { displayTotal = Long.parseLong(savedAmount); } catch (Exception ignored) {}
                            }
                            String savedFineStr = safeString(snap.child("lateFine"));
                            if (savedFineStr != null) {
                                try { displayFine = Long.parseLong(savedFineStr); } catch (Exception ignored) {}
                            }
                            displayLate = displayFine > 0;

                            // Agar is record ka purana subjectFees Firebase
                            // mein maujood hai to wahi use karo (frozen values),
                            // warna (bohot purane records) live values par fallback.
                            Map<String, Long> savedSubjectFees = new HashMap<>();
                            for (DataSnapshot sf : snap.child("subjectFees").getChildren()) {
                                Long v = sf.getValue(Long.class);
                                if (v != null) savedSubjectFees.put(sf.getKey(), v);
                            }
                            if (!savedSubjectFees.isEmpty()) {
                                displaySubjectFees = savedSubjectFees;
                            }

                            challanData.put("amount",   String.valueOf(displayTotal));
                            challanData.put("lateFine", String.valueOf(displayFine));
                            // Paid challan ki purani breakdown/feePerSubject ko
                            // overwrite mat karo — sirf amount/lateFine sync karo.
                            challanData.remove("subjectFees");
                            challanData.remove("feePerSubject");
                            challanData.remove("baseFee");

                            Toast.makeText(FeeChallanActivity.this,
                                    "✅ " + name + "'s fee is already Paid.", Toast.LENGTH_SHORT).show();
                            FirebaseDatabase.getInstance().getReference("Fees")
                                    .child(uid).child(monthKey).updateChildren(challanData);

                        } else {
                            // ── Fee is unpaid — notify both the student and the parent ──
                            challanData.put("status", "Unpaid");
                            FirebaseDatabase.getInstance().getReference("Fees")
                                    .child(uid).child(monthKey)
                                    .setValue(challanData)
                                    .addOnSuccessListener(u -> {
                                        Toast.makeText(FeeChallanActivity.this,
                                                isLate
                                                        ? "✅ Challan saved for " + name + " (Late fine: Rs. " + fineAmount + ")"
                                                        : "✅ Challan saved for " + name,
                                                Toast.LENGTH_SHORT).show();

                                        // ✅ Notify the student
                                        sendNotificationToStudent(uid, name, month, totalWithFine, dueDate, isLate, fineAmount);

                                        // ✅ Notify the parent
                                        sendNotificationToParent(studentUsername, name, month, totalWithFine, dueDate, isLate, fineAmount);
                                    })
                                    .addOnFailureListener(e ->
                                            Toast.makeText(FeeChallanActivity.this,
                                                    "❌ Save failed: " + e.getMessage(),
                                                    Toast.LENGTH_SHORT).show());
                        }

                        buildChallanUI(name, cls, month, dueDate, subjects, finalBaseFee,
                                displayFine, displayTotal, displayLate, alreadyPaid, paidAt,
                                displaySubjectFees);
                        loadPaymentHistory(uid, challanContainer);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError e) {
                        Map<String, Object> safeUpdate = new HashMap<>();
                        safeUpdate.put("studentName",   name);
                        safeUpdate.put("className",     cls);
                        safeUpdate.put("month",         month);
                        safeUpdate.put("dueDate",       dueDate);
                        safeUpdate.put("subjects",      subjects);
                        safeUpdate.put("feePerSubject", feePerSubject);
                        safeUpdate.put("totalSubjects", subjects.size());
                        safeUpdate.put("baseFee",       String.valueOf(finalBaseFee));
                        safeUpdate.put("generatedAt",   System.currentTimeMillis());
                        safeUpdate.put("subjectFees",   subjectFeeMap);
                        FirebaseDatabase.getInstance().getReference("Fees")
                                .child(uid).child(monthKey).updateChildren(safeUpdate);

                        buildChallanUI(name, cls, month, dueDate, subjects, finalBaseFee,
                                fineAmount, totalWithFine, isLate, false, null,
                                subjectFeeMap);
                        loadPaymentHistory(uid, challanContainer);
                    }
                });
    }


    private void sendNotificationToStudent(String studentUid, String studentName,
                                           String month, long amount, String dueDate,
                                           boolean isLate, long fineAmount) {

        String message = isLate
                ? studentName + "'s fee for " + month + " is pending. Amount: Rs. " + amount
                + " (Late fine Rs. " + fineAmount + " included). Due Date: " + dueDate
                : studentName + "'s fee challan for " + month + " has been generated. "
                + "Amount: Rs. " + amount + ". Due Date: " + dueDate;

        Map<String, Object> notif = new HashMap<>();
        notif.put("title",       isLate ? "⚠️ Fee Overdue!" : "📋 Fee Challan Generated");
        notif.put("message",     message);
        notif.put("type",        "fee_pending");
        notif.put("studentName", studentName);
        notif.put("amount",      String.valueOf(amount));
        notif.put("dueDate",     dueDate);
        notif.put("month",       month);
        notif.put("isLate",      isLate);
        notif.put("lateFine",    String.valueOf(fineAmount));
        notif.put("timestamp",   System.currentTimeMillis());
        notif.put("isRead",      false);

        FirebaseDatabase.getInstance()
                .getReference("Notifications")
                .child(studentUid)
                .push()
                .setValue(notif);
    }


    private void sendNotificationToParent(String studentUsername, String studentName,
                                          String month, long amount, String dueDate,
                                          boolean isLate, long fineAmount) {

        if (studentUsername == null || studentUsername.trim().isEmpty()) return;

        FirebaseDatabase.getInstance().getReference("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot userSnap : snapshot.getChildren()) {
                            String role = safeString(userSnap.child("role"));
                            if (!"Parent".equalsIgnoreCase(role)) continue;

                            String linkedUsername = safeString(userSnap.child("linkedChildUsername"));
                            if (linkedUsername == null) continue;

                            if (!linkedUsername.trim().equalsIgnoreCase(studentUsername.trim())) continue;

                            String parentUid = userSnap.getKey();

                            String message = isLate
                                    ? "Your child " + studentName + "'s fee for " + month
                                    + " is still pending. Amount: Rs. " + amount
                                    + " (Late fine Rs. " + fineAmount + " included). Due Date: " + dueDate
                                    : "Your child " + studentName + "'s fee challan for " + month
                                    + " has been generated. "
                                    + "Amount: Rs. " + amount + ". Due Date: " + dueDate;

                            Map<String, Object> notif = new HashMap<>();
                            notif.put("title",       isLate ? "⚠️ Fee Overdue!" : "📋 Fee Challan Generated");
                            notif.put("message",     message);
                            notif.put("type",        "fee_pending");
                            notif.put("studentName", studentName);
                            notif.put("amount",      String.valueOf(amount));
                            notif.put("dueDate",     dueDate);
                            notif.put("month",       month);
                            notif.put("isLate",      isLate);
                            notif.put("lateFine",    String.valueOf(fineAmount));
                            notif.put("timestamp",   System.currentTimeMillis());
                            notif.put("isRead",      false);

                            FirebaseDatabase.getInstance()
                                    .getReference("Notifications")
                                    .child(parentUid)
                                    .push()
                                    .setValue(notif);
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    private void buildChallanUI(String name, String cls, String month, String dueDate,
                                List<String> subjects, long baseFee, long fineAmount,
                                long totalFee, boolean isLate, boolean isPaid, Long paidAt,
                                Map<String, Long> subjectFees) {

        CardView card = new CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, 0, 0, dp(16));
        card.setLayoutParams(cp);
        card.setRadius(dp(14));
        card.setCardElevation(dp(4));
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(18), dp(18), dp(18), dp(18));

        addRow(inner, "🏫 KIPS Coaching Kharian", null, 16f, Typeface.BOLD, 0xFF1565C0, 0xFF1565C0);
        addDivider(inner);
        addRow(inner, "FEE CHALLAN", null, 14f, Typeface.BOLD, 0xFF333333, 0xFF333333);
        addSpacer(inner, dp(10));

        addRow(inner, "Student Name:", name,                      13f, Typeface.NORMAL, 0xFF555555, 0xFF222222);
        addRow(inner, "Class:",        cls.isEmpty() ? "—" : cls, 13f, Typeface.NORMAL, 0xFF555555, 0xFF222222);
        addRow(inner, "Month:",        month,                     13f, Typeface.NORMAL, 0xFF555555, 0xFF222222);
        addRow(inner, "Due Date:",     dueDate,                   13f, Typeface.BOLD,   0xFFE53935, 0xFFE53935);
        addSpacer(inner, dp(12));

        TextView tvHeader = new TextView(this);
        tvHeader.setText("Subject-wise Fee Breakdown");
        tvHeader.setTextSize(13f);
        tvHeader.setTypeface(null, Typeface.BOLD);
        tvHeader.setTextColor(0xFF1565C0);
        LinearLayout.LayoutParams thp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        thp.setMargins(0, 0, 0, dp(8));
        tvHeader.setLayoutParams(thp);
        inner.addView(tvHeader);
        addDivider(inner);

        if (subjects.isEmpty()) {
            TextView tvNoSub = new TextView(this);
            tvNoSub.setText("No subjects enrolled.");
            tvNoSub.setTextSize(13f);
            tvNoSub.setTextColor(0xFF888888);
            tvNoSub.setPadding(0, dp(4), 0, dp(4));
            inner.addView(tvNoSub);
        } else {
            for (String sub : subjects) {
                // Pehle saved/snapshot map se fee lo (frozen value);
                // sirf agar map mein nahi mila to live rate par fallback karo.
                Long feeVal = (subjectFees != null) ? subjectFees.get(sub) : null;
                long feeToShow = (feeVal != null) ? feeVal : getFeeForSubject(sub);
                addRow(inner, sub, "Rs. " + feeToShow, 13f, Typeface.NORMAL, 0xFF333333, 0xFF1976D2);
            }
        }

        addDivider(inner);
        addSpacer(inner, dp(4));
        addRow(inner, "Total Subjects:", String.valueOf(subjects.size()), 13f, Typeface.BOLD,   0xFF333333, 0xFF333333);
        addRow(inner, "Subject Fee:",    "Rs. " + baseFee,                13f, Typeface.NORMAL, 0xFF555555, 0xFF333333);

        if (fineAmount > 0) {
            addRow(inner, "⚠ Late Fine:", "Rs. " + fineAmount, 13f, Typeface.BOLD, 0xFFE53935, 0xFFE53935);
        }

        addDivider(inner);
        addRow(inner, "Total Fee:", "Rs. " + totalFee, 15f, Typeface.BOLD, 0xFF222222, 0xFF2E7D32);
        addSpacer(inner, dp(12));
        addDivider(inner);

        // Status badge
        LinearLayout badgeRow = new LinearLayout(this);
        badgeRow.setOrientation(LinearLayout.HORIZONTAL);
        badgeRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        brp.setMargins(0, dp(10), 0, 0);
        badgeRow.setLayoutParams(brp);

        TextView tvStatusLabel = new TextView(this);
        tvStatusLabel.setText("Payment Status:");
        tvStatusLabel.setTextSize(13f);
        tvStatusLabel.setTextColor(0xFF555555);
        tvStatusLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvBadge = new TextView(this);
        tvBadge.setText(isPaid ? "✓ Paid" : (isLate ? "⏰ Unpaid (Overdue)" : "⏳ Unpaid"));
        tvBadge.setTextSize(12f);
        tvBadge.setTextColor(0xFFFFFFFF);
        tvBadge.setTypeface(null, Typeface.BOLD);
        tvBadge.setPadding(dp(14), dp(6), dp(14), dp(6));
        android.graphics.drawable.GradientDrawable badgeBg =
                new android.graphics.drawable.GradientDrawable();
        badgeBg.setColor(isPaid ? 0xFF43A047 : 0xFFE53935);
        badgeBg.setCornerRadius(dp(20));
        tvBadge.setBackground(badgeBg);
        badgeRow.addView(tvStatusLabel);
        badgeRow.addView(tvBadge);
        inner.addView(badgeRow);

        if (isPaid && paidAt != null && paidAt > 0) {
            TextView tvPaidOn = new TextView(this);
            tvPaidOn.setText("Paid on: " + new SimpleDateFormat(
                    "dd MMM yyyy, hh:mm a", Locale.getDefault()).format(new Date(paidAt)));
            tvPaidOn.setTextSize(12f);
            tvPaidOn.setTypeface(null, Typeface.BOLD);
            tvPaidOn.setTextColor(0xFF2E7D32);
            tvPaidOn.setPadding(0, dp(8), 0, 0);
            inner.addView(tvPaidOn);
        }

        TextView tvFooter = new TextView(this);
        if (isPaid) {
            tvFooter.setText("Fee per subject: Rs. " + feePerSubject + "  |  Thank you for your payment!");
        } else if (isLate) {
            tvFooter.setText("Fee per subject: Rs. " + feePerSubject
                    + "  |  The due date has passed — a Rs. " + LATE_FINE_AMOUNT + " fine has been applied.");
        } else {
            tvFooter.setText("Fee per subject: Rs. " + feePerSubject + "  |  Please pay by " + dueDate);
        }
        tvFooter.setTextSize(11f);
        tvFooter.setTextColor(0xFF888888);
        tvFooter.setPadding(0, dp(10), 0, 0);
        inner.addView(tvFooter);

        card.addView(inner);
        challanContainer.addView(card);
    }

    private void loadPaymentHistory(String uid, LinearLayout container) {
        FirebaseDatabase.getInstance().getReference("Fees").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (!snapshot.exists()) return;

                        CardView histCard = new CardView(FeeChallanActivity.this);
                        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        histCard.setLayoutParams(cp);
                        histCard.setRadius(dp(14));
                        histCard.setCardElevation(dp(2));
                        histCard.setCardBackgroundColor(0xFFFFFFFF);

                        LinearLayout inner2 = new LinearLayout(FeeChallanActivity.this);
                        inner2.setOrientation(LinearLayout.VERTICAL);
                        inner2.setPadding(dp(16), dp(14), dp(16), dp(14));

                        TextView tvHdr = new TextView(FeeChallanActivity.this);
                        tvHdr.setText("Payment History");
                        tvHdr.setTextSize(14f);
                        tvHdr.setTypeface(null, Typeface.BOLD);
                        tvHdr.setTextColor(0xFF333333);
                        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        hp.setMargins(0, 0, 0, dp(8));
                        tvHdr.setLayoutParams(hp);
                        inner2.addView(tvHdr);

                        for (DataSnapshot record : snapshot.getChildren()) {
                            String month  = safeString(record.child("month"));
                            String amount = safeString(record.child("amount"));
                            String status = safeString(record.child("status"));
                            String due    = safeString(record.child("dueDate"));
                            String fine   = safeString(record.child("lateFine"));
                            if (month == null) continue;

                            boolean isPaid     = "Paid".equalsIgnoreCase(status);
                            int badgeColor     = isPaid ? 0xFF43A047 : 0xFFE53935;
                            boolean hasFine    = fine != null && !fine.equals("0");

                            LinearLayout row = new LinearLayout(FeeChallanActivity.this);
                            row.setOrientation(LinearLayout.VERTICAL);
                            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                            rp.setMargins(0, 0, 0, dp(10));
                            row.setLayoutParams(rp);
                            row.setBackgroundColor(0xFFF9F9F9);
                            row.setPadding(dp(10), dp(8), dp(10), dp(8));

                            LinearLayout topRow = new LinearLayout(FeeChallanActivity.this);
                            topRow.setOrientation(LinearLayout.HORIZONTAL);
                            topRow.setGravity(Gravity.CENTER_VERTICAL);

                            TextView tvMonth = new TextView(FeeChallanActivity.this);
                            tvMonth.setText(month);
                            tvMonth.setTextSize(13f);
                            tvMonth.setTypeface(null, Typeface.BOLD);
                            tvMonth.setTextColor(0xFF333333);
                            tvMonth.setLayoutParams(new LinearLayout.LayoutParams(0,
                                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

                            TextView tvBadge2 = new TextView(FeeChallanActivity.this);
                            tvBadge2.setText(isPaid ? "✓ Paid" : "✗ Unpaid");
                            tvBadge2.setTextSize(11f);
                            tvBadge2.setTextColor(0xFFFFFFFF);
                            tvBadge2.setTypeface(null, Typeface.BOLD);
                            tvBadge2.setPadding(dp(10), dp(4), dp(10), dp(4));
                            android.graphics.drawable.GradientDrawable bg2 =
                                    new android.graphics.drawable.GradientDrawable();
                            bg2.setColor(badgeColor);
                            bg2.setCornerRadius(dp(20));
                            tvBadge2.setBackground(bg2);

                            topRow.addView(tvMonth);
                            topRow.addView(tvBadge2);

                            TextView tvDetail = new TextView(FeeChallanActivity.this);
                            Long paidAt = record.child("paidAt").getValue(Long.class);
                            if (paidAt == null) paidAt = record.child("savedAt").getValue(Long.class);
                            String paidDateStr = "";
                            if (isPaid && paidAt != null && paidAt > 0) {
                                paidDateStr = "  |  Paid: " + new SimpleDateFormat(
                                        "dd/MM/yyyy hh:mm a", Locale.getDefault())
                                        .format(new Date(paidAt));
                            }
                            String fineStr = hasFine ? "  |  Fine: Rs. " + fine : "";
                            tvDetail.setText("Amount: Rs. " + (amount != null ? amount : "—")
                                    + "   |   Due: " + (due != null ? due : "—")
                                    + fineStr + paidDateStr);
                            tvDetail.setTextSize(11f);
                            tvDetail.setTextColor(hasFine && !isPaid ? 0xFFE53935 : 0xFF666666);
                            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                            dlp.topMargin = dp(4);
                            tvDetail.setLayoutParams(dlp);

                            row.addView(topRow);
                            row.addView(tvDetail);
                            inner2.addView(row);
                        }

                        histCard.addView(inner2);
                        runOnUiThread(() -> container.addView(histCard));
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    private void addRow(LinearLayout parent, String label, String value,
                        float textSize, int style, int labelColor, int valueColor) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.setMargins(0, 0, 0, dp(4));
        row.setLayoutParams(rp);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(textSize);
        tvLabel.setTypeface(null, style);
        tvLabel.setTextColor(labelColor);
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(tvLabel);

        if (value != null) {
            TextView tvValue = new TextView(this);
            tvValue.setText(value);
            tvValue.setTextSize(textSize);
            tvValue.setTypeface(null, style);
            tvValue.setTextColor(valueColor);
            tvValue.setGravity(Gravity.END);
            row.addView(tvValue);
        }
        parent.addView(row);
    }

    private void addDivider(LinearLayout parent) {
        View v = new View(this);
        v.setBackgroundColor(0xFFEEEEEE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(0, dp(6), 0, dp(6));
        v.setLayoutParams(lp);
        parent.addView(v);
    }

    private void addSpacer(LinearLayout parent, int height) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, height));
        parent.addView(v);
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}