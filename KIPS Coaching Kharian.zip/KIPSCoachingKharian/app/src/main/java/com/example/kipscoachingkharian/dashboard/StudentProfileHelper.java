package com.example.kipscoachingkharian.dashboard;

import android.app.Activity;
import android.content.Intent;
import android.view.View;

public class StudentProfileHelper {

    public static void attach(Activity activity, int viewId) {
        View v = activity.findViewById(viewId);
        if (v != null) {
            v.setOnClickListener(x ->
                    activity.startActivity(new Intent(activity, StudentProfileInfoActivity.class)));
        }
    }
}
