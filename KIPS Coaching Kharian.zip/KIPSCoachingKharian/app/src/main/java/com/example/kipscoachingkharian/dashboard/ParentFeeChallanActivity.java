package com.example.kipscoachingkharian.dashboard;

import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Parent side — child ka fee challan (admin jaise format mein) view + print/save-PDF.
 * Data Fees/{childUid}/{monthKey} se aata hai (jo admin ne generate kiya).
 * Print ke liye Android ka built-in PrintManager (koi external library nahi) —
 * user system dialog se "Save as PDF" bhi kar sakta hai.
 *
 * Admin (FeeChallanActivity) jaisa hi logic:
 *  - Subject-wise breakdown: har subject apne rate ke saath (Urdu/Islamiyat/Pak Study
 *    special rate, baaki normal rate — payment_config se load hota hai).
 *  - Due date guzarne ke baad Unpaid challan par late fine display hoti hai.
 * NOTE: Yeh screen sirf READ karti hai — Firebase par koi write nahi karti.
 */
public class ParentFeeChallanActivity extends AppCompatActivity {

    private WebView webChallan;
    private ProgressBar challanProgress;
    private MaterialButton btnDownloadChallan;
    private ImageView ivBack;

    private String childUid, monthKey, childName = "Student";
    private boolean challanReady = false;

    // ── Admin (FeeChallanActivity) jaise fee rates — payment_config se update hote hain ──
    private long feePerSubject = 3000L;
    private long feeSpecial    = 2500L;

    private static final long LATE_FINE_AMOUNT = 200L;

    private static final java.util.Set<String> SPECIAL_SUBJECTS = new java.util.HashSet<>(
            java.util.Arrays.asList(
                    "urdu",
                    "pakistan studies", "pak studies", "pak study", "pakistan study", "p.st", "pst",
                    "islamiat", "islamic studies", "islamiyat", "islamiyat studies"
            ));

    private long getFeeForSubject(String subject) {
        if (subject == null) return feePerSubject;
        return SPECIAL_SUBJECTS.contains(subject.trim().toLowerCase()) ? feeSpecial : feePerSubject;
    }

    private boolean isPastDueDate(String dueDateStr) {
        if (dueDateStr == null || dueDateStr.isEmpty()) return false;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date dueDate = sdf.parse(dueDateStr);
            if (dueDate == null) return false;
            Calendar dueCal = Calendar.getInstance();
            dueCal.setTime(dueDate);
            dueCal.set(Calendar.HOUR_OF_DAY, 23);
            dueCal.set(Calendar.MINUTE, 59);
            dueCal.set(Calendar.SECOND, 59);
            return new Date().after(dueCal.getTime());
        } catch (ParseException e) {
            return false;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_fee_challan);

        webChallan         = findViewById(R.id.webChallan);
        challanProgress    = findViewById(R.id.challanProgress);
        btnDownloadChallan = findViewById(R.id.btnDownloadChallan);
        ivBack             = findViewById(R.id.ivBack);

        if (ivBack != null) ivBack.setOnClickListener(v -> finish());

        childUid = getIntent().getStringExtra("child_uid");
        String month = getIntent().getStringExtra("fee_month");
        monthKey = (month != null) ? month.trim().replace(" ", "_") : "";

        if (btnDownloadChallan != null) {
            btnDownloadChallan.setEnabled(false);
            btnDownloadChallan.setOnClickListener(v -> printChallan());
        }

        if (childUid == null || childUid.isEmpty() || monthKey.isEmpty()) {
            Toast.makeText(this, "Challan data not available", Toast.LENGTH_LONG).show();
            return;
        }
        loadFeeConfig();
    }

    /** Admin jaisa: payment_config se per-subject rates load karo, phir challan load karo. */
    private void loadFeeConfig() {
        if (challanProgress != null) challanProgress.setVisibility(View.VISIBLE);
        FirebaseDatabase.getInstance().getReference("payment_config")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snap) {
                        if (snap.hasChild("fee_per_subject")) {
                            Long f = snap.child("fee_per_subject").getValue(Long.class);
                            if (f != null) feePerSubject = f;
                        }
                        if (snap.hasChild("fee_special_subject")) {
                            Long f = snap.child("fee_special_subject").getValue(Long.class);
                            if (f != null) feeSpecial = f;
                        }
                        loadChallan();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {
                        // Config na mile to bhi default rates ke saath challan dikhao
                        loadChallan();
                    }
                });
    }

    private void loadChallan() {
        if (challanProgress != null) challanProgress.setVisibility(View.VISIBLE);

        FirebaseDatabase.getInstance().getReference("Fees")
                .child(childUid).child(monthKey)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snap) {
                        if (challanProgress != null) challanProgress.setVisibility(View.GONE);
                        if (!snap.exists()) {
                            Toast.makeText(ParentFeeChallanActivity.this,
                                    "No challan found for this month", Toast.LENGTH_LONG).show();
                            return;
                        }
                        String html = buildChallanHtml(snap);
                        if (webChallan != null) {
                            webChallan.setWebViewClient(new WebViewClient() {
                                @Override public void onPageFinished(WebView view, String url) {
                                    challanReady = true;
                                    if (btnDownloadChallan != null) btnDownloadChallan.setEnabled(true);
                                }
                            });
                            webChallan.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {
                        if (challanProgress != null) challanProgress.setVisibility(View.GONE);
                        Toast.makeText(ParentFeeChallanActivity.this,
                                "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private String val(DataSnapshot snap, String key, String def) {
        Object o = snap.child(key).getValue();
        return o != null ? o.toString() : def;
    }

    private String buildChallanHtml(DataSnapshot snap) {
        childName          = val(snap, "studentName", "Student");
        String className   = val(snap, "className", "-");
        String month       = val(snap, "month", monthKey.replace("_", " "));
        String dueDate     = val(snap, "dueDate", "-");
        String baseFee     = val(snap, "baseFee", "0");
        String lateFine    = val(snap, "lateFine", "0");
        String amount      = val(snap, "amount", "0");
        String status      = val(snap, "status", "Unpaid");

        boolean paid = "Paid".equalsIgnoreCase(status);

        // ── Subject-wise breakdown (admin jaisa): har subject apne rate ke saath ──
        StringBuilder subjectRows = new StringBuilder();
        long computedBase = 0;
        int subjCount = 0;
        DataSnapshot subjectsSnap = snap.child("subjects");
        if (subjectsSnap.exists()) {
            for (DataSnapshot s : subjectsSnap.getChildren()) {
                String sub = s.getValue() != null ? s.getValue().toString() : null;
                if (sub == null || sub.isEmpty()) continue;
                long subFee = getFeeForSubject(sub);
                computedBase += subFee;
                subjCount++;
                subjectRows.append("<tr><td>").append(escape(sub))
                        .append("</td><td style='text-align:right;color:#1976D2'>Rs. ")
                        .append(subFee).append("</td></tr>");
            }
        }

        // Base fee: stored value prefer karo; agar missing/0 ho to subjects se compute
        long baseFeeL = parseLong(baseFee);
        if (baseFeeL <= 0 && computedBase > 0) baseFeeL = computedBase;

        // ── Late fine (admin jaisa live check): Unpaid + due date guzar gayi → fine ──
        long fineL = parseLong(lateFine);
        boolean isLate = !paid && isPastDueDate(dueDate);
        if (!paid && isLate && fineL <= 0) fineL = LATE_FINE_AMOUNT;

        // ── Total: Paid ho to stored amount hi final; Unpaid ho to base + fine ──
        long totalL;
        if (paid) {
            totalL = parseLong(amount);
            if (totalL <= 0) totalL = baseFeeL + fineL;
        } else {
            totalL = baseFeeL + fineL;
        }

        // Paid on timestamp (admin jaisa)
        Long paidAt = snap.child("paidAt").getValue(Long.class);
        if (paidAt == null) paidAt = snap.child("savedAt").getValue(Long.class);
        String paidOnStr = "";
        if (paid && paidAt != null && paidAt > 0) {
            paidOnStr = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                    .format(new Date(paidAt));
        }

        // Status badge (admin jaisa: Paid / Unpaid (Overdue) / Unpaid)
        String statusText  = paid ? "✓ Paid" : (isLate ? "⏰ Unpaid (Overdue)" : "⏳ Unpaid");
        String statusColor = paid ? "#43A047" : "#E53935";

        // Footer (admin jaisa)
        String footer;
        if (paid) {
            footer = "Fee per subject: Rs. " + feePerSubject + "  |  Thank you for your payment!";
        } else if (isLate) {
            footer = "Fee per subject: Rs. " + feePerSubject
                    + "  |  Due date has passed — Rs. " + LATE_FINE_AMOUNT + " late fine has been applied.";
        } else {
            footer = "Fee per subject: Rs. " + feePerSubject + "  |  Please pay by " + escape(dueDate);
        }

        // ── Summary rows (breakdown table ke neeche) ──
        StringBuilder summaryRows = new StringBuilder();
        summaryRows.append("<tr><td><b>Total Subjects</b></td><td style='text-align:right'><b>")
                .append(subjCount).append("</b></td></tr>");
        summaryRows.append("<tr><td>Subject Fee</td><td style='text-align:right'>Rs. ")
                .append(baseFeeL).append("</td></tr>");
        if (fineL > 0) {
            summaryRows.append("<tr><td style='color:#E53935'><b>⚠ Late Fine</b></td>")
                    .append("<td style='text-align:right;color:#E53935'><b>Rs. ")
                    .append(fineL).append("</b></td></tr>");
        }

        return "<!DOCTYPE html><html><head><meta name='viewport' "
                + "content='width=device-width, initial-scale=1'>"
                + "<style>"
                + "body{font-family:sans-serif;color:#222;margin:0;padding:18px;}"
                + ".hd{text-align:center;border-bottom:2px solid #1565C0;padding-bottom:10px;margin-bottom:14px;}"
                + ".hd h2{margin:0;color:#1565C0;}"
                + ".hd p{margin:2px 0;font-size:13px;color:#333;font-weight:bold;}"
                + ".info{font-size:14px;margin:4px 0;}"
                + ".info b{display:inline-block;width:110px;color:#555;}"
                + ".due{color:#E53935;font-weight:bold;}"
                + ".sec{font-size:14px;font-weight:bold;color:#1565C0;margin-top:12px;}"
                + "table{width:100%;border-collapse:collapse;margin-top:8px;font-size:14px;}"
                + "th,td{border:1px solid #ddd;padding:8px;}"
                + "th{background:#E8F0FB;color:#1565C0;text-align:left;}"
                + ".total{font-size:18px;font-weight:bold;margin-top:14px;text-align:right;color:#2E7D32;}"
                + ".status{display:inline-block;margin-top:10px;padding:5px 14px;border-radius:20px;"
                + "color:#fff;font-weight:bold;background:" + statusColor + ";}"
                + ".paidon{margin-top:8px;font-size:13px;font-weight:bold;color:#2E7D32;}"
                + ".foot{margin-top:10px;font-size:11px;color:#888;}"
                + "</style></head><body>"
                + "<div class='hd'><h2>🏫 KIPS Coaching Kharian</h2><p>FEE CHALLAN</p></div>"
                + "<p class='info'><b>Student Name:</b> " + escape(childName) + "</p>"
                + "<p class='info'><b>Class:</b> " + escape(className) + "</p>"
                + "<p class='info'><b>Month:</b> " + escape(month) + "</p>"
                + "<p class='info'><b>Due Date:</b> <span class='due'>" + escape(dueDate) + "</span></p>"
                + "<p class='sec'>Subject-wise Fee Breakdown</p>"
                + "<table><tr><th>Subject</th><th style='text-align:right'>Amount</th></tr>"
                + (subjectRows.length() > 0 ? subjectRows.toString()
                : "<tr><td colspan='2'>No subjects enrolled.</td></tr>")
                + summaryRows + "</table>"
                + "<p class='total'>Total Fee: Rs. " + totalL + "</p>"
                + "<span class='status'>" + statusText + "</span>"
                + (paidOnStr.isEmpty() ? "" : "<p class='paidon'>Paid on: " + paidOnStr + "</p>")
                + "<p class='foot'>" + footer + "</p>"
                + "</body></html>";
    }

    private void printChallan() {
        if (!challanReady || webChallan == null) {
            Toast.makeText(this, "Challan is loading, please wait...", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
            if (printManager == null) {
                Toast.makeText(this, "Print service not available", Toast.LENGTH_SHORT).show();
                return;
            }
            String jobName = "FeeChallan_" + childName.replace(" ", "_") + "_" + monthKey;
            PrintDocumentAdapter adapter = webChallan.createPrintDocumentAdapter(jobName);
            printManager.print(jobName, adapter, new PrintAttributes.Builder().build());
            // System dialog khulega — wahan se "Save as PDF" bhi ho sakta hai
        } catch (Exception e) {
            Toast.makeText(this, "Print error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private long parseLong(String s) {
        if (s == null || s.trim().isEmpty()) return 0;
        try { return Long.parseLong(s.trim()); }
        catch (NumberFormatException e) { return 0; }
    }
}