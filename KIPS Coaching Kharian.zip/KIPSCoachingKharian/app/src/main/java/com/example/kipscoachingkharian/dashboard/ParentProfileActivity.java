package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.ParentLoginActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashSet;
import java.util.Set;

public class ParentProfileActivity extends AppCompatActivity {

    private TextView tvName, tvProfileInitial, tvRole;
    private LinearLayout itemMyProfile, itemNotifications, itemSettings, itemHelp, itemLogout;
    private View dotNewAnnouncement;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    // registrationId — Intent se aaye ya Firebase se fetch ho
    private String registrationId = "";

    // ── Naya-announcement dot ke liye seen-prefs (same prefs jo ParentAnnouncementsActivity use karti hai) ──
    private static final String SEEN_PREFS_NAME = "parent_notif_prefs";
    private String seenKeysPrefKey = "seen_keys";
    private String deletedKeysPrefKey = "deleted_keys";
    private String myParentUidForDot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_profile);

        mAuth     = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Agar Dashboard ne pass kiya ho to seedha le lo
        if (getIntent().hasExtra("STUDENT_ID")) {
            registrationId = getIntent().getStringExtra("STUDENT_ID");
        }

        tvName           = findViewById(R.id.tv_name);
        tvProfileInitial = findViewById(R.id.tv_profile_initial);
        tvRole           = findViewById(R.id.tv_role);
        itemMyProfile    = findViewById(R.id.item_my_profile);
        itemNotifications= findViewById(R.id.item_notifications);
        itemSettings     = findViewById(R.id.item_settings);
        itemHelp         = findViewById(R.id.item_help);
        itemLogout       = findViewById(R.id.item_logout);
        dotNewAnnouncement = findViewById(R.id.dot_yellow); // layout me add karein

        if (mAuth.getCurrentUser() != null) {
            myParentUidForDot = mAuth.getCurrentUser().getUid();
            seenKeysPrefKey    = "seen_keys_" + myParentUidForDot;
            deletedKeysPrefKey = "deleted_keys_" + myParentUidForDot;
        }

        loadParentProfile();   // name + registrationId dono fetch hoga
        setupClickListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkForNewAnnouncementDot();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Yellow dot: Announcements/Parents (flat list) me koi aisa item check karta
    // hai jo is child ke liye ho (registrationId match ya General/blank) aur
    // seen/deleted prefs me na ho. Baqi koi working nahi cheri — sirf dot show/hide.
    // ─────────────────────────────────────────────────────────────────────────
    private void checkForNewAnnouncementDot() {
        if (dotNewAnnouncement == null || myParentUidForDot == null) return;
        if (registrationId == null || registrationId.isEmpty()) return; // abhi profile load nahi hui

        mDatabase.child("Announcements").child("Parents")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        SharedPreferences seenPrefs = getSharedPreferences(SEEN_PREFS_NAME, MODE_PRIVATE);
                        Set<String> seenKeys = seenPrefs.getStringSet(seenKeysPrefKey, new HashSet<>());
                        Set<String> deletedKeys = seenPrefs.getStringSet(deletedKeysPrefKey, new HashSet<>());

                        boolean hasUnseen = false;
                        for (DataSnapshot snap : snapshot.getChildren()) {
                            String targetId = snap.child("registrationId").getValue(String.class);
                            String type     = snap.child("type").getValue(String.class);

                            // ✅ ParentAnnouncementsActivity ki list wale bilkul isi rule ke
                            // mutabiq — "fee_confirmation" (personal) type agar bina
                            // registrationId ke ho to woh list mein kabhi dikhti hi nahi,
                            // is liye dot check mein bhi usay "unseen" mat gino — warna
                            // dot hamesha lage rahega kyunke user usay click hi nahi kar
                            // sakta (kabhi seen mark nahi hogi).
                            boolean isPersonalType = "fee_confirmation".equalsIgnoreCase(type);
                            boolean hasTarget = targetId != null && !targetId.isEmpty();

                            boolean isForMyChild = hasTarget
                                    ? targetId.equals(registrationId)
                                    : !isPersonalType;
                            if (!isForMyChild) continue;

                            String key = snap.getKey();
                            if (!seenKeys.contains(key) && !deletedKeys.contains(key)) {
                                hasUnseen = true;
                                break;
                            }
                        }
                        dotNewAnnouncement.setVisibility(hasUnseen ? View.VISIBLE : View.GONE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // dot ka error baqi profile screen ko affect nahi karega
                    }
                });
    }

    private void loadParentProfile() {
        if (mAuth.getCurrentUser() == null) return;
        String uid = mAuth.getCurrentUser().getUid();

        mDatabase.child("Users").child(uid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) return;

                String name = snapshot.child("name").getValue(String.class);
                if (name != null && !name.isEmpty()) {
                    tvName.setText(name);
                    tvProfileInitial.setText(name.trim().substring(0, 1).toUpperCase());
                }

                String role = snapshot.child("role").getValue(String.class);
                tvRole.setText(role != null ? role : "Parent Account");

                // registrationId — Intent se na mila ho to Firebase se lo
                if (registrationId == null || registrationId.isEmpty()) {
                    String idFromDb = snapshot.child("registrationId").getValue(String.class);
                    if (idFromDb != null) registrationId = idFromDb;
                }

                // registrationId ab mil gayi, dot dobara check kar lo (onResume race-condition fix)
                checkForNewAnnouncementDot();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ParentProfileActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupClickListeners() {

        itemMyProfile.setOnClickListener(v ->
                startActivity(new Intent(this, ParentInfoDetailsActivity.class)));

        // ── Notifications → ParentAnnouncementsActivity with STUDENT_ID ─────────
        itemNotifications.setOnClickListener(v -> {
            if (registrationId == null || registrationId.isEmpty()) {
                Toast.makeText(this, "Fetching student data... please wait.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (dotNewAnnouncement != null) dotNewAnnouncement.setVisibility(View.GONE);
            Intent intent = new Intent(this, ParentAnnouncementsActivity.class);
            intent.putExtra("STUDENT_ID", registrationId);
            startActivity(intent);
        });

        itemSettings.setOnClickListener(v ->
                startActivity(new Intent(this, ParentSettingActivity.class)));

        itemHelp.setOnClickListener(v ->
                startActivity(new Intent(this, ParentHelpActivity.class)));

        itemLogout.setOnClickListener(v -> showLogoutConfirmation());
    }

    private void showLogoutConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to log out?")
                .setPositiveButton("Yes, Logout", (d, w) -> logoutUser())
                .setNegativeButton("No", null)
                .show();
    }

    private void logoutUser() {
        mAuth.signOut();
        getSharedPreferences("UserPrefs", MODE_PRIVATE).edit().clear().apply();
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, ParentLoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}