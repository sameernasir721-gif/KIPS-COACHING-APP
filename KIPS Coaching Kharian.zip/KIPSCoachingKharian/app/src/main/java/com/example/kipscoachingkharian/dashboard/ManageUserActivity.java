package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.example.kipscoachingkharian.R;

public class ManageUserActivity extends AppCompatActivity {

    private CardView cardManageStudent, cardManageTeacher, cardManageParent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_user);

        setupBackButton();

        cardManageStudent = findViewById(R.id.cardManageStudent);
        cardManageTeacher = findViewById(R.id.cardManageTeacher);
        cardManageParent  = findViewById(R.id.cardManageParent);


        cardManageStudent.setOnClickListener(v -> {
            Intent intent = new Intent(ManageUserActivity.this, ManageStudentActivity.class);
            startActivity(intent);
        });


        cardManageTeacher.setOnClickListener(v -> {
            Intent intent = new Intent(ManageUserActivity.this, ManageTeacherActivity.class);
            startActivity(intent);
        });


        cardManageParent.setOnClickListener(v -> {
            Intent intent = new Intent(ManageUserActivity.this, ManageParentsActivity.class);
            startActivity(intent);
        });
    }

    // ── Back button (already in XML, only logic here) ─────────────────────────
    private void setupBackButton() {
        // Replace with your real id, e.g. R.id.btnBack, and delete the loop below
        // View btnBack = findViewById(R.id.btnBack);

        // Tries common ids automatically, so it works even if the name differs
        String[] ids = {"btnBack", "backButton", "btnBackParent", "ivBack",
                "imgBack", "back_button", "btn_back", "ibBack"};
        View btnBack = null;
        for (String name : ids) {
            int resId = getResources().getIdentifier(name, "id", getPackageName());
            if (resId != 0) {
                btnBack = findViewById(resId);
                if (btnBack != null) break;
            }
        }
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());
    }
}