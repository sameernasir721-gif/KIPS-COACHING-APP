package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.example.kipscoachingkharian.R;

public class ManageUserActivity extends AppCompatActivity {

    private CardView cardManageStudent, cardManageTeacher, cardManageParent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_user);

        // 1. XML Views ko Java ke sath bind (initialize) karna
        cardManageStudent = findViewById(R.id.cardManageStudent);
        cardManageTeacher = findViewById(R.id.cardManageTeacher);
        cardManageParent  = findViewById(R.id.cardManageParent);

        // 2. Student Card Click: Yeh pehle 3 cards wali selection screen (StudentCategoryActivity) par le kar jayega
        cardManageStudent.setOnClickListener(v -> {
            Intent intent = new Intent(ManageUserActivity.this, ManageStudentActivity.class);
            startActivity(intent);
        });

        // 3. Teacher Card Click: Yeh direct AddTeacherActivity par le kar jayega
        cardManageTeacher.setOnClickListener(v -> {
            Intent intent = new Intent(ManageUserActivity.this, ManageTeacherActivity.class);
            startActivity(intent);
        });

        // 4. Parent Card Click: Yeh direct ManageParentRequestsActivity par le kar jayega
        cardManageParent.setOnClickListener(v -> {
            Intent intent = new Intent(ManageUserActivity.this, ManageParentsActivity.class);
            startActivity(intent);
        });
    }
}
