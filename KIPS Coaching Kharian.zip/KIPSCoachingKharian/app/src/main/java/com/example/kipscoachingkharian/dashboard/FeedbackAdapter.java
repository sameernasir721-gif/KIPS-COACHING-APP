package com.example.kipscoachingkharian.dashboard;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;

import java.util.ArrayList;

public class FeedbackAdapter extends RecyclerView.Adapter<FeedbackAdapter.ViewHolder> {

    private final ArrayList<FeedbackModel> list;

    public FeedbackAdapter(ArrayList<FeedbackModel> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_student_feedback, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FeedbackModel model = list.get(position);

        // Name
        if (model.getName() != null) {
            holder.tvName.setText(model.getName());
            // First letter as avatar
            holder.tvInitials.setText(model.getName().substring(0, 1).toUpperCase());
        }

        // Feedback body
        holder.tvFeedbackBody.setText(model.getFeedback());

        // Date/Time
        holder.tvDate.setText(model.getTimestamp());

        // Rating
        float rating = model.getRating();
        holder.rbRating.setRating(rating);
        holder.tvRatingValue.setText(String.format(java.util.Locale.ENGLISH, "%.1f", rating));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView  tvInitials, tvName, tvDate, tvFeedbackBody, tvRatingValue;
        RatingBar rbRating;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvInitials      = itemView.findViewById(R.id.tvStudentInitials);
            tvName          = itemView.findViewById(R.id.tvStudentName);
            tvDate          = itemView.findViewById(R.id.tvDate);
            tvFeedbackBody  = itemView.findViewById(R.id.tvStudentFeedbackBody);
            tvRatingValue   = itemView.findViewById(R.id.tvRatingValue);
            rbRating        = itemView.findViewById(R.id.rbStudentRating);
        }
    }
}
