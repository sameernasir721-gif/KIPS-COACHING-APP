package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Toast;

import android.Manifest;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.kipscoachingkharian.R;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ParentDashboardActivity extends AppCompatActivity {

    private LinearLayout parentprofileBtn, homeTab, profileTab;
    private MaterialCardView cardChildAccount, cardCommunication, cardFeePayment,
            cardFeedback, cardAnnouncements; // ← announcements card added

    private String registrationId = "";
    private String myName = "Parent";
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_dashboard);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (getIntent().hasExtra("REGISTRATION_ID")) {
            registrationId = getIntent().getStringExtra("REGISTRATION_ID");
        }

        initViews();

        if (currentUser != null) {
            mDatabase = FirebaseDatabase.getInstance().getReference("Users").child(currentUser.getUid());
            fetchParentData();
        } else {
            Toast.makeText(this, "Session Expired!", Toast.LENGTH_SHORT).show();
            finish();
        }

        setupClickListeners();

        requestNotificationPermissionIfNeeded();
    }

    // ── Android 13+ par popup notifications dikhane ke liye permission zaroori hai ──
    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
    }

    private void initViews() {
        parentprofileBtn  = findViewById(R.id.parentprofile);
        cardChildAccount  = findViewById(R.id.cardChildAccount);
        cardCommunication = findViewById(R.id.cardCommunication);
        cardFeePayment    = findViewById(R.id.cardFeePayment);
        cardFeedback      = findViewById(R.id.cardFeedback);
        cardAnnouncements = findViewById(R.id.cardAnnouncements); // ← must match your XML id
        homeTab           = findViewById(R.id.llHomeTab);
        profileTab        = findViewById(R.id.llProfileTab);
    }

    private void fetchParentData() {
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String idFromDb = snapshot.child("registrationId").getValue(String.class);
                    if (idFromDb != null) registrationId = idFromDb;

                    String nameFromDb = snapshot.child("name").getValue(String.class);
                    if (nameFromDb != null) myName = nameFromDb;
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void setupClickListeners() {

        // Child Account Card
        cardChildAccount.setOnClickListener(v -> {
            if (isValidSession()) {
                Intent intent = new Intent(this, ChildDetailInfoActivity.class);
                intent.putExtra("STUDENT_ID", registrationId);
                startActivity(intent);
            }
        });

        // ── Announcements Card → ParentAnnouncementsActivity ──────────────────
        if (cardAnnouncements != null) {
            cardAnnouncements.setOnClickListener(v -> {
                if (isValidSession()) {
                    Intent intent = new Intent(this, ParentAnnouncementsActivity.class);
                    intent.putExtra("STUDENT_ID", registrationId); // same key as ChildDetailInfoActivity
                    startActivity(intent);
                }
            });
        }

        // Communication Card
        cardCommunication.setOnClickListener(v -> {
            Intent intent = new Intent(this, ParentCommunicationActivity.class);
            intent.putExtra("MY_NAME", myName);
            intent.putExtra("MY_ROLE", "Parent");
            intent.putExtra("STUDENT_ID", registrationId);
            startActivity(intent);
        });

        // Fee Payment Card
        cardFeePayment.setOnClickListener(v -> {
            if (isValidSession()) {
                Intent intent = new Intent(this, PaymentActivity.class);
                intent.putExtra("STUDENT_ID", registrationId);
                startActivity(intent);
            }
        });

        // Feedback Card
        cardFeedback.setOnClickListener(v -> {
            if (isValidSession()) {
                Intent intent = new Intent(this, ParentFeedbackActivity.class);
                intent.putExtra("STUDENT_ID", registrationId);
                startActivity(intent);
            }
        });

        // Profile Buttons
        parentprofileBtn.setOnClickListener(v -> openProfile());
        profileTab.setOnClickListener(v -> openProfile());
        homeTab.setOnClickListener(v ->
                Toast.makeText(this, "You are at Home", Toast.LENGTH_SHORT).show());
    }

    private void openProfile() {
        if (isValidSession()) {
            Intent intent = new Intent(this, ParentProfileActivity.class);
            intent.putExtra("STUDENT_ID", registrationId);
            startActivity(intent);
        }
    }

    private boolean isValidSession() {
        if (registrationId == null || registrationId.isEmpty()) {
            Toast.makeText(this, "Fetching Student Data... Please wait.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}