package com.example.kipscoachingkharian.dashboard;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

/**
 * Activity representing the dashboard for Parents.
 * Features a unique logic to link and display data from a specific Student account
 * based on the phone number provided during registration.
 */
public class ParentDashboardActivity extends AppCompatActivity {

    private TextView tvChildName;
    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_dashboard);

        // Initialize UI components
        tvChildName = findViewById(R.id.tvChildName);
        btnLogout = findViewById(R.id.btnLogout);

        // Initiate the process to find and display the linked child's information
        fetchChildInfo();

        // Handle Logout
        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Toast.makeText(this, "Logged Out", Toast.LENGTH_SHORT).show();

            // Return to login selection and clear the activity stack
            Intent intent = new Intent(ParentDashboardActivity.this, LoginSelectionActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    /**
     * Step 1: Retrieve the Parent's own profile.
     * We need to get the 'linkedChildPhone' stored in the parent's node.
     */
    private void fetchChildInfo() {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            // Extract the phone number of the child entered during registration
                            String phone = snapshot.child("linkedChildPhone").getValue(String.class);

                            if (phone != null && !phone.isEmpty()) {
                                // If phone exists, proceed to Step 2 to find the student
                                findChildUid(phone);
                            } else {
                                tvChildName.setText("No Child Linked");
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(ParentDashboardActivity.this, "Error fetching profile", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    /**
     * Step 2: Search the database for the Student using the phone number.
     * Since we don't have the Child's UID directly, we query by the 'phone' field.
     * @param phone The phone number retrieved from the Parent's profile.
     */
    private void findChildUid(String phone) {
        // Query the "Users" node where the "phone" field matches the provided number
        FirebaseDatabase.getInstance().getReference("Users")
                .orderByChild("phone")
                .equalTo(phone)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            // Loop through results (should be unique ideally)
                            for (DataSnapshot ds : snapshot.getChildren()) {
                                String childName = ds.child("name").getValue(String.class);
                                tvChildName.setText("Student: " + childName);

                                // Once found, we can store the Child's UID for future data fetching (e.g., results)
                                // String childUid = ds.getKey();
                                return;
                            }
                        } else {
                            tvChildName.setText("Child Account Not Found (Check Phone Number)");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(ParentDashboardActivity.this, "Database Error", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}