package com.example.kipscoachingkharian.dashboard;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.view.View;

import android.Manifest;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.example.kipscoachingkharian.R;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ParentDashboardActivity extends AppCompatActivity {

    private LinearLayout parentprofileBtn, homeTab, profileTab;
    private MaterialCardView cardChildAccount, cardCommunication, cardFeePayment,
            cardFeedback, cardAnnouncements;
    private View dotCommunication;

    private String registrationId = "";
    private String myName = "Parent";
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    private static final String ANN_CHANNEL_ID = "parent_announcement_channel";
    private static final String TAG = "ParentAnnNotif";
    private static int annNotifId = 2000;
    private final List<DatabaseReference> watchedRefs = new ArrayList<>();
    private final List<ChildEventListener> watchers = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_dashboard);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (getIntent().hasExtra("REGISTRATION_ID")) {
            registrationId = getIntent().getStringExtra("REGISTRATION_ID");
        }

        initViews();
        attachUnreadDotListener();

        if (currentUser != null) {
            mDatabase = FirebaseDatabase.getInstance().getReference("Users").child(currentUser.getUid());
            fetchParentData();
        } else {
            Toast.makeText(this, "Session Expired!", Toast.LENGTH_SHORT).show();
            finish();
        }

        setupClickListeners();

        requestNotificationPermissionIfNeeded();
        createAnnouncementChannel();
        startAnnouncementNotifications();
    }


    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
    }


    private void attachUnreadDotListener() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null || dotCommunication == null) return;
        FirebaseDatabase.getInstance().getReference("ConversationIndex")
                .child(user.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        boolean hasUnread = false;
                        for (DataSnapshot conv : snapshot.getChildren()) {
                            Integer u = conv.child("unreadCount").getValue(Integer.class);
                            if (u != null && u > 0) { hasUnread = true; break; }
                        }
                        dotCommunication.setVisibility(hasUnread ? View.VISIBLE : View.GONE);
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    private void initViews() {
        parentprofileBtn  = findViewById(R.id.parentprofile);
        cardChildAccount  = findViewById(R.id.cardChildAccount);
        cardCommunication = findViewById(R.id.cardCommunication);
        dotCommunication = findViewById(R.id.dotCommunication);
        cardFeePayment    = findViewById(R.id.cardFeePayment);
        cardFeedback      = findViewById(R.id.cardFeedback);
        cardAnnouncements = findViewById(R.id.cardAnnouncements);
        homeTab           = findViewById(R.id.llHomeTab);
        profileTab        = findViewById(R.id.llProfileTab);
    }

    private void fetchParentData() {
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String idFromDb = snapshot.child("registrationId").getValue(String.class);
                    if (idFromDb != null) registrationId = idFromDb;

                    String nameFromDb = snapshot.child("name").getValue(String.class);
                    if (nameFromDb != null) myName = nameFromDb;
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void setupClickListeners() {


        cardChildAccount.setOnClickListener(v -> {
            if (isValidSession()) {
                Intent intent = new Intent(this, ChildDetailInfoActivity.class);
                intent.putExtra("STUDENT_ID", registrationId);
                startActivity(intent);
            }
        });


        if (cardAnnouncements != null) {
            cardAnnouncements.setOnClickListener(v -> {
                if (isValidSession()) {
                    Intent intent = new Intent(this, ParentAnnouncementsActivity.class);
                    intent.putExtra("STUDENT_ID", registrationId);
                    startActivity(intent);
                }
            });
        }

        cardCommunication.setOnClickListener(v -> {
            Intent intent = new Intent(this, ParentCommunicationActivity.class);
            intent.putExtra("MY_NAME", myName);
            intent.putExtra("MY_ROLE", "Parent");
            intent.putExtra("STUDENT_ID", registrationId);
            startActivity(intent);
        });


        cardFeePayment.setOnClickListener(v -> {
            if (isValidSession()) {
                Intent intent = new Intent(this, ParentFeeActivity.class);
                intent.putExtra("STUDENT_ID", registrationId);
                startActivity(intent);
            }
        });


        cardFeedback.setOnClickListener(v -> {
            if (isValidSession()) {
                Intent intent = new Intent(this, ParentFeedbackActivity.class);
                intent.putExtra("STUDENT_ID", registrationId);
                startActivity(intent);
            }
        });


        parentprofileBtn.setOnClickListener(v -> openProfile());
        profileTab.setOnClickListener(v -> openProfile());
        homeTab.setOnClickListener(v ->
                Toast.makeText(this, "You are at Home", Toast.LENGTH_SHORT).show());
    }

    private void openProfile() {
        if (isValidSession()) {
            Intent intent = new Intent(this, ParentProfileActivity.class);
            intent.putExtra("STUDENT_ID", registrationId);
            startActivity(intent);
        }
    }

    private boolean isValidSession() {
        if (registrationId == null || registrationId.isEmpty()) {
            Toast.makeText(this, "Fetching Student Data... Please wait.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }



    private void startAnnouncementNotifications() {
        FirebaseUser u = mAuth.getCurrentUser();
        if (u == null) return;
        final String uid = u.getUid();
        FirebaseDatabase db = FirebaseDatabase.getInstance();

        db.getReference("Users").child(uid).child("registrationId").get()
                .addOnSuccessListener(regSnap -> {
                    String myRegId = regSnap.getValue(String.class);
                    Log.d(TAG, "listeners start, uid=" + uid + " reg=" + myRegId);
                    DatabaseReference flatRef = db.getReference("Announcements").child("Parents");
                    watchAnnouncements(flatRef.child(uid), false, myRegId); // admin (nested)
                    watchAnnouncements(flatRef, true, myRegId);             // flat (fee etc.)
                })
                .addOnFailureListener(e -> Log.e(TAG, "registrationId read failed", e));
    }

    private void watchAnnouncements(DatabaseReference ref, boolean isFlat, String myRegId) {
        ref.get().addOnSuccessListener(baseline -> {
            if (isDestroyed()) return;
            Set<String> known = new HashSet<>();
            for (DataSnapshot s : baseline.getChildren()) known.add(s.getKey());
            Log.d(TAG, "baseline " + ref.getKey() + " flat=" + isFlat + " count=" + known.size());

            ChildEventListener l = new ChildEventListener() {
                @Override public void onChildAdded(@NonNull DataSnapshot snap, String prev) {
                    if (!known.add(snap.getKey())) return;
                    String title = snap.child("title").getValue(String.class);
                    Log.d(TAG, "new child " + snap.getKey() + " flat=" + isFlat + " title=" + title);
                    if (title == null) return;
                    if (isFlat) {
                        String target = snap.child("registrationId").getValue(String.class);
                        String type = snap.child("type").getValue(String.class);
                        boolean hasTarget = target != null && !target.isEmpty();
                        if (hasTarget ? !target.equals(myRegId)
                                      : "fee_confirmation".equalsIgnoreCase(type)) return;
                    }
                    String msg = snap.child("message").getValue(String.class);
                    showAnnouncementNotification(title, msg != null ? msg : "");
                }
                @Override public void onChildChanged(@NonNull DataSnapshot s, String p) {}
                @Override public void onChildRemoved(@NonNull DataSnapshot s) {}
                @Override public void onChildMoved(@NonNull DataSnapshot s, String p) {}
                @Override public void onCancelled(@NonNull DatabaseError e) {
                    Log.e(TAG, "listener cancelled: " + e.getMessage());
                }
            };
            ref.addChildEventListener(l);
            watchedRefs.add(ref);
            watchers.add(l);
        }).addOnFailureListener(e -> Log.e(TAG, "baseline read failed: " + e.getMessage()));
    }

    private void showAnnouncementNotification(String title, String message) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "POST_NOTIFICATIONS not granted");
            return;
        }
        Intent i = new Intent(this, ParentAnnouncementsActivity.class);
        i.putExtra("STUDENT_ID", registrationId);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, annNotifId, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, ANN_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_announcement)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pi);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(annNotifId++, b.build());
    }

    private void createAnnouncementChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    ANN_CHANNEL_ID, "Parent Announcements", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Announcements from KIPS");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        for (int k = 0; k < watchedRefs.size(); k++)
            watchedRefs.get(k).removeEventListener(watchers.get(k));
    }
}
