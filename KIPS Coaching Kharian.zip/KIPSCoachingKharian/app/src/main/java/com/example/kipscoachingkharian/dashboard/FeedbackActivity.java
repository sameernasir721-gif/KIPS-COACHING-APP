package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class FeedbackActivity extends AppCompatActivity {

    // Views
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private BottomNavigationView bottomNav;
    private android.widget.ImageView ivMenu;
    private TextView tvStudentName, tvStudentClass;

    // Tabs
    private TextView tabSubmit, tabAll;
    private LinearLayout layoutSubmitFeedback, layoutAllFeedback;

    // Submit tab views
    private RatingBar ratingBarFeedback;
    private EditText editName, editFeedback;
    private MaterialButton btnSubmit;

    // All-feedback tab views
    private TextView tvOverallRatingDigit, tvTotalReviews;
    private RatingBar rbOverallStars;
    private RecyclerView rvFeedbacks;

    // Adapter & data
    private FeedbackAdapter adapter;
    private ArrayList<FeedbackModel> feedbackList;

    // Firebase
    private DatabaseReference dbRef, userRef;
    private FirebaseAuth mAuth;
    private String currentStudentName = "Student";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        initViews();

        mAuth   = FirebaseAuth.getInstance();
        dbRef   = FirebaseDatabase.getInstance().getReference("Feedbacks");
        userRef = FirebaseDatabase.getInstance().getReference("Users")
                .child(mAuth.getUid());

        // RecyclerView setup
        feedbackList = new ArrayList<>();
        adapter      = new FeedbackAdapter(feedbackList);
        rvFeedbacks.setLayoutManager(new LinearLayoutManager(this));
        rvFeedbacks.setAdapter(adapter);

        // Load student profile data
        loadStudentData();

        // Click listeners
        ivMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
        tabSubmit.setOnClickListener(v -> showSubmitTab());
        tabAll.setOnClickListener(v -> showAllTab());
        btnSubmit.setOnClickListener(v -> submitFeedback());

        // Load all feedbacks and calculate average
        loadAllFeedbacks();

        setupBottomNav();
    }

    // ── View Bindings ──────────────────────────────────────────────────────────
    private void initViews() {
        drawerLayout       = findViewById(R.id.drawerLayout);
        navigationView     = findViewById(R.id.navigationView);
        bottomNav          = findViewById(R.id.bottomNav);
        ivMenu             = findViewById(R.id.ivMenu);
        tvStudentName      = findViewById(R.id.tvStudentName);
        tvStudentClass     = findViewById(R.id.tvStudentClass);

        tabSubmit          = findViewById(R.id.tabSubmit);
        tabAll             = findViewById(R.id.tabAll);
        layoutSubmitFeedback = findViewById(R.id.layoutSubmitFeedback);
        layoutAllFeedback  = findViewById(R.id.layoutAllFeedback);

        ratingBarFeedback  = findViewById(R.id.ratingBarFeedback);
        editName           = findViewById(R.id.editName);
        editFeedback       = findViewById(R.id.editFeedback);
        btnSubmit          = findViewById(R.id.btnSubmit);

        tvOverallRatingDigit = findViewById(R.id.tvOverallRatingDigit);
        tvTotalReviews     = findViewById(R.id.tvTotalReviews);
        rbOverallStars     = findViewById(R.id.rbOverallStars);
        rvFeedbacks        = findViewById(R.id.rvFeedbacks);
    }

    // ── Load Student Name/Grade into header ────────────────────────────────────
    private void loadStudentData() {
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String name      = snapshot.child("name").getValue(String.class);
                    String className = snapshot.child("className").getValue(String.class);
                    if (name != null) {
                        currentStudentName = name;
                        tvStudentName.setText(name);
                        editName.setText(name);   // Pre-fill name field
                    }
                    if (className != null) {
                        tvStudentClass.setText("Grade: " + className);
                    }
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // ── Submit Feedback to Firebase ────────────────────────────────────────────
    private void submitFeedback() {
        String name         = editName.getText().toString().trim();
        String feedbackText = editFeedback.getText().toString().trim();
        float  ratingValue  = ratingBarFeedback.getRating();

        if (name.isEmpty() || feedbackText.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }
        if (ratingValue == 0) {
            Toast.makeText(this, "Please select a star rating", Toast.LENGTH_SHORT).show();
            return;
        }

        String timestamp  = new SimpleDateFormat("dd MMM yyyy | hh:mm a", Locale.getDefault())
                .format(new Date());
        String feedbackId = dbRef.push().getKey();
        FeedbackModel feedback = new FeedbackModel(
                name, feedbackText, timestamp, mAuth.getUid(), ratingValue);

        if (feedbackId != null) {
            btnSubmit.setEnabled(false);
            dbRef.child(feedbackId).setValue(feedback).addOnCompleteListener(task -> {
                btnSubmit.setEnabled(true);
                if (task.isSuccessful()) {
                    Toast.makeText(this, "Feedback submitted!", Toast.LENGTH_LONG).show();
                    editFeedback.setText("");
                    ratingBarFeedback.setRating(0);
                    showAllTab(); // Switch to "All Feedback" tab after submit
                } else {
                    Toast.makeText(this, "Failed. Try again.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    // ── Load All Feedbacks + Compute Average ───────────────────────────────────
    private void loadAllFeedbacks() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                feedbackList.clear();
                float totalStars = 0;
                int   totalCount = 0;

                for (DataSnapshot data : snapshot.getChildren()) {
                    // "Parent" ek alag container node hai (parents ki feedbacks ke liye),
                    // ye akela feedback entry nahi — isko yahan skip karo
                    if ("Parent".equals(data.getKey())) continue;

                    FeedbackModel model = data.getValue(FeedbackModel.class);
                    if (model != null && model.getName() != null && !model.getName().trim().isEmpty()) {
                        feedbackList.add(0, model); // newest first
                        totalStars += model.getRating();
                        totalCount++;
                    }
                }

                // Update average rating card
                if (totalCount > 0) {
                    float avg = totalStars / totalCount;
                    tvOverallRatingDigit.setText(
                            String.format(Locale.ENGLISH, "%.1f", avg));
                    rbOverallStars.setRating(avg);
                    tvTotalReviews.setText("Based on " + totalCount + " reviews");
                } else {
                    tvOverallRatingDigit.setText("0.0");
                    rbOverallStars.setRating(0);
                    tvTotalReviews.setText("No reviews yet");
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(FeedbackActivity.this,
                        "Database Error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ── Tab Switching ──────────────────────────────────────────────────────────
    private void showSubmitTab() {
        layoutSubmitFeedback.setVisibility(View.VISIBLE);
        layoutAllFeedback.setVisibility(View.GONE);

        tabSubmit.setBackgroundResource(R.drawable.bg_gradient);
        tabSubmit.setTextColor(Color.WHITE);

        tabAll.setBackgroundResource(R.drawable.tab_right_outline);
        tabAll.setTextColor(Color.parseColor("#D50000"));
    }

    private void showAllTab() {
        layoutSubmitFeedback.setVisibility(View.GONE);
        layoutAllFeedback.setVisibility(View.VISIBLE);

        tabAll.setBackgroundResource(R.drawable.bg_gradient);
        tabAll.setTextColor(Color.WHITE);

        tabSubmit.setBackgroundResource(R.drawable.tab_left_outline);
        tabSubmit.setTextColor(Color.parseColor("#D50000"));
    }

    // ── Bottom Navigation ──────────────────────────────────────────────────────
    private void setupBottomNav() {
        bottomNav.setSelectedItemId(R.id.nav_bottom_feedback);

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_bottom_home) {
                Intent intent = new Intent(this, StudentDashboardActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
                return true;

            } else if (id == R.id.nav_bottom_feedback) {
                return true; // Already here

            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                finish();
                return true;
            }
            return false;
        });
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}