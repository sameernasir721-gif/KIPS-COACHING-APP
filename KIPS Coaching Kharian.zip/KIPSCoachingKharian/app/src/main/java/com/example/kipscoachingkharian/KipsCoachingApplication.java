package com.example.kipscoachingkharian;

import android.Manifest;
import android.app.Activity;
import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.kipscoachingkharian.dashboard.AnnouncementsActivity;
import com.example.kipscoachingkharian.dashboard.TeacherAnnouncementsActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


public class KipsCoachingApplication extends Application {

    private static final String CHANNEL_ID   = "announcements_channel";
    private static final String CHANNEL_NAME = "Announcements";

    private FirebaseAuth.AuthStateListener authStateListener;
    private String activeUid;

    private DatabaseReference studentPersonalRef, studentGlobalRef, teacherRef;
    private ChildEventListener studentPersonalListener, studentGlobalListener, teacherListener;

    private int notificationId = 1000;

    private final Map<Activity, Runnable> badgeDetachers = new HashMap<>();


    private static final String OFFLINE_TAG = "offline_overlay";
    private android.net.ConnectivityManager connectivityManager;
    private volatile boolean online = true;
    private Activity resumedActivity;
    private final android.os.Handler mainHandler = new android.os.Handler(android.os.Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();

        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityResumed(@NonNull Activity a) {
                resumedActivity = a;
                updateOfflineOverlay();
                if (badgeDetachers.containsKey(a)) return;
                Runnable detach = attachTeacherNavBadge(a);
                if (detach != null) badgeDetachers.put(a, detach);
            }
            @Override public void onActivityPaused(@NonNull Activity a) {
                if (resumedActivity == a) resumedActivity = null;
                Runnable detach = badgeDetachers.remove(a);
                if (detach != null) detach.run();
            }
            @Override public void onActivityCreated(@NonNull Activity a, Bundle b) {}
            @Override public void onActivityStarted(@NonNull Activity a) {}
            @Override public void onActivityStopped(@NonNull Activity a) {}
            @Override public void onActivitySaveInstanceState(@NonNull Activity a, @NonNull Bundle b) {}
            @Override public void onActivityDestroyed(@NonNull Activity a) {}
        });

        startNetworkMonitor();

        authStateListener = firebaseAuth -> {
            String uid = firebaseAuth.getCurrentUser() != null
                    ? firebaseAuth.getCurrentUser().getUid() : null;

            if (uid == null) {
                detachAllListeners();
                activeUid = null;
            } else if (!uid.equals(activeUid)) {
                detachAllListeners();
                activeUid = uid;
                resolveRoleAndAttach(uid);
            }
        };
        FirebaseAuth.getInstance().addAuthStateListener(authStateListener);
    }


    private void resolveRoleAndAttach(String uid) {
        FirebaseDatabase.getInstance().getReference("Users").child(uid).child("role")
                .get()
                .addOnSuccessListener(snap -> {
                    String role = snap.getValue(String.class);
                    if (role == null) return;
                    if (role.equalsIgnoreCase("Student")) {
                        attachStudentListeners(uid);
                    } else if (role.equalsIgnoreCase("Teacher")) {
                        attachTeacherListeners(uid);
                    }
                });
    }

    private void attachStudentListeners(String studentUid) {
        FirebaseDatabase.getInstance().getReference("Users").child(studentUid)
                .child("className").get()
                .addOnSuccessListener(classSnap -> {
                    String myClassName = classSnap.getValue(String.class);

                    DatabaseReference personalRef = FirebaseDatabase.getInstance()
                            .getReference("Announcements").child("Students").child(studentUid);
                    studentPersonalRef = personalRef;

                    personalRef.get().addOnSuccessListener(baseline -> {
                        Set<String> known = new HashSet<>();
                        for (DataSnapshot s : baseline.getChildren()) known.add(s.getKey());

                        ChildEventListener listener = new SimpleChildAddedListener(key -> known.contains(key),
                                known::add, snapshot -> {
                            String title   = snapshot.child("title").getValue(String.class);
                            String message = snapshot.child("message").getValue(String.class);
                            showNotification(title != null ? title : "New Announcement",
                                    message != null ? message : "", AnnouncementsActivity.class);
                        });
                        personalRef.addChildEventListener(listener);
                        studentPersonalListener = listener;
                    });

                    DatabaseReference globalRef = FirebaseDatabase.getInstance()
                            .getReference("Announcements").child("Students");
                    studentGlobalRef = globalRef;

                    globalRef.get().addOnSuccessListener(baseline -> {
                        Set<String> known = new HashSet<>();
                        for (DataSnapshot s : baseline.getChildren()) known.add(s.getKey());

                        ChildEventListener listener = new SimpleChildAddedListener(key -> known.contains(key),
                                known::add, snapshot -> {

                            if (studentUid.equals(snapshot.getKey())) return;

                            String title = snapshot.child("title").getValue(String.class);
                            if (title == null) return;

                            String target = snapshot.child("targetClass").getValue(String.class);
                            if (target != null && !target.isEmpty() && myClassName != null
                                    && !target.equalsIgnoreCase(myClassName)) return;

                            String message = snapshot.child("message").getValue(String.class);
                            showNotification(title, message != null ? message : "", AnnouncementsActivity.class);
                        });
                        globalRef.addChildEventListener(listener);
                        studentGlobalListener = listener;
                    });
                });
    }


    private void attachTeacherListeners(String teacherUid) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Announcements").child("Teachers");
        teacherRef = ref;

        ref.get().addOnSuccessListener(baseline -> {
            Set<String> known = new HashSet<>();
            for (DataSnapshot s : baseline.getChildren()) known.add(s.getKey());

            ChildEventListener listener = new SimpleChildAddedListener(key -> known.contains(key),
                    known::add, snapshot -> {
                String targetTeacherId = snapshot.child("targetTeacherId").getValue(String.class);
                if (targetTeacherId != null && !targetTeacherId.trim().isEmpty()
                        && !targetTeacherId.equals(teacherUid)) return;

                String title   = snapshot.child("title").getValue(String.class);
                String message = snapshot.child("message").getValue(String.class);
                showNotification(title != null ? title : "New Announcement",
                        message != null ? message : "", TeacherAnnouncementsActivity.class);
            });
            ref.addChildEventListener(listener);
            teacherListener = listener;
        });
    }



    private Runnable attachTeacherNavBadge(Activity activity) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return null;

        BottomNavigationView nav = findTeacherNav(activity.getWindow().getDecorView());
        if (nav == null) return null;

        final String uid = user.getUid();
        final String dismissedKey = "dismissed_keys_teacher_" + uid;
        final String seenKey = "seen_keys_teacher_" + uid;
        final SharedPreferences prefs = activity.getSharedPreferences("seen_announcements", Context.MODE_PRIVATE);
        final List<String> ids = new ArrayList<>();   // announcements meant for this teacher

        final Runnable refresh = () -> {
            Set<String> dismissed = new HashSet<>(prefs.getStringSet(dismissedKey, new HashSet<>()));
            Set<String> seen = new HashSet<>(prefs.getStringSet(seenKey, new HashSet<>()));
            int count = 0;
            for (String id : ids) {
                if (!dismissed.contains(id) && !seen.contains(id)) count++;
            }
            if (count > 0) {
                nav.getOrCreateBadge(R.id.nav_bottom_Announcment).setNumber(count);
            } else {
                nav.removeBadge(R.id.nav_bottom_Announcment);
            }
        };

        final DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("Announcements").child("Teachers");
        final ValueEventListener dbListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                ids.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    String targetTeacherId = snap.child("targetTeacherId").getValue(String.class);
                    if (targetTeacherId != null && !targetTeacherId.trim().isEmpty()
                            && !targetTeacherId.equals(uid)) continue;
                    if (snap.getKey() != null) ids.add(snap.getKey());
                }
                refresh.run();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        };


        final SharedPreferences.OnSharedPreferenceChangeListener prefListener =
                (p, key) -> refresh.run();

        final DatabaseReference msgRef = FirebaseDatabase.getInstance()
                .getReference("ConversationIndex").child(uid);
        final ValueEventListener msgListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                int total = 0;
                for (DataSnapshot conv : snapshot.getChildren()) {
                    Integer n = conv.child("unreadCount").getValue(Integer.class);
                    if (n != null && n > 0) total += n;
                }
                if (total > 0) {
                    nav.getOrCreateBadge(R.id.nav_bottom_Message).setNumber(total);
                } else {
                    nav.removeBadge(R.id.nav_bottom_Message);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        };

        ref.addValueEventListener(dbListener);
        msgRef.addValueEventListener(msgListener);
        prefs.registerOnSharedPreferenceChangeListener(prefListener);

        return () -> {
            ref.removeEventListener(dbListener);
            msgRef.removeEventListener(msgListener);
            prefs.unregisterOnSharedPreferenceChangeListener(prefListener);
        };
    }

    private static BottomNavigationView findTeacherNav(View v) {
        if (v instanceof BottomNavigationView) {
            BottomNavigationView b = (BottomNavigationView) v;
            return b.getMenu().findItem(R.id.nav_bottom_Announcment) != null ? b : null;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                BottomNavigationView found = findTeacherNav(g.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    // ── No internet page ──
    private void startNetworkMonitor() {
        connectivityManager = (android.net.ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) return;
        online = isOnline();

        connectivityManager.registerDefaultNetworkCallback(new android.net.ConnectivityManager.NetworkCallback() {

            @Override public void onAvailable(@NonNull android.net.Network network) {
                online = true;
                mainHandler.post(KipsCoachingApplication.this::updateOfflineOverlay);
            }

            @Override public void onLost(@NonNull android.net.Network network) {

                mainHandler.postDelayed(() -> {
                    if (!isOnline()) {
                        online = false;
                        updateOfflineOverlay();
                    }
                }, 1000);
            }
        });
    }

    private boolean isOnline() {
        if (connectivityManager == null) return true;
        android.net.Network n = connectivityManager.getActiveNetwork();
        if (n == null) return false;
        android.net.NetworkCapabilities c = connectivityManager.getNetworkCapabilities(n);
        return c != null && c.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }


    private void updateOfflineOverlay() {
        Activity a = resumedActivity;
        if (a == null) return;
        ViewGroup content = a.findViewById(android.R.id.content);
        if (content == null) return;
        View existing = content.findViewWithTag(OFFLINE_TAG);

        if (online) {
            if (existing != null) content.removeView(existing);
            return;
        }
        if (existing != null) return;
        content.addView(buildOfflineView(a));
    }

    private View buildOfflineView(Activity a) {
        final float d = getResources().getDisplayMetrics().density;

        android.widget.FrameLayout root = new android.widget.FrameLayout(a);
        root.setTag(OFFLINE_TAG);
        root.setBackgroundColor(0xFFFFFFFF);
        root.setClickable(true);
        root.setElevation(1000 * d);

        android.widget.LinearLayout box = new android.widget.LinearLayout(a);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setGravity(android.view.Gravity.CENTER);
        int pad = Math.round(32 * d);
        box.setPadding(pad, pad, pad, pad);
        root.addView(box, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        android.widget.TextView icon = new android.widget.TextView(a);
        icon.setText("\uD83D\uDCE1");
        icon.setTextSize(56f);
        icon.setGravity(android.view.Gravity.CENTER);
        box.addView(icon);

        android.widget.TextView title = new android.widget.TextView(a);
        title.setText("No Internet Connection");
        title.setTextSize(20f);
        title.setTextColor(0xFF333333);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        title.setGravity(android.view.Gravity.CENTER);
        title.setPadding(0, Math.round(16 * d), 0, Math.round(8 * d));
        box.addView(title);

        android.widget.TextView sub = new android.widget.TextView(a);
        sub.setText("Please check your connection and try again.");
        sub.setTextSize(14f);
        sub.setTextColor(0xFF777777);
        sub.setGravity(android.view.Gravity.CENTER);
        box.addView(sub);

        final android.widget.ProgressBar progress = new android.widget.ProgressBar(a);
        progress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(0xFFD2192B));
        progress.setVisibility(View.GONE);

        final android.widget.Button retry = new android.widget.Button(a);
        retry.setText("Retry");
        retry.setAllCaps(false);
        retry.setTextColor(0xFFFFFFFF);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xFFD2192B);
        bg.setCornerRadius(24 * d);
        retry.setBackground(bg);
        retry.setOnClickListener(v -> {

            retry.setVisibility(View.GONE);
            progress.setVisibility(View.VISIBLE);
            mainHandler.postDelayed(() -> {
                if (isOnline()) {
                    online = true;
                    updateOfflineOverlay();
                } else {
                    progress.setVisibility(View.GONE);
                    retry.setVisibility(View.VISIBLE);
                }
            }, 1200);
        });
        android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                Math.round(160 * d), Math.round(48 * d));
        lp.topMargin = Math.round(28 * d);
        box.addView(retry, lp);

        android.widget.LinearLayout.LayoutParams plp = new android.widget.LinearLayout.LayoutParams(
                Math.round(48 * d), Math.round(48 * d));
        plp.topMargin = Math.round(28 * d);
        box.addView(progress, plp);

        return root;
    }

    private void detachAllListeners() {
        if (studentPersonalRef != null && studentPersonalListener != null)
            studentPersonalRef.removeEventListener(studentPersonalListener);
        if (studentGlobalRef != null && studentGlobalListener != null)
            studentGlobalRef.removeEventListener(studentGlobalListener);
        if (teacherRef != null && teacherListener != null)
            teacherRef.removeEventListener(teacherListener);

        studentPersonalRef = studentGlobalRef = teacherRef = null;
        studentPersonalListener = studentGlobalListener = teacherListener = null;
    }


    private void showNotification(String title, String message, Class<?> targetActivity) {
        if (Build.VERSION.SDK_INT >= 33 &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        Intent intent = new Intent(this, targetActivity);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, notificationId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_announcement)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        NotificationManagerCompat.from(this).notify(notificationId++, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("New announcements aur updates ki notification");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }


    private interface KeyCheck { boolean alreadyKnown(String key); }
    private interface KeyAdd   { void markKnown(String key); }
    private interface OnNew    { void onNewItem(@NonNull DataSnapshot snapshot); }

    private static class SimpleChildAddedListener implements ChildEventListener {
        private final KeyCheck check;
        private final KeyAdd add;
        private final OnNew onNew;

        SimpleChildAddedListener(KeyCheck check, KeyAdd add, OnNew onNew) {
            this.check = check;
            this.add = add;
            this.onNew = onNew;
        }

        @Override public void onChildAdded(@NonNull DataSnapshot snapshot, String prevKey) {
            String key = snapshot.getKey();
            if (key == null || check.alreadyKnown(key)) return;
            add.markKnown(key);
            onNew.onNewItem(snapshot);
        }

        @Override public void onChildChanged(@NonNull DataSnapshot snapshot, String prevKey) {}
        @Override public void onChildRemoved(@NonNull DataSnapshot snapshot) {}
        @Override public void onChildMoved(@NonNull DataSnapshot snapshot, String prevKey) {}
        @Override public void onCancelled(@NonNull DatabaseError error) {}
    }
}