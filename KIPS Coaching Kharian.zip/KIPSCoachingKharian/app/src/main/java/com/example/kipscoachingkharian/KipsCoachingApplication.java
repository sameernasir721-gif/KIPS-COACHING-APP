package com.example.kipscoachingkharian;

import android.Manifest;
import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.kipscoachingkharian.dashboard.AnnouncementsActivity;
import com.example.kipscoachingkharian.dashboard.TeacherAnnouncementsActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashSet;
import java.util.Set;

/**
 * App-wide Application class.
 *
 * Jab tak app process zinda hai (foreground ya background), yeh class
 * Firebase ke "Announcements" node par continuously sun rahi hoti hai. Jaise
 * hi koi nayi announcement aati hai (student ke liye ya teacher ke liye),
 * ek system notification (popup banner — WhatsApp jaisi) dikhayi jaati hai,
 * chahe user kisi bhi screen par ho.
 *
 * Note: yeh sirf app open/background (process alive) hone tak kaam karta
 * hai. Agar app poori tarah band (force-stop/swipe-killed) ho jaye to yeh
 * notification nahi aayegi — uske liye Firebase Cloud Messaging (server
 * push) ki zaroorat hoti hai, jo alag setup hai.
 */
public class KipsCoachingApplication extends Application {

    private static final String CHANNEL_ID   = "announcements_channel";
    private static final String CHANNEL_NAME = "Announcements";

    private FirebaseAuth.AuthStateListener authStateListener;
    private String activeUid;

    // Active listeners — taake user switch/logout par hata sakein
    private DatabaseReference studentPersonalRef, studentGlobalRef, teacherRef;
    private ChildEventListener studentPersonalListener, studentGlobalListener, teacherListener;

    private int notificationId = 1000;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();

        authStateListener = firebaseAuth -> {
            String uid = firebaseAuth.getCurrentUser() != null
                    ? firebaseAuth.getCurrentUser().getUid() : null;

            if (uid == null) {
                detachAllListeners();
                activeUid = null;
            } else if (!uid.equals(activeUid)) {
                detachAllListeners();
                activeUid = uid;
                resolveRoleAndAttach(uid);
            }
        };
        FirebaseAuth.getInstance().addAuthStateListener(authStateListener);
    }

    // ── Role check karo (Users/{uid}/role) phir sahi listener attach karo ──
    private void resolveRoleAndAttach(String uid) {
        FirebaseDatabase.getInstance().getReference("Users").child(uid).child("role")
                .get()
                .addOnSuccessListener(snap -> {
                    String role = snap.getValue(String.class);
                    if (role == null) return;
                    if (role.equalsIgnoreCase("Student")) {
                        attachStudentListeners(uid);
                    } else if (role.equalsIgnoreCase("Teacher")) {
                        attachTeacherListeners(uid);
                    }
                });
    }

    // ── STUDENT: per-student targeted + class-wide global announcements ──
    private void attachStudentListeners(String studentUid) {
        FirebaseDatabase.getInstance().getReference("Users").child(studentUid)
                .child("className").get()
                .addOnSuccessListener(classSnap -> {
                    String myClassName = classSnap.getValue(String.class);

                    // 1) Sirf isi student ke liye targeted announcements
                    DatabaseReference personalRef = FirebaseDatabase.getInstance()
                            .getReference("Announcements").child("Students").child(studentUid);
                    studentPersonalRef = personalRef;

                    personalRef.get().addOnSuccessListener(baseline -> {
                        Set<String> known = new HashSet<>();
                        for (DataSnapshot s : baseline.getChildren()) known.add(s.getKey());

                        ChildEventListener listener = new SimpleChildAddedListener(key -> known.contains(key),
                                known::add, snapshot -> {
                            String title   = snapshot.child("title").getValue(String.class);
                            String message = snapshot.child("message").getValue(String.class);
                            showNotification(title != null ? title : "New Announcement",
                                    message != null ? message : "", AnnouncementsActivity.class);
                        });
                        personalRef.addChildEventListener(listener);
                        studentPersonalListener = listener;
                    });

                    // 2) Class-wide / global announcements (purana flat structure)
                    DatabaseReference globalRef = FirebaseDatabase.getInstance()
                            .getReference("Announcements").child("Students");
                    studentGlobalRef = globalRef;

                    globalRef.get().addOnSuccessListener(baseline -> {
                        Set<String> known = new HashSet<>();
                        for (DataSnapshot s : baseline.getChildren()) known.add(s.getKey());

                        ChildEventListener listener = new SimpleChildAddedListener(key -> known.contains(key),
                                known::add, snapshot -> {
                            // Yeh student ka apna container node hai to personal listener pehle hi handle kar chuka
                            if (studentUid.equals(snapshot.getKey())) return;

                            String title = snapshot.child("title").getValue(String.class);
                            if (title == null) return; // kisi doosray student ka per-student container — ignore

                            String target = snapshot.child("targetClass").getValue(String.class);
                            if (target != null && !target.isEmpty() && myClassName != null
                                    && !target.equalsIgnoreCase(myClassName)) return;

                            String message = snapshot.child("message").getValue(String.class);
                            showNotification(title, message != null ? message : "", AnnouncementsActivity.class);
                        });
                        globalRef.addChildEventListener(listener);
                        studentGlobalListener = listener;
                    });
                });
    }

    // ── TEACHER: Announcements/Teachers node (targetTeacherId filter) ──
    private void attachTeacherListeners(String teacherUid) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Announcements").child("Teachers");
        teacherRef = ref;

        ref.get().addOnSuccessListener(baseline -> {
            Set<String> known = new HashSet<>();
            for (DataSnapshot s : baseline.getChildren()) known.add(s.getKey());

            ChildEventListener listener = new SimpleChildAddedListener(key -> known.contains(key),
                    known::add, snapshot -> {
                String targetTeacherId = snapshot.child("targetTeacherId").getValue(String.class);
                if (targetTeacherId != null && !targetTeacherId.trim().isEmpty()
                        && !targetTeacherId.equals(teacherUid)) return;

                String title   = snapshot.child("title").getValue(String.class);
                String message = snapshot.child("message").getValue(String.class);
                showNotification(title != null ? title : "New Announcement",
                        message != null ? message : "", TeacherAnnouncementsActivity.class);
            });
            ref.addChildEventListener(listener);
            teacherListener = listener;
        });
    }

    private void detachAllListeners() {
        if (studentPersonalRef != null && studentPersonalListener != null)
            studentPersonalRef.removeEventListener(studentPersonalListener);
        if (studentGlobalRef != null && studentGlobalListener != null)
            studentGlobalRef.removeEventListener(studentGlobalListener);
        if (teacherRef != null && teacherListener != null)
            teacherRef.removeEventListener(teacherListener);

        studentPersonalRef = studentGlobalRef = teacherRef = null;
        studentPersonalListener = studentGlobalListener = teacherListener = null;
    }

    // ── Popup notification banaye (heads-up jaisa, WhatsApp ki tarah) ──
    private void showNotification(String title, String message, Class<?> targetActivity) {
        if (Build.VERSION.SDK_INT >= 33 &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            return; // permission abhi nahi mili — silently skip
        }

        Intent intent = new Intent(this, targetActivity);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, notificationId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_announcement)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        NotificationManagerCompat.from(this).notify(notificationId++, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("New announcements aur updates ki notification");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    // ── Chhota helper: "naye child add hone par" logic baar baar likhne se bachne ke liye ──
    private interface KeyCheck { boolean alreadyKnown(String key); }
    private interface KeyAdd   { void markKnown(String key); }
    private interface OnNew    { void onNewItem(@NonNull DataSnapshot snapshot); }

    private static class SimpleChildAddedListener implements ChildEventListener {
        private final KeyCheck check;
        private final KeyAdd add;
        private final OnNew onNew;

        SimpleChildAddedListener(KeyCheck check, KeyAdd add, OnNew onNew) {
            this.check = check;
            this.add = add;
            this.onNew = onNew;
        }

        @Override public void onChildAdded(@NonNull DataSnapshot snapshot, String prevKey) {
            String key = snapshot.getKey();
            if (key == null || check.alreadyKnown(key)) return;
            add.markKnown(key);
            onNew.onNewItem(snapshot);
        }

        @Override public void onChildChanged(@NonNull DataSnapshot snapshot, String prevKey) {}
        @Override public void onChildRemoved(@NonNull DataSnapshot snapshot) {}
        @Override public void onChildMoved(@NonNull DataSnapshot snapshot, String prevKey) {}
        @Override public void onCancelled(@NonNull DatabaseError error) {}
    }
}
