package com.example.kipscoachingkharian.dashboard;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ParentCommunicationActivity extends AppCompatActivity {

    private static final String CHANNEL_ID   = "parent_chat_channel";
    private static final String CHANNEL_NAME = "Teacher Messages";
    private static final int    NOTIF_ID     = 1001;

    private RecyclerView rvConversations;
    private ProgressBar  progressBar;
    private TextView     tvEmpty;
    private FloatingActionButton fabNewChat;
    private LinearLayout llHomeTab, llProfileTab;
    private EditText     etSearch;

    private ConversationAdapter adapter;
    private final List<Conversation> conversationList = new ArrayList<>();
    private final List<Conversation> filteredList     = new ArrayList<>();

    // Track known unread counts per conversation — for notification trigger
    private final java.util.Map<String, Integer> knownUnreadMap = new java.util.HashMap<>();

    private String myUid, myName, myRole, studentId;

    // Real-time listener — so notifications fire when new message arrives
    private ChildEventListener convListener;
    private DatabaseReference  indexRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_communication);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) { finish(); return; }
        myUid     = FirebaseAuth.getInstance().getCurrentUser().getUid();
        myName    = getIntent().getStringExtra("MY_NAME");
        myRole    = getIntent().getStringExtra("MY_ROLE");
        studentId = getIntent().getStringExtra("STUDENT_ID");

        if (myName == null) myName = "Parent";
        if (myRole == null) myRole = "Parent";

        createNotificationChannel();
        initViews();
        listenForConversations();
    }

    // ─────────────────────────────────────────────────────────────
    // INIT
    // ─────────────────────────────────────────────────────────────
    private void initViews() {
        rvConversations = findViewById(R.id.rvConversations);
        progressBar     = findViewById(R.id.progressBar);
        tvEmpty         = findViewById(R.id.tvEmpty);
        fabNewChat      = findViewById(R.id.fabNewChat);
        llHomeTab       = findViewById(R.id.llHomeTab);
        llProfileTab    = findViewById(R.id.llProfileTab);
        etSearch        = findViewById(R.id.etSearch);

        ImageView ivBack = findViewById(R.id.ivBack);
        if (ivBack != null) ivBack.setOnClickListener(v -> finish());

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
            @Override public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                filter(s.toString());
            }
            @Override public void afterTextChanged(Editable e) {}
        });

        adapter = new ConversationAdapter(this, filteredList, conv -> {
            Intent intent = new Intent(ParentCommunicationActivity.this, ChatActivity.class);
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_ID,   conv.getOtherUserId());
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_NAME, conv.getOtherUserName());
            intent.putExtra(ChatActivity.EXTRA_RECEIVER_ROLE, conv.getOtherUserRole());
            intent.putExtra(ChatActivity.EXTRA_MY_NAME,       myName);
            intent.putExtra(ChatActivity.EXTRA_MY_ROLE,       myRole);
            intent.putExtra(ChatActivity.EXTRA_OTHER_DETAIL,  conv.getOtherUserDetail());
            startActivity(intent);
        });
        rvConversations.setLayoutManager(new LinearLayoutManager(this));
        rvConversations.setAdapter(adapter);

        fabNewChat.setOnClickListener(v -> {
            Intent intent = new Intent(ParentCommunicationActivity.this, TeacherPickerActivity.class);
            intent.putExtra("MY_NAME",    myName);
            intent.putExtra("MY_ROLE",    myRole);
            intent.putExtra("STUDENT_ID", studentId);
            startActivity(intent);
        });

        if (llHomeTab    != null) llHomeTab.setOnClickListener(v -> finish());
        if (llProfileTab != null) llProfileTab.setOnClickListener(v -> {
            Intent intent = new Intent(this, ParentProfileActivity.class);
            intent.putExtra("STUDENT_ID", studentId);
            startActivity(intent);
        });
    }

    // ─────────────────────────────────────────────────────────────
    // REAL-TIME LISTENER — ChildEventListener for instant notifications
    // ─────────────────────────────────────────────────────────────
    private void listenForConversations() {
        progressBar.setVisibility(View.VISIBLE);
        indexRef = FirebaseDatabase.getInstance()
                .getReference("ConversationIndex").child(myUid);

        // Use ValueEventListener for list updates
        indexRef.orderByChild("lastTimestamp")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        conversationList.clear();
                        for (DataSnapshot ds : snapshot.getChildren()) {
                            Conversation conv = ds.getValue(Conversation.class);
                            if (conv == null) continue;

                            // ── Notification logic ──────────────────────────
                            int newUnread = conv.getUnreadCount();
                            String convId  = conv.getConversationId() != null
                                    ? conv.getConversationId() : ds.getKey();
                            int prevUnread = knownUnreadMap.containsKey(convId)
                                    ? knownUnreadMap.get(convId) : 0;

                            // Agar unread count badha hai — teacher ne naya message bheja
                            if (newUnread > prevUnread && prevUnread >= 0) {
                                showChatNotification(
                                        conv.getOtherUserName(),
                                        conv.getLastMessage(),
                                        conv);
                            }
                            knownUnreadMap.put(convId, newUnread);
                            // ─────────────────────────────────────────────────

                            conversationList.add(0, conv);
                        }
                        filter(etSearch.getText().toString());
                        progressBar.setVisibility(View.GONE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(ParentCommunicationActivity.this,
                                "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // ─────────────────────────────────────────────────────────────
    // NOTIFICATION — "Teacher X ne message bheja"
    // ─────────────────────────────────────────────────────────────
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Messages from Teachers");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void showChatNotification(String teacherName, String lastMessage, Conversation conv) {
        // Tap karne par ChatActivity khule
        Intent openChat = new Intent(this, ChatActivity.class);
        openChat.putExtra(ChatActivity.EXTRA_RECEIVER_ID,   conv.getOtherUserId());
        openChat.putExtra(ChatActivity.EXTRA_RECEIVER_NAME, conv.getOtherUserName());
        openChat.putExtra(ChatActivity.EXTRA_RECEIVER_ROLE, conv.getOtherUserRole());
        openChat.putExtra(ChatActivity.EXTRA_MY_NAME,       myName);
        openChat.putExtra(ChatActivity.EXTRA_MY_ROLE,       myRole);
        openChat.putExtra(ChatActivity.EXTRA_OTHER_DETAIL,  conv.getOtherUserDetail());
        openChat.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pi = PendingIntent.getActivity(this, 0, openChat,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.app_logo)
                .setContentTitle("Message from " + (teacherName != null ? teacherName : "Teacher"))
                .setContentText(lastMessage != null ? lastMessage : "New message")
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText(lastMessage != null ? lastMessage : "New message"))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pi);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, builder.build());
    }

    // ─────────────────────────────────────────────────────────────
    // FILTER
    // ─────────────────────────────────────────────────────────────
    private void filter(String query) {
        filteredList.clear();
        for (Conversation conv : conversationList) {
            if (conv.getOtherUserName() != null &&
                    conv.getOtherUserName().toLowerCase()
                            .contains(query.toLowerCase().trim())) {
                filteredList.add(conv);
            }
        }
        adapter.notifyDataSetChanged();
        tvEmpty.setVisibility(filteredList.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // ValueEventListener auto-detach nahi hota — manually hataao
        if (indexRef != null && convListener != null) {
            indexRef.removeEventListener(convListener);
        }
    }
}