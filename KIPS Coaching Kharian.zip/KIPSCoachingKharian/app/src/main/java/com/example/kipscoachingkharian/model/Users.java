package com.example.kipscoachingkharian.model;

public class Users {

    private String name;
    private String username;
    private String email;
    private String role;
    private String status;
    private String password;
    private String className;
    private String subject;
    private String linkedChildUsername;

    public Users() { }

    // Updated Constructor with Email
    public Users(String name, String username, String email, String role, String status, String password, String className, String subject) {
        this.name = name;
        this.username = username;
        this.email = email; // Initialize Email
        this.role = role;
        this.status = status;
        this.password = password;
        this.className = className;
        this.subject = subject;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getLinkedChildUsername() { return linkedChildUsername; }
    public void setLinkedChildUsername(String linkedChildUsername) { this.linkedChildUsername = linkedChildUsername; }
}