package com.example.kipscoachingkharian;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.example.kipscoachingkharian.dashboard.AdminDashboardActivity;
import com.example.kipscoachingkharian.dashboard.ParentDashboardActivity;
import com.example.kipscoachingkharian.dashboard.StudentDashboardActivity;
import com.example.kipscoachingkharian.dashboard.TeacherDashboardActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SplashActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            FirebaseUser currentUser = mAuth.getCurrentUser();

            if (currentUser != null) {
                checkRoleAndRedirect(currentUser.getUid());
            } else {
                // Not logged in? Go to Selection Screen
                startActivity(new Intent(SplashActivity.this, LoginSelectionActivity.class));
                finish();
            }
        }, 2500);
    }

    private void checkRoleAndRedirect(String uid) {
        mDatabase.child("Users").child(uid).child("role")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (!snapshot.exists()) {
                            mAuth.signOut();
                            startActivity(new Intent(SplashActivity.this, LoginSelectionActivity.class));
                            finish();
                            return;
                        }

                        String role = snapshot.getValue(String.class);

                        if ("Student".equalsIgnoreCase(role)) {
                            // Student — go to student dashboard
                            startActivity(new Intent(SplashActivity.this, StudentDashboardActivity.class));
                            finishAffinity();

                        } else if ("Teacher".equalsIgnoreCase(role)) {
                            // Teacher — go to teacher dashboard, stay logged in
                            startActivity(new Intent(SplashActivity.this, TeacherDashboardActivity.class));
                            finishAffinity();

                        } else if ("Parent".equalsIgnoreCase(role)) {
                            // Parent — go to parent dashboard, stay logged in
                            startActivity(new Intent(SplashActivity.this, ParentDashboardActivity.class));
                            finishAffinity();

                        } else if ("Admin".equalsIgnoreCase(role)) {
                            // ✅ Admin — go to admin dashboard, stay logged in
                            startActivity(new Intent(SplashActivity.this, AdminDashboardActivity.class));
                            finishAffinity();

                        } else {
                            // Unknown role — logout and go to selection
                            mAuth.signOut();
                            startActivity(new Intent(SplashActivity.this, LoginSelectionActivity.class));
                            finish();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        startActivity(new Intent(SplashActivity.this, LoginSelectionActivity.class));
                        finish();
                    }
                });
    }
}