package com.example.kipscoachingkharian;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.example.kipscoachingkharian.dashboard.AdminDashboardActivity;
import com.example.kipscoachingkharian.dashboard.ParentDashboardActivity;
import com.example.kipscoachingkharian.dashboard.StudentDashboardActivity;
import com.example.kipscoachingkharian.dashboard.TeacherDashboardActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * The initial Activity displayed when the application launches.
 * It serves two main purposes:
 * 1. Displaying the app branding/logo for a few seconds.
 * 2. Checking for an existing session (Auto-Login) and routing the user to the correct Dashboard.
 */
public class SplashActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Initialize Firebase instances
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Create a delay to show the splash screen before executing logic
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            FirebaseUser currentUser = mAuth.getCurrentUser();

            if (currentUser != null) {
                // User is already logged in from a previous session.
                // We must check their role in the database to decide which Dashboard to open.
                checkRoleAndRedirect(currentUser.getUid());
            } else {
                // No active session found. Redirect to the Login Selection screen.
                startActivity(new Intent(SplashActivity.this, LoginSelectionActivity.class));
                finish(); // Close SplashActivity so it cannot be returned to.
            }
        }, 2500); // 2.5 seconds delay
    }

    /**
     * Queries the Realtime Database to find the role associated with the current User ID.
     * Routes the user to the specific dashboard (Admin, Student, Parent, Teacher).
     * @param uid The unique User ID from Firebase Auth.
     */
    private void checkRoleAndRedirect(String uid) {
        mDatabase.child("Users").child(uid).child("role").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String role = snapshot.getValue(String.class);

                    if (role != null) {
                        // Switch based on the retrieved role string
                        switch (role) {
                            case "Admin":
                                startActivity(new Intent(SplashActivity.this, AdminDashboardActivity.class));
                                break;
                            case "Student":
                                startActivity(new Intent(SplashActivity.this, StudentDashboardActivity.class));
                                break;
                            case "Parent":
                                startActivity(new Intent(SplashActivity.this, ParentDashboardActivity.class));
                                break;
                            case "Teacher":
                                startActivity(new Intent(SplashActivity.this, TeacherDashboardActivity.class));
                                break;
                            default:
                                // Fallback: Role exists but is unrecognized
                                startActivity(new Intent(SplashActivity.this, LoginSelectionActivity.class));
                        }
                        // Clear the back stack so the user cannot press 'Back' to return to the Splash screen
                        finishAffinity();
                    }
                } else {
                    // Edge Case: User exists in Auth but their profile data is missing from Database.
                    // Redirect to login to allow re-authentication or debugging.
                    startActivity(new Intent(SplashActivity.this, LoginSelectionActivity.class));
                    finish();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle database read errors (e.g., network issues)
                Toast.makeText(SplashActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                startActivity(new Intent(SplashActivity.this, LoginSelectionActivity.class));
                finish();
            }
        });
    }
}