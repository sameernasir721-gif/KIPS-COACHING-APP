package com.example.kipscoachingkharian.dashboard;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;

import java.util.ArrayList;

public class ParentFeedbackAdapter extends RecyclerView.Adapter<ParentFeedbackAdapter.ViewHolder> {

    private ArrayList<ParentFeedbackModel> list;

    public ParentFeedbackAdapter(ArrayList<ParentFeedbackModel> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_parent_feedback, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ParentFeedbackModel model = list.get(position);

        holder.tvName.setText(model.name);
        holder.tvMessage.setText(model.message);
        holder.tvDate.setText(model.date);

        // Individual Rating Logic
        if (model.rating != null && !model.rating.isEmpty()) {
            float ratingValue = Float.parseFloat(model.rating);
            holder.rbStars.setRating(ratingValue);
            holder.tvRatingValue.setText(String.valueOf(ratingValue));
        }

        // Initials Logic
        if (model.name != null && !model.name.isEmpty()) {
            holder.tvInitial.setText(model.name.substring(0, 1).toUpperCase());
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvMessage, tvDate, tvInitial, tvRatingValue;
        RatingBar rbStars;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvParentName);
            tvMessage = itemView.findViewById(R.id.tvFeedbackText);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvInitial = itemView.findViewById(R.id.tvInitials);
            tvRatingValue = itemView.findViewById(R.id.tvRatingValue);
            rbStars = itemView.findViewById(R.id.rbFeedbackStars);
        }
    }
}