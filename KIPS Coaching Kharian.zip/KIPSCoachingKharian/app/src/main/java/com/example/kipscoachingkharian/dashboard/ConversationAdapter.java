package com.example.kipscoachingkharian.dashboard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ConversationAdapter extends RecyclerView.Adapter<ConversationAdapter.ViewHolder> {

    public interface OnConversationClickListener {
        void onConversationClick(Conversation conversation);
    }

    private final Context context;
    private final List<Conversation> conversations;
    private final OnConversationClickListener listener;

    public ConversationAdapter(Context context, List<Conversation> conversations,
                               OnConversationClickListener listener) {
        this.context = context;
        this.conversations = conversations;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_conversation_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Conversation conv = conversations.get(position);

        holder.tvName.setText(conv.getOtherUserName());

        // --- Role ki jagah Subject ya Student detail dikhayein ---
        if (conv.getOtherUserDetail() != null && !conv.getOtherUserDetail().isEmpty()) {
            holder.tvRole.setText(conv.getOtherUserDetail());
        } else {
            // Fallback agar detail nahi hai
            holder.tvRole.setText(conv.getOtherUserRole());
        }

        holder.tvLastMessage.setText(conv.getLastMessage() != null ? conv.getLastMessage() : "");

        if (conv.getLastTimestamp() > 0) {
            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            holder.tvTime.setText(sdf.format(new Date(conv.getLastTimestamp())));
        } else {
            holder.tvTime.setText("");
        }

        if (conv.getUnreadCount() > 0) {
            holder.tvUnread.setVisibility(View.VISIBLE);
            holder.tvUnread.setText(String.valueOf(conv.getUnreadCount()));
        } else {
            holder.tvUnread.setVisibility(View.GONE);
        }

        if (conv.getOtherUserName() != null && !conv.getOtherUserName().isEmpty()) {
            holder.tvAvatar.setText(String.valueOf(conv.getOtherUserName().charAt(0)).toUpperCase());
        }

        holder.itemView.setOnClickListener(v -> listener.onConversationClick(conv));
    }

    @Override
    public int getItemCount() { return conversations.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvAvatar, tvName, tvRole, tvLastMessage, tvTime, tvUnread;
        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvAvatar = itemView.findViewById(R.id.tvAvatar);
            tvName = itemView.findViewById(R.id.tvConvName);
            tvRole = itemView.findViewById(R.id.tvConvRole);
            tvLastMessage = itemView.findViewById(R.id.tvLastMessage);
            tvTime = itemView.findViewById(R.id.tvConvTime);
            tvUnread = itemView.findViewById(R.id.tvUnreadBadge);
        }
    }
}