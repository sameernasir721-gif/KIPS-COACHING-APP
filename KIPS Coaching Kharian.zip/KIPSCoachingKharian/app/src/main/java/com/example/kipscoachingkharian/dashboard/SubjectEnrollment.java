package com.example.kipscoachingkharian.dashboard;

public class SubjectEnrollment {

    private String subjectId;
    private String subjectName;

    public SubjectEnrollment(String subjectId, String subjectName) {
        this.subjectId = subjectId;
        this.subjectName = subjectName;
    }

    public String getSubjectId() { return subjectId; }
    public String getSubjectName() { return subjectName; }
}
