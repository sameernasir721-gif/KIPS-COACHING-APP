package com.example.kipscoachingkharian.dashboard;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.graphics.Typeface;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public final class NotificationDeepLink {

    public static final String EXTRA_ID      = "dl_id";       // quiz / assignment / material id (if known)
    public static final String EXTRA_TITLE   = "dl_title";    // notification title
    public static final String EXTRA_MONTH   = "dl_month";    // fee month, e.g. "October 2026"
    public static final String EXTRA_SUBJECT = "dl_subject";  // subject name (subject approval)

    private NotificationDeepLink() {}

    /** True if the screen was opened from a notification that points to a specific item. */
    public static boolean has(Intent intent) {
        if (intent == null) return false;
        return notEmpty(intent.getStringExtra(EXTRA_ID))
                || notEmpty(intent.getStringExtra(EXTRA_TITLE))
                || notEmpty(intent.getStringExtra(EXTRA_MONTH))
                || notEmpty(intent.getStringExtra(EXTRA_SUBJECT));
    }

    public static boolean matches(Intent intent, String itemId, String itemTitle) {
        if (intent == null) return false;
        String id = intent.getStringExtra(EXTRA_ID);
        if (notEmpty(id) && notEmpty(itemId) && id.equals(itemId)) return true;

        if (!notEmpty(itemTitle)) return false;
        for (String name : nameCandidates(intent.getStringExtra(EXTRA_TITLE))) {
            if (name.equalsIgnoreCase(itemTitle.trim())) return true;
        }
        return false;
    }

    /** Names that can be read from a notification title (with and without a trailing "(subject)"). */
    public static List<String> nameCandidates(String notifTitle) {
        List<String> out = new ArrayList<>();
        if (!notEmpty(notifTitle)) return out;

        String t = notifTitle.trim();
        int dash  = t.indexOf(" \u2014 ");   // "Progress Updated — Physics"
        int colon = t.indexOf(": ");         // "New Quiz: Algebra (Maths)"
        if (dash >= 0)       t = t.substring(dash + 3).trim();
        else if (colon >= 0) t = t.substring(colon + 2).trim();

        out.add(t);
        String stripped = t.replaceAll("\\s*\\([^()]*\\)\\s*$", "").trim();
        if (!stripped.equals(t) && !stripped.isEmpty()) out.add(stripped);
        return out;
    }

    // ── Scroll + highlight ────────────────────────────────────────────────────

    public static void scrollToAndFlash(View target) {
        attempt(target, 0);
    }

    private static void attempt(View target, int tries) {
        // Wait until the item has actually been laid out
        if ((target.getHeight() == 0 || !target.isAttachedToWindow()) && tries < 8) {
            target.postDelayed(() -> attempt(target, tries + 1), 120);
            return;
        }
        View scroller = findScrollParent(target);
        if (scroller != null) {
            Rect r = new Rect();
            target.getDrawingRect(r);
            ((ViewGroup) scroller).offsetDescendantRectToMyCoords(target, r);
            int y = Math.max(0, r.top - Math.round(90 * target.getResources().getDisplayMetrics().density));
            if (scroller instanceof NestedScrollView) ((NestedScrollView) scroller).smoothScrollTo(0, y);
            else ((ScrollView) scroller).smoothScrollTo(0, y);
        }
        target.postDelayed(() -> flash(target), scroller != null ? 350 : 0);
    }

    private static View findScrollParent(View v) {
        ViewParent p = v.getParent();
        while (p instanceof View) {
            if (p instanceof NestedScrollView || p instanceof ScrollView) return (View) p;
            p = p.getParent();
        }
        return null;
    }

    public static void scrollToItemAndFlash(RecyclerView rv, int position) {
        waitForItem(rv, position, 0);
    }

    private static void waitForItem(RecyclerView rv, int position, int tries) {
        RecyclerView.ViewHolder vh = rv.findViewHolderForAdapterPosition(position);
        if (vh != null && vh.itemView.getHeight() > 0) {
            scrollToAndFlash(vh.itemView);
            return;
        }
        if (tries < 20) rv.postDelayed(() -> waitForItem(rv, position, tries + 1), 100);
    }


    public static void flash(View v) {
        flashAttempt(v, 0);
    }

    private static void flashAttempt(View v, int tries) {
        // Layout complete hone ka intezar (width 0 ho to blink nazar hi nahi aata)
        if (v.getWidth() == 0 || v.getHeight() == 0 || !v.isAttachedToWindow()) {
            if (tries < 10) v.postDelayed(() -> flashAttempt(v, tries + 1), 150);
            return;
        }

        float d = v.getResources().getDisplayMetrics().density;

        final float origZ = v.getTranslationZ();
        final float origScale = v.getScaleX();

        // Koi color/blink nahi: item ~3.5 sec ke liye ubhra hua + text bold rehta hai
        final List<TextView> texts = new ArrayList<>();
        final List<Typeface> origFaces = new ArrayList<>();
        collectTextViews(v, texts);
        for (TextView tv : texts) {
            origFaces.add(tv.getTypeface());
            tv.setTypeface(tv.getTypeface(), Typeface.BOLD);
        }

        v.animate()
                .scaleX(origScale * 1.03f).scaleY(origScale * 1.03f)
                .translationZ(origZ + 10 * d)
                .setDuration(250)
                .start();

        v.postDelayed(() -> {
            for (int i = 0; i < texts.size(); i++) texts.get(i).setTypeface(origFaces.get(i));
            v.animate()
                    .scaleX(origScale).scaleY(origScale)
                    .translationZ(origZ)
                    .setDuration(250)
                    .start();
        }, 3500);
    }

    private static void collectTextViews(View v, List<TextView> out) {
        if (v instanceof TextView) {
            out.add((TextView) v);
        } else if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) collectTextViews(g.getChildAt(i), out);
        }
    }

    private static boolean notEmpty(String s) {
        return s != null && !s.trim().isEmpty();
    }
}