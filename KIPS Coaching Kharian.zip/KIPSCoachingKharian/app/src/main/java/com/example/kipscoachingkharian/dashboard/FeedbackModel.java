package com.example.kipscoachingkharian.dashboard;

public class FeedbackModel {
    private String name;
    private String feedback;
    private String timestamp;
    private String uid;
    private float rating; // Naya field

    // Empty Constructor
    public FeedbackModel() {}

    // Parameterized Constructor
    public FeedbackModel(String name, String feedback, String timestamp, String uid, float rating) {
        this.name = name;
        this.feedback = feedback;
        this.timestamp = timestamp;
        this.uid = uid;
        this.rating = rating;
    }

    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }

    public String getUid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }

    public float getRating() { return rating; }
    public void setRating(float rating) { this.rating = rating; }
}

