package com.example.kipscoachingkharian.dashboard;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;

import java.util.ArrayList;
import java.util.List;

public class EnrollmentRequestAdapter
        extends RecyclerView.Adapter<EnrollmentRequestAdapter.VH> {

    public interface Listener {
        void onApprove(EnrollmentRequest request);
        void onReject(EnrollmentRequest request);
    }

    private final List<EnrollmentRequest> items = new ArrayList<>();
    private final Listener listener;

    public EnrollmentRequestAdapter(Listener listener) {
        this.listener = listener;
    }

    public void setData(List<EnrollmentRequest> data) {
        items.clear();
        items.addAll(data);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_enrollment_request, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        EnrollmentRequest r = items.get(position);
        h.tvSubject.setText(r.getSubjectName());
        String cls = r.getClassName();
        h.tvClass.setText(cls != null && !cls.isEmpty() ? "Class " + cls : "");
        h.btnApprove.setOnClickListener(v -> listener.onApprove(r));
        h.btnReject.setOnClickListener(v -> listener.onReject(r));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvSubject, tvClass;
        Button btnApprove, btnReject;

        VH(View v) {
            super(v);
            tvSubject  = v.findViewById(R.id.tvRequestSubject);
            tvClass    = v.findViewById(R.id.tvRequestClass);
            btnApprove = v.findViewById(R.id.btnApprove);
            btnReject  = v.findViewById(R.id.btnReject);
        }
    }
}