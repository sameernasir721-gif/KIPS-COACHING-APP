package com.example.kipscoachingkharian.dashboard;

public class EnrolledStudent {

    private String id;
    private String name;
    private String subjectName;

    public EnrolledStudent(String id, String name, String subjectName) {
        this.id = id;
        this.name = name;
        this.subjectName = subjectName;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getSubjectName() { return subjectName; }
}
