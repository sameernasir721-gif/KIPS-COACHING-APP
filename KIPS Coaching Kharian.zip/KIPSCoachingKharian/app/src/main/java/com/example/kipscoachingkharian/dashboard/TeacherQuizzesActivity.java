package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TeacherQuizzesActivity extends AppCompatActivity {

    private TextView tvTeacherName, tvTeacherID;
    private EditText etSearch;
    private Button btnCreate;
    private TextView chipAll, chipActive, chipDraft, chipPending;
    private View indicatorAll, indicatorActive, indicatorDraft, indicatorPending;
    private String activeFilter = "all";
    private LinearLayout layoutQuizList;
    private TextView tvNoQuizzes;
    private BottomNavigationView bottomNav;

    private DatabaseReference dbRef;
    private String teacherUid;

    private final List<Map<String, Object>> allQuizzes = new ArrayList<>();

    private final ActivityResultLauncher<Intent> createLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    r -> { if (r.getResultCode() == RESULT_OK) loadQuizzes(); });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_quizzes);

        teacherUid = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : "";
        dbRef = FirebaseDatabase.getInstance().getReference();

        initViews();
        loadTeacherInfo();
        setupChips();
        setupSearch();
        btnCreate.setOnClickListener(v ->
                createLauncher.launch(new Intent(this, CreateQuizActivity.class)));
        setupBottomNav();
        loadQuizzes();
    }

    private void initViews() {
        tvTeacherName  = findViewById(R.id.tvTeacherName);
        tvTeacherID    = findViewById(R.id.tvTeacherID);
        etSearch       = findViewById(R.id.etSearch);
        btnCreate      = findViewById(R.id.btnCreate);
        chipAll        = findViewById(R.id.chipAll);
        chipActive     = findViewById(R.id.chipActive);
        chipDraft      = findViewById(R.id.chipDraft);
        chipPending    = findViewById(R.id.chipPending);
        indicatorAll      = findViewById(R.id.indicatorAll);
        indicatorActive   = findViewById(R.id.indicatorActive);
        indicatorDraft    = findViewById(R.id.indicatorDraft);
        indicatorPending  = findViewById(R.id.indicatorPending);
        layoutQuizList = findViewById(R.id.layoutQuizList);
        tvNoQuizzes    = findViewById(R.id.tvNoQuizzes);
        bottomNav      = findViewById(R.id.bottomNav);
    }

    private void loadTeacherInfo() {
        // Header shows static page title "Quizzes" — no overwrite needed
    }

    private void setupChips() {
        chipAll.setOnClickListener(v     -> setFilter("all",       chipAll));
        chipActive.setOnClickListener(v  -> setFilter("active",    chipActive));
        chipDraft.setOnClickListener(v   -> setFilter("draft",     chipDraft));
        chipPending.setOnClickListener(v -> setFilter("completed", chipPending));
        setFilter("all", chipAll);
    }

    private void setFilter(String f, TextView chip) {
        activeFilter = f;
        indicatorAll.setVisibility(chip == chipAll ? View.VISIBLE : View.GONE);
        indicatorActive.setVisibility(chip == chipActive ? View.VISIBLE : View.GONE);
        indicatorDraft.setVisibility(chip == chipDraft ? View.VISIBLE : View.GONE);
        indicatorPending.setVisibility(chip == chipPending ? View.VISIBLE : View.GONE);
        renderCards(filtered());
    }

    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) { renderCards(filtered()); }
        });
    }

    private void loadQuizzes() {
        if (teacherUid.isEmpty()) return;
        dbRef.child("Quizzes").child(teacherUid)
                .addValueEventListener(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snap) {
                        allQuizzes.clear();
                        for (DataSnapshot ds : snap.getChildren()) {
                            Map<String, Object> q = new HashMap<>();
                            for (DataSnapshot f : ds.getChildren()) q.put(f.getKey(), f.getValue());
                            if (!q.containsKey("quizId")) q.put("quizId", ds.getKey());
                            allQuizzes.add(q);
                        }
                        allQuizzes.sort((a, b) -> {
                            long ta = a.containsKey("createdAt") ? ((Number)a.get("createdAt")).longValue() : 0;
                            long tb = b.containsKey("createdAt") ? ((Number)b.get("createdAt")).longValue() : 0;
                            return Long.compare(tb, ta);
                        });
                        renderCards(filtered());
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {
                        Toast.makeText(TeacherQuizzesActivity.this,
                                "Load failed", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private List<Map<String, Object>> filtered() {
        String q = etSearch.getText().toString().trim().toLowerCase();
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> quiz : allQuizzes) {
            if (!"all".equals(activeFilter) && !activeFilter.equals(s(quiz, "status"))) continue;
            if (!q.isEmpty()) {
                if (!s(quiz,"title").toLowerCase().contains(q)
                        && !s(quiz,"subject").toLowerCase().contains(q)
                        && !s(quiz,"className").toLowerCase().contains(q)) continue;
            }
            out.add(quiz);
        }
        return out;
    }

    private void renderCards(List<Map<String, Object>> list) {
        layoutQuizList.removeAllViews();
        tvNoQuizzes.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
        for (Map<String, Object> quiz : list) layoutQuizList.addView(buildCard(quiz));
    }

    private View buildCard(Map<String, Object> quiz) {
        View v = LayoutInflater.from(this).inflate(R.layout.card_quiz_item, layoutQuizList, false);

        String status  = s(quiz, "status");
        String title   = s(quiz, "title");
        String subject = s(quiz, "subject");
        String cls     = s(quiz, "className");
        String endDate = s(quiz, "endDate");
        String qType   = s(quiz, "questionType");
        String quizId  = s(quiz, "quizId");

        // Subject + class badges
        ((TextView) v.findViewById(R.id.tvQuizSubject)).setText(
                subject + (!qType.isEmpty() ? " • " + qType : ""));
        ((TextView) v.findViewById(R.id.tvQuizClass)).setText(cls);

        TextView    tvTitle     = v.findViewById(R.id.tvQuizTitle);
        TextView    tvTime      = v.findViewById(R.id.tvQuizTime);
        TextView    tvStatus    = v.findViewById(R.id.tvQuizStatus);
        ProgressBar pb          = v.findViewById(R.id.progressQuiz);
        LinearLayout statsRow   = v.findViewById(R.id.layoutStats);
        LinearLayout scoreBox   = v.findViewById(R.id.layoutScore);
        LinearLayout shareSection = v.findViewById(R.id.layoutShareSection);
        FrameLayout  frameSubmissions = v.findViewById(R.id.frameSubmissions);
        Button       btnSubmissions   = v.findViewById(R.id.btnSubmissions);
        Button       btnShare         = v.findViewById(R.id.btnShare);
        TextView     tvBadge          = v.findViewById(R.id.tvSubmissionBadge);
        ImageView    ivMenu           = v.findViewById(R.id.ivQuizMenu);

        tvTitle.setText(title);

        // Share section pickers
        android.widget.RelativeLayout layoutShareStart = v.findViewById(R.id.layoutShareStart);
        android.widget.RelativeLayout layoutShareEnd   = v.findViewById(R.id.layoutShareEnd);
        TextView tvShareStart = v.findViewById(R.id.tvShareStart);
        TextView tvShareEnd   = v.findViewById(R.id.tvShareEnd);
        EditText etMsg        = v.findViewById(R.id.etShareMessage);
        Button   btnConfirm   = v.findViewById(R.id.btnConfirmShare);

        final String[] sStart = {""}, sEnd = {""};

        layoutShareStart.setOnClickListener(x -> {
            java.util.Calendar cal = java.util.Calendar.getInstance();
            new android.app.DatePickerDialog(this, (dv, y, m, d) -> {
                sStart[0] = d + "/" + (m+1) + "/" + y;
                tvShareStart.setText(sStart[0]);
                tvShareStart.setTextColor(0xFF000000);
            }, cal.get(java.util.Calendar.YEAR),
                    cal.get(java.util.Calendar.MONTH),
                    cal.get(java.util.Calendar.DAY_OF_MONTH)).show();
        });

        layoutShareEnd.setOnClickListener(x -> {
            java.util.Calendar cal = java.util.Calendar.getInstance();
            new android.app.DatePickerDialog(this, (dv, y, m, d) -> {
                sEnd[0] = d + "/" + (m+1) + "/" + y;
                tvShareEnd.setText(sEnd[0]);
                tvShareEnd.setTextColor(0xFF000000);
            }, cal.get(java.util.Calendar.YEAR),
                    cal.get(java.util.Calendar.MONTH),
                    cal.get(java.util.Calendar.DAY_OF_MONTH)).show();
        });

        btnConfirm.setOnClickListener(x -> {
            if (sStart[0].isEmpty()) {
                Toast.makeText(this, "Please Select Start date", Toast.LENGTH_SHORT).show(); return;
            }
            if (sEnd[0].isEmpty()) {
                Toast.makeText(this, "Please Select Deadline", Toast.LENGTH_SHORT).show(); return;
            }

            // Disable to prevent double-tap
            btnConfirm.setEnabled(false);
            btnConfirm.setText("Sharing...");

            Map<String, Object> updates = new HashMap<>();
            updates.put("status", "active");
            updates.put("startDate", sStart[0]);
            updates.put("endDate",   sEnd[0]);
            if (!etMsg.getText().toString().trim().isEmpty())
                updates.put("shareMessage", etMsg.getText().toString().trim());

            dbRef.child("Quizzes").child(teacherUid).child(quizId)
                    .updateChildren(updates)
                    .addOnSuccessListener(u -> {
                        shareSection.setVisibility(View.GONE);
                        // Share to matching students
                        shareQuizToStudents(quizId, updates);
                    })
                    .addOnFailureListener(e -> {
                        btnConfirm.setEnabled(true);
                        btnConfirm.setText("Confirm Share");
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        });

        // ── PopupMenu (assignment style) ─────────────────────────────────
        ivMenu.setImageResource(android.R.drawable.ic_menu_more);
        ivMenu.setColorFilter(0xFF555555);

        ivMenu.setOnClickListener(anchor -> {
            PopupMenu popup = new PopupMenu(this, anchor);
            boolean isShared = "active".equals(status) || "completed".equals(status);

            if (isShared) {
                popup.getMenu().add(0, 1, 1, "📄  Submissions");
                popup.getMenu().add(0, 3, 2, "🗑  Delete");
            } else {
                popup.getMenu().add(0, 2, 1, "✏  Edit");
                popup.getMenu().add(0, 3, 2, "🗑  Delete");
            }

            popup.setOnMenuItemClickListener(item -> {
                switch (item.getItemId()) {
                    case 1: openSubmissions(quiz); return true;
                    case 2: openEdit(quiz); return true;
                    case 3: confirmDelete(quiz);   return true;
                }
                return false;
            });
            popup.show();
        });

        // ── Status-based UI ──────────────────────────────────────────────
        switch (status) {

            case "active":
                tvStatus.setText("● Active");
                tvStatus.setTextColor(0xFF4CAF50);
                tvTime.setText(endDate.isEmpty() ? "No deadline" : "Due: " + endDate);
                pb.setVisibility(View.VISIBLE);
                statsRow.setVisibility(View.VISIBLE);
                ((TextView) v.findViewById(R.id.tvQuizStudents)).setText("Awaiting attempts");
                // ── FIX: Active quiz par "Extend Deadline" button — sirf date extend, reshare nahi ──
                btnShare.setVisibility(View.VISIBLE);
                btnShare.setText("Extend Time");
                btnShare.setOnClickListener(b -> showExtendDeadlineDialog(quizId, endDate));
                // Submissions button — only show if there are attempts
                listenForAttempts(quizId, frameSubmissions, tvBadge, btnSubmissions, quiz);
                break;

            case "draft":
                tvStatus.setText("● Draft");
                tvStatus.setTextColor(0xFF9E9E9E);
                tvTime.setText("Not shared yet");
                // Only Share button, no Submissions
                btnShare.setVisibility(View.VISIBLE);
                btnShare.setOnClickListener(b -> shareSection.setVisibility(
                        shareSection.getVisibility() == View.GONE ? View.VISIBLE : View.GONE));
                break;

            case "completed":
                tvStatus.setText("● Completed");
                tvStatus.setTextColor(0xFF2196F3);
                tvTime.setText(endDate.isEmpty() ? "" : "Ended: " + endDate);
                scoreBox.setVisibility(View.VISIBLE);
                loadAvgScore(quizId, v);
                // Always show Submissions on completed
                frameSubmissions.setVisibility(View.VISIBLE);
                btnSubmissions.setOnClickListener(b -> openSubmissions(quiz));
                listenForAttempts(quizId, frameSubmissions, tvBadge, btnSubmissions, quiz);
                break;

            default:
                tvStatus.setText("● Draft");
                tvStatus.setTextColor(0xFF9E9E9E);
                tvTime.setText("Not shared yet");
                btnShare.setVisibility(View.VISIBLE);
                btnShare.setOnClickListener(b -> shareSection.setVisibility(
                        shareSection.getVisibility() == View.GONE ? View.VISIBLE : View.GONE));
                break;
        }

        return v;
    }

    private void openEdit(Map<String, Object> quiz) {
        Intent i = new Intent(this, CreateQuizActivity.class);
        i.putExtra("EDIT_MODE", true);
        i.putExtra("QUIZ_ID",       s(quiz, "quizId"));
        i.putExtra("QUIZ_TITLE",    s(quiz, "title"));
        i.putExtra("QUIZ_SUBJECT",  s(quiz, "subject"));
        i.putExtra("QUIZ_CLASS",    s(quiz, "className"));
        i.putExtra("QUIZ_TYPE",     s(quiz, "questionType"));
        i.putExtra("QUIZ_TIME",     s(quiz, "timeLimit"));
        i.putExtra("QUIZ_DESC",     s(quiz, "description"));
        i.putExtra("QUIZ_START",    s(quiz, "startDate"));
        i.putExtra("QUIZ_END",      s(quiz, "endDate"));
        i.putExtra("QUIZ_STATUS",   s(quiz, "status")); // FIX: status pass karo
        createLauncher.launch(i);
    }

    // ── Listen for quiz attempts — show Submissions button + badge ──────
    private void listenForAttempts(String quizId, FrameLayout frame,
                                   TextView badge, Button btnSub,
                                   Map<String, Object> quiz) {
        dbRef.child("QuizAttempts").child(quizId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snap) {
                        long count = snap.getChildrenCount();
                        // Show Submissions button only when at least 1 attempt
                        frame.setVisibility(count > 0 ? View.VISIBLE : View.GONE);
                        if (count > 0) {
                            // Button text with count — same style as assignment
                            btnSub.setText("📄 SUBMISSIONS  (" + count + ")");
                            btnSub.setOnClickListener(b -> openSubmissions(quiz));
                        }

                        // ── Auto-complete check ──────────────────────────────
                        // Fresh status Firebase se read karo (stale map se nahi)
                        dbRef.child("Quizzes").child(teacherUid).child(quizId)
                                .child("status").get().addOnSuccessListener(statusSnap -> {
                                    String currentStatus = statusSnap.getValue(String.class);
                                    if (!"active".equals(currentStatus)) return; // sirf active par check

                                    // 1) Deadline expire check
                                    String endDate = s(quiz, "endDate");
                                    if (!endDate.isEmpty()) {
                                        try {
                                            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("d/M/yyyy", java.util.Locale.getDefault());
                                            java.util.Date deadline = sdf.parse(endDate);
                                            if (deadline != null) {
                                                // Deadline ke din ka end (midnight) tak allow karo
                                                java.util.Calendar cal = java.util.Calendar.getInstance();
                                                cal.setTime(deadline);
                                                cal.set(java.util.Calendar.HOUR_OF_DAY, 23);
                                                cal.set(java.util.Calendar.MINUTE, 59);
                                                cal.set(java.util.Calendar.SECOND, 59);
                                                java.util.Date deadlineEnd = cal.getTime();
                                                java.util.Date now = new java.util.Date();
                                                if (now.after(deadlineEnd)) {
                                                    markQuizCompleted(quizId);
                                                    return;
                                                }
                                            }
                                        } catch (Exception ignored) {}
                                    }

                                    // 2) All shared students submitted check
                                    dbRef.child("SharedQuizzes").get()
                                            .addOnSuccessListener(allShared -> {
                                                long sharedCount = 0;
                                                for (DataSnapshot studentNode : allShared.getChildren()) {
                                                    if (studentNode.hasChild(quizId)) sharedCount++;
                                                }
                                                if (sharedCount > 0 && count >= sharedCount) {
                                                    markQuizCompleted(quizId);
                                                }
                                            });
                                });
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError e) {
                        frame.setVisibility(View.GONE);
                    }
                });
    }

    private void markQuizCompleted(String quizId) {
        dbRef.child("Quizzes").child(teacherUid).child(quizId)
                .child("status").setValue("completed");
    }

    private void openSubmissions(Map<String, Object> quiz) {
        Intent i = new Intent(this, QuizSubmissionsActivity.class);
        i.putExtra(QuizSubmissionsActivity.EXTRA_QUIZ_ID,    s(quiz, "quizId"));
        i.putExtra(QuizSubmissionsActivity.EXTRA_QUIZ_TITLE, s(quiz, "title"));
        i.putExtra(QuizSubmissionsActivity.EXTRA_TEACHER_ID, teacherUid);
        startActivity(i);
    }

    private void loadAvgScore(String quizId, View cardView) {
        dbRef.child("QuizAttempts").child(quizId).get()
                .addOnSuccessListener(snap -> {
                    if (!snap.exists()) return;
                    int total = 0, count = 0;
                    for (DataSnapshot ds : snap.getChildren()) {
                        Object sc = ds.child("score").getValue();
                        if (sc != null) { total += ((Number)sc).intValue(); count++; }
                    }
                    if (count > 0) {
                        int avg = total / count;
                        String avgText = "Avg Score: " + avg + " marks  |  " + count + (count > 1 ? " students" : " student") + " submitted";
                        ((TextView) cardView.findViewById(R.id.tvAvgScore)).setText(avgText);
                    } else {
                        ((TextView) cardView.findViewById(R.id.tvAvgScore)).setText("No submissions yet");
                    }
                });
    }

    private void confirmDelete(Map<String, Object> quiz) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Quiz")
                .setMessage("\"" + s(quiz,"title") + "\" Are you sure you want to delete?")
                .setPositiveButton("Delete", (d, w) ->
                        dbRef.child("Quizzes").child(teacherUid).child(s(quiz,"quizId"))
                                .removeValue()
                                .addOnSuccessListener(u ->
                                        Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(e ->
                                        Toast.makeText(this, "Failed: " + e.getMessage(),
                                                Toast.LENGTH_SHORT).show()))
                .setNegativeButton("Cancel", null).show();
    }

    private void setupBottomNav() {
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                Intent intent = new Intent(this, TeacherDashboardActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
                return true;
            }
            if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class));
                finish();
                return true;
            }
            if (id == R.id.nav_bottom_Announcment) {
                startActivity(new Intent(this, TeacherAnnouncementsActivity.class));
                finish();
                return true;
            }
            if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileMenuActivity.class));
                finish();
                return true;
            }
            return false;
        });
    }

    private String s(Map<String, Object> map, String key) {
        Object val = map.get(key); return val != null ? val.toString() : "";
    }

    // ─── Extend Time Dialog — timeLimit extend + optional deadline extend ────
    private void showExtendDeadlineDialog(String quizId, String currentEndDate) {
        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(50, 20, 50, 10);

        android.widget.EditText etNewTime = new android.widget.EditText(this);
        etNewTime.setHint("Extra minutes (e.g. 10)");
        etNewTime.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        android.widget.TextView tvDeadlineLabel = new android.widget.TextView(this);
        tvDeadlineLabel.setText("Current deadline: " + (currentEndDate.isEmpty() ? "Not set" : currentEndDate));
        tvDeadlineLabel.setTextSize(12f);
        tvDeadlineLabel.setPadding(0, 16, 0, 4);

        android.widget.EditText etNewDeadline = new android.widget.EditText(this);
        etNewDeadline.setHint("New deadline (optional, tap to pick)");
        etNewDeadline.setFocusable(false);
        etNewDeadline.setClickable(true);
        final String[] pickedDate = {""};
        etNewDeadline.setOnClickListener(v -> {
            java.util.Calendar cal = java.util.Calendar.getInstance();
            new android.app.DatePickerDialog(this, (dv, y, m, d) -> {
                pickedDate[0] = d + "/" + (m + 1) + "/" + y;
                etNewDeadline.setText(pickedDate[0]);
            }, cal.get(java.util.Calendar.YEAR),
                    cal.get(java.util.Calendar.MONTH),
                    cal.get(java.util.Calendar.DAY_OF_MONTH)).show();
        });

        layout.addView(etNewTime);
        layout.addView(tvDeadlineLabel);
        layout.addView(etNewDeadline);

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("⏱️ Extend Quiz Time")
                .setMessage("Enter extra minutes to add to the quiz timer:")
                .setView(layout)
                .setPositiveButton("Extend", (dialog, which) -> {
                    String input = etNewTime.getText().toString().trim();
                    if (input.isEmpty()) {
                        Toast.makeText(this, "Please enter extra minutes", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int extraMins = Integer.parseInt(input);
                    if (extraMins <= 0) {
                        Toast.makeText(this, "Minutes must be > 0", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    dbRef.child("Quizzes").child(teacherUid).child(quizId)
                            .child("timeLimit").get()
                            .addOnSuccessListener(snap -> {
                                int currentTime = 0;
                                if (snap.getValue() != null) {
                                    try { currentTime = Integer.parseInt(snap.getValue().toString()); }
                                    catch (NumberFormatException ignored) {}
                                }
                                int newTime = currentTime + extraMins;
                                String confirmMsg = "Current time: " + currentTime + " min"
                                        + "\nExtra: +" + extraMins + " min"
                                        + "\nNew time: " + newTime + " min";
                                if (!pickedDate[0].isEmpty())
                                    confirmMsg += "\nNew deadline: " + pickedDate[0];
                                confirmMsg += "\n\nConfirm extension?";

                                final int finalNewTime = newTime;
                                new androidx.appcompat.app.AlertDialog.Builder(this)
                                        .setTitle("Confirm Extension")
                                        .setMessage(confirmMsg)
                                        .setPositiveButton("Yes, Extend", (d2, w2) -> {
                                            Map<String, Object> upd = new HashMap<>();
                                            upd.put("timeLimit", String.valueOf(finalNewTime));
                                            if (!pickedDate[0].isEmpty())
                                                upd.put("endDate", pickedDate[0]);
                                            dbRef.child("Quizzes").child(teacherUid).child(quizId)
                                                    .updateChildren(upd)
                                                    .addOnSuccessListener(u ->
                                                            updateSharedQuizTime(quizId, finalNewTime, pickedDate[0])
                                                    )
                                                    .addOnFailureListener(e ->
                                                            Toast.makeText(this,
                                                                    "Failed: " + e.getMessage(),
                                                                    Toast.LENGTH_SHORT).show());
                                        })
                                        .setNegativeButton("Cancel", null).show();
                            });
                })
                .setNegativeButton("Cancel", null).show();
    }

    // ─── SharedQuizzes mein timeLimit update + optional deadline + students ko announcement ──
    private void updateSharedQuizTime(String quizId, int newTime, String newDeadline) {
        dbRef.child("SharedQuizzes").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Map<String, Object> batchUpdates = new HashMap<>();
                String[] quizTitle = {"Quiz"};
                String[] quizClass = {""};

                for (DataSnapshot studentSnap : snapshot.getChildren()) {
                    if (studentSnap.hasChild(quizId)) {
                        String studentUid = studentSnap.getKey();

                        // timeLimit update
                        batchUpdates.put("SharedQuizzes/" + studentUid
                                + "/" + quizId + "/timeLimit", String.valueOf(newTime));

                        // Optional deadline update
                        if (newDeadline != null && !newDeadline.isEmpty()) {
                            batchUpdates.put("SharedQuizzes/" + studentUid
                                    + "/" + quizId + "/endDate", newDeadline);
                        }

                        DataSnapshot quizSnap = studentSnap.child(quizId);
                        if (quizSnap.child("title").getValue() != null)
                            quizTitle[0] = quizSnap.child("title").getValue(String.class);
                        if (quizSnap.child("className").getValue() != null)
                            quizClass[0] = quizSnap.child("className").getValue(String.class);
                    }
                }

                if (!batchUpdates.isEmpty()) {
                    String announceMsg = "New time limit: " + newTime + " minutes";
                    if (newDeadline != null && !newDeadline.isEmpty())
                        announceMsg += " | Deadline: " + newDeadline;

                    String announceKey = quizId + "_ext_" + System.currentTimeMillis();
                    Map<String, Object> announcement = new HashMap<>();
                    announcement.put("title",     "⏱️ Quiz Time Extended: " + quizTitle[0]);
                    announcement.put("message",   announceMsg);
                    announcement.put("timestamp", System.currentTimeMillis());
                    announcement.put("pdfUrl",    "");
                    announcement.put("targetClass", quizClass[0]);
                    batchUpdates.put("Announcements/Students/" + announceKey, announcement);

                    dbRef.updateChildren(batchUpdates)
                            .addOnSuccessListener(u ->
                                    Toast.makeText(TeacherQuizzesActivity.this,
                                            "✅ Time extended & students notified!",
                                            Toast.LENGTH_SHORT).show())
                            .addOnFailureListener(e ->
                                    Toast.makeText(TeacherQuizzesActivity.this,
                                            "Update failed: " + e.getMessage(),
                                            Toast.LENGTH_SHORT).show());
                } else {
                    Toast.makeText(TeacherQuizzesActivity.this,
                            "No shared students found to update.", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // ─── Quiz: matching students ko Firebase mein share karo ─────────────
    // ─── Assignment ki tarah exact same logic ────────────────────────────────
    private void shareQuizToStudents(String quizId, Map<String, Object> quizUpdates) {
        dbRef.child("Quizzes").child(teacherUid).child(quizId).get()
                .addOnSuccessListener(quizSnap -> {
                    if (!quizSnap.exists()) {
                        Toast.makeText(this, "Quiz data not found.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    @SuppressWarnings("unchecked")
                    Map<String, Object> quizData = (Map<String, Object>) quizSnap.getValue();
                    if (quizData == null) return;

                    String className = quizData.containsKey("className") && quizData.get("className") != null
                            ? quizData.get("className").toString().trim() : "";
                    String quizTitle = quizData.containsKey("title") && quizData.get("title") != null
                            ? quizData.get("title").toString() : "Quiz";
                    String subject   = quizData.containsKey("subject") && quizData.get("subject") != null
                            ? quizData.get("subject").toString().trim() : "";

                    if (className.isEmpty()) {
                        Toast.makeText(this, "Class not set for this quiz.", Toast.LENGTH_LONG).show();
                        return;
                    }

                    FirebaseDatabase.getInstance().getReference("Users")
                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    int[] count = {0};
                                    DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
                                    Map<String, Object> childUpdates = new HashMap<>();

                                    for (DataSnapshot userSnap : snapshot.getChildren()) {
                                        String role = userSnap.child("role").getValue(String.class);
                                        if (role == null || !role.equalsIgnoreCase("Student")) continue;

                                        String status = userSnap.child("status").getValue(String.class);
                                        if (status == null || !status.equalsIgnoreCase("Approved")) continue;

                                        String studentClass = userSnap.child("className").getValue(String.class);
                                        if (studentClass == null) continue;

                                        if (!className.isEmpty() && !studentClass.trim().equalsIgnoreCase(className)) continue;

                                        // Subject ke hisaab se bhi filter karo — sirf woh students
                                        // jinhone is subject mein enrollment ki hai
                                        if (!subject.isEmpty()) {
                                            boolean enrolled = false;
                                            for (DataSnapshot sub : userSnap.child("enrolledSubjects").getChildren()) {
                                                String val = sub.getValue(String.class);
                                                if (val != null && val.equalsIgnoreCase(subject)) { enrolled = true; break; }
                                            }
                                            if (!enrolled) continue;
                                        }

                                        String studentUid = userSnap.getKey();

                                        Map<String, Object> sharedData = new HashMap<>();
                                        sharedData.put("quizId",       quizId);
                                        sharedData.put("teacherUid",   teacherUid);
                                        sharedData.put("title",        quizTitle);
                                        sharedData.put("subject",      subject);
                                        sharedData.put("className",    className);
                                        sharedData.put("timeLimit",    quizData.containsKey("timeLimit") ? quizData.get("timeLimit") : "30");
                                        sharedData.put("startDate",    quizUpdates.containsKey("startDate") ? quizUpdates.get("startDate") : "");
                                        sharedData.put("endDate",      quizUpdates.containsKey("endDate")   ? quizUpdates.get("endDate")   : "");
                                        sharedData.put("description",  quizData.containsKey("description") ? quizData.get("description") : "");
                                        sharedData.put("questionType", quizData.containsKey("questionType") ? quizData.get("questionType") : "");
                                        sharedData.put("status",       "active");
                                        sharedData.put("sharedAt",     System.currentTimeMillis());
                                        childUpdates.put("SharedQuizzes/" + studentUid + "/" + quizId, sharedData);
                                        count[0]++;
                                    }

                                    if (count[0] > 0) {
                                        Map<String, Object> announcement = new HashMap<>();
                                        announcement.put("title",     "📝 New Quiz: " + quizTitle + " (" + subject + ")");
                                        announcement.put("message",   quizData.containsKey("description") && quizData.get("description") != null
                                                ? quizData.get("description").toString() + "\nClass: " + className
                                                : "Class: " + className);
                                        announcement.put("timestamp", System.currentTimeMillis());
                                        announcement.put("pdfUrl",    "");
                                        announcement.put("targetClass", className);
                                        childUpdates.put("/Announcements/Students/" + quizId, announcement);

                                        rootRef.updateChildren(childUpdates).addOnCompleteListener(task -> {
                                            if (task.isSuccessful()) {
                                                Toast.makeText(TeacherQuizzesActivity.this,
                                                        "✅ Quiz shared & Admin Announcement distributed!", Toast.LENGTH_SHORT).show();
                                            } else {
                                                Toast.makeText(TeacherQuizzesActivity.this,
                                                        "Database Write Error", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                    } else {
                                        Toast.makeText(TeacherQuizzesActivity.this,
                                                "⚠️ No approved students found for class: " + className, Toast.LENGTH_SHORT).show();
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
                                    Toast.makeText(TeacherQuizzesActivity.this,
                                            "Share failed: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to load quiz: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}