package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class TeacherAnnouncementsActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    // UI Components
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private BottomNavigationView bottomNav;
    private ImageView ivMenu, ivBack;
    private EditText etSearchAnnouncements;
    private LinearLayout containerAnnouncements;
    private TextView tvTotalAnnouncements;

    // Firebase & Local Variables
    private DatabaseReference mDatabase;
    private String searchQueryKeyword = "";
    private final List<SimpleNotificationModel> dataList = new ArrayList<>();

    // ✅ Swipe-to-delete: teacher jo announcement swipe kar ke delete kare,
    // uska id yahan save hota hai — taake dobara wo card list mein na aaye
    // (naye announcements ke liye affect nahi karta, aur teacher ke apne UID
    // ke sath persist hota hai, alag teachers ka data mix nahi hota)
    private SharedPreferences seenPrefs;
    private static final String PREFS_NAME = "seen_announcements";
    private String dismissedKeysPrefKey = "dismissed_keys_teacher";

    // Internal Object Structure Data Model
    static class SimpleNotificationModel {
        String id, title, message, targetGroup, targetClass, targetTeacherId;
        long timestamp;

        SimpleNotificationModel(String id, String title, String message, String targetGroup,
                                String targetClass, String targetTeacherId, long timestamp) {
            this.id = id;
            this.title = title;
            this.message = message;
            this.targetGroup = targetGroup;
            this.targetClass = targetClass;
            this.targetTeacherId = targetTeacherId;
            this.timestamp = timestamp;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_announcements);

        // --- Init All UI Views ---
        initViews();

        // Swipe-to-delete: per-teacher dismissed list, taake logout/login
        // ke baad bhi qaim rahe aur alag teachers ka data mix na ho
        seenPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            dismissedKeysPrefKey = "dismissed_keys_teacher_" + FirebaseAuth.getInstance().getCurrentUser().getUid();
        }

        // --- Firebase Node Reference Setup ---
        mDatabase = FirebaseDatabase.getInstance().getReference().child("Announcements").child("Teachers");

        // --- Setup Custom Search Engine ---
        setupSearchEngineInput();

        navigationView.setNavigationItemSelectedListener(this);

        // Header Navigation Handle Click
        if (ivBack != null) {
            ivBack.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
        }
        if (ivMenu != null) {
            ivMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
        }

        // --- Bottom Navigation Mapping ---
        setupBottomNavigation();

        // Trigger Main Firebase Continuous Stream Fetch
        fetchNotificationsData();
    }

    private void initViews() {
        drawerLayout           = findViewById(R.id.drawerLayout);
        navigationView         = findViewById(R.id.navigationView);
        bottomNav              = findViewById(R.id.bottomNav);
        ivMenu                 = findViewById(R.id.ivMenu);
        ivBack                 = findViewById(R.id.ivBack);
        containerAnnouncements = findViewById(R.id.containerAnnouncements);
        etSearchAnnouncements  = findViewById(R.id.etSearchAnnouncements);
        tvTotalAnnouncements   = findViewById(R.id.tvTotalAnnouncements);
    }

    // Characters Typing Live Search Mechanism
    private void setupSearchEngineInput() {
        if (etSearchAnnouncements == null) return;
        etSearchAnnouncements.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQueryKeyword = s.toString().trim().toLowerCase();
                populateCardsUI();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    // Firebase Data Reader Logic Loop
    private void fetchNotificationsData() {
        String currentTeacherUid = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : null;

        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dataList.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    String title  = snap.child("title").getValue(String.class);
                    String msg    = snap.child("message").getValue(String.class);
                    String target = snap.child("targetGroup").getValue(String.class);
                    String cls    = snap.child("targetClass").getValue(String.class);
                    String targetTeacherId = snap.child("targetTeacherId").getValue(String.class);
                    Long time     = snap.child("timestamp").getValue(Long.class);

                    // Agar yeh announcement kisi specific teacher ke liye hai
                    // (e.g. assignment submission notification), to sirf wahi
                    // teacher dekh sake — baqi sab ko skip karo.
                    if (targetTeacherId != null && !targetTeacherId.trim().isEmpty()
                            && !targetTeacherId.equals(currentTeacherUid)) {
                        continue;
                    }

                    if (target == null) target = "All Teachers";
                    if (cls == null || cls.trim().isEmpty()) cls = "All Classes";

                    dataList.add(new SimpleNotificationModel(
                            snap.getKey(), title, msg, target, cls, targetTeacherId, time != null ? time : 0L));
                }

                // Latest announcement sab se upar (student wale design ki tarah)
                Collections.sort(dataList, (a, b) -> Long.compare(b.timestamp, a.timestamp));

                populateCardsUI();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(TeacherAnnouncementsActivity.this, "Network Sync Error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Dynamic Row Elements Inflation Engine
    private void populateCardsUI() {
        if (containerAnnouncements == null) return;
        containerAnnouncements.removeAllViews();

        boolean hasItems = false;
        int displayNumber = 0;

        Set<String> dismissedKeys = new HashSet<>(seenPrefs.getStringSet(dismissedKeysPrefKey, new HashSet<>()));

        // ✅ Total count ab dismissed items ko chor kar (search se independent)
        // calculate hota hai, taake swipe-delete ke baad turant update ho jaye
        int visibleTotal = 0;
        for (SimpleNotificationModel it : dataList) {
            if (it.id == null || !dismissedKeys.contains(it.id)) visibleTotal++;
        }
        if (tvTotalAnnouncements != null) {
            tvTotalAnnouncements.setText("Total Announcements: " + visibleTotal);
        }

        for (SimpleNotificationModel item : dataList) {

            // ✅ swipe se delete kiya hua skip karo
            if (item.id != null && dismissedKeys.contains(item.id)) {
                continue;
            }

            // Search Keyword Sequence Matching
            if (!searchQueryKeyword.isEmpty()) {
                boolean matchTitle = item.title != null && item.title.toLowerCase().contains(searchQueryKeyword);
                boolean matchMsg   = item.message != null && item.message.toLowerCase().contains(searchQueryKeyword);
                if (!matchTitle && !matchMsg) {
                    continue;
                }
            }

            hasItems = true;
            displayNumber++;

            // Layout Inflater to bind item elements card view layout
            View cardView = LayoutInflater.from(this).inflate(R.layout.item_teacher_announcements, containerAnnouncements, false);

            TextView tvItemNumber      = cardView.findViewById(R.id.tvItemNumber);
            TextView tvItemTitle       = cardView.findViewById(R.id.tvItemTitle);
            TextView tvItemDate        = cardView.findViewById(R.id.tvItemDate);
            TextView tvItemDescription = cardView.findViewById(R.id.tvItemDescription);
            TextView tvItemAudience    = cardView.findViewById(R.id.tvItemAudience);

            if (tvItemNumber != null) tvItemNumber.setText("#" + displayNumber);
            if (tvItemTitle != null) tvItemTitle.setText(item.title);
            if (tvItemDescription != null) tvItemDescription.setText(item.message);
            if (tvItemAudience != null) tvItemAudience.setText("👥 " + item.targetGroup);



            if (tvItemDate != null && item.timestamp > 0) {
                tvItemDate.setText(new SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(new Date(item.timestamp)));
            }

            // ✅ Swipe left/right to delete — card ko taraf khinchne pe fade/slide
            // ho ke list se hamesha ke liye hat jata hai (locally, per-teacher saved)
            enableSwipeToDelete(cardView, item);

            containerAnnouncements.addView(cardView);
        }

        if (!hasItems) {
            showEmptyPlaceholder();
        }
    }

    /**
     * Card ko horizontal swipe karne pe drag + fade animate karta hai; agar
     * swipe threshold se zyada ho to card animate ho ke gayab ho jata hai aur
     * uska id "dismissed" list mein save ho jata hai (taake dobara na dikhe).
     * Halke se swipe pe card wapas apni jagah snap ho jata hai.
     * Vertical scroll (ScrollView) ke sath conflict na ho, is liye pehle
     * movement ki direction check ki jati hai — sirf clearly horizontal
     * movement ko swipe treat kiya jata hai.
     */
    private void enableSwipeToDelete(final View itemView, final SimpleNotificationModel item) {
        final float dp = getResources().getDisplayMetrics().density;
        final float dismissThreshold = 120 * dp;

        // Card ko clickable/focusable banana zaroori hai, warna ACTION_DOWN
        // consume nahi hota aur baad ki MOVE/UP events (swipe gesture) is
        // view tak pohanchti hi nahi (kyunke card par koi click listener
        // pehle se attached nahi hai, student wali activity ke ulat).
        itemView.setClickable(true);
        itemView.setFocusable(true);

        itemView.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private boolean swiping = false;

            @Override
            public boolean onTouch(View v, android.view.MotionEvent event) {
                switch (event.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        downX = event.getRawX();
                        downY = event.getRawY();
                        swiping = false;
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        return false; // click bhi kaam karta rahe

                    case android.view.MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (!swiping && Math.abs(dx) > (12 * dp) && Math.abs(dx) > Math.abs(dy)) {
                            swiping = true;
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                        }
                        if (swiping) {
                            v.setTranslationX(dx);
                            v.setAlpha(Math.max(0.25f, 1f - (Math.abs(dx) / (600f * dp / 2f))));
                            return true;
                        }
                        return false;

                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        if (swiping) {
                            float finalDx = event.getRawX() - downX;
                            v.getParent().requestDisallowInterceptTouchEvent(false);
                            if (Math.abs(finalDx) > dismissThreshold) {
                                float target = finalDx > 0 ? v.getWidth() : -v.getWidth();
                                v.animate().translationX(target).alpha(0f).setDuration(200)
                                        .withEndAction(() -> dismissAnnouncement(item))
                                        .start();
                            } else {
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start();
                            }
                            swiping = false;
                            return true;
                        }
                        return false;
                }
                return false;
            }
        });
    }

    /**
     * Announcement ko permanently (is device/teacher ke liye) hide kar deta hai —
     * id ko "dismissed" list mein save kar ke, list se remove karta hai.
     */
    private void dismissAnnouncement(SimpleNotificationModel item) {
        if (item.id == null) return;
        Set<String> dismissedKeys = new HashSet<>(seenPrefs.getStringSet(dismissedKeysPrefKey, new HashSet<>()));
        dismissedKeys.add(item.id);
        seenPrefs.edit().putStringSet(dismissedKeysPrefKey, dismissedKeys).apply();
        dataList.remove(item);
        populateCardsUI();
    }

    private void showEmptyPlaceholder() {
        TextView tvEmpty = new TextView(this);
        tvEmpty.setText("No announcements available.");
        tvEmpty.setTextSize(14f);
        tvEmpty.setGravity(Gravity.CENTER);
        tvEmpty.setTextColor(Color.parseColor("#888888"));
        tvEmpty.setPadding(0, 80, 0, 0);
        containerAnnouncements.addView(tvEmpty);
    }

    // Bottom Navigation Transitions Controller
    private void setupBottomNavigation() {
        bottomNav.setSelectedItemId(R.id.nav_bottom_Announcment);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_bottom_home) {
                Intent intent = new Intent(this, TeacherDashboardActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
                return true;
            } else if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class));
                finish();
                return true;
            } else if (id == R.id.nav_bottom_Announcment) {
                return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileMenuActivity.class));
                finish();
                return true;
            }
            return false;
        });
    }

    // --- Side Drawer Framework Navigation Click Events ---
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_change_password) {
            Toast.makeText(this, "Change Password", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_logout) {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(this, LoginSelectionActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finishAffinity();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}