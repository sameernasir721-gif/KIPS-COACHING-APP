package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class TeacherAnnouncementsActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    // UI Components
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private BottomNavigationView bottomNav;
    private ImageView ivMenu, ivBack;
    private EditText etSearchAnnouncements;
    private LinearLayout containerAnnouncements;
    private TextView tvTotalAnnouncements;

    // Firebase & Local Variables
    private DatabaseReference mDatabase;
    private String searchQueryKeyword = "";
    private final List<SimpleNotificationModel> dataList = new ArrayList<>();


    private SharedPreferences seenPrefs;
    private static final String PREFS_NAME = "seen_announcements";
    private String dismissedKeysPrefKey = "dismissed_keys_teacher";
    private String seenKeysPrefKey = "seen_keys_teacher";

    private static final int DELETE_REVEAL_DP = 76;
    private Snackbar undoSnackbar = null;
    private View openedCard = null;


    static class SimpleNotificationModel {
        String id, title, message, targetGroup, targetClass, targetTeacherId;
        String type;
        long timestamp;

        SimpleNotificationModel(String id, String title, String message, String targetGroup,
                                String targetClass, String targetTeacherId, long timestamp) {
            this.id = id;
            this.title = title;
            this.message = message;
            this.targetGroup = targetGroup;
            this.targetClass = targetClass;
            this.targetTeacherId = targetTeacherId;
            this.timestamp = timestamp;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_announcements);


        initViews();


        seenPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            dismissedKeysPrefKey = "dismissed_keys_teacher_" + FirebaseAuth.getInstance().getCurrentUser().getUid();
            seenKeysPrefKey = "seen_keys_teacher_" + FirebaseAuth.getInstance().getCurrentUser().getUid();
        }


        mDatabase = FirebaseDatabase.getInstance().getReference().child("Announcements").child("Teachers");


        setupSearchEngineInput();

        navigationView.setNavigationItemSelectedListener(this);

        if (ivBack != null) {
            ivBack.setOnClickListener(v -> startActivity(new Intent(this, TeacherProfileInfoActivity.class)));
        }
        if (ivMenu != null) {
            ivMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
        }

        // --- Bottom Navigation Mapping ---
        setupBottomNavigation();


        fetchNotificationsData();
    }

    private void initViews() {
        drawerLayout           = findViewById(R.id.drawerLayout);
        navigationView         = findViewById(R.id.navigationView);
        bottomNav              = findViewById(R.id.bottomNav);
        ivMenu                 = findViewById(R.id.ivMenu);
        ivBack                 = findViewById(R.id.ivBack);
        containerAnnouncements = findViewById(R.id.containerAnnouncements);
        etSearchAnnouncements  = findViewById(R.id.etSearchAnnouncements);
        tvTotalAnnouncements   = findViewById(R.id.tvTotalAnnouncements);
    }

    private void setupSearchEngineInput() {
        if (etSearchAnnouncements == null) return;
        etSearchAnnouncements.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQueryKeyword = s.toString().trim().toLowerCase();
                populateCardsUI();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void fetchNotificationsData() {
        String currentTeacherUid = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : null;

        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dataList.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    String title  = snap.child("title").getValue(String.class);
                    String msg    = snap.child("message").getValue(String.class);
                    String target = snap.child("targetGroup").getValue(String.class);
                    String cls    = snap.child("targetClass").getValue(String.class);
                    String targetTeacherId = snap.child("targetTeacherId").getValue(String.class);
                    Long time     = snap.child("timestamp").getValue(Long.class);


                    if (targetTeacherId != null && !targetTeacherId.trim().isEmpty()
                            && !targetTeacherId.equals(currentTeacherUid)) {
                        continue;
                    }

                    if (target == null) target = "All Teachers";
                    if (cls == null || cls.trim().isEmpty()) cls = "All Classes";

                    SimpleNotificationModel model = new SimpleNotificationModel(
                            snap.getKey(), title, msg, target, cls, targetTeacherId, time != null ? time : 0L);
                    model.type = snap.child("type").getValue(String.class);
                    dataList.add(model);
                }


                Collections.sort(dataList, (a, b) -> Long.compare(b.timestamp, a.timestamp));

                populateCardsUI();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(TeacherAnnouncementsActivity.this, "Network Sync Error", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void populateCardsUI() {
        if (containerAnnouncements == null) return;
        containerAnnouncements.removeAllViews();
        openedCard = null;

        boolean hasItems = false;
        int displayNumber = 0;

        Set<String> dismissedKeys = new HashSet<>(seenPrefs.getStringSet(dismissedKeysPrefKey, new HashSet<>()));
        Set<String> seenKeys = new HashSet<>(seenPrefs.getStringSet(seenKeysPrefKey, new HashSet<>()));


        int visibleTotal = 0;
        for (SimpleNotificationModel it : dataList) {
            if (it.id == null || !dismissedKeys.contains(it.id)) visibleTotal++;
        }
        if (tvTotalAnnouncements != null) {
            tvTotalAnnouncements.setText("Total Announcements: " + visibleTotal);
        }

        for (SimpleNotificationModel item : dataList) {


            if (item.id != null && dismissedKeys.contains(item.id)) {
                continue;
            }


            if (!searchQueryKeyword.isEmpty()) {
                boolean matchTitle = item.title != null && item.title.toLowerCase().contains(searchQueryKeyword);
                boolean matchMsg   = item.message != null && item.message.toLowerCase().contains(searchQueryKeyword);
                if (!matchTitle && !matchMsg) {
                    continue;
                }
            }

            hasItems = true;
            displayNumber++;


            FrameLayout row = new FrameLayout(this);
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rowLp.bottomMargin = dpToPx(10);
            row.setLayoutParams(rowLp);

            FrameLayout deleteLayer = new FrameLayout(this);
            deleteLayer.setBackgroundColor(0xFFE53935);
            deleteLayer.setVisibility(View.INVISIBLE);
            row.addView(deleteLayer, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            ImageView bin = new ImageView(this);
            bin.setImageDrawable(binIcon());
            bin.setContentDescription("Delete notification");
            int pad = dpToPx(24);
            bin.setPadding(pad, 0, pad, 0);
            deleteLayer.addView(bin, new FrameLayout.LayoutParams(
                    dpToPx(DELETE_REVEAL_DP), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));

            ImageView binLeft = new ImageView(this);
            binLeft.setImageDrawable(binIcon());
            binLeft.setContentDescription("Delete notification");
            binLeft.setPadding(pad, 0, pad, 0);
            deleteLayer.addView(binLeft, new FrameLayout.LayoutParams(
                    dpToPx(DELETE_REVEAL_DP), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START));

            View cardView = LayoutInflater.from(this).inflate(R.layout.item_teacher_announcements, row, false);
            ((ViewGroup.MarginLayoutParams) cardView.getLayoutParams()).bottomMargin = 0;
            row.addView(cardView);
            cardView.setTag(deleteLayer);

            TextView tvNewTag          = cardView.findViewById(R.id.tvNewTag);
            TextView tvItemNumber      = cardView.findViewById(R.id.tvItemNumber);
            TextView tvItemTitle       = cardView.findViewById(R.id.tvItemTitle);
            TextView tvItemDate        = cardView.findViewById(R.id.tvItemDate);
            TextView tvItemDescription = cardView.findViewById(R.id.tvItemDescription);
            TextView tvItemAudience    = cardView.findViewById(R.id.tvItemAudience);

            if (tvItemNumber != null) tvItemNumber.setText("#" + displayNumber);
            if (tvItemTitle != null) tvItemTitle.setText(item.title);
            if (tvItemDescription != null) tvItemDescription.setText(item.message);
            if (tvItemAudience != null) tvItemAudience.setText("👥 " + item.targetGroup);



            if (tvItemDate != null && item.timestamp > 0) {
                tvItemDate.setText(new SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(new Date(item.timestamp)));
            }

            final boolean isNew = item.id != null && !seenKeys.contains(item.id);
            if (tvNewTag != null) tvNewTag.setVisibility(isNew ? View.VISIBLE : View.GONE);

            cardView.setOnClickListener(v -> {

                if (cardView.getTranslationX() != 0f) {
                    setCardOpen(cardView, false);
                    return;
                }
                if (isNew) {
                    if (tvNewTag != null) tvNewTag.setVisibility(View.GONE);
                    Set<String> updated = new HashSet<>(seenPrefs.getStringSet(seenKeysPrefKey, new HashSet<>()));
                    updated.add(item.id);
                    seenPrefs.edit().putStringSet(seenKeysPrefKey, updated).apply();
                }
                openRelatedScreen(item);
            });


            bin.setOnClickListener(v -> deleteWithUndo(item, cardView));
            binLeft.setOnClickListener(v -> deleteWithUndo(item, cardView));

            enableSwipeToReveal(cardView, deleteLayer, () -> deleteWithUndo(item, cardView));

            containerAnnouncements.addView(row);
        }

        if (!hasItems) {
            showEmptyPlaceholder();
        }
    }


    private Class<?> resolveTargetScreen(SimpleNotificationModel item) {
        String t = item.type != null ? item.type.trim().toLowerCase(Locale.ROOT) : "";
        switch (t) {
            case "assignment_submission":
                return TeacherAssignmentActivity.class;
            case "quiz_submission":
                return TeacherQuizzesActivity.class;
            case "timetable":
                return TeacherTimeScheduleActivity.class;
        }


        String title = item.title != null ? item.title.toLowerCase(Locale.ROOT) : "";
        if (title.contains("assignment submitted")) return TeacherAssignmentActivity.class;
        if (title.contains("quiz submitted"))       return TeacherQuizzesActivity.class;
        if (title.contains("timetable"))            return TeacherTimeScheduleActivity.class;
        return null;
    }


    private void openRelatedScreen(SimpleNotificationModel item) {
        Class<?> target = resolveTargetScreen(item);
        if (target == null) return;

        Intent go = new Intent(this, target);

        String itemTitle = firstGroup(item.message, "submitted \"(.*?)\"(?: - .*)?$");
        if (itemTitle != null) go.putExtra("dl_title", itemTitle);
        startActivity(go);
    }

    private static String firstGroup(String text, String regex) {
        if (text == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(regex, java.util.regex.Pattern.DOTALL).matcher(text);
        return m.find() ? m.group(1) : null;
    }

    private void enableSwipeToReveal(View card, View deleteLayer, Runnable onFullSwipe) {
        final int reveal = dpToPx(DELETE_REVEAL_DP);
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        final float[] down = new float[3];          // downX, downY, start translation
        final boolean[] swiping = {false};

        card.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = e.getRawX();
                    down[1] = e.getRawY();
                    down[2] = card.getTranslationX();
                    swiping[0] = false;
                    return false;

                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - down[0];
                    float dy = e.getRawY() - down[1];
                    if (!swiping[0]) {

                        if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                            swiping[0] = true;
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            v.setPressed(false);
                            if (openedCard != null && openedCard != card) setCardOpen(openedCard, false);
                        } else {
                            return false;
                        }
                    }
                    float maxTx = card.getWidth();
                    float tx = Math.max(-maxTx, Math.min(maxTx, down[2] + dx));
                    card.setTranslationX(tx);
                    deleteLayer.setVisibility(tx != 0f ? View.VISIBLE : View.INVISIBLE);
                    return true;
                }

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (swiping[0]) {
                        swiping[0] = false;
                        float abs = Math.abs(card.getTranslationX());
                        if (abs > card.getWidth() * 0.45f) {
                            onFullSwipe.run();
                            setCardOpen(card, abs > reveal / 2f);
                        }
                        return true;
                    }
                    return false;
            }
            return false;
        });
    }

    private void setCardOpen(View card, boolean open) {
        final View layer = (View) card.getTag();
        if (layer != null && open) layer.setVisibility(View.VISIBLE);

        card.animate()
                .translationX(open ? (card.getTranslationX() > 0 ? 1 : -1) * dpToPx(DELETE_REVEAL_DP) : 0f)
                .setDuration(160)
                .withEndAction(() -> {
                    if (!open && layer != null) layer.setVisibility(View.INVISIBLE);
                })
                .start();

        if (open) openedCard = card;
        else if (openedCard == card) openedCard = null;
    }


    private void deleteWithUndo(SimpleNotificationModel item, View card) {
        if (item.id == null) return;
        openedCard = null;

        Set<String> dismissedKeys = new HashSet<>(seenPrefs.getStringSet(dismissedKeysPrefKey, new HashSet<>()));
        dismissedKeys.add(item.id);
        seenPrefs.edit().putStringSet(dismissedKeysPrefKey, dismissedKeys).apply();

        card.animate()
                .translationX(card.getTranslationX() > 0 ? card.getWidth() : -card.getWidth())
                .alpha(0f)
                .setDuration(180)
                .withEndAction(this::populateCardsUI)
                .start();

        showUndoSnackbar(item);
    }


    private void showUndoSnackbar(SimpleNotificationModel item) {

        if (undoSnackbar != null && undoSnackbar.isShown()) undoSnackbar.dismiss();

        View root = findViewById(android.R.id.content);
        Snackbar bar = Snackbar.make(root, "Notification deleted", 4000)
                .setAction("UNDO", v -> restoreAnnouncement(item));
        undoSnackbar = bar;

        View sbView = bar.getView();
        android.graphics.drawable.GradientDrawable snackBg = new android.graphics.drawable.GradientDrawable();
        snackBg.setColor(0xFFFFFFFF);
        snackBg.setCornerRadius(dpToPx(14));
        snackBg.setStroke(dpToPx(1), 0xFFE0E0E0);
        sbView.setBackground(snackBg);

        ViewGroup.LayoutParams lp = sbView.getLayoutParams();
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) lp;
            int side = dpToPx(16);
            mlp.leftMargin = side;
            mlp.rightMargin = side;
            mlp.bottomMargin = dpToPx(bottomNav != null ? 12 : 24);
            sbView.setLayoutParams(mlp);
        }
        sbView.setElevation(dpToPx(12));

        TextView tvText = sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        if (tvText != null) {
            tvText.setTextColor(0xFF000000);
            tvText.setTextSize(15f);
            tvText.setTypeface(tvText.getTypeface(), android.graphics.Typeface.BOLD);
            tvText.setCompoundDrawablesWithIntrinsicBounds(binIcon(), null, null, null);
            tvText.setCompoundDrawablePadding(dpToPx(10));
            tvText.setCompoundDrawableTintList(android.content.res.ColorStateList.valueOf(0xFF000000));
        }
        bar.setActionTextColor(0xFFEF5350);   // light red UNDO
        TextView tvAction = sbView.findViewById(com.google.android.material.R.id.snackbar_action);
        if (tvAction != null) {
            tvAction.setTextSize(14f);
            tvAction.setTypeface(tvAction.getTypeface(), android.graphics.Typeface.BOLD);
        }

        if (bottomNav != null) bar.setAnchorView(bottomNav);
        bar.show();
    }

    private void restoreAnnouncement(SimpleNotificationModel item) {
        if (item.id == null) return;
        Set<String> dismissedKeys = new HashSet<>(seenPrefs.getStringSet(dismissedKeysPrefKey, new HashSet<>()));
        dismissedKeys.remove(item.id);
        seenPrefs.edit().putStringSet(dismissedKeysPrefKey, dismissedKeys).apply();
        populateCardsUI();
    }

    private android.graphics.drawable.Drawable binIcon() {
        android.graphics.Path path = androidx.core.graphics.PathParser.createPathFromPathData(
                "M6,19c0,1.1 0.9,2 2,2h8c1.1,0 2,-0.9 2,-2V7H6v12zM19,4h-3.5l-1,-1h-5l-1,1H5v2h14V4z");
        android.graphics.drawable.ShapeDrawable d = new android.graphics.drawable.ShapeDrawable(
                new android.graphics.drawable.shapes.PathShape(path, 24, 24));
        d.getPaint().setColor(0xFFFFFFFF);
        d.setIntrinsicWidth(dpToPx(24));
        d.setIntrinsicHeight(dpToPx(24));
        return d;
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private void showEmptyPlaceholder() {
        TextView tvEmpty = new TextView(this);
        tvEmpty.setText("No announcements available.");
        tvEmpty.setTextSize(14f);
        tvEmpty.setGravity(Gravity.CENTER);
        tvEmpty.setTextColor(Color.parseColor("#888888"));
        tvEmpty.setPadding(0, 80, 0, 0);
        containerAnnouncements.addView(tvEmpty);
    }

    private void setupBottomNavigation() {
        bottomNav.setSelectedItemId(R.id.nav_bottom_Announcment);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_bottom_home) {
                Intent intent = new Intent(this, TeacherDashboardActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
                return true;
            } else if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class));
                finish();
                return true;
            } else if (id == R.id.nav_bottom_Announcment) {
                return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileMenuActivity.class));
                finish();
                return true;
            }
            return false;
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_logout) {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(this, LoginSelectionActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finishAffinity();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}