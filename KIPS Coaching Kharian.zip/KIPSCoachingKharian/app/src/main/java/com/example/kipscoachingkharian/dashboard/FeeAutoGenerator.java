package com.example.kipscoachingkharian.dashboard;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Monthly fee challan AUTO generator — bina server ke, sirf app ke andar.
 *
 * Admin jab bhi app kholta hai (AdminDashboardActivity), yeh class din mein
 * sirf EK baar chalti hai aur:
 *   1) Is mahine ka challan har Approved student ka bana deti hai (agar pehle
 *      se na bana ho) + student/parent ko notification.
 *   2) 15 tareekh guzar jaye to is mahine ke Unpaid challans par Rs. 200 late
 *      fine laga deti hai (sirf ek baar) + "Fee Overdue" notification.
 *
 * Rules FeeChallanActivity jaise hi hain: fee payment_config se, special
 * subjects ka alag rate, due date 15, path Fees/{uid}/{Month_YYYY}.
 *
 * Duplicate se bachao: har student ka challan Firebase transaction se likha
 * jata hai — maujood challan (Paid ya Unpaid) kabhi overwrite nahi hota.
 * "AutoFee/lastRunDate" mein aaj ki date save hoti hai taake din mein dobara
 * poora scan na ho (chahe do admin devices hon).
 */
public final class FeeAutoGenerator {

    private static final String TAG = "FeeAutoGenerator";
    private static final TimeZone TZ = TimeZone.getTimeZone("Asia/Karachi");

    private static final int  DUE_DAY = 15;
    private static final long LATE_FINE = 200L;
    private static final long DEFAULT_FEE_PER_SUBJECT = 3000L;
    private static final long DEFAULT_FEE_SPECIAL = 2500L;

    private static final Set<String> SPECIAL_SUBJECTS = new HashSet<>(Arrays.asList(
            "urdu",
            "pakistan studies", "pak studies", "pak study", "pakistan study", "p.st", "pst",
            "islamiat", "islamic studies", "islamiyat", "islamiyat studies"));

    private static boolean running = false;

    private FeeAutoGenerator() {}

    private static class Student {
        String uid, name, className, username;
        List<String> subjects = new ArrayList<>();
    }

    // ── Entry point ─────────────────────────────────────────────────────────
    public static synchronized void runIfNeeded() {
        if (running) return;
        running = true;

        final String today = fmt("yyyy-MM-dd", Calendar.getInstance(TZ, Locale.ENGLISH));
        final DatabaseReference stateRef = FirebaseDatabase.getInstance()
                .getReference("AutoFee").child("lastRunDate");

        stateRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                if (today.equals(str(snap.getValue()))) { finish(); return; }
                loadConfig(today, stateRef);
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {
                Log.w(TAG, "state read failed: " + e.getMessage());
                finish();
            }
        });
    }

    private static synchronized void finish() { running = false; }

    // ── Step 1: fee rates ───────────────────────────────────────────────────
    private static void loadConfig(final String today, final DatabaseReference stateRef) {
        FirebaseDatabase.getInstance().getReference("payment_config")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snap) {
                        long perSubject = toLong(snap.child("fee_per_subject").getValue());
                        long special    = toLong(snap.child("fee_special_subject").getValue());
                        if (perSubject <= 0) perSubject = DEFAULT_FEE_PER_SUBJECT;
                        if (special <= 0)    special    = DEFAULT_FEE_SPECIAL;
                        loadUsers(today, stateRef, perSubject, special);
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) { finish(); }
                });
    }

    // ── Step 2: students + parents ──────────────────────────────────────────
    private static void loadUsers(final String today, final DatabaseReference stateRef,
                                  final long perSubject, final long special) {
        FirebaseDatabase.getInstance().getReference("Users")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot usersSnap) {
                        Map<String, List<String>> parentsByChild = new HashMap<>();
                        List<Student> students = new ArrayList<>();

                        for (DataSnapshot u : usersSnap.getChildren()) {
                            String role   = str(u.child("role").getValue());
                            String status = str(u.child("status").getValue());
                            if (role == null) continue;

                            if (role.equalsIgnoreCase("Parent")) {
                                String linked = str(u.child("linkedChildUsername").getValue());
                                if (linked == null) continue;
                                String k = linked.trim().toLowerCase(Locale.ROOT);
                                List<String> l = parentsByChild.get(k);
                                if (l == null) { l = new ArrayList<>(); parentsByChild.put(k, l); }
                                l.add(u.getKey());

                            } else if (role.equalsIgnoreCase("Student")
                                    && "Approved".equalsIgnoreCase(status)) {
                                String name = str(u.child("name").getValue());
                                if (name == null) continue;
                                Student s = new Student();
                                s.uid = u.getKey();
                                s.name = name;
                                String cls = str(u.child("className").getValue());
                                s.className = cls != null ? cls : "";
                                String un = str(u.child("username").getValue());
                                s.username = un != null ? un : "";
                                for (DataSnapshot sub : u.child("enrolledSubjects").getChildren()) {
                                    String sv = str(sub.getValue());
                                    if (sv != null) s.subjects.add(sv);
                                }
                                students.add(s);
                            }
                        }
                        processAll(students, parentsByChild, perSubject, special, today, stateRef);
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) { finish(); }
                });
    }

    // ── Step 3: har student ─────────────────────────────────────────────────
    private static void processAll(List<Student> students,
                                   final Map<String, List<String>> parentsByChild,
                                   final long perSubject, final long special,
                                   final String today, final DatabaseReference stateRef) {

        Calendar now = Calendar.getInstance(TZ, Locale.ENGLISH);
        final String month    = fmt("MMMM yyyy", now);              // "October 2026"
        final String monthKey = month.replace(" ", "_");            // "October_2026"
        final String dueDate  = String.format(Locale.ENGLISH, "%02d/%s",
                DUE_DAY, fmt("MM/yyyy", now));                      // "15/10/2026"
        final boolean isLate  = now.get(Calendar.DAY_OF_MONTH) > DUE_DAY;

        if (students.isEmpty()) { markDone(stateRef, today); return; }

        final AtomicInteger pending = new AtomicInteger(students.size());
        final AtomicInteger failed  = new AtomicInteger(0);

        final Runnable oneDone = () -> {
            if (pending.decrementAndGet() == 0) {
                if (failed.get() == 0) markDone(stateRef, today);
                else finish(); // kuch fail hua — agli baar dobara try hoga
            }
        };

        for (final Student s : students) {
            if (s.subjects.isEmpty()) { oneDone.run(); continue; }

            long base = 0;
            Map<String, Object> subjectFees = new HashMap<>();
            for (String sub : s.subjects) {
                long f = SPECIAL_SUBJECTS.contains(sub.trim().toLowerCase(Locale.ROOT))
                        ? special : perSubject;
                subjectFees.put(sub.replaceAll("[.$#\\[\\]/]", "_"), f);
                base += f;
            }
            final long fine  = isLate ? LATE_FINE : 0L;
            final long total = base + fine;

            final Map<String, Object> challan = new HashMap<>();
            challan.put("studentName",   s.name);
            challan.put("className",     s.className);
            challan.put("month",         month);
            challan.put("dueDate",       dueDate);
            challan.put("subjects",      s.subjects);
            challan.put("feePerSubject", perSubject);
            challan.put("totalSubjects", s.subjects.size());
            challan.put("baseFee",       String.valueOf(base));
            challan.put("lateFine",      String.valueOf(fine));
            challan.put("amount",        String.valueOf(total));
            challan.put("generatedAt",   System.currentTimeMillis());
            challan.put("subjectFees",   subjectFees);
            challan.put("status",        "Unpaid");
            challan.put("autoGenerated", true);

            final boolean[] created = {false};
            final boolean[] fined   = {false};
            final long[]    amount  = {0L};

            FirebaseDatabase.getInstance().getReference("Fees")
                    .child(s.uid).child(monthKey)
                    .runTransaction(new Transaction.Handler() {
                        @NonNull @Override
                        public Transaction.Result doTransaction(@NonNull MutableData d) {
                            created[0] = false; fined[0] = false;

                            // Challan hai hi nahi -> naya bana do
                            if (d.getValue() == null) {
                                d.setValue(challan);
                                created[0] = true;
                                amount[0] = total;
                                return Transaction.success(d);
                            }
                            // Challan pehle se hai: sirf late fine ka sawal
                            if (!isLate) return Transaction.abort();
                            if ("paid".equalsIgnoreCase(str(d.child("status").getValue())))
                                return Transaction.abort();
                            if (toLong(d.child("lateFine").getValue()) > 0)
                                return Transaction.abort();
                            long b = toLong(d.child("baseFee").getValue());
                            if (b <= 0) return Transaction.abort();

                            d.child("lateFine").setValue(String.valueOf(LATE_FINE));
                            d.child("amount").setValue(String.valueOf(b + LATE_FINE));
                            fined[0] = true;
                            amount[0] = b + LATE_FINE;
                            return Transaction.success(d);
                        }

                        @Override
                        public void onComplete(@Nullable DatabaseError error, boolean committed,
                                               @Nullable DataSnapshot snap) {
                            if (error != null) {
                                Log.w(TAG, "challan failed for " + s.name + ": " + error.getMessage());
                                failed.incrementAndGet();
                            } else if (committed && (created[0] || fined[0])) {
                                if (created[0]) {
                                    // Naya challan bana -> purani "Paid" flag reset karo, warna
                                    // Payment screen par naya mahina bhi "Paid" dikhega.
                                    Map<String, Object> reset = new HashMap<>();
                                    reset.put("feePaid", false);
                                    reset.put("feeStatus", "Pending");
                                    FirebaseDatabase.getInstance().getReference("Users")
                                            .child(s.uid).updateChildren(reset);
                                }
                                boolean overdue = isLate; // naya late challan ya fine lagna = overdue msg
                                sendNotifications(s, parentsByChild, month, amount[0], dueDate,
                                        overdue, overdue ? LATE_FINE : 0L);
                            }
                            oneDone.run();
                        }
                    });
        }
    }

    private static void markDone(DatabaseReference stateRef, String today) {
        stateRef.setValue(today);
        finish();
    }

    // ── Notifications (FeeChallanActivity jaise hi fields) ─────────────────
    private static void sendNotifications(Student s, Map<String, List<String>> parentsByChild,
                                          String month, long amount, String dueDate,
                                          boolean isLate, long fine) {
        push(s.uid, build(s.name, s.name, month, amount, dueDate, isLate, fine));

        List<String> parents = parentsByChild.get(s.username.trim().toLowerCase(Locale.ROOT));
        if (parents != null) {
            for (String pUid : parents) {
                push(pUid, build(s.name, "Your child " + s.name, month, amount, dueDate, isLate, fine));
            }
        }
    }

    private static Map<String, Object> build(String studentName, String who, String month,
                                             long amount, String dueDate,
                                             boolean isLate, long fine) {
        String msg = isLate
                ? who + "'s fee for " + month + " is pending. Amount: Rs. " + amount
                + " (Late fine Rs. " + fine + " included). Due Date: " + dueDate
                : who + "'s fee challan for " + month + " has been generated. Amount: Rs. "
                + amount + ". Due Date: " + dueDate;

        Map<String, Object> n = new HashMap<>();
        n.put("title",       isLate ? "⚠️ Fee Overdue!" : "📋 Fee Challan Generated");
        n.put("message",     msg);
        n.put("type",        "fee_pending");
        n.put("studentName", studentName);
        n.put("amount",      String.valueOf(amount));
        n.put("dueDate",     dueDate);
        n.put("month",       month);
        n.put("isLate",      isLate);
        n.put("lateFine",    String.valueOf(fine));
        n.put("timestamp",   System.currentTimeMillis());
        n.put("isRead",      false);
        return n;
    }

    private static void push(String uid, Map<String, Object> n) {
        FirebaseDatabase.getInstance().getReference("Notifications")
                .child(uid).push().setValue(n);
    }

    // ── Helpers ─────────────────────────────────────────────────────────────
    private static String fmt(String pattern, Calendar c) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.ENGLISH);
        sdf.setTimeZone(TZ);
        return sdf.format(c.getTime());
    }

    private static String str(Object o) { return o == null ? null : String.valueOf(o); }

    private static long toLong(Object o) {
        if (o == null) return 0L;
        if (o instanceof Number) return ((Number) o).longValue();
        try { return Long.parseLong(String.valueOf(o).trim()); } catch (Exception e) { return 0L; }
    }
}