package com.example.kipscoachingkharian.dashboard;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FeedManagmentActivity extends AppCompatActivity {

    private LinearLayout mainContainer;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_feedback);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        mainContainer = findViewById(R.id.containerFeedbacks);

        // Firebase reference — FeedbackActivity.java isi path par seedha
        // feedbackId ke neeche data save karta hai (flat structure)
        dbRef = FirebaseDatabase.getInstance().getReference("Feedbacks");

        fetchData();
    }

    private void fetchData() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (mainContainer == null) return;
                mainContainer.removeAllViews();

                if (!snapshot.exists()) {
                    Log.d("FirebaseData", "Node 'Feedbacks' does not exist");
                    Toast.makeText(FeedManagmentActivity.this, "No data in Firebase", Toast.LENGTH_SHORT).show();
                    return;
                }

                for (DataSnapshot child : snapshot.getChildren()) {

                    // FIX: Detect karo ki yeh DIRECT feedback hai ya ROLE-grouped node hai.
                    // FeedbackActivity.java seedha "name"/"feedback"/"rating" fields
                    // feedbackId ke andar save karta hai — yeh FLAT structure hai.
                    boolean isDirectFeedback = child.hasChild("name")
                            || child.hasChild("feedback")
                            || child.hasChild("rating")
                            || child.hasChild("userId");

                    if (isDirectFeedback) {
                        // FLAT structure: Feedbacks/{feedbackId} -> {name, feedback, rating, ...}
                        parseAndAddCard(child, /*role*/ "Student", /*pathPrefix*/ null);
                    } else {
                        // NESTED structure (purana style): Feedbacks/{role}/{feedbackId}
                        String roleName = child.getKey();
                        for (DataSnapshot feedbackSnap : child.getChildren()) {
                            parseAndAddCard(feedbackSnap, roleName, roleName);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseData", "DB Error: " + error.getMessage());
            }
        });
    }

    // pathPrefix == null matlab is feedback ka parent node khud "Feedbacks" hai
    // (delete karte waqt seedha Feedbacks/{key} use hoga)
    private void parseAndAddCard(DataSnapshot feedbackSnap, String roleName, String pathPrefix) {
        try {
            // 1. Name fallback
            String name = null;
            if (feedbackSnap.hasChild("name")) name = String.valueOf(feedbackSnap.child("name").getValue());
            else if (feedbackSnap.hasChild("senderName")) name = String.valueOf(feedbackSnap.child("senderName").getValue());
            else if (feedbackSnap.hasChild("userName")) name = String.valueOf(feedbackSnap.child("userName").getValue());
            else if (feedbackSnap.hasChild("studentName")) name = String.valueOf(feedbackSnap.child("studentName").getValue());

            if (name == null || name.trim().isEmpty() || name.equals("null")) {
                name = "Anonymous " + (roleName != null ? roleName : "User");
            }

            // 2. Message fallback — FeedbackModel mein field "feedback" hai
            String msg = null;
            if (feedbackSnap.hasChild("feedback")) msg = String.valueOf(feedbackSnap.child("feedback").getValue());
            else if (feedbackSnap.hasChild("message")) msg = String.valueOf(feedbackSnap.child("message").getValue());
            else if (feedbackSnap.hasChild("msg")) msg = String.valueOf(feedbackSnap.child("msg").getValue());
            else if (feedbackSnap.hasChild("comment")) msg = String.valueOf(feedbackSnap.child("comment").getValue());

            if (msg == null || msg.trim().isEmpty() || msg.equals("null")) {
                msg = "(No text message provided)";
            }

            String key = feedbackSnap.getKey();

            // 3. Rating safety parse
            float rating = 5.0f;
            if (feedbackSnap.hasChild("rating")) {
                Object rawRating = feedbackSnap.child("rating").getValue();
                if (rawRating != null) {
                    rating = Float.parseFloat(String.valueOf(rawRating));
                }
            }

            if (key != null) {
                addCard(name, msg, roleName, rating, key, pathPrefix);
            }

        } catch (Exception e) {
            Log.e("FirebaseData", "Row parser error: " + e.getMessage());
        }
    }

    private void addCard(String name, String msg, String role, float rating,
                         String key, String pathPrefix) {
        View v = LayoutInflater.from(this).inflate(R.layout.item_feedback, mainContainer, false);

        TextView tvName = v.findViewById(R.id.tvFeedbackUser);
        TextView tvRole = v.findViewById(R.id.tvUserRoleTag);
        TextView tvFeedback = v.findViewById(R.id.tvFeedbackMessage);
        RatingBar rb = v.findViewById(R.id.feedbackRatingIndicator);
        ImageView btnDel = v.findViewById(R.id.btnFeedbackMenu);

        if (tvName != null) tvName.setText(name);
        if (tvFeedback != null) tvFeedback.setText(msg);
        if (rb != null) rb.setRating(rating);

        if (tvRole != null && role != null) {
            tvRole.setText(role.toUpperCase());
            if (role.toLowerCase().contains("student")) {
                tvRole.setTextColor(Color.parseColor("#1E88E5")); // Soft Blue
                tvRole.setBackgroundColor(Color.parseColor("#E3F2FD"));
            } else {
                tvRole.setTextColor(Color.parseColor("#2E7D32")); // Soft Green
                tvRole.setBackgroundColor(Color.parseColor("#E8F5E9"));
            }
        }

        if (btnDel != null) {
            btnDel.setOnClickListener(view -> {
                if (key != null) {
                    // FIX: pathPrefix null ho to seedha Feedbacks/{key} delete karo (flat),
                    // warna Feedbacks/{role}/{key} delete karo (nested)
                    DatabaseReference target = (pathPrefix == null)
                            ? dbRef.child(key)
                            : dbRef.child(pathPrefix).child(key);

                    target.removeValue().addOnSuccessListener(aVoid ->
                            Toast.makeText(this, "Feedback Deleted Successfully", Toast.LENGTH_SHORT).show());
                }
            });
        }

        // Naya feedback top par push karne k liye index 0
        mainContainer.addView(v, 0);
    }
}