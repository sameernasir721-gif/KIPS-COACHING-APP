package com.example.kipscoachingkharian.dashboard;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FeedManagmentActivity extends AppCompatActivity {

    private LinearLayout mainContainer;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_feedback);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        setupBackButton();

        mainContainer = findViewById(R.id.containerFeedbacks);

        // Firebase reference — FeedbackActivity.java isi path par seedha
        // feedbackId ke neeche data save karta hai (flat structure)
        dbRef = FirebaseDatabase.getInstance().getReference("Feedbacks");

        fetchData();
    }

    // ── Back button (auto-finds the one already in XML) ───────────────────────
    private void setupBackButton() {
        View back = findBackView(findViewById(android.R.id.content));
        if (back == null) {
            Log.w("BackButton", "Back button not found in layout");
            return;
        }
        back.setClickable(true);
        back.setOnClickListener(v -> finish());
    }

    private View findBackView(View v) {
        if (v == null) return null;
        if (isBackView(v)) return v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View found = findBackView(g.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    private boolean isBackView(View v) {
        // 1) id name contains "back" (ignoring feedback / background / callback)
        if (v.getId() != View.NO_ID) {
            try {
                String name = getResources().getResourceEntryName(v.getId())
                        .toLowerCase()
                        .replace("feedback", "")
                        .replace("background", "")
                        .replace("callback", "")
                        .replace("playback", "");
                if (name.contains("back")) return true;
            } catch (Exception ignored) { }
        }
        // 2) contentDescription contains "back"
        CharSequence cd = v.getContentDescription();
        if (cd != null && cd.toString().toLowerCase().contains("back")) return true;
        // 3) short text such as "Back", "← Back" or "←"
        if (v instanceof TextView) {
            CharSequence t = ((TextView) v).getText();
            if (t != null) {
                String s = t.toString().trim().toLowerCase();
                if (s.length() <= 10 && (s.contains("back") || s.contains("←"))) return true;
            }
        }
        return false;
    }

    private void fetchData() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (mainContainer == null) return;
                mainContainer.removeAllViews();

                if (!snapshot.exists()) {
                    Log.d("FirebaseData", "Node 'Feedbacks' does not exist");
                    Toast.makeText(FeedManagmentActivity.this, "No data in Firebase", Toast.LENGTH_SHORT).show();
                    return;
                }

                for (DataSnapshot child : snapshot.getChildren()) {


                    boolean isDirectFeedback = child.hasChild("name")
                            || child.hasChild("feedback")
                            || child.hasChild("rating")
                            || child.hasChild("userId");

                    if (isDirectFeedback) {
                        // FLAT structure: Feedbacks/{feedbackId} -> {name, feedback, rating, ...}
                        parseAndAddCard(child, /*role*/ "Student", /*pathPrefix*/ null);
                    } else {
                        // NESTED structure (purana style): Feedbacks/{role}/{feedbackId}
                        String roleName = child.getKey();
                        for (DataSnapshot feedbackSnap : child.getChildren()) {
                            parseAndAddCard(feedbackSnap, roleName, roleName);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseData", "DB Error: " + error.getMessage());
            }
        });
    }


    private void parseAndAddCard(DataSnapshot feedbackSnap, String roleName, String pathPrefix) {
        try {
            // 1. Name fallback
            String name = null;
            if (feedbackSnap.hasChild("name")) name = String.valueOf(feedbackSnap.child("name").getValue());
            else if (feedbackSnap.hasChild("senderName")) name = String.valueOf(feedbackSnap.child("senderName").getValue());
            else if (feedbackSnap.hasChild("userName")) name = String.valueOf(feedbackSnap.child("userName").getValue());
            else if (feedbackSnap.hasChild("studentName")) name = String.valueOf(feedbackSnap.child("studentName").getValue());

            if (name == null || name.trim().isEmpty() || name.equals("null")) {
                name = "Anonymous " + (roleName != null ? roleName : "User");
            }

            // 2. Message fallback — FeedbackModel mein field "feedback" hai
            String msg = null;
            if (feedbackSnap.hasChild("feedback")) msg = String.valueOf(feedbackSnap.child("feedback").getValue());
            else if (feedbackSnap.hasChild("message")) msg = String.valueOf(feedbackSnap.child("message").getValue());
            else if (feedbackSnap.hasChild("msg")) msg = String.valueOf(feedbackSnap.child("msg").getValue());
            else if (feedbackSnap.hasChild("comment")) msg = String.valueOf(feedbackSnap.child("comment").getValue());

            if (msg == null || msg.trim().isEmpty() || msg.equals("null")) {
                msg = "(No text message provided)";
            }

            String key = feedbackSnap.getKey();

            // 3. Rating safety parse
            float rating = 5.0f;
            if (feedbackSnap.hasChild("rating")) {
                Object rawRating = feedbackSnap.child("rating").getValue();
                if (rawRating != null) {
                    rating = Float.parseFloat(String.valueOf(rawRating));
                }
            }

            if (key != null) {
                addCard(name, msg, roleName, rating, key, pathPrefix);
            }

        } catch (Exception e) {
            Log.e("FirebaseData", "Row parser error: " + e.getMessage());
        }
    }

    private void addCard(String name, String msg, String role, float rating,
                         String key, String pathPrefix) {
        View v = LayoutInflater.from(this).inflate(R.layout.item_feedback, mainContainer, false);

        TextView tvName = v.findViewById(R.id.tvFeedbackUser);
        TextView tvRole = v.findViewById(R.id.tvUserRoleTag);
        TextView tvFeedback = v.findViewById(R.id.tvFeedbackMessage);
        RatingBar rb = v.findViewById(R.id.feedbackRatingIndicator);
        ImageView btnDel = v.findViewById(R.id.btnFeedbackMenu);

        if (tvName != null) tvName.setText(name);
        if (tvFeedback != null) tvFeedback.setText(msg);
        if (rb != null) rb.setRating(rating);

        if (tvRole != null && role != null) {
            tvRole.setText(role.toUpperCase());
            if (role.toLowerCase().contains("student")) {
                tvRole.setTextColor(Color.parseColor("#1E88E5")); // Soft Blue
                tvRole.setBackgroundColor(Color.parseColor("#E3F2FD"));
            } else {
                tvRole.setTextColor(Color.parseColor("#2E7D32")); // Soft Green
                tvRole.setBackgroundColor(Color.parseColor("#E8F5E9"));
            }
        }

        if (btnDel != null) {
            btnDel.setOnClickListener(view -> {
                if (key != null) {
                    DatabaseReference target = (pathPrefix == null)
                            ? dbRef.child(key)
                            : dbRef.child(pathPrefix).child(key);

                    target.removeValue().addOnSuccessListener(aVoid ->
                            Toast.makeText(this, "Feedback Deleted Successfully", Toast.LENGTH_SHORT).show());
                }
            });
        }

        // Naya feedback top par push karne k liye index 0
        mainContainer.addView(v, 0);
    }
}