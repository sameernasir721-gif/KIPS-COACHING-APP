package com.example.kipscoachingkharian.model;


/**
 * Assignment model — Firebase se map hoti hai
 * Firebase path: Assignments/{teacherUid}/{assignmentId}
 */
public class Assignment {

    private String assignmentId;   // Firebase key (local use)
    private String teacherId;
    private String title;
    private String subject;
    private String grade;
    private String marks;
    private String dueDate;
    private String dueTime;
    private String postedDate;
    private String description;
    private String status;         // "Active" / "Closed"
    private long   createdAt;
    private String pdfUrl;         // Teacher ne attach ki PDF (optional)

    // Firebase ke liye empty constructor zaroori hai
    public Assignment() {}

    public Assignment(String assignmentId, String teacherId, String title,
                      String subject, String grade, String marks,
                      String dueDate, String postedDate, String description,
                      String status, long createdAt) {
        this.assignmentId = assignmentId;
        this.teacherId    = teacherId;
        this.title        = title;
        this.subject      = subject;
        this.grade        = grade;
        this.marks        = marks;
        this.dueDate      = dueDate;
        this.postedDate   = postedDate;
        this.description  = description;
        this.status       = status;
        this.createdAt    = createdAt;
    }

    // ── Getters ──────────────────────────────────────────────────────────────

    public String getAssignmentId()  { return assignmentId; }
    public String getTeacherId()     { return teacherId; }
    public String getTitle()         { return title; }
    public String getSubject()       { return subject; }
    public String getGrade()         { return grade; }
    public String getMarks()         { return marks; }
    public String getDueDate()       { return dueDate; }
    public String getDueTime()       { return dueTime; }
    public String getPostedDate()    { return postedDate; }
    public String getDescription()   { return description; }
    public String getStatus()        { return status; }
    public long   getCreatedAt()     { return createdAt; }
    public String getPdfUrl()        { return pdfUrl; }

    // ── Setters ──────────────────────────────────────────────────────────────

    public void setAssignmentId(String assignmentId) { this.assignmentId = assignmentId; }
    public void setTeacherId(String teacherId)       { this.teacherId    = teacherId; }
    public void setTitle(String title)               { this.title        = title; }
    public void setSubject(String subject)           { this.subject      = subject; }
    public void setGrade(String grade)               { this.grade        = grade; }
    public void setMarks(String marks)               { this.marks        = marks; }
    public void setDueDate(String dueDate)           { this.dueDate      = dueDate; }
    public void setDueTime(String dueTime)           { this.dueTime      = dueTime; }
    public void setPostedDate(String postedDate)     { this.postedDate   = postedDate; }
    public void setDescription(String description)   { this.description  = description; }
    public void setStatus(String status)             { this.status       = status; }
    public void setCreatedAt(long createdAt)         { this.createdAt    = createdAt; }
    public void setPdfUrl(String pdfUrl)             { this.pdfUrl       = pdfUrl; }
}