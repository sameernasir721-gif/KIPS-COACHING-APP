package com.example.kipscoachingkharian.dashboard;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.DataSnapshot;

import java.util.List;

public class GenericReportAdapter extends RecyclerView.Adapter<GenericReportAdapter.ViewHolder> {

    private List<DataSnapshot> list;
    private String nodeType;

    public GenericReportAdapter(List<DataSnapshot> list, String nodeType) {
        this.list = list;
        this.nodeType = nodeType;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_report_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DataSnapshot snapshot = list.get(position);

        if (nodeType.equals("StudentMarks")) {
            // Structure: StudentMarks -> ID -> QuizName -> {marks: "10"}
            String quizName = snapshot.getKey();
            Object marksObj = snapshot.child("marks").getValue();
            String marks = (marksObj != null) ? marksObj.toString() : "N/A";

            holder.tvMainTitle.setText(quizName);
            holder.tvSubDetail.setText("Marks Obtained: " + marks);
            holder.tvStatusBadge.setText("Result");
            holder.tvStatusBadge.setBackgroundColor(android.graphics.Color.parseColor("#E3F2FD")); // Blue

        } else if (nodeType.equals("Submissions")) {
            // Structure: Submissions -> PushID -> {assignmentTitle: "...", status: "..."}
            String title = snapshot.child("assignmentTitle").getValue(String.class);
            String status = snapshot.child("status").getValue(String.class);
            String date = snapshot.child("submittedAt").getValue(String.class);

            holder.tvMainTitle.setText(title != null ? title : "Assignment");
            holder.tvSubDetail.setText("Date: " + (date != null ? date : "N/A"));
            holder.tvStatusBadge.setText(status != null ? status : "Pending");

            if ("Pending".equalsIgnoreCase(status)) {
                holder.tvStatusBadge.setBackgroundColor(android.graphics.Color.parseColor("#FFEBEE")); // Red background
            }

        } else if (nodeType.equals("StudentProgress")) {
            // Structure: StudentProgress -> ID -> Term -> "85%"
            String term = snapshot.getKey();
            Object progress = snapshot.getValue();

            holder.tvMainTitle.setText(term);
            holder.tvSubDetail.setText("Overall Performance: " + progress.toString());
            holder.tvStatusBadge.setText("Progress");
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvMainTitle, tvSubDetail, tvStatusBadge;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMainTitle = itemView.findViewById(R.id.tvMainTitle);
            tvSubDetail = itemView.findViewById(R.id.tvSubDetail);
            tvStatusBadge = itemView.findViewById(R.id.tvStatusBadge);
        }
    }
}