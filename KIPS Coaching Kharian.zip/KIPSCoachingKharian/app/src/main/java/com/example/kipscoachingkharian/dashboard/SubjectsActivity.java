package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class SubjectsActivity extends AppCompatActivity {

    private static final String STATUS_PENDING  = "Pending";
    private static final String STATUS_REJECTED = "Rejected";

    private TextView tvTitle;
    private TextView tvStudentName, tvStudentClass, tvNoSubjects, tvNoAvailable;
    private TextView tabEnrolled, tabAvailable;
    private LinearLayout layoutEnrolled, layoutAvailable, containerAvailable, layoutStudyTip;
    private BottomNavigationView bottomNav;

    private CardView[] subjectCards = new CardView[9];
    private ImageView[] subjectIcons = new ImageView[9];
    private TextView[] tvSubjectNames = new TextView[9];

    private DatabaseReference mDatabase;
    private FirebaseUser currentUser;

    // Live listeners (so a newly approved subject shows up without reopening the screen)
    private DatabaseReference userRef, requestsRef, subjectsRef;
    private ValueEventListener userListener, requestsListener, subjectsListener;

    private final List<String> enrolledSubjects = new ArrayList<>();
    // Admin's "Subjects" node: sanitized key -> display name
    private final Map<String, String> allSubjects = new LinkedHashMap<>();
    // SubjectRequests/{uid}: sanitized subject key -> status
    private final Map<String, String> requestStatus = new HashMap<>();

    private String studentName = "";
    private String studentClass = "";
    private boolean subjectsLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subjects);
        StudentProfileHelper.attach(this, R.id.ivStudent);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        initViews();
        setupTabs();
        setupBottomNav();
        attachListeners();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (userRef != null && userListener != null) userRef.removeEventListener(userListener);
        if (requestsRef != null && requestsListener != null) requestsRef.removeEventListener(requestsListener);
        if (subjectsRef != null && subjectsListener != null) subjectsRef.removeEventListener(subjectsListener);
    }

    private void initViews() {
        tvTitle = findViewById(R.id.tvTitle);
        tvStudentName = findViewById(R.id.tvStudentName);
        tvStudentClass = findViewById(R.id.tvStudentClass);
        tvNoSubjects = findViewById(R.id.tvNoSubjects);
        tvNoAvailable = findViewById(R.id.tvNoAvailable);
        tabEnrolled = findViewById(R.id.tabEnrolled);
        tabAvailable = findViewById(R.id.tabAvailable);
        layoutEnrolled = findViewById(R.id.layoutEnrolled);
        layoutAvailable = findViewById(R.id.layoutAvailable);
        containerAvailable = findViewById(R.id.containerAvailable);
        layoutStudyTip = findViewById(R.id.layoutStudyTip);
        bottomNav = findViewById(R.id.bottomNav);

        if (tvTitle != null) tvTitle.setText("Subjects");

        // Cards mapping
        int[] cardIds = {R.id.cardSubject1, R.id.cardSubject2, R.id.cardSubject3,
                R.id.cardSubject4, R.id.cardSubject5, R.id.cardSubject6,
                R.id.cardSubject7, R.id.cardSubject8, R.id.cardSubject9};
        int[] iconIds = {R.id.imgSubjectIcon1, R.id.imgSubjectIcon2, R.id.imgSubjectIcon3,
                R.id.imgSubjectIcon4, R.id.imgSubjectIcon5, R.id.imgSubjectIcon6,
                R.id.imgSubjectIcon7, R.id.imgSubjectIcon8, R.id.imgSubjectIcon9};
        int[] nameIds = {R.id.tvSubjectName1, R.id.tvSubjectName2, R.id.tvSubjectName3,
                R.id.tvSubjectName4, R.id.tvSubjectName5, R.id.tvSubjectName6,
                R.id.tvSubjectName7, R.id.tvSubjectName8, R.id.tvSubjectName9};

        for (int i = 0; i < 9; i++) {
            subjectCards[i] = findViewById(cardIds[i]);
            subjectIcons[i] = findViewById(iconIds[i]);
            tvSubjectNames[i] = findViewById(nameIds[i]);

            final int index = i;
            if (subjectCards[i] != null) {
                subjectCards[i].setOnClickListener(v -> {

                    String subjectName = tvSubjectNames[index].getText().toString();
                    if (!subjectName.isEmpty()) {

                        Intent intent = new Intent(SubjectsActivity.this, StudyMaterialActivity.class);
                        intent.putExtra("FILTER_SUBJECT", subjectName);
                        startActivity(intent);
                    }
                });
            }
        }
        hideAllCards();
    }

    // ── TABS: Enrolled | Available ──
    private void setupTabs() {
        tabEnrolled.setOnClickListener(v -> showTab(true));
        tabAvailable.setOnClickListener(v -> showTab(false));
        showTab(true);
    }

    private void showTab(boolean enrolled) {
        layoutEnrolled.setVisibility(enrolled ? View.VISIBLE : View.GONE);
        layoutAvailable.setVisibility(enrolled ? View.GONE : View.VISIBLE);
        if (layoutStudyTip != null) layoutStudyTip.setVisibility(enrolled ? View.VISIBLE : View.GONE);

        tabEnrolled.setBackgroundResource(enrolled ? R.drawable.bg_tab_selected : R.drawable.bg_tab_unselected);
        tabEnrolled.setTextColor(enrolled ? 0xFFFFFFFF : 0xFFB71C1C);
        tabAvailable.setBackgroundResource(enrolled ? R.drawable.bg_tab_unselected : R.drawable.bg_tab_selected);
        tabAvailable.setTextColor(enrolled ? 0xFFB71C1C : 0xFFFFFFFF);
    }

    // ── BOTTOM NAVIGATION ──
    private void setupBottomNav() {
        if (bottomNav == null) return;

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_bottom_home) {
                Intent i = new Intent(this, StudentDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
                return true;
            } else if (id == R.id.nav_bottom_feedback) {
                startActivity(new Intent(this, FeedbackActivity.class));
                finish();
                return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                finish();
                return true;
            }
            return false;
        });
    }

    // ── FIREBASE LISTENERS ──
    private void attachListeners() {
        // All subjects offered by the admin
        subjectsRef = mDatabase.child("Subjects");
        subjectsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                allSubjects.clear();
                for (DataSnapshot s : snapshot.getChildren()) {
                    String name = s.child("name").getValue(String.class);
                    if (name == null || name.trim().isEmpty()) name = s.getKey();
                    if (name == null) continue;
                    allSubjects.put(sanitizeKey(name), name.trim());
                }
                subjectsLoaded = true;
                renderAvailable();
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {}
        };
        subjectsRef.addValueEventListener(subjectsListener);

        if (currentUser == null) return;
        String uid = currentUser.getUid();

        // Student profile + enrolled subjects
        userRef = mDatabase.child("Users").child(uid);
        userListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) return;

                String name = snapshot.child("name").getValue(String.class);
                Object classValue = snapshot.child("className").getValue();
                studentClass = (classValue != null) ? String.valueOf(classValue) : "";
                studentName = name != null ? name : "";

                if (name != null) tvStudentName.setText(name);
                if (!studentClass.isEmpty()) tvStudentClass.setText("Grade: " + studentClass);

                enrolledSubjects.clear();
                for (DataSnapshot ds : snapshot.child("enrolledSubjects").getChildren()) {
                    String subject = ds.getValue(String.class);
                    if (subject != null) enrolledSubjects.add(subject);
                }

                if (!enrolledSubjects.isEmpty()) {
                    tvNoSubjects.setVisibility(View.GONE);
                    displaySubjects(enrolledSubjects);
                } else {
                    showEmptyState(snapshot.child("enrolledSubjects").exists()
                            ? "No subjects enrolled." : "No subjects found.");
                }
                tabEnrolled.setText("Enrolled (" + enrolledSubjects.size() + ")");
                renderAvailable();
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {}
        };
        userRef.addValueEventListener(userListener);

        // This student's enrollment requests
        requestsRef = mDatabase.child("SubjectRequests").child(uid);
        requestsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                requestStatus.clear();
                for (DataSnapshot r : snapshot.getChildren()) {
                    String status = r.child("status").getValue(String.class);
                    if (r.getKey() != null && status != null) requestStatus.put(r.getKey(), status);
                }
                renderAvailable();
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {}
        };
        requestsRef.addValueEventListener(requestsListener);
    }

    // ── ENROLLED SUBJECTS (existing cards) ──
    private void displaySubjects(List<String> list) {
        hideAllCards();
        for (int i = 0; i < Math.min(list.size(), 9); i++) {
            if (subjectCards[i] != null) {
                subjectCards[i].setVisibility(View.VISIBLE);
                String subName = list.get(i);
                tvSubjectNames[i].setText(subName);
                subjectIcons[i].setImageResource(iconFor(subName));
            }
        }
        openSubjectFromNotification(list);
    }

    // Notification click (subject approved): scroll to that subject's card and highlight it (only once)
    private boolean deepLinkDone = false;

    private void openSubjectFromNotification(List<String> list) {
        if (deepLinkDone) return;
        String wanted = getIntent().getStringExtra(NotificationDeepLink.EXTRA_SUBJECT);
        if (wanted == null || wanted.trim().isEmpty()) return;
        for (int i = 0; i < Math.min(list.size(), 9); i++) {
            if (subjectCards[i] != null && list.get(i).trim().equalsIgnoreCase(wanted.trim())) {
                deepLinkDone = true;
                showTab(true);
                NotificationDeepLink.scrollToAndFlash(subjectCards[i]);
                return;
            }
        }
    }

    private void hideAllCards() {
        for (CardView cv : subjectCards) {
            if (cv != null) cv.setVisibility(View.GONE);
        }
    }

    private void showEmptyState(String msg) {
        tvNoSubjects.setVisibility(View.VISIBLE);
        tvNoSubjects.setText(msg);
        hideAllCards();
    }

    private int iconFor(String subName) {
        int iconRes = R.drawable.ic_subject;
        String lowSub = subName.toLowerCase();
        if (lowSub.contains("math")) iconRes = R.drawable.ic_mathematics;
        else if (lowSub.contains("physic")) iconRes = R.drawable.ic_physics;
        else if (lowSub.contains("chem")) iconRes = R.drawable.ic_chemistry;
        else if (lowSub.contains("eng")) iconRes = R.drawable.ic_english;
        else if (lowSub.contains("biology")) iconRes = R.drawable.ic_biology;
        else if (lowSub.contains("computer")) iconRes = R.drawable.ic_computer;
        else if (lowSub.contains("urdu")) iconRes = R.drawable.ic_urdu;
        else if (lowSub.contains("islamiyat")) iconRes = R.drawable.ic_islamiyat;
        else if (lowSub.contains("pak study")) iconRes = R.drawable.ic_pakstudy;
        return iconRes;
    }

    // ── AVAILABLE SUBJECTS (not enrolled yet) ──
    private boolean isEnrolled(String subjectName) {
        for (String s : enrolledSubjects) {
            if (s != null && s.trim().equalsIgnoreCase(subjectName.trim())) return true;
        }
        return false;
    }

    private void renderAvailable() {
        if (containerAvailable == null || !subjectsLoaded) return;
        containerAvailable.removeAllViews();

        int count = 0;
        for (String name : allSubjects.values()) {
            if (isEnrolled(name)) continue;
            addAvailableCard(name);
            count++;
        }

        tabAvailable.setText("Available (" + count + ")");
        if (count == 0) {
            tvNoAvailable.setText(allSubjects.isEmpty()
                    ? "No subjects available right now."
                    : "You are enrolled in all available subjects.");
            tvNoAvailable.setVisibility(View.VISIBLE);
        } else {
            tvNoAvailable.setVisibility(View.GONE);
        }
    }

    private void addAvailableCard(String name) {
        String status = requestStatus.get(sanitizeKey(name));
        boolean pending = STATUS_PENDING.equalsIgnoreCase(status);

        CardView card = new CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, 0, 0, dp(16));
        card.setLayoutParams(cp);
        card.setRadius(dp(12));
        card.setCardElevation(dp(4));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(12), dp(12), dp(12));

        ImageView icon = new ImageView(this);
        icon.setLayoutParams(new LinearLayout.LayoutParams(dp(55), dp(55)));
        icon.setImageResource(iconFor(name));
        row.addView(icon);

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tcp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tcp.setMarginStart(dp(15));
        textCol.setLayoutParams(tcp);

        TextView tvName = new TextView(this);
        tvName.setText(name);
        tvName.setTextSize(17f);
        tvName.setTextColor(0xFF212121);
        tvName.setTypeface(null, Typeface.BOLD);
        textCol.addView(tvName);

        // A declined request shows no message: the subject simply appears again with "Request".
        if (pending) {
            TextView tvNote = new TextView(this);
            tvNote.setText("Waiting for admin approval");
            tvNote.setTextSize(11.5f);
            tvNote.setTextColor(0xFFF57C00);
            textCol.addView(tvNote);
        }
        row.addView(textCol);

        Button btn = new Button(this);
        btn.setAllCaps(false);
        btn.setTextSize(13f);
        btn.setTextColor(0xFFFFFFFF);
        btn.setMinWidth(0);
        btn.setMinimumWidth(0);
        btn.setPadding(dp(16), 0, dp(16), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(20));
        if (pending) {
            btn.setText("Pending");
            btn.setEnabled(false);
            bg.setColor(0xFF9E9E9E);
        } else {
            btn.setText("Request");
            bg.setColor(0xFFB71C1C);
            btn.setOnClickListener(v -> confirmRequest(name, btn));
        }
        btn.setBackground(bg);
        row.addView(btn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(40)));

        card.addView(row);
        containerAvailable.addView(card);
    }

    private void confirmRequest(String subjectName, Button btn) {
        new AlertDialog.Builder(this)
                .setTitle("Request Enrollment")
                .setMessage("Send a request to the admin to enroll you in " + subjectName + "?")
                .setPositiveButton("Send", (d, w) -> sendRequest(subjectName, btn))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void sendRequest(String subjectName, Button btn) {
        if (currentUser == null) {
            Toast.makeText(this, "Please login again.", Toast.LENGTH_SHORT).show();
            return;
        }
        btn.setEnabled(false);

        String uid = currentUser.getUid();
        Map<String, Object> req = new HashMap<>();
        req.put("uid", uid);
        req.put("studentName", studentName);
        req.put("className", studentClass);
        req.put("subject", subjectName);
        req.put("status", STATUS_PENDING);
        req.put("requestedAt", ServerValue.TIMESTAMP);

        mDatabase.child("SubjectRequests").child(uid).child(sanitizeKey(subjectName))
                .setValue(req)
                .addOnSuccessListener(a -> Toast.makeText(this,
                        "Request sent to admin for " + subjectName, Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> {
                    btn.setEnabled(true);
                    Toast.makeText(this, "Failed to send request: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    // ── Helpers ──
    // Same key format as ManageSubjectsActivity uses for the "Subjects" node.
    private String sanitizeKey(String name) {
        return name.trim()
                .replaceAll("[.#$\\[\\]/]", "_")
                .replaceAll("\\s+", "_");
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}