package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class SubjectsActivity extends AppCompatActivity {

    // Views
    private TextView tvTitle;
    private TextView tvStudentName, tvStudentClass, tvNoSubjects;
    private TextView tabInter;
    private BottomNavigationView bottomNav;

    private CardView[] subjectCards = new CardView[9];
    private ImageView[] subjectIcons = new ImageView[9];
    private TextView[] tvSubjectNames = new TextView[9];

    private DatabaseReference mDatabase;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subjects);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        initViews();
        setupBottomNav();
        fetchStudentInfo();
    }

    private void initViews() {
        tvTitle = findViewById(R.id.tvTitle);
        tvStudentName = findViewById(R.id.tvStudentName);
        tvStudentClass = findViewById(R.id.tvStudentClass);
        tvNoSubjects = findViewById(R.id.tvNoSubjects);
        tabInter = findViewById(R.id.tabInter);
        bottomNav = findViewById(R.id.bottomNav);

        if (tvTitle != null) tvTitle.setText("Subjects");

        // Cards mapping
        int[] cardIds = {R.id.cardSubject1, R.id.cardSubject2, R.id.cardSubject3,
                R.id.cardSubject4, R.id.cardSubject5, R.id.cardSubject6,
                R.id.cardSubject7, R.id.cardSubject8, R.id.cardSubject9};
        int[] iconIds = {R.id.imgSubjectIcon1, R.id.imgSubjectIcon2, R.id.imgSubjectIcon3,
                R.id.imgSubjectIcon4, R.id.imgSubjectIcon5, R.id.imgSubjectIcon6,
                R.id.imgSubjectIcon7, R.id.imgSubjectIcon8, R.id.imgSubjectIcon9};
        int[] nameIds = {R.id.tvSubjectName1, R.id.tvSubjectName2, R.id.tvSubjectName3,
                R.id.tvSubjectName4, R.id.tvSubjectName5, R.id.tvSubjectName6,
                R.id.tvSubjectName7, R.id.tvSubjectName8, R.id.tvSubjectName9};

        for (int i = 0; i < 9; i++) {
            subjectCards[i] = findViewById(cardIds[i]);
            subjectIcons[i] = findViewById(iconIds[i]);
            tvSubjectNames[i] = findViewById(nameIds[i]);

            final int index = i;
            if (subjectCards[i] != null) {
                subjectCards[i].setOnClickListener(v -> {
                    // Subject ka naam lo
                    String subjectName = tvSubjectNames[index].getText().toString();
                    if (!subjectName.isEmpty()) {
                        // StudyMaterialActivity ko open karo aur subject pass karo
                        Intent intent = new Intent(SubjectsActivity.this, StudyMaterialActivity.class);
                        intent.putExtra("FILTER_SUBJECT", subjectName);
                        startActivity(intent);
                    }
                });
            }
        }
        hideAllCards();
    }

    // ── BOTTOM NAVIGATION WORKING LOGIC ──
    private void setupBottomNav() {
        if (bottomNav == null) return;

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_bottom_home) {
                Intent i = new Intent(this, StudentDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
                return true;
            } else if (id == R.id.nav_bottom_feedback) {
                startActivity(new Intent(this, FeedbackActivity.class));
                finish();
                return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                finish();
                return true;
            }
            return false;
        });
    }

    private void fetchStudentInfo() {
        if (currentUser == null) return;

        String uid = currentUser.getUid();
        mDatabase.child("Users").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String name = snapshot.child("name").getValue(String.class);
                    Object classValue = snapshot.child("className").getValue();
                    String sClass = (classValue != null) ? String.valueOf(classValue) : "";

                    if (name != null) {
                        tvStudentName.setText(name);
                    }

                    if (!sClass.isEmpty()) {
                        tvStudentClass.setText("Grade: " + sClass);

                        if (sClass.contains("9") || sClass.contains("10") || sClass.toLowerCase().contains("matric")) {
                            tabInter.setText("Matric Section");
                        } else {
                            tabInter.setText("Inter Section");
                        }
                    }

                    // Subjects Fetching
                    List<String> enrolled = new ArrayList<>();
                    DataSnapshot subsSnapshot = snapshot.child("enrolledSubjects");
                    if (subsSnapshot.exists()) {
                        for (DataSnapshot ds : subsSnapshot.getChildren()) {
                            String subject = ds.getValue(String.class);
                            if (subject != null) enrolled.add(subject);
                        }
                        if (!enrolled.isEmpty()) {
                            tvNoSubjects.setVisibility(View.GONE);
                            displaySubjects(enrolled);
                        } else {
                            showEmptyState("No subjects enrolled.");
                        }
                    } else {
                        showEmptyState("No subjects found.");
                    }
                }
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void displaySubjects(List<String> list) {
        hideAllCards();
        for (int i = 0; i < Math.min(list.size(), 9); i++) {
            if (subjectCards[i] != null) {
                subjectCards[i].setVisibility(View.VISIBLE);
                String subName = list.get(i);
                tvSubjectNames[i].setText(subName);

                int iconRes = R.drawable.ic_subject;
                String lowSub = subName.toLowerCase();
                if (lowSub.contains("math")) iconRes = R.drawable.ic_mathematics;
                else if (lowSub.contains("physic")) iconRes = R.drawable.ic_physics;
                else if (lowSub.contains("chem")) iconRes = R.drawable.ic_chemistry;
                else if (lowSub.contains("eng")) iconRes = R.drawable.ic_english;
                else if (lowSub.contains("biology")) iconRes = R.drawable.ic_biology;
                else if (lowSub.contains("computer")) iconRes = R.drawable.ic_computer;
                else if (lowSub.contains("urdu")) iconRes = R.drawable.ic_urdu;
                else if (lowSub.contains("islamiyat")) iconRes = R.drawable.ic_islamiyat;
                else if (lowSub.contains("pak study")) iconRes = R.drawable.ic_pakstudy;

                subjectIcons[i].setImageResource(iconRes);
            }
        }
    }

    private void hideAllCards() {
        for (CardView cv : subjectCards) {
            if (cv != null) cv.setVisibility(View.GONE);
        }
    }

    private void showEmptyState(String msg) {
        tvNoSubjects.setVisibility(View.VISIBLE);
        tvNoSubjects.setText(msg);
        hideAllCards();
    }
}

