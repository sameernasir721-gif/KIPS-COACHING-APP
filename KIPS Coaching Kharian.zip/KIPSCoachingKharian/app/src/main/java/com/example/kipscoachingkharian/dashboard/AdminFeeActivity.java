package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class AdminFeeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ── Root Layout ───────────────────────────────────────────────────
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF4F6FA);

        // ── Toolbar ───────────────────────────────────────────────────────
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setBackgroundColor(0xFFD32F2F);
        toolbar.setPadding(dp(16), dp(14), dp(16), dp(14));

        ImageView ivBack = new ImageView(this);
        ivBack.setImageResource(android.R.drawable.ic_menu_revert);
        ivBack.setColorFilter(0xFFFFFFFF);
        ivBack.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(dp(24), dp(24));
        bLp.setMarginEnd(dp(14));
        ivBack.setLayoutParams(bLp);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Fee Management");
        tvTitle.setTextSize(18f);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);

        toolbar.addView(ivBack);
        toolbar.addView(tvTitle);

        // ── ScrollView + Container ────────────────────────────────────────
        ScrollView sv = new ScrollView(this);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(16), dp(24), dp(16), dp(24));

        // ── Section Label ─────────────────────────────────────────────────
        TextView tvSection = new TextView(this);
        tvSection.setText("Select an option");
        tvSection.setTextSize(13f);
        tvSection.setTextColor(0xFF888888);
        tvSection.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.setMargins(0, 0, 0, dp(16));
        tvSection.setLayoutParams(slp);
        container.addView(tvSection);

        // ── Card 1: Fee Management ────────────────────────────────────────
        CardView cardFeeManagement = makeBigCard(
                "💰  Fee Management",
                "View all students with their fee amount,\npaid/pending status and history.",
                0xFF1565C0, 0xFFE3F2FD
        );
        cardFeeManagement.setOnClickListener(v ->
                startActivity(new Intent(this, FeemanagementActivity.class)));
        container.addView(cardFeeManagement);

        // ── Card 2: Fee Challan ───────────────────────────────────────────
        CardView cardFeeChallan = makeBigCard(
                "🧾  Fee Challan",
                "Generate subject-wise fee challan for\neach student based on enrollment.",
                0xFF2E7D32, 0xFFE8F5E9
        );
        cardFeeChallan.setOnClickListener(v ->
                startActivity(new Intent(this, FeeChallanActivity.class)));
        container.addView(cardFeeChallan);

        sv.addView(container);
        root.addView(toolbar);
        root.addView(sv);
        setContentView(root);
    }

    private CardView makeBigCard(String title, String subtitle, int textColor, int bgColor) {
        CardView card = new CardView(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, 0, 0, dp(16));
        card.setLayoutParams(cp);
        card.setRadius(dp(16));
        card.setCardElevation(dp(4));
        card.setCardBackgroundColor(bgColor);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(20), dp(22), dp(20), dp(22));

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(17f);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setTextColor(textColor);

        TextView tvSub = new TextView(this);
        tvSub.setText(subtitle);
        tvSub.setTextSize(13f);
        tvSub.setTextColor(0xFF555555);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        sp.topMargin = dp(6);
        tvSub.setLayoutParams(sp);

        // Arrow icon
        TextView tvArrow = new TextView(this);
        tvArrow.setText("→");
        tvArrow.setTextSize(20f);
        tvArrow.setTextColor(textColor);
        tvArrow.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        ap.topMargin = dp(14);
        tvArrow.setLayoutParams(ap);

        inner.addView(tvTitle);
        inner.addView(tvSub);
        inner.addView(tvArrow);
        card.addView(inner);
        return card;
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density);
    }
}