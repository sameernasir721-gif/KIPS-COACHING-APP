package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;

public class AdminFeeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_fee);

        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        findViewById(R.id.cardFeeManagement).setOnClickListener(v ->
                startActivity(new Intent(this, FeemanagementActivity.class)));

        findViewById(R.id.cardFeeChallan).setOnClickListener(v ->
                startActivity(new Intent(this, FeeChallanActivity.class)));

        findViewById(R.id.cardChangeFeeStructure).setOnClickListener(v ->
                startActivity(new Intent(this, ChangeFeeStructureActivity.class)));

        findViewById(R.id.cardPaymentSetup).setOnClickListener(v ->
                startActivity(new Intent(this, AdminPaymentConfigActivity.class)));
    }
}