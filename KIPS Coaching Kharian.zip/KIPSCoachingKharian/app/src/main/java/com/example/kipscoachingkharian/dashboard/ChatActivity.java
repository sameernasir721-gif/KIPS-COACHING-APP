package com.example.kipscoachingkharian.dashboard;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ChatActivity extends AppCompatActivity {

    private static final String TAG = "ChatActivity";

    public static final String EXTRA_RECEIVER_ID   = "RECEIVER_ID";
    public static final String EXTRA_RECEIVER_NAME = "RECEIVER_NAME";
    public static final String EXTRA_RECEIVER_ROLE = "RECEIVER_ROLE";
    public static final String EXTRA_MY_NAME       = "MY_NAME";
    public static final String EXTRA_MY_ROLE       = "MY_ROLE";
    public static final String EXTRA_OTHER_DETAIL  = "OTHER_DETAIL";

    private RecyclerView   rvMessages;
    private EditText       etMessage;
    private ImageButton    btnSend, btnAttach;
    private ProgressBar    progressUpload;
    private TextView       tvChatTitle, tvChatSubtitle;
    private MessageAdapter adapter;

    private final List<Message> messageList = new ArrayList<>();

    private String myUid, myName, myRole;
    private String receiverId, receiverName, receiverRole;
    private String conversationId, otherUserDetail;

    private DatabaseReference  chatsRef, indexRef;
    private ChildEventListener chatListener;
    private Menu               mMenu;

    // ── Cloudinary config (StudyMaterial module jaisa hi unsigned preset) ──
    private static final String CLOUDINARY_CLOUD_NAME    = "dzxkjbtfb";
    private static final String CLOUDINARY_UPLOAD_PRESET = "kips_unsigned";

    // ── File picker: image ya pdf select karne ke liye ──
    private final ActivityResultLauncher<Intent> filePickerLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == Activity.RESULT_OK
                                && result.getData() != null) {
                            Uri uri = result.getData().getData();
                            if (uri != null) handleSelectedFile(uri);
                        }
                    });

    // ─────────────────────────────────────────────────────────────
    // onCreate
    // ─────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        // ── Toolbar ──────────────────────────────────────────────
        Toolbar toolbar = findViewById(R.id.toolbarChat);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayShowTitleEnabled(false);

        // ── myUid: FirebaseAuth se lo, null check zaroori ────────
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        myUid = currentUser.getUid();

        // ── Intent extras ────────────────────────────────────────
        receiverId      = getIntent().getStringExtra(EXTRA_RECEIVER_ID);
        receiverName    = getIntent().getStringExtra(EXTRA_RECEIVER_NAME);
        receiverRole    = getIntent().getStringExtra(EXTRA_RECEIVER_ROLE);
        myName          = getIntent().getStringExtra(EXTRA_MY_NAME);
        myRole          = getIntent().getStringExtra(EXTRA_MY_ROLE);
        otherUserDetail = getIntent().getStringExtra(EXTRA_OTHER_DETAIL);

        // Null safety
        if (myName    == null) myName    = "";
        if (myRole    == null) myRole    = "";
        if (receiverName == null) receiverName = "";
        if (receiverRole == null) receiverRole = "";

        Log.d(TAG, "myUid=" + myUid + " myRole=" + myRole
                + " receiverId=" + receiverId + " receiverRole=" + receiverRole);

        if (receiverId == null || receiverId.isEmpty()) {
            Toast.makeText(this, "Chat error: missing receiver info.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // ── conversationId: dono UIDs ko alphabetically sort karo ─
        // Dono users ko exactly same conversationId mile
        conversationId = myUid.compareTo(receiverId) < 0
                ? myUid + "_" + receiverId
                : receiverId + "_" + myUid;

        chatsRef = FirebaseDatabase.getInstance()
                .getReference("Chats").child(conversationId);
        indexRef = FirebaseDatabase.getInstance()
                .getReference("ConversationIndex");

        initViews();
        listenForMessages();
    }

    // ─────────────────────────────────────────────────────────────
    // UI SETUP
    // ─────────────────────────────────────────────────────────────

    private void initViews() {
        tvChatTitle    = findViewById(R.id.tvChatTitle);
        tvChatSubtitle = findViewById(R.id.tvChatSubtitle);
        rvMessages     = findViewById(R.id.rvMessages);
        etMessage      = findViewById(R.id.etMessage);
        btnSend        = findViewById(R.id.btnSend);
        btnAttach      = findViewById(R.id.btnAttach);
        progressUpload = findViewById(R.id.progressUpload);

        tvChatTitle.setText(receiverName);

        // Subtitle: otherUserDetail pehle, warna role
        if (otherUserDetail != null && !otherUserDetail.isEmpty()) {
            tvChatSubtitle.setText(otherUserDetail);
        } else {
            tvChatSubtitle.setText(receiverRole);
        }

        adapter = new MessageAdapter(this, messageList, myUid);
        rvMessages.setLayoutManager(new LinearLayoutManager(this));
        rvMessages.setAdapter(adapter);

        // ── Long press → delete dialog ───────────────────────────
        // Long press pe: selection mode on hoti hai MessageAdapter mein
        // Phir ChatActivity ko callback milta hai → delete dialog dikhao
        adapter.setOnMessageLongPressListener(this::showDeleteDialog);

        // Image/PDF pe tap → file open karo
        adapter.setOnAttachmentClickListener(this::openAttachment);

        // 📎 Attach button → image/pdf picker kholo
        btnAttach.setOnClickListener(v -> openFilePicker());

        // Back button: selection mode mein → mode cancel, warna finish
        findViewById(R.id.ivBack).setOnClickListener(v -> {
            if (adapter.isSelectionMode()) disableSelectionMode();
            else finish();
        });

        btnSend.setOnClickListener(v -> sendMessage());
    }

    // ─────────────────────────────────────────────────────────────
    // MENU — existing chat_menu.xml (action_select, action_clear_chat,
    //         action_delete_selected) — koi naya item nahi add karna
    // ─────────────────────────────────────────────────────────────

    @Override
    protected void onResume() {
        super.onResume();
        // Chat kholte hi mera unread hamesha 0 (badge foran saaf ho)
        markConversationRead();
    }

    /** Meri taraf ka unreadCount 0 kar do — read flag ki shart ke baghair */
    private void markConversationRead() {
        if (myUid != null && conversationId != null && indexRef != null) {
            indexRef.child(myUid).child(conversationId)
                    .child("unreadCount").setValue(0);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chat_menu, menu);
        this.mMenu = menu;
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_select) {
            // "Select Messages" → selection mode on karo
            enableSelectionMode();

        } else if (id == R.id.action_clear_chat) {
            // "Clear Chat" → apni side ke liye saare messages soft-delete
            confirmClearChat();

        } else if (id == R.id.action_delete_selected) {
            // "Delete" icon → selected messages pe bulk delete dialog
            List<Message> sel = adapter.getSelectedMessages();
            if (sel.isEmpty()) {
                Toast.makeText(this, "No messages selected", Toast.LENGTH_SHORT).show();
            } else {
                showBulkDeleteDialog(sel);
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void enableSelectionMode() {
        adapter.setSelectionMode(true);
        if (mMenu != null) {
            mMenu.findItem(R.id.action_select).setVisible(false);
            mMenu.findItem(R.id.action_clear_chat).setVisible(false);
            mMenu.findItem(R.id.action_delete_selected).setVisible(true);
        }
        tvChatTitle.setText("Select Messages");
    }

    public void disableSelectionMode() {
        adapter.setSelectionMode(false);
        if (mMenu != null) {
            mMenu.findItem(R.id.action_select).setVisible(true);
            mMenu.findItem(R.id.action_clear_chat).setVisible(true);
            mMenu.findItem(R.id.action_delete_selected).setVisible(false);
        }
        tvChatTitle.setText(receiverName);
    }

    // ─────────────────────────────────────────────────────────────
    // DELETE DIALOG — long press pe ek message ke liye
    //
    // RULE:
    //   msg.getSenderId() == myUid  →  maine bheja  →  dono options
    //   msg.getSenderId() != myUid  →  doosre ne bheja  →  sirf "Delete from me"
    // ─────────────────────────────────────────────────────────────

    private void showDeleteDialog(Message msg) {
        // senderId aur myUid compare karke decide karo
        String senderId    = msg.getSenderId() != null ? msg.getSenderId() : "";
        boolean isSentByMe = senderId.equals(myUid);
        boolean alreadyDeleted = msg.isDeletedForEveryone();

        Log.d(TAG, "showDeleteDialog: senderId=" + senderId
                + " myUid=" + myUid + " isSentByMe=" + isSentByMe);

        if (isSentByMe && !alreadyDeleted) {
            // Mera bheja hua (aur abhi tak delete-for-everyone nahi) → dono options
            new AlertDialog.Builder(this)
                    .setTitle("Delete message")
                    .setItems(
                            new CharSequence[]{"Delete from me", "Delete from everyone", "Cancel"},
                            (dialog, which) -> {
                                if      (which == 0) performDeleteFromMe(msg);
                                else if (which == 1) performDeleteFromEveryone(msg);
                                // which == 2 → Cancel
                                disableSelectionMode();
                            })
                    .show();
        } else {
            // Doosre ka message YA already-deleted placeholder → sirf "Delete from me"
            new AlertDialog.Builder(this)
                    .setTitle("Delete message")
                    .setItems(
                            new CharSequence[]{"Delete from me", "Cancel"},
                            (dialog, which) -> {
                                if (which == 0) performDeleteFromMe(msg);
                                // which == 1 → Cancel
                                disableSelectionMode();
                            })
                    .show();
        }
    }

    // ─────────────────────────────────────────────────────────────
    // BULK DELETE DIALOG — menu "Delete" button (multiple messages)
    // ─────────────────────────────────────────────────────────────

    private void showBulkDeleteDialog(List<Message> selected) {
        // Kya selected messages mein se koi mera bheja hua hai?
        boolean hasMySentMsg = false;
        for (Message m : selected) {
            String sid = m.getSenderId() != null ? m.getSenderId() : "";
            // sirf woh messages jo maine bheje AUR abhi delete-for-everyone nahi hue
            if (sid.equals(myUid) && !m.isDeletedForEveryone()) { hasMySentMsg = true; break; }
        }

        if (hasMySentMsg) {
            // Kuch mera bheja hua hai → dono options
            new AlertDialog.Builder(this)
                    .setTitle("Delete " + selected.size() + " message(s)")
                    .setItems(
                            new CharSequence[]{"Delete from me", "Delete from everyone", "Cancel"},
                            (dialog, which) -> {
                                if (which == 0) {
                                    // Saare selected → Delete from me
                                    for (Message m : selected) performDeleteFromMe(m);
                                } else if (which == 1) {
                                    for (Message m : selected) {
                                        String sid = m.getSenderId() != null ? m.getSenderId() : "";
                                        if (m.isDeletedForEveryone())
                                            performDeleteFromMe(m);       // pehle se deleted → sirf apni taraf hatao
                                        else if (sid.equals(myUid))
                                            performDeleteFromEveryone(m); // mera → dono taraf
                                        else
                                            performDeleteFromMe(m);       // doosre ka → sirf apni taraf
                                    }
                                }
                                // which == 2 → Cancel, kuch nahi
                                disableSelectionMode();
                            })
                    .show();
        } else {
            // Sirf received messages → only "Delete from me"
            new AlertDialog.Builder(this)
                    .setTitle("Delete " + selected.size() + " message(s)")
                    .setItems(
                            new CharSequence[]{"Delete from me", "Cancel"},
                            (dialog, which) -> {
                                if (which == 0)
                                    for (Message m : selected) performDeleteFromMe(m);
                                disableSelectionMode();
                            })
                    .show();
        }
    }

    // ─────────────────────────────────────────────────────────────
    // DELETE FROM ME
    // Firebase: Chats/{convId}/{msgId}/deletedFor/{myUid} = true
    // Doosre user ka message intact rehta hai
    // ─────────────────────────────────────────────────────────────

    private void performDeleteFromMe(Message msg) {
        if (msg.getMessageId() == null) return;

        chatsRef.child(msg.getMessageId())
                .child("deletedFor")
                .child(myUid)
                .setValue(true);

        // Local list se turant hatao (UI immediately update ho)
        int idx = findIndexById(msg.getMessageId());
        if (idx != -1) {
            messageList.remove(idx);
            adapter.notifyItemRemoved(idx);
        }
        refreshConversationIndex();
    }

    // ─────────────────────────────────────────────────────────────
    // DELETE FROM EVERYONE
    // Firebase: Chats/{convId}/{msgId}/deletedForEveryone = true
    //                                 /text = ""
    // Dono users ke onChildChanged fire hoga
    // Dono ke adapter mein "This message was deleted" placeholder aayega
    // Sirf original sender kar sakta hai
    // ─────────────────────────────────────────────────────────────

    private void performDeleteFromEveryone(Message msg) {
        if (msg.getMessageId() == null) return;
        String senderId = msg.getSenderId() != null ? msg.getSenderId() : "";
        if (!senderId.equals(myUid)) return; // Safety: sirf sender kar sakta hai

        Map<String, Object> updates = new HashMap<>();
        updates.put("deletedForEveryone", true);
        updates.put("text", ""); // original text Firebase se wipe karo

        chatsRef.child(msg.getMessageId()).updateChildren(updates)
                .addOnSuccessListener(unused -> {
                    // Local list mein bhi turant placeholder set karo
                    int idx = findIndexById(msg.getMessageId());
                    if (idx != -1) {
                        messageList.get(idx).setDeletedForEveryone(true);
                        messageList.get(idx).setText("");
                        adapter.notifyItemChanged(idx);
                    }
                    // Dono users ki conversation list update karo:
                    //  - apni side: unread reset OK (main chat mein hoon)
                    //  - dusre user: unread preserve (uska badge na bigde)
                    refreshConversationIndexFor(myUid, receiverId, receiverName,
                            receiverRole, false);
                    refreshConversationIndexFor(receiverId, myUid, myName,
                            myRole, true);
                });
    }

    // ─────────────────────────────────────────────────────────────
    // CLEAR CHAT — apni side ke liye saare messages soft-delete
    // Firebase: har message mein deletedFor/{myUid} = true
    // Doosre user ka chat bilkul safe rehta hai
    // ─────────────────────────────────────────────────────────────

    private void confirmClearChat() {
        new AlertDialog.Builder(this)
                .setTitle("Clear Chat")
                .setMessage("All messages will be removed from your side only. "
                        + "The other person's chat will remain unchanged.")
                .setPositiveButton("Clear", (d, w) ->
                        chatsRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                for (DataSnapshot ds : snapshot.getChildren())
                                    ds.getRef().child("deletedFor")
                                            .child(myUid).setValue(true);

                                indexRef.child(myUid).child(conversationId).removeValue()
                                        .addOnSuccessListener(v -> {
                                            Toast.makeText(ChatActivity.this,
                                                    "Chat cleared", Toast.LENGTH_SHORT).show();
                                            finish();
                                        });
                            }
                            @Override public void onCancelled(@NonNull DatabaseError e) {
                                Log.e(TAG, "Clear chat error: " + e.getMessage());
                            }
                        }))
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ─────────────────────────────────────────────────────────────
    // MESSAGES LISTENER — real-time Firebase listener
    // ─────────────────────────────────────────────────────────────

    private void listenForMessages() {
        chatListener = new ChildEventListener() {

            // Naya message Firebase mein add hua
            @Override
            public void onChildAdded(@NonNull DataSnapshot s, String prev) {
                Message m = s.getValue(Message.class);
                if (m == null) return;

                // Agar yeh message mere liye soft-deleted hai → skip
                if (s.child("deletedFor").hasChild(myUid)) return;

                // deletedForEveryone message bhi show karo — adapter placeholder dikhayega
                messageList.add(m);
                adapter.notifyItemInserted(messageList.size() - 1);
                rvMessages.scrollToPosition(messageList.size() - 1);

                // Read receipt: agar mujhe receive hua
                String rcvId = m.getReceiverId() != null ? m.getReceiverId() : "";
                if (rcvId.equals(myUid) && !m.isDeletedForEveryone()) {
                    if (!m.isRead()) {
                        chatsRef.child(m.getMessageId()).child("read").setValue(true);
                    }
                    // Chat khuli hai → mera unread hamesha 0 (read flag ki shart nahi)
                    indexRef.child(myUid).child(conversationId)
                            .child("unreadCount").setValue(0);
                }
            }

            // Existing message update hua (deletedFor, deletedForEveryone, read status)
            @Override
            public void onChildChanged(@NonNull DataSnapshot s, String prev) {
                Message m = s.getValue(Message.class);
                if (m == null) return;

                String msgId = m.getMessageId() != null ? m.getMessageId() : s.getKey();

                // Agar ab mere liye delete-from-me mark ho gaya → list se hatao
                if (s.child("deletedFor").hasChild(myUid)) {
                    int idx = findIndexById(msgId);
                    if (idx != -1) {
                        messageList.remove(idx);
                        adapter.notifyItemRemoved(idx);
                    }
                    return;
                }

                // Koi aur update (deletedForEveryone, read) → in-place update
                int idx = findIndexById(msgId);
                if (idx != -1) {
                    messageList.set(idx, m);
                    adapter.notifyItemChanged(idx);
                }
            }

            // Kabhi actual node delete ho to handle karo (edge case)
            @Override
            public void onChildRemoved(@NonNull DataSnapshot s) {
                String id = s.getKey();
                int idx = findIndexById(id);
                if (idx != -1) {
                    messageList.remove(idx);
                    adapter.notifyItemRemoved(idx);
                }
            }

            @Override public void onCancelled(@NonNull DatabaseError e) {
                Log.e(TAG, "Chat listener error: " + e.getMessage());
            }
            @Override public void onChildMoved(@NonNull DataSnapshot s, String p) {}
        };
        chatsRef.addChildEventListener(chatListener);
    }

    // ─────────────────────────────────────────────────────────────
    // SEND MESSAGE
    // ─────────────────────────────────────────────────────────────

    private void sendMessage() {
        String text = etMessage.getText().toString().trim();
        if (TextUtils.isEmpty(text)) return;

        String id = chatsRef.push().getKey();
        if (id == null) return;

        // Message object banao: senderId = myUid (guaranteed correct)
        Message msg = new Message(id, myUid, myName, myRole,
                receiverId, receiverName, text, System.currentTimeMillis());
        chatsRef.child(id).setValue(msg);

        // Apni ConversationIndex entry: receiver ka detail
        fetchUserDetail(receiverId, receiverRole, detailR ->
                updateConversationIndex(myUid, receiverId, receiverName,
                        receiverRole, text, msg.getTimestamp(), false, detailR));

        // Receiver ki ConversationIndex entry: mera detail (unreadCount++)
        fetchUserDetail(myUid, myRole, detailMe ->
                updateConversationIndex(receiverId, myUid, myName,
                        myRole, text, msg.getTimestamp(), true, detailMe));

        etMessage.setText("");
    }

    // ─────────────────────────────────────────────────────────────
    // IMAGE / PDF ATTACHMENTS
    // ─────────────────────────────────────────────────────────────

    /** Picker kholo — sirf image aur pdf allow */
    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES,
                new String[]{"image/*", "application/pdf"});
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        filePickerLauncher.launch(Intent.createChooser(intent, "Select Image or PDF"));
    }

    /** Selected file ko validate karke seedha upload + send karo */
    private void handleSelectedFile(Uri uri) {
        String mimeType = getContentResolver().getType(uri);
        if (mimeType == null ||
                (!mimeType.equals("application/pdf") && !mimeType.startsWith("image/"))) {
            Toast.makeText(this, "Only Image and PDF files are allowed",
                    Toast.LENGTH_LONG).show();
            return;
        }
        String type     = mimeType.equals("application/pdf") ? "pdf" : "image";
        String fileName = getFileName(uri);
        String fileSize = getFileSize(uri);
        uploadAndSendFile(uri, type, fileName, fileSize);
    }

    /** Cloudinary pe upload karo (background), phir Firebase mein message bhejo */
    private void uploadAndSendFile(Uri uri, String type, String fileName, String fileSize) {
        progressUpload.setVisibility(View.VISIBLE);
        btnAttach.setEnabled(false);
        btnSend.setEnabled(false);

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            try {
                // File bytes read karo
                InputStream inputStream = getContentResolver().openInputStream(uri);
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                byte[] temp = new byte[8192];
                int bytesRead;
                while (inputStream != null && (bytesRead = inputStream.read(temp)) != -1) {
                    buffer.write(temp, 0, bytesRead);
                }
                if (inputStream != null) inputStream.close();
                byte[] fileBytes = buffer.toByteArray();

                String mimeType = getContentResolver().getType(uri);
                if (mimeType == null) mimeType = "application/octet-stream";

                // pdf → raw, image → image
                String resourceType = "pdf".equals(type) ? "raw" : "image";
                String uploadUrl = "https://api.cloudinary.com/v1_1/"
                        + CLOUDINARY_CLOUD_NAME + "/" + resourceType + "/upload";

                RequestBody fileBody = RequestBody.create(fileBytes, MediaType.parse(mimeType));
                MultipartBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("file", fileName, fileBody)
                        .addFormDataPart("upload_preset", CLOUDINARY_UPLOAD_PRESET)
                        .build();

                Request request = new Request.Builder()
                        .url(uploadUrl).post(requestBody).build();

                OkHttpClient client = new OkHttpClient();
                Response response = client.newCall(request).execute();
                String responseBody = response.body() != null ? response.body().string() : "";

                if (response.isSuccessful()) {
                    JSONObject json = new JSONObject(responseBody);
                    String fileUrl = json.getString("secure_url");
                    handler.post(() -> {
                        stopUploadUi();
                        sendFileMessage(type, fileUrl, fileName, fileSize);
                    });
                } else {
                    handler.post(() -> {
                        stopUploadUi();
                        Toast.makeText(this, "Upload failed. Please try again.",
                                Toast.LENGTH_LONG).show();
                    });
                }
            } catch (Exception e) {
                handler.post(() -> {
                    stopUploadUi();
                    Toast.makeText(this, "Upload error: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void stopUploadUi() {
        progressUpload.setVisibility(View.GONE);
        btnAttach.setEnabled(true);
        btnSend.setEnabled(true);
    }

    /** Image/PDF message ko Firebase mein bhejo (text message jaisa hi flow) */
    private void sendFileMessage(String type, String fileUrl, String fileName, String fileSize) {
        String id = chatsRef.push().getKey();
        if (id == null) return;

        Message msg = new Message(id, myUid, myName, myRole,
                receiverId, receiverName, "", System.currentTimeMillis());
        msg.setType(type);
        msg.setFileUrl(fileUrl);
        msg.setFileName(fileName);
        msg.setFileSize(fileSize);
        chatsRef.child(id).setValue(msg);

        // ConversationIndex ke liye chhota label
        String preview = "image".equals(type) ? "\uD83D\uDCF7 Photo"
                : "\uD83D\uDCC4 " + (fileName != null && !fileName.isEmpty() ? fileName : "PDF");

        fetchUserDetail(receiverId, receiverRole, detailR ->
                updateConversationIndex(myUid, receiverId, receiverName,
                        receiverRole, preview, msg.getTimestamp(), false, detailR));

        fetchUserDetail(myUid, myRole, detailMe ->
                updateConversationIndex(receiverId, myUid, myName,
                        myRole, preview, msg.getTimestamp(), true, detailMe));
    }

    /** Image/PDF tap → device ke viewer/browser mein kholo */
    private void openAttachment(Message msg) {
        String url = msg.getFileUrl();
        if (url == null || url.isEmpty()) {
            Toast.makeText(this, "File not available", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "No app found to open this file", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * ConversationIndex / last-message ke liye readable preview.
     * viewerUid = jis user ki list ke liye preview ban raha hai.
     * Deleted-for-everyone par: agar viewer ne hi bheja tha → "You deleted this message",
     * warna → "This message was deleted".
     */
    private String previewFor(Message m, String viewerUid) {
        if (m.isDeletedForEveryone()) {
            String sid = m.getSenderId() != null ? m.getSenderId() : "";
            return sid.equals(viewerUid)
                    ? "You deleted this message"
                    : "This message was deleted";
        }
        if (m.isImage()) return "\uD83D\uDCF7 Photo";
        if (m.isPdf()) {
            String n = m.getFileName();
            return "\uD83D\uDCC4 " + (n != null && !n.isEmpty() ? n : "PDF");
        }
        return m.getText();
    }

    /** Content URI se file ka naam nikalo */
    private String getFileName(Uri uri) {
        String result = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) result = cursor.getString(idx);
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            if (result != null) {
                int cut = result.lastIndexOf('/');
                if (cut != -1) result = result.substring(cut + 1);
            }
        }
        return result != null ? result : "file";
    }

    /** Content URI se readable file size nikalo */
    private String getFileSize(Uri uri) {
        long size = 0;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.SIZE);
                    if (idx >= 0 && !cursor.isNull(idx)) size = cursor.getLong(idx);
                }
            }
        }
        if (size <= 0) return "";
        if (size < 1024)        return size + " B";
        if (size < 1024 * 1024) return (size / 1024) + " KB";
        return String.format(java.util.Locale.getDefault(), "%.1f MB", size / (1024.0 * 1024));
    }

    /** messageId se local messageList mein index dhundo */
    private int findIndexById(String msgId) {
        if (msgId == null) return -1;
        for (int i = 0; i < messageList.size(); i++) {
            String id = messageList.get(i).getMessageId();
            if (msgId.equals(id)) return i;
        }
        return -1;
    }

    private interface DetailCallback { void onDetail(String detail); }

    /** Users/{uid} se role ke hisaab se detail fetch karo */
    private void fetchUserDetail(String uid, String role, DetailCallback cb) {
        if (uid == null || uid.isEmpty()) { cb.onDetail(null); return; }
        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snap) {
                        String detail;
                        if (role != null && role.equalsIgnoreCase("Teacher")) {
                            String sub = snap.child("subject").getValue(String.class);
                            detail = (sub != null && !sub.isEmpty()) ? sub : "No Subject";
                        } else {
                            String rid = snap.child("registrationId").getValue(String.class);
                            detail = (rid != null && !rid.isEmpty())
                                    ? ("Student ID: " + rid) : "No ID";
                        }
                        cb.onDetail(detail);
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {
                        cb.onDetail(null);
                    }
                });
    }

    /**
     * Delete ke baad ConversationIndex mein last visible message update karo.
     * Latest 20 messages mein se pehla jo mujhe visible ho woh use karo.
     */
    /** Apni (myUid) side ke liye conversation index refresh karo */
    private void refreshConversationIndex() {
        refreshConversationIndexFor(myUid, receiverId, receiverName, receiverRole, false);
    }

    /**
     * Kisi bhi owner ke liye conversation index ka last-message preview refresh karo.
     * - owner ki nazar se last *visible* message dhoondo (deletedFor/{owner} skip)
     * - preview owner ki perspective se banao (You deleted / This message was deleted)
     * - preserveUnread = true ho to owner ka unreadCount na chero (dusre user ke liye zaroori)
     */
    private void refreshConversationIndexFor(String owner, String other,
                                             String oName, String oRole,
                                             boolean preserveUnread) {
        chatsRef.orderByChild("timestamp").limitToLast(20)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snap) {
                        String lastText = "No messages";
                        long   lastTime = System.currentTimeMillis();

                        List<DataSnapshot> list = new ArrayList<>();
                        for (DataSnapshot ds : snap.getChildren()) list.add(ds);

                        for (int i = list.size() - 1; i >= 0; i--) {
                            DataSnapshot ds = list.get(i);
                            if (ds.child("deletedFor").hasChild(owner)) continue;
                            Message last = ds.getValue(Message.class);
                            if (last == null) continue;
                            lastText = previewFor(last, owner);
                            lastTime = last.getTimestamp();
                            break;
                        }

                        final String ft = lastText;
                        final long   fl = lastTime;
                        fetchUserDetail(other, oRole, detail ->
                                writeIndexPreview(owner, other, oName, oRole,
                                        ft, fl, detail, preserveUnread));
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {
                        Log.e(TAG, "refreshIndex error: " + e.getMessage());
                    }
                });
    }

    /** Index ke preview fields update karo (merge). preserveUnread=false ho to unread 0 set */
    private void writeIndexPreview(String owner, String other, String oName, String oRole,
                                   String lastMsg, long time, String detail,
                                   boolean preserveUnread) {
        DatabaseReference ref = indexRef.child(owner).child(conversationId);
        Map<String, Object> map = new HashMap<>();
        map.put("conversationId",  conversationId);
        map.put("otherUserId",     other);
        map.put("otherUserName",   oName);
        map.put("otherUserRole",   oRole);
        map.put("lastMessage",     lastMsg != null ? lastMsg : "");
        map.put("lastTimestamp",   time);
        map.put("otherUserDetail", detail != null ? detail : "");
        if (!preserveUnread) map.put("unreadCount", 0);
        ref.updateChildren(map);
    }

    private void updateConversationIndex(String owner, String other, String oName,
                                         String oRole, String lastMsg, long time,
                                         boolean incrementUnread, String detail) {
        DatabaseReference ref = indexRef.child(owner).child(conversationId);
        Map<String, Object> map = new HashMap<>();
        map.put("conversationId",  conversationId);
        map.put("otherUserId",     other);
        map.put("otherUserName",   oName);
        map.put("otherUserRole",   oRole);
        map.put("lastMessage",     lastMsg != null ? lastMsg : "");
        map.put("lastTimestamp",   time);
        map.put("otherUserDetail", detail != null ? detail : "");

        if (incrementUnread) {
            ref.child("unreadCount").get().addOnSuccessListener(s -> {
                int cur = (s.exists() && s.getValue(Integer.class) != null)
                        ? s.getValue(Integer.class) : 0;
                ref.child("unreadCount").setValue(cur + 1);
            });
        } else {
            map.put("unreadCount", 0);
        }
        ref.updateChildren(map);
    }

    // ─────────────────────────────────────────────────────────────
    // LIFECYCLE
    // ─────────────────────────────────────────────────────────────

    @Override
    public void onBackPressed() {
        if (adapter != null && adapter.isSelectionMode()) disableSelectionMode();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (chatListener != null) chatsRef.removeEventListener(chatListener);
    }
}