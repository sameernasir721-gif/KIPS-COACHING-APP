package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import com.google.android.material.snackbar.Snackbar;
import android.widget.FrameLayout;
import android.view.ViewGroup;
import android.view.ViewConfiguration;
import android.view.MotionEvent;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class AnnouncementsActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ImageView ivMenu;
    private TextView tvStudentInfo;
    private EditText etSearch;
    private LinearLayout containerAnnouncements;
    private BottomNavigationView bottomNav;
    private NavigationView navigationView;

    private DatabaseReference mDatabase;
    private String currentStudentUid;
    private String myClassName = "";
    private java.util.List<String> myEnrolledSubjects = new java.util.ArrayList<>();
    private final String userRoleType = "Students";

    private SharedPreferences seenPrefs;
    private static final String PREFS_NAME = "seen_announcements";


    private String seenKeysPrefKey = "seen_keys";

    private String dismissedKeysPrefKey = "dismissed_keys";

    // Data Structure
    static class NotifItem {
        String title, message, classLink;
        long timestamp;
        boolean isHighlight, isLiveClass;
        String uniqueKey;
        String type;
        String refId;
        String month;
        String subject;

        NotifItem(String title, String message, String classLink, Long timestamp,
                  boolean isHighlight, boolean isLiveClass, String uniqueKey) {
            this.title = title != null ? title : "";
            this.message = message != null ? message : "";
            this.classLink = classLink;
            this.timestamp = timestamp != null ? timestamp : 0L;
            this.isHighlight = isHighlight;
            this.isLiveClass = isLiveClass;
            this.uniqueKey = uniqueKey != null ? uniqueKey : String.valueOf(timestamp);
        }
    }

    private final List<NotifItem> masterList = new ArrayList<>();
    private final List<NotifItem> adminItems      = new ArrayList<>();
    private final List<NotifItem> assignmentItems = new ArrayList<>();
    private final List<NotifItem> marksItems      = new ArrayList<>();
    private final List<NotifItem> liveClassItems  = new ArrayList<>();

    private int loadedSources = 0;
    private static final int TOTAL_SOURCES = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcements);
        StudentProfileHelper.attach(this, R.id.ivStudent);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        seenPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            currentStudentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            seenKeysPrefKey = "seen_keys_" + currentStudentUid;
            dismissedKeysPrefKey = "dismissed_keys_" + currentStudentUid;
        }

        initViews();
        setupNavigation();
        setupSearch();
        fetchStudentProfileAndData();
    }

    private void initViews() {
        drawerLayout = findViewById(R.id.drawerLayout);
        ivMenu = findViewById(R.id.ivMenu);
        tvStudentInfo = findViewById(R.id.tvStudentInfo);
        etSearch = findViewById(R.id.etSearch);
        containerAnnouncements = findViewById(R.id.containerAnnouncements);
        bottomNav = findViewById(R.id.bottomNav);
        navigationView = findViewById(R.id.navigationView);
    }

    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderList(s.toString().toLowerCase().trim());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void setupNavigation() {
        ivMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                Intent i = new Intent(this, StudentDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
                return true;
            }  else if (id == R.id.nav_bottom_feedback) {
                startActivity(new Intent(this, FeedbackActivity.class));
                finish();
                return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                finish();
                return true;
            }
            return false;
        });

        navigationView.setNavigationItemSelectedListener(item -> {
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });
    }

    private void fetchStudentProfileAndData() {
        if (currentStudentUid == null) { startAllFetches(); return; }

        mDatabase.child("Users").child(currentStudentUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            String name = snapshot.child("name").getValue(String.class);
                            myClassName = snapshot.child("className").getValue(String.class);

                            myEnrolledSubjects.clear();
                            for (DataSnapshot subSnap : snapshot.child("enrolledSubjects").getChildren()) {
                                String subVal = subSnap.getValue(String.class);
                                if (subVal != null) myEnrolledSubjects.add(subVal);
                            }

                            String info = (myClassName != null && !myClassName.isEmpty())
                                    ? "Grade: " + myClassName : "Grade: --";
                            tvStudentInfo.setText(info);
                        }
                        startAllFetches();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) { startAllFetches(); }
                });
    }

    private void startAllFetches() {
        loadedSources = 0;
        fetchAdminAnnouncements();
        fetchSharedAssignments();
        fetchMarksNotifications();
        fetchLiveClasses();
    }

    private void fetchAdminAnnouncements() {
        if (currentStudentUid == null) { onSourceLoaded(); return; }
        adminItems.clear();

        mDatabase.child("Announcements").child("Students")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot snap : snapshot.getChildren()) {

                            if (snap.getKey() != null && snap.getKey().equals(currentStudentUid)) {
                                for (DataSnapshot child : snap.getChildren()) {
                                    adminItems.add(withExtras(withType(new NotifItem(child.child("title").getValue(String.class),
                                                    child.child("message").getValue(String.class),
                                                    child.child("classLink").getValue(String.class),
                                                    child.child("timestamp").getValue(Long.class),
                                                    true, false, "admin_" + child.getKey()),
                                            child.child("type").getValue(String.class)), child, true));
                                }
                            } else {

                                String target = snap.child("targetClass").getValue(String.class);
                                String targetSubject = snap.child("targetSubject").getValue(String.class);

                                boolean classMatches = target == null || target.isEmpty()
                                        || (myClassName != null && target.trim().equalsIgnoreCase(myClassName.trim()));
                                boolean subjectMatches = targetSubject == null || targetSubject.isEmpty()
                                        || myEnrolledSubjects.contains(targetSubject);

                                if (classMatches && subjectMatches) {
                                    adminItems.add(withExtras(withType(new NotifItem(snap.child("title").getValue(String.class),
                                                    snap.child("message").getValue(String.class),
                                                    snap.child("classLink").getValue(String.class),
                                                    snap.child("timestamp").getValue(Long.class),
                                                    true, false, "admin_" + snap.getKey()),
                                            snap.child("type").getValue(String.class)), snap, true));
                                }
                            }
                        }
                        onSourceLoaded();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) { onSourceLoaded(); }
                });
    }

    private void fetchSharedAssignments() {
        mDatabase.child("SharedAssignments").child(currentStudentUid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                assignmentItems.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    assignmentItems.add(withExtras(withType(new NotifItem(snap.child("title").getValue(String.class), snap.child("description").getValue(String.class),
                            null, snap.child("sharedAt").getValue(Long.class), true, false, "asg_" + snap.getKey()), "assignment"), snap, true));
                }
                onSourceLoaded();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) { onSourceLoaded(); }
        });
    }

    private void fetchMarksNotifications() {
        mDatabase.child("Notifications").child(currentStudentUid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                marksItems.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    marksItems.add(withExtras(withType(new NotifItem(snap.child("title").getValue(String.class), snap.child("message").getValue(String.class),
                                    null, snap.child("timestamp").getValue(Long.class), true, false, "mrk_" + snap.getKey()),
                            snap.child("type").getValue(String.class)), snap, false));
                }
                onSourceLoaded();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) { onSourceLoaded(); }
        });
    }

    private void fetchLiveClasses() {
        mDatabase.child("LiveClasses").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                liveClassItems.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    liveClassItems.add(new NotifItem("🎥 Live: " + snap.child("title").getValue(String.class),
                            "Click to join", snap.child("classLink").getValue(String.class),
                            snap.child("timestamp").getValue(Long.class), true, true, "live_" + snap.getKey()));
                }
                onSourceLoaded();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) { onSourceLoaded(); }
        });
    }

    private static NotifItem withType(NotifItem item, String type) {
        item.type = type;
        return item;
    }


    private static NotifItem withExtras(NotifItem item, DataSnapshot snap, boolean keyIsContentId) {
        if (keyIsContentId) item.refId = snap.getKey();

        String month = snap.child("month").getValue(String.class);
        if (month == null) month = firstGroup(item.message, "for ([A-Za-z]+ \\d{4})");
        item.month = month;

        String subject = snap.child("subject").getValue(String.class);
        if (subject == null) subject = firstGroup(item.message, "request for (.+?) (?:has been|was)");
        item.subject = subject;
        return item;
    }

    private static String firstGroup(String text, String regex) {
        if (text == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(regex).matcher(text);
        return m.find() ? m.group(1) : null;
    }


    private Class<?> resolveTargetScreen(NotifItem item) {
        String t = item.type != null ? item.type.trim().toLowerCase(Locale.ROOT) : "";
        switch (t) {
            case "assignment":
            case "assignment_marks":
                return AssignmentActivity.class;
            case "quiz":
                return QuizActivity.class;
            case "progress_marks":
                return ProgressActivity.class;
            case "fee_pending":
            case "fee_confirmation":
            case "wallet_topup":
            case "wallet_bonus":
                return FeeActivity.class;
            case "new_class":
            case "timetable":
                return ClassScheduleActivity.class;
            case "subject_approved":
            case "subject_rejected":
                return SubjectsActivity.class;
            case "admin":
                return null;
        }

        String title = item.title.toLowerCase(Locale.ROOT);
        if (title.contains("new quiz") || title.contains("quiz")) return QuizActivity.class;
        if (title.contains("study material")) return StudyMaterialActivity.class;
        if (title.contains("assignment") || title.contains("marks received")) return AssignmentActivity.class;
        if (title.contains("progress")) return ProgressActivity.class;
        if (title.contains("timetable") || title.contains("new class")) return ClassScheduleActivity.class;
        if (title.contains("subject approved") || title.contains("subject request")) return SubjectsActivity.class;
        if (title.contains("fee") || title.contains("challan") || title.contains("wallet")
                || title.contains("payment")) return FeeActivity.class;
        return null;
    }

    private synchronized void onSourceLoaded() {
        loadedSources++;
        if (loadedSources < TOTAL_SOURCES) return;
        runOnUiThread(() -> {
            masterList.clear();
            masterList.addAll(marksItems);
            masterList.addAll(assignmentItems);
            masterList.addAll(adminItems);
            masterList.addAll(liveClassItems);
            Collections.sort(masterList, (a, b) -> Long.compare(b.timestamp, a.timestamp));
            renderList("");
        });
    }

    private void renderList(String query) {
        containerAnnouncements.removeAllViews();
        Set<String> dismissedKeys = new HashSet<>(seenPrefs.getStringSet(dismissedKeysPrefKey, new HashSet<>()));
        List<NotifItem> filtered = new ArrayList<>();
        for (NotifItem item : masterList) {
            if (dismissedKeys.contains(item.uniqueKey)) continue;
            if (query.isEmpty() || item.title.toLowerCase().contains(query) || item.message.toLowerCase().contains(query)) {
                filtered.add(item);
            }
        }
        Set<String> seenKeys = new HashSet<>(seenPrefs.getStringSet(seenKeysPrefKey, new HashSet<>()));
        for (int i = 0; i < filtered.size(); i++) {
            inflateItemView(filtered.get(i), i + 1, !seenKeys.contains(filtered.get(i).uniqueKey));
        }
    }

    private static final int DELETE_REVEAL_DP = 76;
    private Snackbar undoSnackbar = null;
    private View openedCard = null;

    private void inflateItemView(NotifItem item, int number, boolean isNew) {

        FrameLayout row = new FrameLayout(this);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.bottomMargin = dpToPx(10);
        row.setLayoutParams(rowLp);

        FrameLayout deleteLayer = new FrameLayout(this);
        deleteLayer.setBackgroundColor(0xFFE53935);
        deleteLayer.setVisibility(View.INVISIBLE);
        row.addView(deleteLayer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ImageView bin = new ImageView(this);
        bin.setImageDrawable(binIcon());
        bin.setContentDescription("Delete notification");
        int pad = dpToPx(24);
        bin.setPadding(pad, 0, pad, 0);
        deleteLayer.addView(bin, new FrameLayout.LayoutParams(
                dpToPx(DELETE_REVEAL_DP), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));

        ImageView binLeft = new ImageView(this);
        binLeft.setImageDrawable(binIcon());
        binLeft.setContentDescription("Delete notification");
        binLeft.setPadding(pad, 0, pad, 0);
        deleteLayer.addView(binLeft, new FrameLayout.LayoutParams(
                dpToPx(DELETE_REVEAL_DP), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START));

        View view = LayoutInflater.from(this).inflate(R.layout.item_announcement, row, false);
        ((ViewGroup.MarginLayoutParams) view.getLayoutParams()).bottomMargin = 0;
        row.addView(view);
        view.setTag(deleteLayer);

        TextView tvNumber = view.findViewById(R.id.tvAnnouncementNumber);
        TextView tvTitle = view.findViewById(R.id.tvAnnouncementTitle);
        TextView tvMsg = view.findViewById(R.id.tvAnnouncementMessage);
        TextView tvDate = view.findViewById(R.id.tvAnnouncementDate);
        TextView tvNew = view.findViewById(R.id.tvNewTag);

        tvNumber.setText("#" + number);
        tvTitle.setText(item.title);
        tvMsg.setText(item.message);
        if (item.timestamp > 0) {
            tvDate.setText(new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(new Date(item.timestamp)));
        }
        tvNew.setVisibility(isNew ? View.VISIBLE : View.GONE);

        view.setOnClickListener(v -> {

            if (view.getTranslationX() != 0f) {
                setCardOpen(view, false);
                return;
            }
            if (isNew) {
                tvNew.setVisibility(View.GONE);
                Set<String> updated = new HashSet<>(seenPrefs.getStringSet(seenKeysPrefKey, new HashSet<>()));
                updated.add(item.uniqueKey);
                seenPrefs.edit().putStringSet(seenKeysPrefKey, updated).apply();
            }
            if (item.classLink != null && !item.classLink.isEmpty()) {

                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(item.classLink)));
            } else {

                Class<?> target = resolveTargetScreen(item);
                if (target != null) {
                    Intent go = new Intent(this, target);
                    if (item.refId != null)   go.putExtra("dl_id", item.refId);
                    go.putExtra("dl_title", item.title);
                    if (item.month != null)   go.putExtra("dl_month", item.month);
                    if (item.subject != null) go.putExtra("dl_subject", item.subject);
                    startActivity(go);
                }
            }
        });

        // Dustbin tap -> delete (with Undo)
        bin.setOnClickListener(v -> deleteWithUndo(item, view));
        binLeft.setOnClickListener(v -> deleteWithUndo(item, view));

        enableSwipeToReveal(view, deleteLayer, () -> deleteWithUndo(item, view));
        containerAnnouncements.addView(row);
    }


    private void enableSwipeToReveal(View card, View deleteLayer, Runnable onFullSwipe) {
        final int reveal = dpToPx(DELETE_REVEAL_DP);
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        final float[] down = new float[3];
        final boolean[] swiping = {false};

        card.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = e.getRawX();
                    down[1] = e.getRawY();
                    down[2] = card.getTranslationX();
                    swiping[0] = false;
                    return false;

                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - down[0];
                    float dy = e.getRawY() - down[1];
                    if (!swiping[0]) {

                        if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                            swiping[0] = true;
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            v.setPressed(false);
                            if (openedCard != null && openedCard != card) setCardOpen(openedCard, false);
                        } else {
                            return false;
                        }
                    }
                    float maxTx = card.getWidth();
                    float tx = Math.max(-maxTx, Math.min(maxTx, down[2] + dx));
                    card.setTranslationX(tx);
                    deleteLayer.setVisibility(tx != 0f ? View.VISIBLE : View.INVISIBLE);
                    return true;
                }

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (swiping[0]) {
                        swiping[0] = false;
                        float abs = Math.abs(card.getTranslationX());
                        if (abs > card.getWidth() * 0.45f) {
                            onFullSwipe.run();
                        } else {
                            setCardOpen(card, abs > reveal / 2f);
                        }
                        return true;
                    }
                    return false;
            }
            return false;
        });
    }

    private void setCardOpen(View card, boolean open) {
        final View layer = (View) card.getTag();
        if (layer != null && open) layer.setVisibility(View.VISIBLE);

        card.animate()
                .translationX(open ? (card.getTranslationX() > 0 ? 1 : -1) * dpToPx(DELETE_REVEAL_DP) : 0f)
                .setDuration(160)
                .withEndAction(() -> {
                    if (!open && layer != null) layer.setVisibility(View.INVISIBLE);
                })
                .start();

        if (open) openedCard = card;
        else if (openedCard == card) openedCard = null;
    }


    private void deleteWithUndo(NotifItem item, View card) {
        openedCard = null;

        Set<String> dismissedKeys = new HashSet<>(seenPrefs.getStringSet(dismissedKeysPrefKey, new HashSet<>()));
        dismissedKeys.add(item.uniqueKey);
        seenPrefs.edit().putStringSet(dismissedKeysPrefKey, dismissedKeys).apply();

        card.animate()
                .translationX(card.getTranslationX() > 0 ? card.getWidth() : -card.getWidth())
                .alpha(0f)
                .setDuration(180)
                .withEndAction(() -> renderList(etSearch.getText().toString().toLowerCase().trim()))
                .start();

        showUndoSnackbar(item);
    }


    private void showUndoSnackbar(NotifItem item) {

        if (undoSnackbar != null && undoSnackbar.isShown()) undoSnackbar.dismiss();

        View root = findViewById(android.R.id.content);
        Snackbar bar = Snackbar.make(root, "Notification deleted", 4000)
                .setAction("UNDO", v -> restoreAnnouncement(item));
        undoSnackbar = bar;

        View sbView = bar.getView();
        android.graphics.drawable.GradientDrawable snackBg = new android.graphics.drawable.GradientDrawable();
        snackBg.setColor(0xFFFFFFFF);
        snackBg.setCornerRadius(dpToPx(14));
        snackBg.setStroke(dpToPx(1), 0xFFE0E0E0);
        sbView.setBackground(snackBg);


        ViewGroup.LayoutParams lp = sbView.getLayoutParams();
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) lp;
            int side = dpToPx(16);
            mlp.leftMargin = side;
            mlp.rightMargin = side;
            mlp.bottomMargin = dpToPx(bottomNav != null ? 12 : 24);
            sbView.setLayoutParams(mlp);
        }
        sbView.setElevation(dpToPx(12));

        TextView tvText = sbView.findViewById(com.google.android.material.R.id.snackbar_text);
        if (tvText != null) {
            tvText.setTextColor(0xFF000000);
            tvText.setTextSize(15f);
            tvText.setTypeface(tvText.getTypeface(), android.graphics.Typeface.BOLD);
            tvText.setCompoundDrawablesWithIntrinsicBounds(binIcon(), null, null, null);
            tvText.setCompoundDrawablePadding(dpToPx(10));
            tvText.setCompoundDrawableTintList(android.content.res.ColorStateList.valueOf(0xFF000000));
        }
        bar.setActionTextColor(0xFFEF5350);   // light red UNDO
        TextView tvAction = sbView.findViewById(com.google.android.material.R.id.snackbar_action);
        if (tvAction != null) {
            tvAction.setTextSize(14f);
            tvAction.setTypeface(tvAction.getTypeface(), android.graphics.Typeface.BOLD);
        }

        if (bottomNav != null) bar.setAnchorView(bottomNav);
        bar.show();
    }

    private void restoreAnnouncement(NotifItem item) {
        Set<String> dismissedKeys = new HashSet<>(seenPrefs.getStringSet(dismissedKeysPrefKey, new HashSet<>()));
        dismissedKeys.remove(item.uniqueKey);
        seenPrefs.edit().putStringSet(dismissedKeysPrefKey, dismissedKeys).apply();
        renderList(etSearch.getText().toString().toLowerCase().trim());
    }


    private android.graphics.drawable.Drawable binIcon() {
        android.graphics.Path path = androidx.core.graphics.PathParser.createPathFromPathData(
                "M6,19c0,1.1 0.9,2 2,2h8c1.1,0 2,-0.9 2,-2V7H6v12zM19,4h-3.5l-1,-1h-5l-1,1H5v2h14V4z");
        android.graphics.drawable.ShapeDrawable d = new android.graphics.drawable.ShapeDrawable(
                new android.graphics.drawable.shapes.PathShape(path, 24, 24));
        d.getPaint().setColor(0xFFFFFFFF);
        d.setIntrinsicWidth(dpToPx(24));
        d.setIntrinsicHeight(dpToPx(24));
        return d;
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}