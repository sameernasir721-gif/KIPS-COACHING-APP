package com.example.kipscoachingkharian.dashboard;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class AnnouncementsActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ImageView ivMenu;
    private TextView tvStudentInfo;
    private EditText etSearch;
    private LinearLayout containerAnnouncements;
    private BottomNavigationView bottomNav;
    private NavigationView navigationView;

    private DatabaseReference mDatabase;
    private String currentStudentUid;
    private String myClassName = "";
    private final String userRoleType = "Students";

    private SharedPreferences seenPrefs;
    private static final String PREFS_NAME = "seen_announcements";

    // Har student ka apna seen-list key (uid ke sath), taake ek device pr
    // alag students ka "seen" status mix na ho aur logout/login k baad bhi qaim rahe
    private String seenKeysPrefKey = "seen_keys";

    // ✅ Swipe-to-delete: student jo announcement swipe kar ke delete kare,
    // uska uniqueKey yahan save hota hai — taake dobara wo card list mein na aaye
    // (naye announcements ke liye affect nahi karta, aur student ke apne UID
    // ke sath persist hota hai, alag students ka data mix nahi hota)
    private String dismissedKeysPrefKey = "dismissed_keys";

    // Data Structure
    static class NotifItem {
        String title, message, classLink;
        long timestamp;
        boolean isHighlight, isLiveClass;
        String uniqueKey;

        NotifItem(String title, String message, String classLink, Long timestamp,
                  boolean isHighlight, boolean isLiveClass, String uniqueKey) {
            this.title = title != null ? title : "";
            this.message = message != null ? message : "";
            this.classLink = classLink;
            this.timestamp = timestamp != null ? timestamp : 0L;
            this.isHighlight = isHighlight;
            this.isLiveClass = isLiveClass;
            this.uniqueKey = uniqueKey != null ? uniqueKey : String.valueOf(timestamp);
        }
    }

    private final List<NotifItem> masterList = new ArrayList<>();
    private final List<NotifItem> adminItems      = new ArrayList<>();
    private final List<NotifItem> assignmentItems = new ArrayList<>();
    private final List<NotifItem> marksItems      = new ArrayList<>();
    private final List<NotifItem> liveClassItems  = new ArrayList<>();

    private int loadedSources = 0;
    private static final int TOTAL_SOURCES = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcements);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        seenPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            currentStudentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            seenKeysPrefKey = "seen_keys_" + currentStudentUid;
            dismissedKeysPrefKey = "dismissed_keys_" + currentStudentUid;
        }

        initViews();
        setupNavigation(); // Working Bottom Nav added here
        setupSearch();
        fetchStudentProfileAndData();
    }

    private void initViews() {
        drawerLayout = findViewById(R.id.drawerLayout);
        ivMenu = findViewById(R.id.ivMenu);
        tvStudentInfo = findViewById(R.id.tvStudentInfo);
        etSearch = findViewById(R.id.etSearch);
        containerAnnouncements = findViewById(R.id.containerAnnouncements);
        bottomNav = findViewById(R.id.bottomNav);
        navigationView = findViewById(R.id.navigationView);
    }

    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderList(s.toString().toLowerCase().trim());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    // ── BOTTOM NAVIGATION WORKING CODE ──
    private void setupNavigation() {
        ivMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                Intent i = new Intent(this, StudentDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
                return true;
            }  else if (id == R.id.nav_bottom_feedback) {
                startActivity(new Intent(this, FeedbackActivity.class));
                finish();
                return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                finish();
                return true;
            }
            return false;
        });

        navigationView.setNavigationItemSelectedListener(item -> {
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });
    }

    private void fetchStudentProfileAndData() {
        if (currentStudentUid == null) { startAllFetches(); return; }

        mDatabase.child("Users").child(currentStudentUid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            String name = snapshot.child("name").getValue(String.class);
                            myClassName = snapshot.child("className").getValue(String.class);

                            String info = (myClassName != null && !myClassName.isEmpty())
                                    ? "Grade: " + myClassName : "Grade: --";
                            tvStudentInfo.setText(info);
                        }
                        startAllFetches();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) { startAllFetches(); }
                });
    }

    private void startAllFetches() {
        loadedSources = 0;
        fetchAdminAnnouncements();
        fetchSharedAssignments();
        fetchMarksNotifications();
        fetchLiveClasses();
    }

    // (Firebase methods remain the same as your logic...)
    private void fetchAdminAnnouncements() {
        if (currentStudentUid == null) { onSourceLoaded(); return; }
        adminItems.clear();

        // Purani global entries + nayi per-student entries dono fetch karo
        mDatabase.child("Announcements").child("Students")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot snap : snapshot.getChildren()) {
                            // Nayi per-student entry: key = studentUid
                            if (snap.getKey() != null && snap.getKey().equals(currentStudentUid)) {
                                for (DataSnapshot child : snap.getChildren()) {
                                    adminItems.add(new NotifItem(child.child("title").getValue(String.class),
                                            child.child("message").getValue(String.class),
                                            child.child("classLink").getValue(String.class),
                                            child.child("timestamp").getValue(Long.class),
                                            true, false, "admin_" + child.getKey()));
                                }
                            } else {
                                // Purani global entry — targetClass se filter karo
                                String target = snap.child("targetClass").getValue(String.class);
                                if (target == null || target.isEmpty() || target.equalsIgnoreCase(myClassName)) {
                                    adminItems.add(new NotifItem(snap.child("title").getValue(String.class),
                                            snap.child("message").getValue(String.class),
                                            snap.child("classLink").getValue(String.class),
                                            snap.child("timestamp").getValue(Long.class),
                                            true, false, "admin_" + snap.getKey()));
                                }
                            }
                        }
                        onSourceLoaded();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) { onSourceLoaded(); }
                });
    }

    private void fetchSharedAssignments() {
        mDatabase.child("SharedAssignments").child(currentStudentUid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                assignmentItems.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    assignmentItems.add(new NotifItem(snap.child("title").getValue(String.class), snap.child("description").getValue(String.class),
                            null, snap.child("sharedAt").getValue(Long.class), true, false, "asg_" + snap.getKey()));
                }
                onSourceLoaded();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) { onSourceLoaded(); }
        });
    }

    private void fetchMarksNotifications() {
        mDatabase.child("Notifications").child(currentStudentUid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                marksItems.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    marksItems.add(new NotifItem(snap.child("title").getValue(String.class), snap.child("message").getValue(String.class),
                            null, snap.child("timestamp").getValue(Long.class), true, false, "mrk_" + snap.getKey()));
                }
                onSourceLoaded();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) { onSourceLoaded(); }
        });
    }

    private void fetchLiveClasses() {
        mDatabase.child("LiveClasses").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                liveClassItems.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    liveClassItems.add(new NotifItem("🎥 Live: " + snap.child("title").getValue(String.class),
                            "Click to join", snap.child("classLink").getValue(String.class),
                            snap.child("timestamp").getValue(Long.class), true, true, "live_" + snap.getKey()));
                }
                onSourceLoaded();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) { onSourceLoaded(); }
        });
    }

    private synchronized void onSourceLoaded() {
        loadedSources++;
        if (loadedSources < TOTAL_SOURCES) return;
        runOnUiThread(() -> {
            masterList.clear();
            masterList.addAll(marksItems);
            masterList.addAll(assignmentItems);
            masterList.addAll(adminItems);
            masterList.addAll(liveClassItems);
            Collections.sort(masterList, (a, b) -> Long.compare(b.timestamp, a.timestamp));
            renderList("");
        });
    }

    private void renderList(String query) {
        containerAnnouncements.removeAllViews();
        Set<String> dismissedKeys = new HashSet<>(seenPrefs.getStringSet(dismissedKeysPrefKey, new HashSet<>()));
        List<NotifItem> filtered = new ArrayList<>();
        for (NotifItem item : masterList) {
            if (dismissedKeys.contains(item.uniqueKey)) continue; // ✅ swipe se delete kiya hua skip karo
            if (query.isEmpty() || item.title.toLowerCase().contains(query) || item.message.toLowerCase().contains(query)) {
                filtered.add(item);
            }
        }
        Set<String> seenKeys = new HashSet<>(seenPrefs.getStringSet(seenKeysPrefKey, new HashSet<>()));
        for (int i = 0; i < filtered.size(); i++) {
            inflateItemView(filtered.get(i), i + 1, !seenKeys.contains(filtered.get(i).uniqueKey));
        }
    }

    private void inflateItemView(NotifItem item, int number, boolean isNew) {
        View view = LayoutInflater.from(this).inflate(R.layout.item_announcement, containerAnnouncements, false);
        TextView tvNumber = view.findViewById(R.id.tvAnnouncementNumber);
        TextView tvTitle = view.findViewById(R.id.tvAnnouncementTitle);
        TextView tvMsg = view.findViewById(R.id.tvAnnouncementMessage);
        TextView tvDate = view.findViewById(R.id.tvAnnouncementDate);
        TextView tvNew = view.findViewById(R.id.tvNewTag);

        tvNumber.setText("#" + number);
        tvTitle.setText(item.title);
        tvMsg.setText(item.message);
        if (item.timestamp > 0) {
            tvDate.setText(new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(new Date(item.timestamp)));
        }
        tvNew.setVisibility(isNew ? View.VISIBLE : View.GONE);

        view.setOnClickListener(v -> {
            if (isNew) {
                tvNew.setVisibility(View.GONE);
                Set<String> updated = new HashSet<>(seenPrefs.getStringSet(seenKeysPrefKey, new HashSet<>()));
                updated.add(item.uniqueKey);
                seenPrefs.edit().putStringSet(seenKeysPrefKey, updated).apply();
            }
            if (item.classLink != null && !item.classLink.isEmpty()) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(item.classLink)));
            }
        });

        // ✅ Swipe left/right to delete — card ko taraf khinchne pe fade/slide ho
        // ke list se hamesha ke liye hat jata hai (locally, per-student saved)
        enableSwipeToDelete(view, item);

        containerAnnouncements.addView(view);
    }

    /**
     * Card ko horizontal swipe karne pe drag + fade animate karta hai; agar
     * swipe threshold se zyada ho to card animate ho ke gayab ho jata hai aur
     * uska uniqueKey "dismissed" list mein save ho jata hai (taake dobara na
     * dikhe). Halke se swipe pe card wapas apni jagah snap ho jata hai.
     * Vertical scroll (ScrollView) ke sath conflict na ho, is liye pehle
     * movement ki direction check ki jati hai — sirf clearly horizontal
     * movement ko swipe treat kiya jata hai.
     */
    private void enableSwipeToDelete(final View itemView, final NotifItem item) {
        final float dp = getResources().getDisplayMetrics().density;
        final float dismissThreshold = 120 * dp;

        itemView.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private boolean swiping = false;

            @Override
            public boolean onTouch(View v, android.view.MotionEvent event) {
                switch (event.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        downX = event.getRawX();
                        downY = event.getRawY();
                        swiping = false;
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        return false; // click bhi kaam karta rahe

                    case android.view.MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (!swiping && Math.abs(dx) > (12 * dp) && Math.abs(dx) > Math.abs(dy)) {
                            swiping = true;
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                        }
                        if (swiping) {
                            v.setTranslationX(dx);
                            v.setAlpha(Math.max(0.25f, 1f - (Math.abs(dx) / (600f * dp / 2f))));
                            return true;
                        }
                        return false;

                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        if (swiping) {
                            float finalDx = event.getRawX() - downX;
                            v.getParent().requestDisallowInterceptTouchEvent(false);
                            if (Math.abs(finalDx) > dismissThreshold) {
                                float target = finalDx > 0 ? v.getWidth() : -v.getWidth();
                                v.animate().translationX(target).alpha(0f).setDuration(200)
                                        .withEndAction(() -> dismissAnnouncement(item))
                                        .start();
                            } else {
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start();
                            }
                            swiping = false;
                            return true;
                        }
                        return false;
                }
                return false;
            }
        });
    }

    /**
     * Announcement ko permanently (is device/student ke liye) hide kar deta hai —
     * uniqueKey ko "dismissed" list mein save kar ke, list se remove karta hai.
     */
    private void dismissAnnouncement(NotifItem item) {
        Set<String> dismissedKeys = new HashSet<>(seenPrefs.getStringSet(dismissedKeysPrefKey, new HashSet<>()));
        dismissedKeys.add(item.uniqueKey);
        seenPrefs.edit().putStringSet(dismissedKeysPrefKey, dismissedKeys).apply();
        masterList.remove(item);
        renderList(etSearch.getText().toString().toLowerCase().trim());
    }
}