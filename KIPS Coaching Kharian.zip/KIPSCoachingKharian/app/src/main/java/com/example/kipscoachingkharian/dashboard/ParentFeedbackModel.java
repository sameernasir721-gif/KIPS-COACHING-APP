package com.example.kipscoachingkharian.dashboard;

public class ParentFeedbackModel {
    public String id;
    public String name;
    public String message; // Renamed from 'feedback' to 'message'
    public String rating;
    public String date;

    // Empty constructor for Firebase
    public ParentFeedbackModel() {
    }

    public ParentFeedbackModel(String id, String name, String message, String rating, String date) {
        this.id = id;
        this.name = name;
        this.message = message;
        this.rating = rating;
        this.date = date;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    // This is the method your code was looking for
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getRating() { return rating; }
    public void setRating(String rating) { this.rating = rating; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
}