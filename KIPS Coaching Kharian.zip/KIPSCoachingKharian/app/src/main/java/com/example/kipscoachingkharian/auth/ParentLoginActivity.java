package com.example.kipscoachingkharian.auth;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.ParentDashboardActivity;
import com.example.kipscoachingkharian.model.User;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Activity handles Parent Authentication.
 * Includes unique logic to link a Parent account to a specific Child (Student) account via phone number.
 * Uses Firebase Auth for credentials and Realtime Database for profile storage.
 */
public class ParentLoginActivity extends AppCompatActivity {

    // UI Components for Tab switching and Layouts
    private TextView tabLogin, tabRegister;
    private LinearLayout layoutLogin, layoutRegister;

    // Firebase instances
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    // Login Input Fields
    private TextInputEditText etParentUsername, etParentPassword;

    // Registration Input Fields
    // Note: etChildPhone is specific to Parent registration
    private TextInputEditText etRegName, etRegPhone, etRegPassword, etChildPhone;

    // Action Buttons
    private MaterialButton btnParentLogin, btnParentRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_login);

        // Initialize Firebase Auth and Database references
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Initialize UI elements
        initViews();

        // Configure tab click listeners
        setupTabs();

        // Set authentication action listeners
        btnParentRegister.setOnClickListener(v -> registerParent());
        btnParentLogin.setOnClickListener(v -> loginParent());
    }

    /**
     * Binds XML views to Java objects.
     * Sets the initial state to the Login view.
     */
    private void initViews() {
        tabLogin = findViewById(R.id.tabLogin);
        tabRegister = findViewById(R.id.tabRegister);
        layoutLogin = findViewById(R.id.layoutLogin);
        layoutRegister = findViewById(R.id.layoutRegister);

        etParentUsername = findViewById(R.id.etParentUsername);
        etParentPassword = findViewById(R.id.etParentPassword);
        btnParentLogin = findViewById(R.id.btnParentLogin);

        etRegName = findViewById(R.id.etRegName);
        etRegPhone = findViewById(R.id.etRegPhone);
        etRegPassword = findViewById(R.id.etRegPassword);
        etChildPhone = findViewById(R.id.etChildPhone); // Unique to Parent
        btnParentRegister = findViewById(R.id.btnParentRegister);

        showLoginView();
    }

    /**
     * Handles new Parent registration.
     * 1. Validates all fields, including the Child's Phone Number.
     * 2. Creates a Firebase Auth user.
     * 3. Saves the User object with the 'linkedChildPhone' attribute.
     */
    private void registerParent() {
        String name = etRegName.getText().toString().trim();
        String phone = etRegPhone.getText().toString().trim();
        String password = etRegPassword.getText().toString().trim();
        String childPhone = etChildPhone.getText().toString().trim();

        // Validate inputs
        if (name.isEmpty() || phone.isEmpty() || password.isEmpty() || childPhone.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        // Generate synthetic email for Firebase Auth
        String fakeEmail = phone + "@kips.com";

        // Create User in Auth
        mAuth.createUserWithEmailAndPassword(fakeEmail, password).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                String uid = mAuth.getCurrentUser().getUid();

                // Create User Object with "Parent" role and "Approved" status
                // The linkedChildPhone is critical for fetching the correct student data later
                User user = new User(name, phone, "Parent", "Approved", password, "", "");
                user.setLinkedChildPhone(childPhone);

                // Save to Database
                mDatabase.child("Users").child(uid).setValue(user).addOnCompleteListener(t -> {
                    if (t.isSuccessful()) {
                        Toast.makeText(this, "Registered Successfully!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, ParentDashboardActivity.class));
                        finishAffinity();
                    }
                });
            } else {
                Toast.makeText(this, "Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Handles Parent Login.
     * Authenticates via Firebase using the phone number as the identifier.
     */
    private void loginParent() {
        String phone = etParentUsername.getText().toString().trim();
        String password = etParentPassword.getText().toString().trim();

        if (phone.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        mAuth.signInWithEmailAndPassword(phone + "@kips.com", password).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                checkRole(mAuth.getCurrentUser().getUid());
            } else {
                Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Verifies the user has the "Parent" role.
     * Note: This implementation currently bypasses the 'status' check (e.g., Pending/Approved).
     * @param uid The current User ID.
     */
    private void checkRole(String uid) {
        mDatabase.child("Users").child(uid).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult().exists()) {
                String role = String.valueOf(task.getResult().child("role").getValue());

                if ("Parent".equals(role)) {
                    // Access Granted
                    startActivity(new Intent(this, ParentDashboardActivity.class));
                    finishAffinity();
                } else {
                    // Access Denied - Wrong Role
                    Toast.makeText(this, "Access Denied: Not a Parent Account", Toast.LENGTH_SHORT).show();
                    mAuth.signOut();
                }
            }
        });
    }

    /**
     * Sets up listeners for switching between Login and Register views.
     */
    private void setupTabs() {
        tabLogin.setOnClickListener(v -> showLoginView());
        tabRegister.setOnClickListener(v -> showRegisterView());
    }

    /**
     * UI Helper: Switches to Login layout.
     */
    private void showLoginView() {
        layoutLogin.setVisibility(View.VISIBLE);
        layoutRegister.setVisibility(View.GONE);

        tabLogin.setBackgroundResource(R.drawable.toggle_bg);
        tabLogin.setTextColor(Color.parseColor("#B71C1C"));

        tabRegister.setBackground(null);
        tabRegister.setTextColor(Color.parseColor("#FFFFFF"));
    }

    /**
     * UI Helper: Switches to Register layout.
     */
    private void showRegisterView() {
        layoutLogin.setVisibility(View.GONE);
        layoutRegister.setVisibility(View.VISIBLE);

        tabRegister.setBackgroundResource(R.drawable.toggle_bg);
        tabRegister.setTextColor(Color.parseColor("#B71C1C"));

        tabLogin.setBackground(null);
        tabLogin.setTextColor(Color.parseColor("#FFFFFF"));
    }
}