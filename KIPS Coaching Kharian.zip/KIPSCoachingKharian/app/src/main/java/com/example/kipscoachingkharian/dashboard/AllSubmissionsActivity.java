package com.example.kipscoachingkharian.dashboard;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AllSubmissionsActivity extends AppCompatActivity {

    public static final String EXTRA_ASSIGNMENT_ID    = "assignment_id";
    public static final String EXTRA_TEACHER_ID       = "teacher_id";
    public static final String EXTRA_ASSIGNMENT_TITLE = "assignment_title";
    public static final String EXTRA_TOTAL_MARKS      = "total_marks";
    public static final String EXTRA_DUE_DATE         = "due_date";

    private RecyclerView rvSubmissions;
    private LinearLayout layoutEmpty;
    private TextView tvSubmissionCount, tvAssignmentTitle;
    private SubmissionsAdapter adapter;
    private final List<Map<String, Object>> submissionList = new ArrayList<>();
    private final List<String> studentKeyList = new ArrayList<>();

    private DatabaseReference submissionsRef;
    private ValueEventListener submissionsListener;
    private String teacherId, assignmentId;
    private int totalMarks = 0;
    private String dueDateStr = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_all_submissions);

        assignmentId    = getIntent().getStringExtra(EXTRA_ASSIGNMENT_ID);
        teacherId       = getIntent().getStringExtra(EXTRA_TEACHER_ID);
        String assignmentTitle = getIntent().getStringExtra(EXTRA_ASSIGNMENT_TITLE);
        String marksStr = getIntent().getStringExtra(EXTRA_TOTAL_MARKS);
        if (marksStr != null && !marksStr.isEmpty()) {
            try { totalMarks = Integer.parseInt(marksStr.replaceAll("[^0-9]", "")); } catch (Exception ignored) {}
        }
        dueDateStr = getIntent().getStringExtra(EXTRA_DUE_DATE);
        if (dueDateStr == null) dueDateStr = "";

        rvSubmissions     = findViewById(R.id.rvSubmissions);
        layoutEmpty       = findViewById(R.id.layoutEmpty);
        tvSubmissionCount = findViewById(R.id.tvSubmissionCount);
        tvAssignmentTitle = findViewById(R.id.tvAssignmentTitle);
        ImageView ivBack  = findViewById(R.id.ivBack);

        if (assignmentTitle != null) tvAssignmentTitle.setText(assignmentTitle);
        ivBack.setOnClickListener(v -> finish());

        rvSubmissions.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SubmissionsAdapter(submissionList, studentKeyList);
        rvSubmissions.setAdapter(adapter);

        if (teacherId != null && assignmentId != null) {
            loadSubmissions(teacherId, assignmentId);
        } else {
            showEmpty();
        }

        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                startActivity(new Intent(this, TeacherDashboardActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_Announcment) {
                startActivity(new Intent(this, TeacherAnnouncementsActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileMenuActivity.class));
                finish(); return true;
            }
            return false;
        });

    }

    private void loadSubmissions(String teacherId, String assignmentId) {
        // Actual Firebase path: Submissions/{assignmentId}/{studentUid}
        submissionsRef = FirebaseDatabase.getInstance()
                .getReference("Submissions")
                .child(assignmentId);

        submissionsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                submissionList.clear();
                studentKeyList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> item = (Map<String, Object>) child.getValue();
                    if (item != null) {
                        submissionList.add(item);
                        studentKeyList.add(child.getKey()); // studentUid as key
                    }
                }
                adapter.notifyDataSetChanged();
                int count = submissionList.size();
                tvSubmissionCount.setText(count + (count == 1 ? " Submission" : " Submissions"));
                if (count == 0) showEmpty();
                else {
                    rvSubmissions.setVisibility(View.VISIBLE);
                    layoutEmpty.setVisibility(View.GONE);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AllSubmissionsActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };
        submissionsRef.addValueEventListener(submissionsListener);
    }

    // ─── Marks Dialog ──────────────────────────────────────────────────
    private void showMarksDialog(String studentUid, Map<String, Object> submission, int position) {
        String studentName = getVal(submission, "studentName");
        String currentMarks = getVal(submission, "obtainedMarks");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(60, 30, 60, 10);

        TextView tvInfo = new TextView(this);
        tvInfo.setText("Student: " + (studentName.isEmpty() ? "Unknown" : studentName)
                + (totalMarks > 0 ? "\nTotal Marks: " + totalMarks : ""));
        tvInfo.setTextSize(13f);
        tvInfo.setTextColor(0xFF555555);
        tvInfo.setPadding(0, 0, 0, 16);
        layout.addView(tvInfo);

        EditText etMarks = new EditText(this);
        etMarks.setHint("Enter obtained marks");
        etMarks.setInputType(InputType.TYPE_CLASS_NUMBER);
        if (!currentMarks.isEmpty() && !currentMarks.equals("0")) etMarks.setText(currentMarks);
        layout.addView(etMarks);

        new AlertDialog.Builder(this)
                .setTitle("Give Marks")
                .setView(layout)
                .setPositiveButton("Save", (d, w) -> {
                    String marksInput = etMarks.getText().toString().trim();
                    if (marksInput.isEmpty()) {
                        Toast.makeText(this, "Please enter marks", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int marks;
                    try { marks = Integer.parseInt(marksInput); } catch (Exception e) {
                        Toast.makeText(this, "Invalid marks", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (totalMarks > 0 && marks > totalMarks) {
                        Toast.makeText(this, "Marks cannot exceed " + totalMarks, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    saveMarks(studentUid, marks, position);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveMarks(String studentUid, int marks, int position) {
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        Map<String, Object> updates = new HashMap<>();

        // 1. Save in Submissions/{assignmentId}/{studentUid} (actual Firebase path)
        updates.put("Submissions/" + assignmentId + "/" + studentUid + "/obtainedMarks",
                String.valueOf(marks));
        updates.put("Submissions/" + assignmentId + "/" + studentUid + "/status", "Graded");

        // 2. StudentProgress for reports
        updates.put("StudentProgress/" + studentUid + "/assignments/" + assignmentId + "/marksObtained", marks);
        updates.put("StudentProgress/" + studentUid + "/assignments/" + assignmentId + "/totalMarks", totalMarks);
        updates.put("StudentProgress/" + studentUid + "/assignments/" + assignmentId + "/gradedAt",
                System.currentTimeMillis());

        rootRef.updateChildren(updates)
                .addOnSuccessListener(u -> {
                    Toast.makeText(this,
                            "Marks have been sent to the student successfully!",
                            Toast.LENGTH_LONG).show();
                    adapter.notifyDataSetChanged();

                    // Notification likhna — AnnouncementsActivity mein dikhegi
                    String assignTitle = tvAssignmentTitle.getText().toString();
                    String notifMsg = "Your assignment \"" + assignTitle + "\" has been graded.\n"
                            + "Marks: " + marks + (totalMarks > 0 ? " / " + totalMarks : "");

                    Map<String, Object> notif = new HashMap<>();
                    notif.put("title", "Assignment Graded — " + assignTitle);
                    notif.put("message", notifMsg);
                    notif.put("timestamp", System.currentTimeMillis());
                    notif.put("read", false);
                    notif.put("type", "assignment_marks");

                    FirebaseDatabase.getInstance()
                            .getReference("Notifications")
                            .child(studentUid)
                            .push()
                            .setValue(notif);

                    // Announcements/Students mein bhi likho
                    Map<String, Object> annNotif = new HashMap<>();
                    annNotif.put("title", "🏆 Marks Received: " + assignTitle);
                    annNotif.put("message", notifMsg);
                    annNotif.put("timestamp", System.currentTimeMillis());
                    annNotif.put("pdfUrl", "");
                    FirebaseDatabase.getInstance()
                            .getReference("Announcements")
                            .child("Students")
                            .child(studentUid)
                            .push()
                            .setValue(annNotif);
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    // ─── Late Check ────────────────────────────────────────────────────
    // dueDate format: "dd MMM yyyy" (e.g. "30 Apr 2026")
    // submittedAt format: "dd MMM yyyy · hh:mm a"
    private boolean isLateSubmission(String submittedAt) {
        if (dueDateStr.isEmpty() || submittedAt.isEmpty()) return false;
        try {
            SimpleDateFormat dueFmt = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
            SimpleDateFormat subFmt = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
            // submittedAt mein " · " ke pehle wala part sirf date hai
            String submittedDate = submittedAt.contains("·")
                    ? submittedAt.split("·")[0].trim()
                    : submittedAt.trim();
            Date due = dueFmt.parse(dueDateStr.trim());
            Date sub = subFmt.parse(submittedDate);
            if (due == null || sub == null) return false;
            return sub.after(due); // submitted date due date ke baad hai
        } catch (Exception e) {
            return false;
        }
    }

    private void showEmpty() {
        rvSubmissions.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.VISIBLE);
        tvSubmissionCount.setText("0 Submissions");
    }

    private String getVal(Map<String, Object> map, String key) {
        Object val = map.get(key);
        return val != null ? val.toString() : "";
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (submissionsRef != null && submissionsListener != null)
            submissionsRef.removeEventListener(submissionsListener);
    }

    // ════════════════════════════════════════════════════════════════════
    // Adapter
    // ════════════════════════════════════════════════════════════════════
    private class SubmissionsAdapter
            extends RecyclerView.Adapter<SubmissionsAdapter.VH> {

        private final List<Map<String, Object>> list;
        private final List<String> keys;

        SubmissionsAdapter(List<Map<String, Object>> list, List<String> keys) {
            this.list = list;
            this.keys = keys;
        }

        @NonNull @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_submission, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Map<String, Object> s = list.get(position);
            String studentUid = keys.get(position);

            String name        = getVal(s, "studentName");
            String studentId   = getVal(s, "rollNo");         // Firebase field: rollNo
            String answer      = getVal(s, "answer");
            String submittedAt = getVal(s, "submittedDate"); // Firebase field: submittedDate
            String obtained    = getVal(s, "obtainedMarks");

            h.tvStudentName.setText(name.isEmpty() ? "Unknown Student" : name);
            h.tvStudentId.setText("Student ID: " + (studentId.isEmpty() ? "N/A" : studentId));
            h.tvAnswer.setText(answer.isEmpty() ? "No answer text provided" : answer);
            h.tvSubmittedAt.setText("Submitted: " + submittedAt);

            // Marks display
            if (!obtained.isEmpty() && !obtained.equals("0")) {
                String marksText = "Marks: " + obtained;
                if (totalMarks > 0) marksText += " / " + totalMarks;
                h.tvObtainedMarks.setText(marksText);
                h.tvObtainedMarks.setTextColor(0xFF2E7D32);
                h.tvStatus.setText("Graded");
                h.tvStatus.setTextColor(0xFF1565C0);
                try {
                    ((View) h.tvStatus.getParent()).setBackgroundColor(0xFFE3F2FD);
                } catch (Exception ignored) {}
            } else {
                h.tvObtainedMarks.setText("Marks: Not graded yet");
                h.tvObtainedMarks.setTextColor(0xFF888888);
                h.tvStatus.setText("Submitted");
                h.tvStatus.setTextColor(0xFF2E7D32);
            }

            // Late badge — due date ke baad submit hua?
            boolean late = isLateSubmission(submittedAt);
            h.tvLate.setVisibility(late ? View.VISIBLE : View.GONE);

            // Avatar initial
            String initial = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
            h.tvStudentInitial.setText(initial);

            // Give Marks button — agar already graded hai to disable karo
            if (!obtained.isEmpty() && !obtained.equals("0")) {
                h.btnGiveMarks.setText("Marks Given ✓");
                h.btnGiveMarks.setEnabled(false);
                h.btnGiveMarks.setAlpha(0.5f);
                h.btnGiveMarks.setBackgroundTintList(
                        android.content.res.ColorStateList.valueOf(0xFF4CAF50));
            } else {
                h.btnGiveMarks.setText("Give Marks");
                h.btnGiveMarks.setEnabled(true);
                h.btnGiveMarks.setAlpha(1f);
                h.btnGiveMarks.setBackgroundTintList(
                        android.content.res.ColorStateList.valueOf(0xFFD2192B));
                h.btnGiveMarks.setOnClickListener(v ->
                        showMarksDialog(studentUid, s, position));
            }

            // View Answer button — hamesha available (graded ho ya na ho)
            h.btnViewAnswer.setOnClickListener(v -> {
                String sName      = getVal(s, "studentName");
                String sAnswer    = getVal(s, "answer");
                String sSubmitted = getVal(s, "submittedDate");
                String sPdfUrl    = getVal(s, "pdfUrl");

                // Agar student ne PDF attach ki hai
                if (!sPdfUrl.isEmpty()) {
                    new android.app.AlertDialog.Builder(AllSubmissionsActivity.this)
                            .setTitle("Submission — " + (sName.isEmpty() ? "Student" : sName))
                            .setMessage(
                                    "Submitted: " + (sSubmitted.isEmpty() ? "N/A" : sSubmitted)
                                            + "\n\n"
                                            + (sAnswer.isEmpty() ? "" : "Answer: " + sAnswer + "\n\n")
                                            + "PDF file attached."
                            )
                            .setPositiveButton("📄 View PDF", (d, w) -> {
                                try {
                                    startActivity(new android.content.Intent(
                                            android.content.Intent.ACTION_VIEW,
                                            android.net.Uri.parse(sPdfUrl)));
                                } catch (Exception e) {
                                    Toast.makeText(AllSubmissionsActivity.this,
                                            "Cannot open PDF", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .setNegativeButton("Close", null)
                            .show();
                } else {
                    new android.app.AlertDialog.Builder(AllSubmissionsActivity.this)
                            .setTitle("Answer — " + (sName.isEmpty() ? "Student" : sName))
                            .setMessage(
                                    "Submitted: " + (sSubmitted.isEmpty() ? "N/A" : sSubmitted)
                                            + "\n\n"
                                            + (sAnswer.isEmpty() ? "No answer provided." : sAnswer)
                            )
                            .setPositiveButton("Close", null)
                            .show();
                }
            });
        }

        @Override
        public int getItemCount() { return list.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView tvStudentName, tvStudentInitial, tvStudentId,
                    tvAnswer, tvSubmittedAt, tvStatus, tvObtainedMarks, tvLate;
            Button btnGiveMarks, btnViewAnswer;

            VH(@NonNull View v) {
                super(v);
                tvStudentName    = v.findViewById(R.id.tvStudentName);
                tvStudentInitial = v.findViewById(R.id.tvStudentInitial);
                tvStudentId      = v.findViewById(R.id.tvStudentId);
                tvAnswer         = v.findViewById(R.id.tvAnswer);
                tvSubmittedAt    = v.findViewById(R.id.tvSubmittedAt);
                tvStatus         = v.findViewById(R.id.tvStatus);
                tvObtainedMarks  = v.findViewById(R.id.tvObtainedMarks);
                tvLate           = v.findViewById(R.id.tvLate);
                btnGiveMarks     = v.findViewById(R.id.btnGiveMarks);
                btnViewAnswer    = v.findViewById(R.id.btnViewAnswer);
            }
        }
    }
}