package com.example.kipscoachingkharian.auth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.StudentSelectionActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class StudentLoginActivity extends AppCompatActivity {

    private TextView tabLogin, tabRegister;
    private TextView tvForgotPassword;
    private LinearLayout layoutLogin, layoutRegister;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    // Login fields
    private TextInputEditText etStudentGmail, etStudentId, etStudentPassword;
    private TextInputLayout tilStudentEmail, tilStudentId, tilStudentPassword;
    private MaterialButton btnStudentLogin;
    private MaterialButton btnEmailVerified;

    // Register fields
    private TextInputEditText etRegName, etRegEmail, etRegPhone, etRegPassword;
    private TextInputLayout tilRegName, tilRegEmail, tilRegPhone, tilRegClass, tilRegPassword;
    private AutoCompleteTextView spinnerClass;
    private MaterialButton btnStudentRegister;

    // ── Dynamic subjects (admin-controlled via "Subjects" node)
    private LinearLayout containerRegSubjects;
    private final List<CheckBox> subjectCheckBoxes = new ArrayList<>();
    private final Map<CheckBox, String> checkboxToSubjectName = new LinkedHashMap<>();
    private TextView tvRegTotalFee;
    private int regTotalFee = 0;

    // ── Fee amounts (admin-controlled via "payment_config" node)
    private long feePerSubject = 3000L;
    private long feeSpecial    = 2500L;

    // Kept in sync with FeeChallanActivity.SPECIAL_SUBJECTS so registration-time
    // fee preview matches what will actually be charged on the challan.
    private static final Set<String> SPECIAL_SUBJECTS = new HashSet<>(
            java.util.Arrays.asList(
                    "urdu",
                    "pakistan studies", "pak studies", "pak study", "pakistan study", "p.st", "pst",
                    "islamiat", "islamic studies", "islamiyat", "islamiyat studies"
            ));

    private long getFeeForSubject(String subjectName) {
        if (subjectName == null) return feePerSubject;
        return SPECIAL_SUBJECTS.contains(subjectName.trim().toLowerCase()) ? feeSpecial : feePerSubject;
    }

    // Password show/hide state
    private boolean isLoginPasswordVisible = false;
    private boolean isRegPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_login);

        mAuth    = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        initViews();
        setupTabs();

        btnStudentRegister.setOnClickListener(v -> registerStudent());
        btnStudentLogin.setOnClickListener(v -> loginStudent());
        tvForgotPassword.setOnClickListener(v -> sendPasswordResetEmail());
        btnEmailVerified.setOnClickListener(v -> checkEmailVerification());

        // ✅ Admin-controlled data — loaded fresh every time this screen opens,
        loadFeeStructure();
        loadClassesFromFirebase();
        loadSubjectsFromFirebase();

        android.content.SharedPreferences prefs =
                getSharedPreferences("kips_prefs", MODE_PRIVATE);
        if (prefs.getBoolean("email_verified_done", false)) {
            btnEmailVerified.setVisibility(android.view.View.GONE);
            tilStudentId.setVisibility(android.view.View.VISIBLE);
            btnStudentLogin.setVisibility(android.view.View.VISIBLE);
        } else {
            // Pehli dafa: sirf Email + Password + "I've Verified" button dikhao
            tilStudentId.setVisibility(android.view.View.GONE);
            btnStudentLogin.setVisibility(android.view.View.GONE);
            btnEmailVerified.setVisibility(android.view.View.VISIBLE);
        }
    }

    private void initViews() {
        tabLogin    = findViewById(R.id.tabLogin);
        tabRegister = findViewById(R.id.tabRegister);
        layoutLogin    = findViewById(R.id.layoutLogin);
        layoutRegister = findViewById(R.id.layoutRegister);

        // Login
        etStudentGmail   = findViewById(R.id.etStudentUsername);
        etStudentId      = findViewById(R.id.etStudentId);
        etStudentPassword = findViewById(R.id.etStudentPassword);
        btnStudentLogin  = findViewById(R.id.btnStudentLogin);
        btnEmailVerified = findViewById(R.id.btnEmailVerified);
        tilStudentEmail    = findViewById(R.id.tilStudentEmail);
        tilStudentId       = findViewById(R.id.tilStudentId);
        tilStudentPassword = findViewById(R.id.tilStudentPassword);
        tvForgotPassword   = findViewById(R.id.tvForgotPassword);

        // Register
        etRegName     = findViewById(R.id.etRegName);
        etRegEmail    = findViewById(R.id.etRegEmail);
        etRegPhone    = findViewById(R.id.etRegPhone);
        spinnerClass  = findViewById(R.id.etRegClass);
        etRegPassword = findViewById(R.id.etRegPassword);
        btnStudentRegister = findViewById(R.id.btnStudentRegister);
        tilRegName     = findViewById(R.id.tilRegName);
        tilRegEmail    = findViewById(R.id.tilRegEmail);
        tilRegPhone    = findViewById(R.id.tilRegPhone);
        tilRegClass    = findViewById(R.id.tilRegClass);
        tilRegPassword = findViewById(R.id.tilRegPassword);

        // Password eye-icon: hidden -> slashed eye, visible -> plain eye
        setupPasswordToggle(tilStudentPassword, etStudentPassword, true);
        setupPasswordToggle(tilRegPassword, etRegPassword, false);

        clearErrorOnEdit(tilStudentEmail, etStudentGmail);
        clearErrorOnEdit(tilStudentId, etStudentId);
        clearErrorOnEdit(tilStudentPassword, etStudentPassword);
        clearErrorOnEdit(tilRegName, etRegName);
        clearErrorOnEdit(tilRegEmail, etRegEmail);
        clearErrorOnEdit(tilRegPhone, etRegPhone);
        clearErrorOnEdit(tilRegClass, spinnerClass);
        clearErrorOnEdit(tilRegPassword, etRegPassword);

        // ── Dynamic subjects container + total-fee label ─────────────────────
        // NOTE: add a `LinearLayout` (vertical) with this id in
        // activity_student_login.xml where the subject checkboxes should
        // appear, and remove the old fixed checkboxes (cbRegMath, cbRegUrdu, ...).
        containerRegSubjects = findViewById(R.id.containerRegSubjects);
        tvRegTotalFee = findViewById(R.id.tvRegTotalFee);
    }

    // Password ka eye icon
    private void setupPasswordToggle(TextInputLayout til, TextInputEditText et, boolean isLoginField) {
        if (til == null || et == null) return;

        til.setEndIconDrawable(R.drawable.ic_eye_slash);
        et.setTransformationMethod(PasswordTransformationMethod.getInstance());

        til.setEndIconOnClickListener(v -> {
            boolean currentlyVisible = isLoginField ? isLoginPasswordVisible : isRegPasswordVisible;
            boolean makeVisible = !currentlyVisible;

            if (makeVisible) {
                et.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                til.setEndIconDrawable(R.drawable.ic_eye_open);
            } else {
                et.setTransformationMethod(PasswordTransformationMethod.getInstance());
                til.setEndIconDrawable(R.drawable.ic_eye_slash);
            }

            // Cursor ko text k end pr rakhna
            if (et.getText() != null) {
                et.setSelection(et.getText().length());
            }

            if (isLoginField) {
                isLoginPasswordVisible = makeVisible;
            } else {
                isRegPasswordVisible = makeVisible;
            }
        });
    }

    // ── Admin-controlled: fee amounts ("payment_config" node) ────────────────
    private void loadFeeStructure() {
        mDatabase.child("payment_config").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                Long perSubject = snap.child("fee_per_subject").getValue(Long.class);
                Long special = snap.child("fee_special_subject").getValue(Long.class);
                if (perSubject != null) feePerSubject = perSubject;
                if (special != null) feeSpecial = special;

                // Refresh any already-rendered checkbox labels + total with the live fee.
                relabelSubjectCheckboxes();
                recalcTotalFee();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {
                // Fall back to defaults already set above; registration still works.
            }
        });
    }

    // ── Admin-controlled: classes ("AcademicClasses" node) ───────────────────
    private void loadClassesFromFirebase() {
        mDatabase.child("AcademicClasses").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<String> classNames = new ArrayList<>();
                for (DataSnapshot classSnap : snapshot.getChildren()) {
                    String name = classSnap.child("name").getValue(String.class);
                    if (name == null || name.isEmpty()) name = classSnap.getKey();
                    if (name != null) classNames.add(name);
                }

                if (classNames.isEmpty()) {
                    // Safety net in case Admin hasn't added any classes yet.
                    classNames.add("9th");
                    classNames.add("10th");
                    classNames.add("11th");
                    classNames.add("12th");
                } else {
                    // ✅ Sequence fix: sort by the leading number in each class name
                    // (9th, 10th, 11th, 12th ...) instead of Firebase's default
                    // alphabetical key order, which used to put "10th" before "9th".
                    Collections.sort(classNames, (a, b) -> {
                        int numA = extractLeadingNumber(a);
                        int numB = extractLeadingNumber(b);
                        if (numA != numB) return Integer.compare(numA, numB);
                        return a.compareToIgnoreCase(b);
                    });
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        StudentLoginActivity.this, android.R.layout.simple_list_item_1, classNames);
                spinnerClass.setAdapter(adapter);
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(StudentLoginActivity.this,
                        "Could not load classes: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Naya helper: string ke shuru se number nikalta hai (e.g. "11th" -> 11).
    // Agar koi number na mile to us item ko list ke end mein bhej deta hai.
    private int extractLeadingNumber(String s) {
        if (s == null) return Integer.MAX_VALUE;
        StringBuilder digits = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (Character.isDigit(c)) {
                digits.append(c);
            } else if (digits.length() > 0) {
                break;
            }
        }
        if (digits.length() == 0) return Integer.MAX_VALUE;
        try {
            return Integer.parseInt(digits.toString());
        } catch (NumberFormatException e) {
            return Integer.MAX_VALUE;
        }
    }

    // ── Admin-controlled: subjects ("Subjects" node) ──────────────────────────
    private void loadSubjectsFromFirebase() {
        mDatabase.child("Subjects").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                containerRegSubjects.removeAllViews();
                subjectCheckBoxes.clear();
                checkboxToSubjectName.clear();
                regTotalFee = 0;

                for (DataSnapshot subSnap : snapshot.getChildren()) {
                    String name = subSnap.child("name").getValue(String.class);
                    if (name == null || name.isEmpty()) name = subSnap.getKey();
                    if (name == null) continue;
                    addSubjectCheckbox(name);
                }

                if (subjectCheckBoxes.isEmpty()) {
                    TextView tvEmpty = new TextView(StudentLoginActivity.this);
                    tvEmpty.setText("No subjects available yet. Please contact Admin.");
                    tvEmpty.setTextColor(0xFFFFFFFF);
                    tvEmpty.setTextSize(13f);
                    containerRegSubjects.addView(tvEmpty);
                }

                recalcTotalFee();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(StudentLoginActivity.this,
                        "Could not load subjects: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addSubjectCheckbox(String subjectName) {
        CheckBox cb = new CheckBox(this);
        cb.setText(subjectLabel(subjectName));
        cb.setTextSize(14.5f);
        // Matches the screen's dark gradient background — same styling the
        // original fixed checkboxes (cbRegMath, cbRegUrdu, ...) used.
        cb.setTextColor(0xFFFFFFFF);
        cb.setButtonTintList(android.content.res.ColorStateList.valueOf(0xFFB71C1C));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(4);
        cb.setLayoutParams(lp);

        cb.setOnCheckedChangeListener((btn, checked) -> recalcTotalFee());

        checkboxToSubjectName.put(cb, subjectName);
        subjectCheckBoxes.add(cb);
        containerRegSubjects.addView(cb);
    }

    private String subjectLabel(String subjectName) {
        return subjectName + "  (Rs " + getFeeForSubject(subjectName) + ")";
    }

    // Re-apply current fee amounts onto already-rendered checkbox labels
    // (used when payment_config finishes loading after subjects already rendered).
    private void relabelSubjectCheckboxes() {
        for (Map.Entry<CheckBox, String> entry : checkboxToSubjectName.entrySet()) {
            entry.getKey().setText(subjectLabel(entry.getValue()));
        }
    }

    private void recalcTotalFee() {
        regTotalFee = 0;
        for (Map.Entry<CheckBox, String> entry : checkboxToSubjectName.entrySet()) {
            if (entry.getKey().isChecked()) {
                regTotalFee += getFeeForSubject(entry.getValue());
            }
        }
        if (tvRegTotalFee != null) {
            tvRegTotalFee.setText("Total Fee: Rs " + regTotalFee);
        }
    }

    // ─── VALIDATION HELPERS
    private boolean isValidEmail(String email) {
        if (email.isEmpty()) return false;
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) return false;
        // Sirf Gmail (@gmail.com) allow hai
        return email.toLowerCase().endsWith("@gmail.com");
    }

    private boolean isValidName(String name) {
        return name.matches("^[A-Za-z ]{3,40}$");
    }

    private boolean isValidPhone(String phone) {
        return phone.matches("^[0-9]{11}$");
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 8) return false;
        return password.matches(".*[^A-Za-z0-9].*");
    }

    private void clearErrorOnEdit(TextInputLayout layout, EditText input) {
        if (layout == null || input == null) return;
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                layout.setError(null);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void setupTabs() {
        showLoginView();
        tabLogin.setOnClickListener(v -> showLoginView());
        tabRegister.setOnClickListener(v -> showRegisterView());
    }

    private void showLoginView() {
        layoutLogin.setVisibility(View.VISIBLE);
        layoutRegister.setVisibility(View.GONE);
        tabLogin.setBackgroundResource(R.drawable.bg_tab_active);
        tabLogin.setTextColor(Color.parseColor("#C62828"));
        tabRegister.setBackgroundResource(0);
        tabRegister.setTextColor(Color.WHITE);
    }

    private void showRegisterView() {
        layoutRegister.setVisibility(View.VISIBLE);
        layoutLogin.setVisibility(View.GONE);
        tabRegister.setBackgroundResource(R.drawable.bg_tab_active);
        tabRegister.setTextColor(Color.parseColor("#C62828"));
        tabLogin.setBackgroundResource(0);
        tabLogin.setTextColor(Color.WHITE);
    }

    // ─── REGISTRATION ────────────────────────────────────────────────────────
    private void registerStudent() {
        String name      = etRegName.getText().toString().trim();
        String email     = etRegEmail.getText().toString().trim();
        String phone     = etRegPhone.getText().toString().trim();
        String className = spinnerClass.getText().toString().trim();
        String password  = etRegPassword.getText().toString().trim();

        tilRegName.setError(null);
        tilRegEmail.setError(null);
        tilRegPhone.setError(null);
        tilRegClass.setError(null);
        tilRegPassword.setError(null);

        boolean isValid = true;

        if (name.isEmpty()) {
            tilRegName.setError("Please enter your name");
            isValid = false;
        } else if (!isValidName(name)) {
            tilRegName.setError("Only alphabets allowed");
            isValid = false;
        }

        if (email.isEmpty()) {
            tilRegEmail.setError("Please enter your email");
            isValid = false;
        } else if (!email.toLowerCase().endsWith("@gmail.com")) {
            tilRegEmail.setError("Only Gmail address allowed (e.g. name@gmail.com)");
            tilRegEmail.requestFocus();
            return;
        } else if (!isValidEmail(email)) {
            tilRegEmail.setError("Enter a valid Gmail address");
            isValid = false;
        }

        if (phone.isEmpty()) {
            tilRegPhone.setError("Please enter your phone number");
            isValid = false;
        } else if (!isValidPhone(phone)) {
            tilRegPhone.setError("Write 11-digits number");
            isValid = false;
        }

        if (className.isEmpty()) {
            tilRegClass.setError("Choose class");
            isValid = false;
        }

        if (password.isEmpty()) {
            tilRegPassword.setError("Please enter password");
            isValid = false;
        } else if (!isValidPassword(password)) {
            tilRegPassword.setError("Password must be atleast 8 characters including special symbol");
            isValid = false;
        }

        if (!isValid) {
            return;
        }

        // Registration ke waqt hi subjects choose karo — ab admin ke "Subjects"
        // node se aayi dynamic checkbox list se selected subjects nikalte hain.
        List<String> selectedSubjects = new ArrayList<>();
        for (Map.Entry<CheckBox, String> entry : checkboxToSubjectName.entrySet()) {
            if (entry.getKey().isChecked()) {
                selectedSubjects.add(entry.getValue());
            }
        }

        if (selectedSubjects.isEmpty()) {
            Toast.makeText(this, "Choose at least one subject", Toast.LENGTH_SHORT).show();
            return;
        }

        btnStudentRegister.setEnabled(false);

        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                String uid  = mAuth.getUid();
                String date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());

                Map<String, Object> data = new HashMap<>();
                data.put("uid",              uid);
                data.put("name",             name);
                data.put("email",            email);
                data.put("phone",            phone);
                data.put("className",        className);
                data.put("role",             "Student");
                data.put("status",           "Pending");
                data.put("password",         password);
                data.put("enrolledSubjects", selectedSubjects);   // subjects saved at registration
                data.put("totalFee",         regTotalFee);
                data.put("enrollmentDate",   date);
                data.put("registrationId",   "");
                data.put("feePaid",          false);
                data.put("emailVerified",    false);

                mDatabase.child("Users").child(uid).setValue(data).addOnCompleteListener(dbTask -> {
                    btnStudentRegister.setEnabled(true);
                    if (dbTask.isSuccessful()) {
                        // Verification email bhejo taake dummy/fake email register na ho sakay
                        com.google.firebase.auth.FirebaseUser fUser = mAuth.getCurrentUser();
                        if (fUser != null) {
                            fUser.sendEmailVerification().addOnCompleteListener(verifyTask -> {
                                mAuth.signOut();
                                if (verifyTask.isSuccessful()) {
                                    Toast.makeText(this,
                                            "Registered! Verification link sent to " + email + ". "
                                                    + "Please verify your email first, then wait for Admin approval.",
                                            Toast.LENGTH_LONG).show();
                                } else {
                                    Toast.makeText(this,
                                            "Registered, but verification email could not be sent. "
                                                    + "Try resending it when you attempt to login.",
                                            Toast.LENGTH_LONG).show();
                                }
                                resetVerificationUiForNewAccount();
                                showLoginView();
                            });
                        } else {
                            mAuth.signOut();
                            Toast.makeText(this, "Registered! Wait for Admin approval.", Toast.LENGTH_LONG).show();
                            resetVerificationUiForNewAccount();
                            showLoginView();
                        }
                    } else {
                        Toast.makeText(this, "Data save failed. Try again.", Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                btnStudentRegister.setEnabled(true);
                Toast.makeText(this, "Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ✅ Naya student register hote hi is device ka purana "already verified" flag
    // reset karo, taake naye (abhi tak unverified) account k liye "I have verified"
    // button dobara show ho jaye — pehle ye flag hamesha ke liye true reh jata tha
    // jis se naye students k liye button kabhi nahi aata tha.
    private void resetVerificationUiForNewAccount() {
        getSharedPreferences("kips_prefs", MODE_PRIVATE)
                .edit().putBoolean("email_verified_done", false).apply();

        tilStudentId.setVisibility(android.view.View.GONE);
        btnStudentLogin.setVisibility(android.view.View.GONE);
        btnEmailVerified.setVisibility(android.view.View.VISIBLE);
        btnEmailVerified.setEnabled(true);
    }

    // ─── FORGOT / RESET PASSWORD ───────────────────────────────────────────────
    private void sendPasswordResetEmail() {
        String email = etStudentGmail.getText().toString().trim();

        tilStudentEmail.setError(null);

        if (email.isEmpty()) {
            tilStudentEmail.setError("Write email for reset link");
            Toast.makeText(this, "Write email here", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!email.toLowerCase().endsWith("@gmail.com")) {
            tilStudentEmail.setError("Only Gmail address allowed (e.g. name@gmail.com)");
            return;
        }
        if (!isValidEmail(email)) {
            tilStudentEmail.setError("Please enter a valid Gmail address");
            return;
        }

        tvForgotPassword.setEnabled(false);
        mAuth.sendPasswordResetEmail(email).addOnCompleteListener(task -> {
            tvForgotPassword.setEnabled(true);
            if (task.isSuccessful()) {
                Toast.makeText(this, "Password reset link " + email + " has been sent. Set your new password from the link, then login with the new password.", Toast.LENGTH_LONG).show();
            } else {
                String msg = task.getException() != null ? task.getException().getMessage() : "Try again";
                Toast.makeText(this, "Failed: " + msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ─── EMAIL VERIFICATION STATUS CHECK ─────────────────────────────────────
    private void checkEmailVerification() {
        String email    = etStudentGmail.getText().toString().trim();
        String password = etStudentPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter your Email and Password first", Toast.LENGTH_SHORT).show();
            return;
        }

        btnEmailVerified.setEnabled(false);

        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                com.google.firebase.auth.FirebaseUser fUser = mAuth.getCurrentUser();
                if (fUser != null && fUser.isEmailVerified()) {
                    // Email verified hai — database update karo
                    String uid = fUser.getUid();
                    mDatabase.child("Users").child(uid)
                            .child("emailVerified").setValue(true)
                            .addOnCompleteListener(dbTask -> {
                                mAuth.signOut();
                                btnEmailVerified.setVisibility(android.view.View.GONE);
                                // ✅ Ab Student ID field aur Login button reveal karo
                                tilStudentId.setVisibility(android.view.View.VISIBLE);
                                btnStudentLogin.setVisibility(android.view.View.VISIBLE);
                                btnStudentLogin.setEnabled(true);
                                // ✅ Permanently save — button ab dobara kabhi show nahi hoga
                                getSharedPreferences("kips_prefs", MODE_PRIVATE)
                                        .edit().putBoolean("email_verified_done", true).apply();
                                Toast.makeText(this,
                                        "Email verified! Admin will now see your verified status. Please wait for approval.",
                                        Toast.LENGTH_LONG).show();
                            });
                } else {
                    // Abhi tak link click nahi kiya
                    if (fUser != null) fUser.sendEmailVerification();
                    mAuth.signOut();
                    btnEmailVerified.setEnabled(true);
                    Toast.makeText(this,
                            "Email not verified yet. Please check your inbox/spam and click the verification link first.",
                            Toast.LENGTH_LONG).show();
                }
            } else {
                btnEmailVerified.setEnabled(true);
                Toast.makeText(this, "Incorrect email or password", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ─── LOGIN ───────────────────────────────────────────────────────────────
    private void loginStudent() {
        String email    = etStudentGmail.getText().toString().trim();
        String regId    = etStudentId.getText().toString().trim();
        String password = etStudentPassword.getText().toString().trim();

        tilStudentEmail.setError(null);
        tilStudentId.setError(null);
        tilStudentPassword.setError(null);

        boolean isValid = true;

        if (email.isEmpty()) {
            tilStudentEmail.setError("Please enter email");
            isValid = false;
        } else if (!email.toLowerCase().endsWith("@gmail.com")) {
            tilStudentEmail.setError("Only Gmail address allowed (e.g. name@gmail.com)");
            isValid = false;
        } else if (!isValidEmail(email)) {
            tilStudentEmail.setError("Enter a valid Gmail address");
            isValid = false;
        }

        if (regId.isEmpty()) {
            tilStudentId.setError("Please enter Student ID ");
            isValid = false;
        }

        // ✅ Login par sirf empty check. Strength check yahan nahi lagta, warna reset link se
        // bana naya password (jo Firebase ke rules se banta hai) app mein login hi nahi hota.
        // Password sahi hai ya nahi, ye Firebase Auth khud check karta hai.
        if (password.isEmpty()) {
            tilStudentPassword.setError("Please enter password");
            isValid = false;
        }

        if (!isValid) {
            return;
        }

        btnStudentLogin.setEnabled(false);

        mDatabase.child("Users").orderByChild("registrationId").equalTo(regId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            for (DataSnapshot ds : snapshot.getChildren()) {
                                String status  = ds.child("status").getValue(String.class);
                                String dbEmail = ds.child("email").getValue(String.class);

                                if (dbEmail != null && dbEmail.equalsIgnoreCase(email)) {
                                    if ("Approved".equals(status)) {
                                        mAuth.signInWithEmailAndPassword(email, password)
                                                .addOnCompleteListener(task -> {
                                                    if (task.isSuccessful()) {
                                                        com.google.firebase.auth.FirebaseUser fUser = mAuth.getCurrentUser();
                                                        boolean verified = fUser != null && fUser.isEmailVerified();

                                                        if (!verified) {
                                                            // Email abhi tak verify nahi hua - login block karo
                                                            if (fUser != null) {
                                                                fUser.sendEmailVerification();
                                                            }
                                                            mAuth.signOut();
                                                            Toast.makeText(StudentLoginActivity.this,
                                                                    "Please verify your email first. Verification link resent to "
                                                                            + email + ".",
                                                                    Toast.LENGTH_LONG).show();
                                                            btnStudentLogin.setEnabled(true);
                                                            return;
                                                        }

                                                        // Login successful — database mein bhi password sync karo
                                                        String uid = mAuth.getUid();
                                                        if (uid != null) {
                                                            syncPasswordToDatabase(uid, password);
                                                            mDatabase.child("Users").child(uid)
                                                                    .child("emailVerified").setValue(true);

                                                            // ✅ Daily users tracking (Admin System Report ke liye)
                                                            recordDailyLogin(uid);
                                                        }
                                                        // ✅ Login hi ho gaya matlab email verified hai —
                                                        // button ab is device pe kabhi show nahi hoga
                                                        getSharedPreferences("kips_prefs", MODE_PRIVATE)
                                                                .edit().putBoolean("email_verified_done", true).apply();
                                                        startActivity(new Intent(StudentLoginActivity.this,
                                                                StudentSelectionActivity.class));
                                                        finish();
                                                    } else {
                                                        Toast.makeText(StudentLoginActivity.this,
                                                                "Password is incorrect", Toast.LENGTH_SHORT).show();
                                                        btnStudentLogin.setEnabled(true);
                                                    }
                                                });
                                    } else {
                                        // Pending account — lekin email verification status update karo
                                        mAuth.signInWithEmailAndPassword(email, password)
                                                .addOnCompleteListener(task -> {
                                                    if (task.isSuccessful()) {
                                                        com.google.firebase.auth.FirebaseUser fUser = mAuth.getCurrentUser();
                                                        if (fUser != null && fUser.isEmailVerified()) {
                                                            String uid = fUser.getUid();
                                                            mDatabase.child("Users").child(uid)
                                                                    .child("emailVerified").setValue(true);
                                                        }
                                                        mAuth.signOut();
                                                    }
                                                    Toast.makeText(StudentLoginActivity.this,
                                                            "Pending Account, Contact Admin", Toast.LENGTH_LONG).show();
                                                    btnStudentLogin.setEnabled(true);
                                                });
                                    }
                                    return;
                                }
                            }
                        }
                        Toast.makeText(StudentLoginActivity.this,
                                "incorrect ID or Email", Toast.LENGTH_SHORT).show();
                        btnStudentLogin.setEnabled(true);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        btnStudentLogin.setEnabled(true);
                        Toast.makeText(StudentLoginActivity.this,
                                "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // ─── RESET PASSWORD SYNC ─────────────────────────────────────────────────
    // Student jab reset link se password badalta hai to sirf Firebase Auth ka password
    // badalta hai (link Firebase ke web page par khulta hai, app ko naya password nahi
    // milta). Isliye jab student naye password se login karta hai aur Firebase Auth usay
    // sahi maan leta hai, to yahan Database wala password bhi naye password se update
    // ho jata hai. Purana password Firebase Auth khud reject kar deta hai.
    private void syncPasswordToDatabase(String uid, String newPassword) {
        if (uid == null || newPassword == null || newPassword.isEmpty()) return;
        final DatabaseReference passRef = mDatabase.child("Users").child(uid).child("password");
        passRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String stored = snapshot.getValue(String.class);
                if (stored == null || !stored.equals(newPassword)) {
                    passRef.setValue(newPassword);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Sync fail hua to login par asar nahi padta, agli baar dobara try hoga
            }
        });
    }

    // ─── DAILY USERS TRACKING (Admin System Report ke liye) ─────────────────
    // Har successful (Approved + verified) student login pe is date ke under
    // uid save hota hai. Isse Admin Report mein date-wise unique daily-active
    // -users count nikal sakte hain.
    private void recordDailyLogin(String uid) {
        if (uid == null) return;
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        mDatabase.child("DailyLogins").child(today).child(uid).setValue(true);
    }

    private int dp(int val) {
        return (int) (val * getResources().getDisplayMetrics().density);
    }
}