package com.example.kipscoachingkharian.auth;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.StudentDashboardActivity;
import com.example.kipscoachingkharian.model.User;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Activity handles Student Authentication.
 * Includes specific fields for 'Class' (e.g., 9th, 10th) which is essential for sorting students later.
 * Uses Firebase Auth for credentials and Realtime Database for profile storage.
 */
public class StudentLoginActivity extends AppCompatActivity {

    // UI Components for Tab switching and Layouts
    private TextView tabLogin, tabRegister;
    private LinearLayout layoutLogin, layoutRegister;

    // Firebase instances
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    // Login Input Fields
    private TextInputEditText etStudentId, etStudentPassword;
    private MaterialButton btnStudentLogin;

    // Registration Input Fields
    // Note: etRegClass is specific to Student registration
    private TextInputEditText etRegName, etRegPhone, etRegClass, etRegPassword;
    private MaterialButton btnStudentRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_login);

        // Initialize Firebase Auth and Database references
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Initialize UI elements
        initViews();

        // Configure tab click listeners
        setupTabs();

        // Set authentication action listeners
        btnStudentRegister.setOnClickListener(v -> registerStudent());
        btnStudentLogin.setOnClickListener(v -> loginStudent());
    }

    /**
     * Binds XML views to Java objects.
     * Sets the initial state to the Login view.
     */
    private void initViews() {
        tabLogin = findViewById(R.id.tabLogin);
        tabRegister = findViewById(R.id.tabRegister);
        layoutLogin = findViewById(R.id.layoutLogin);
        layoutRegister = findViewById(R.id.layoutRegister);

        etStudentId = findViewById(R.id.etStudentId);
        etStudentPassword = findViewById(R.id.etStudentPassword);
        btnStudentLogin = findViewById(R.id.btnStudentLogin);

        etRegName = findViewById(R.id.etRegName);
        etRegPhone = findViewById(R.id.etRegPhone);
        etRegClass = findViewById(R.id.etRegClass); // Unique to Student
        etRegPassword = findViewById(R.id.etRegPassword);
        btnStudentRegister = findViewById(R.id.btnStudentRegister);

        showLoginView();
    }

    /**
     * Handles new Student registration.
     * 1. Validates inputs including 'Class Name'.
     * 2. Creates a Firebase Auth user using a synthetic email (phone + domain).
     * 3. Saves the User object with 'Student' role and specific class data.
     */
    private void registerStudent() {
        String name = etRegName.getText().toString().trim();
        String phone = etRegPhone.getText().toString().trim();
        String className = etRegClass.getText().toString().trim();
        String password = etRegPassword.getText().toString().trim();

        // Validate all fields
        if (name.isEmpty() || phone.isEmpty() || className.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Generate synthetic email for Firebase Auth compatibility
        String fakeEmail = phone + "@kips.com";

        // Create User in Auth
        mAuth.createUserWithEmailAndPassword(fakeEmail, password).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                String uid = mAuth.getCurrentUser().getUid();

                // Create User Object with "Student" role and "Approved" status
                // Passing 'className' to the designated field in the User model
                User user = new User(name, phone, "Student", "Approved", password, className, "");

                // Save to Realtime Database
                mDatabase.child("Users").child(uid).setValue(user).addOnCompleteListener(dbTask -> {
                    if (dbTask.isSuccessful()) {
                        Toast.makeText(this, "Registered Successfully! Logging in...", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, StudentDashboardActivity.class));
                        finishAffinity();
                    }
                });
            } else {
                Toast.makeText(this, "Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Handles Student Login.
     * Checks credentials against Firebase Auth.
     */
    private void loginStudent() {
        String phone = etStudentId.getText().toString().trim();
        String password = etStudentPassword.getText().toString().trim();

        if (phone.isEmpty() || password.isEmpty()) return;

        // Ensure the phone number is formatted as an email for Firebase Auth
        if (!phone.contains("@")) {
            phone = phone + "@kips.com";
        }

        mAuth.signInWithEmailAndPassword(phone, password).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                checkRole(mAuth.getCurrentUser().getUid());
            } else {
                Toast.makeText(this, "Login Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Verifies the user has the "Student" role.
     * Prevents other user types (e.g., Teachers) from logging in through this portal.
     * @param uid The current User ID.
     */
    private void checkRole(String uid) {
        mDatabase.child("Users").child(uid).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult().exists()) {
                String role = String.valueOf(task.getResult().child("role").getValue());

                // Direct login without waiting for administrative approval (Status check skipped)
                if ("Student".equals(role)) {
                    startActivity(new Intent(this, StudentDashboardActivity.class));
                    finishAffinity();
                } else {
                    Toast.makeText(this, "Not a Student Account", Toast.LENGTH_SHORT).show();
                    mAuth.signOut();
                }
            }
        });
    }

    /**
     * Sets up listeners for switching between Login and Register views.
     */
    private void setupTabs() {
        tabLogin.setOnClickListener(v -> showLoginView());
        tabRegister.setOnClickListener(v -> showRegisterView());
    }

    /**
     * UI Helper: Switches to Login layout.
     */
    private void showLoginView() {
        layoutLogin.setVisibility(View.VISIBLE);
        layoutRegister.setVisibility(View.GONE);

        tabLogin.setBackgroundResource(R.drawable.toggle_bg);
        tabLogin.setTextColor(Color.parseColor("#B71C1C"));

        tabRegister.setBackground(null);
        tabRegister.setTextColor(Color.parseColor("#FFFFFF"));
    }

    /**
     * UI Helper: Switches to Register layout.
     */
    private void showRegisterView() {
        layoutLogin.setVisibility(View.GONE);
        layoutRegister.setVisibility(View.VISIBLE);

        tabRegister.setBackgroundResource(R.drawable.toggle_bg);
        tabRegister.setTextColor(Color.parseColor("#B71C1C"));

        tabLogin.setBackground(null);
        tabLogin.setTextColor(Color.parseColor("#FFFFFF"));
    }
}