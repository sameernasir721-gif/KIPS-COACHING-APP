package com.example.kipscoachingkharian.dashboard;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.kipscoachingkharian.R;

public class TeacherHelpActivity extends AppCompatActivity {

    private ImageView btnBack;
    private LinearLayout layoutFaqContainer;

    // FAQ data: {question, answer}
    private final String[][] faqs = {
            {"How do I share an assignment or quiz?",
                    "Open the 'Assignments' or 'Quizzes' card from your dashboard, create a new item and tap the 'Share' button to send it to your students."},
            {"How do I check student submissions?",
                    "Open the assignment card and tap 'Submissions' to see what each student has submitted."},
            {"How do I give marks to students?",
                    "Go to 'Student Progress', select the student and enter their marks. The student will automatically get a notification."},
            {"How do I view announcements?",
                    "Open 'Announcements' from the bottom navigation to view announcements sent by the admin."},
            {"How do I view the Time schedule?",
                    "Open 'Time Schedule' from your dashboard to see your upcoming classes and timings."},
            {"How do I create a quiz for my students?",
                    "Open the 'Quizzes' card from your dashboard, tap the add button, fill in the questions and share it with your class."},
            {"How do I update my profile or change my password?",
                    "Open 'My Profile' from this menu and tap the edit (pencil) icon to update your details or password."},
            {"How do I change app settings like font size or dark mode?",
                    "Open 'Settings' from this menu to adjust font size and dark mode."}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_help);

        btnBack            = findViewById(R.id.btnBack);
        layoutFaqContainer = findViewById(R.id.layoutFaqContainer);

        btnBack.setOnClickListener(v -> finish());

        buildFaqList();
    }

    private void buildFaqList() {
        for (String[] faq : faqs) {
            layoutFaqContainer.addView(createFaqCard(faq[0], faq[1]));
        }
    }

    private CardView createFaqCard(String question, String answer) {
        int dp8  = dpToPx(8);
        int dp12 = dpToPx(12);
        int dp18 = dpToPx(18);

        CardView card = new CardView(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.bottomMargin = dp12;
        card.setLayoutParams(cardParams);
        card.setRadius(dpToPx(16));
        card.setCardElevation(dpToPx(3));
        card.setUseCompatPadding(true);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // Header row (question + chevron)
        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);
        headerRow.setPadding(dp18, dp18, dp18, dp18);
        headerRow.setClickable(true);
        headerRow.setFocusable(true);
        headerRow.setBackgroundResource(android.R.drawable.list_selector_background);

        TextView tvQuestion = new TextView(this);
        tvQuestion.setText(question);
        tvQuestion.setTextColor(0xFF263238);
        tvQuestion.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        tvQuestion.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams qParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tvQuestion.setLayoutParams(qParams);
        headerRow.addView(tvQuestion);

        ImageView ivChevron = new ImageView(this);
        ivChevron.setImageResource(R.drawable.ic_chevron_right);
        LinearLayout.LayoutParams chevronParams = new LinearLayout.LayoutParams(dpToPx(18), dpToPx(18));
        chevronParams.leftMargin = dp8;
        ivChevron.setLayoutParams(chevronParams);
        headerRow.addView(ivChevron);

        // Answer (hidden by default)
        TextView tvAnswer = new TextView(this);
        tvAnswer.setText(answer);
        tvAnswer.setTextColor(0xFF757575);
        tvAnswer.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        tvAnswer.setLineSpacing(dpToPx(2), 1f);
        LinearLayout.LayoutParams aParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        aParams.leftMargin  = dp18;
        aParams.rightMargin = dp18;
        aParams.bottomMargin = dp18;
        tvAnswer.setLayoutParams(aParams);
        tvAnswer.setVisibility(View.GONE);

        headerRow.setOnClickListener(v -> {
            boolean isVisible = tvAnswer.getVisibility() == View.VISIBLE;
            tvAnswer.setVisibility(isVisible ? View.GONE : View.VISIBLE);
            ivChevron.setRotation(isVisible ? 0f : 90f);
        });

        container.addView(headerRow);
        container.addView(tvAnswer);
        card.addView(container);

        return card;
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (dp * density);
    }
}