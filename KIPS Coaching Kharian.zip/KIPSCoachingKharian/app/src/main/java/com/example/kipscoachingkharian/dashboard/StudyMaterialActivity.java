package com.example.kipscoachingkharian.dashboard;


import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.LoginSelectionActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Student Study Material Activity
 * Fetches all study materials uploaded by teachers from Firebase
 * and displays them in a filterable list.
 */
public class StudyMaterialActivity extends AppCompatActivity {

    // ── Views ─────────────────────────────────────────────────────────────────
    private DrawerLayout        drawerLayout;
    private NavigationView      navigationView;
    private RecyclerView        rvMaterials;
    private LinearLayout        layoutEmpty;
    private EditText            etSearch;

    // Filter chip TextViews (match IDs in activity_study_material.xml)
    private TextView chipAll, chipPdf, chipImage;

    // Header + dynamic subject chips
    private TextView tvHeaderStudentInfo;
    private LinearLayout containerSubjectChips;
    private String selectedSubject = "all"; // "all" = no subject filter applied

    // ── Data ──────────────────────────────────────────────────────────────────
    private final List<StudyMaterial> allMaterials = new ArrayList<>();
    private MaterialListAdapter adapter;
    private String currentFilter = "all";
    private String searchQuery   = "";

    // ── Firebase ──────────────────────────────────────────────────────────────
    private DatabaseReference materialsRootRef;
    private ValueEventListener materialsListener;

    // ─────────────────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study_material);

        // Guard: must be logged in
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, LoginSelectionActivity.class));
            finish();
            return;
        }

        bindViews();

        // Agar SubjectsActivity se subject card click karke aaye hain,
        // to sirf usi subject ka card open hona chahiye
        String filterSubject = getIntent().getStringExtra("FILTER_SUBJECT");
        if (filterSubject != null && !filterSubject.trim().isEmpty()) {
            selectedSubject = filterSubject.trim();
        }

        setupDrawer();
        setupBottomNav();
        setupSearch();
        setupFilterChips();
        setupRecyclerView();
        loadHeaderInfo();
        loadEnrolledSubjects();
        loadAllMaterials();
    }

    // ── View binding ─────────────────────────────────────────────────────────
    private void bindViews() {
        drawerLayout   = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);
        rvMaterials    = findViewById(R.id.rvStudyMaterial);
        layoutEmpty    = findViewById(R.id.layoutEmpty);
        etSearch       = findViewById(R.id.etSearch);

        // Filter chips — may not be present in every layout version; null-safe
        chipAll   = findViewById(R.id.chipAll);
        chipPdf   = findViewById(R.id.chipPdf);
        chipImage = findViewById(R.id.chipImage);

        tvHeaderStudentInfo    = findViewById(R.id.tvHeaderStudentInfo);
        containerSubjectChips = findViewById(R.id.containerSubjectChips);

        ImageView ivMenu = findViewById(R.id.ivMenu);
        if (ivMenu != null)
            ivMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
    }

    // ── Navigation drawer ────────────────────────────────────────────────────
    private void setupDrawer() {
        if (navigationView == null) return;
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_logout) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(this, LoginSelectionActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finishAffinity();
            }
            if (drawerLayout != null) drawerLayout.closeDrawers();
            return true;
        });
    }

    // ── Bottom navigation ────────────────────────────────────────────────────
    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        if (bottomNav == null) return;
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                Intent i = new Intent(this, StudentDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
                return true;
            } else if (id == R.id.nav_bottom_feedback) {
                startActivity(new Intent(this, FeedbackActivity.class));
                finish();
                return true;
            } else if (id == R.id.nav_bottom_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                finish();
                return true;
            }
            return false;
        });
    }

    // ── Search ────────────────────────────────────────────────────────────────
    private void setupSearch() {
        if (etSearch == null) return;
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                searchQuery = s.toString().trim().toLowerCase();
                if (adapter != null) adapter.filter(currentFilter, searchQuery);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    // ── Filter chips ─────────────────────────────────────────────────────────
    private void setupFilterChips() {
        if (chipAll == null) return;

        setChipSelected(chipAll);
        setChipUnselected(chipPdf);
        setChipUnselected(chipImage);

        chipAll.setOnClickListener(v -> {
            currentFilter = "all";
            setChipSelected(chipAll);
            setChipUnselected(chipPdf);
            setChipUnselected(chipImage);
            if (adapter != null) adapter.filter(currentFilter, searchQuery);
        });
        chipPdf.setOnClickListener(v -> {
            currentFilter = "pdf";
            setChipSelected(chipPdf);
            setChipUnselected(chipAll);
            setChipUnselected(chipImage);
            if (adapter != null) adapter.filter(currentFilter, searchQuery);
        });
        chipImage.setOnClickListener(v -> {
            currentFilter = "image";
            setChipSelected(chipImage);
            setChipUnselected(chipAll);
            setChipUnselected(chipPdf);
            if (adapter != null) adapter.filter(currentFilter, searchQuery);
        });
    }

    private void setChipSelected(TextView chip) {
        if (chip == null) return;
        chip.setBackgroundColor(0xFFE53935);
        chip.setTextColor(0xFFFFFFFF);
    }

    private void setChipUnselected(TextView chip) {
        if (chip == null) return;
        chip.setBackgroundColor(0xFFF0F0F0);
        chip.setTextColor(0xFF333333);
    }

    // ── Header: name + grade from Firebase (single row) ─────────────────────
    private void loadHeaderInfo() {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseDatabase.getInstance().getReference("Users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String grade = snapshot.child("className").getValue(String.class);
                        if (tvHeaderStudentInfo != null) {
                            String info = (grade != null ? "Grade: " + grade : "");
                            tvHeaderStudentInfo.setText(info);
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    // ── Subject chips: only subjects the student is enrolled in ────────────
    private void loadEnrolledSubjects() {
        if (containerSubjectChips == null) return;
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        FirebaseDatabase.getInstance().getReference("Users").child(uid).child("enrolledSubjects")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        containerSubjectChips.removeAllViews();

                        List<String> subjects = new ArrayList<>();
                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String subj = ds.getValue(String.class);
                            if (subj != null && !subj.trim().isEmpty()) subjects.add(subj.trim());
                        }

                        // "All" chip always first
                        addSubjectChip("All", true);
                        for (String subj : subjects) {
                            addSubjectChip(subj, false);
                        }

                        // Jo subject card se aaye hain (ya "all"), usi chip ko selected dikhao
                        highlightSelectedSubjectChip();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void addSubjectChip(String subjectName, boolean isAllChip) {
        float dp = getResources().getDisplayMetrics().density;

        androidx.cardview.widget.CardView card = new androidx.cardview.widget.CardView(this);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(dp(95), dp(100));
        cardLp.setMarginEnd(dp(12));
        card.setLayoutParams(cardLp);
        card.setRadius(16 * dp);
        card.setCardElevation((isAllChip ? 4 : 2) * dp);
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout inner = new LinearLayout(this);
        inner.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setGravity(Gravity.CENTER);
        inner.setPadding(dp(8), dp(8), dp(8), dp(8));

        ImageView icon = new ImageView(this);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(36), dp(36));
        icon.setLayoutParams(iconLp);
        icon.setImageResource(getSubjectIcon(subjectName, isAllChip));

        TextView label = new TextView(this);
        label.setText(subjectName);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        labelLp.topMargin = dp(8);
        label.setLayoutParams(labelLp);
        label.setTextSize(14);
        label.setTypeface(null, android.graphics.Typeface.BOLD);
        label.setTextColor(isAllChip ? 0xFFC62828 : 0xFF333333);

        inner.addView(icon);
        inner.addView(label);
        card.addView(inner);

        card.setTag(isAllChip ? "all" : subjectName);
        card.setOnClickListener(v -> {
            selectedSubject = (String) card.getTag();
            // Reset visuals on all cards
            for (int i = 0; i < containerSubjectChips.getChildCount(); i++) {
                View c = containerSubjectChips.getChildAt(i);
                if (c instanceof androidx.cardview.widget.CardView) {
                    androidx.cardview.widget.CardView cv = (androidx.cardview.widget.CardView) c;
                    cv.setCardElevation(2 * dp);
                    View childInner = cv.getChildAt(0);
                    if (childInner instanceof LinearLayout) {
                        LinearLayout li = (LinearLayout) childInner;
                        if (li.getChildAt(1) instanceof TextView)
                            ((TextView) li.getChildAt(1)).setTextColor(0xFF333333);
                    }
                }
            }
            card.setCardElevation(6 * dp);
            label.setTextColor(0xFFC62828);

            if (adapter != null) adapter.filterBySubject(selectedSubject, currentFilter, searchQuery);
        });

        containerSubjectChips.addView(card);
    }

    // Selected subject ke mutabiq sahi chip ko highlight (red/elevated) karo
    private void highlightSelectedSubjectChip() {
        if (containerSubjectChips == null) return;
        float dp = getResources().getDisplayMetrics().density;

        for (int i = 0; i < containerSubjectChips.getChildCount(); i++) {
            View c = containerSubjectChips.getChildAt(i);
            if (c instanceof androidx.cardview.widget.CardView) {
                androidx.cardview.widget.CardView cv = (androidx.cardview.widget.CardView) c;
                String tag = String.valueOf(cv.getTag());
                boolean isSelected = tag.equalsIgnoreCase(selectedSubject);

                cv.setCardElevation((isSelected ? 6 : 2) * dp);
                View childInner = cv.getChildAt(0);
                if (childInner instanceof LinearLayout) {
                    LinearLayout li = (LinearLayout) childInner;
                    if (li.getChildAt(1) instanceof TextView) {
                        ((TextView) li.getChildAt(1)).setTextColor(isSelected ? 0xFFC62828 : 0xFF333333);
                    }
                }
            }
        }
    }

    private int getSubjectIcon(String subject, boolean isAllChip) {
        if (isAllChip) return R.drawable.ic_subject;
        String s = subject.toLowerCase();
        if (s.contains("phys"))               return R.drawable.ic_physics;
        if (s.contains("chem"))               return R.drawable.ic_chemistry;
        if (s.contains("math"))               return R.drawable.ic_mathematics;
        if (s.contains("bio"))                return R.drawable.ic_biology;
        if (s.contains("eng"))                return R.drawable.ic_english;
        if (s.contains("urdu"))               return R.drawable.ic_urdu;
        if (s.contains("computer"))           return R.drawable.ic_computer;
        if (s.contains("islamiyat"))           return R.drawable.ic_islamiyat;
        if (s.contains("pakstudy"))           return R.drawable.ic_pakstudy;


        return R.drawable.ic_subject;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }


    private void setupRecyclerView() {
        if (rvMaterials == null) return;
        LinearLayoutManager layoutManager = new LinearLayoutManager(this) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        rvMaterials.setLayoutManager(layoutManager);
        rvMaterials.setNestedScrollingEnabled(false);
        adapter = new MaterialListAdapter(new ArrayList<>());
        rvMaterials.setAdapter(adapter);
    }

    // ── Load only materials shared with this student ───────────────────────
    private void loadAllMaterials() {
        String studentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        materialsRootRef = FirebaseDatabase.getInstance()
                .getReference("SharedStudyMaterials").child(studentUid);

        materialsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                allMaterials.clear();

                for (DataSnapshot materialSnap : snapshot.getChildren()) {
                    StudyMaterial m = materialSnap.getValue(StudyMaterial.class);
                    if (m != null) allMaterials.add(m);
                }

                if (adapter != null) {
                    adapter.setData(allMaterials);
                    adapter.filter(currentFilter, searchQuery);
                }
                updateEmptyState(allMaterials.isEmpty());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(StudyMaterialActivity.this,
                        "Error loading materials: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        };

        materialsRootRef.addValueEventListener(materialsListener);
    }

    private void updateEmptyState(boolean isEmpty) {
        if (rvMaterials != null)
            rvMaterials.setVisibility(isEmpty ? View.GONE    : View.VISIBLE);
        if (layoutEmpty != null)
            layoutEmpty.setVisibility( isEmpty ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (materialsRootRef != null && materialsListener != null)
            materialsRootRef.removeEventListener(materialsListener);
    }

    // ════════════════════════════════════════════════════════════════════════
    // Inner RecyclerView Adapter
    // ════════════════════════════════════════════════════════════════════════
    private class MaterialListAdapter
            extends RecyclerView.Adapter<MaterialListAdapter.ViewHolder> {

        private List<StudyMaterial> fullList;
        private List<StudyMaterial> filteredList = new ArrayList<>();

        MaterialListAdapter(List<StudyMaterial> list) {
            this.fullList = new ArrayList<>(list);
            this.filteredList = new ArrayList<>(list);
        }

        void setData(List<StudyMaterial> list) {
            this.fullList = new ArrayList<>(list);
        }

        void filter(String typeFilter, String query) {
            filterBySubject(StudyMaterialActivity.this.selectedSubject, typeFilter, query);
        }

        void filterBySubject(String subjectFilter, String typeFilter, String query) {
            filteredList = new ArrayList<>();
            for (StudyMaterial m : fullList) {
                boolean subjectOk = subjectFilter == null || subjectFilter.equals("all")
                        || (m.getSubject() != null && m.getSubject().equalsIgnoreCase(subjectFilter));
                boolean typeOk = typeFilter.equals("all")
                        || typeFilter.equalsIgnoreCase(m.getType());
                boolean queryOk = query.isEmpty()
                        || (m.getTitle()   != null && m.getTitle()  .toLowerCase().contains(query))
                        || (m.getSubject() != null && m.getSubject().toLowerCase().contains(query))
                        || (m.getGrade()   != null && m.getGrade()  .toLowerCase().contains(query));
                if (subjectOk && typeOk && queryOk) filteredList.add(m);
            }
            notifyDataSetChanged();
            updateEmptyState(filteredList.isEmpty());
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // Reuse the same item card layout used by teacher's list
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_teacher_studymaterial, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder h, int position) {
            StudyMaterial m = filteredList.get(position);

            h.tvTitle      .setText(safe(m.getTitle()));
            h.tvSubject    .setText(safe(m.getSubject()));
            h.tvGrade      .setText(safe(m.getGrade()));
            h.tvDescription.setText(safe(m.getDescription()));
            h.tvPostedDate .setText("Uploaded: " + safe(m.getUploadedDate()));
            h.tvFileType   .setText(safe(m.getFileSize()) + " • "
                    + safe(m.getType()).toUpperCase());

            // Hide the 3-dot menu (students can't edit/delete)
            if (h.btnMenu != null) h.btnMenu.setVisibility(View.GONE);

            // File icon
            boolean isPdf = "pdf".equalsIgnoreCase(m.getType());
            h.ivFileIcon.setImageResource(
                    isPdf ? R.drawable.ic_pdf1 : android.R.drawable.ic_menu_gallery);

            // VIEW button — open URL directly in browser (Chrome renders PDFs natively)
            h.btnView.setOnClickListener(v -> {
                String url = safe(m.getFileUrl());
                if (url.isEmpty()) {
                    Toast.makeText(StudyMaterialActivity.this,
                            "File not available", Toast.LENGTH_SHORT).show();
                    return;
                }
                // Use URL as-is (new PDFs are raw/upload, images are image/upload)
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    Toast.makeText(StudyMaterialActivity.this,
                            "No app found to open this file", Toast.LENGTH_SHORT).show();
                }
            });

            // DOWNLOAD button — save file to device Downloads folder
            h.btnShare.setText("⬇ Download");
            h.btnShare.setOnClickListener(v -> {
                String url = safe(m.getFileUrl());
                if (url.isEmpty()) {
                    Toast.makeText(StudyMaterialActivity.this,
                            "File not available", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    String fileName = safe(m.getTitle()).replaceAll("[^a-zA-Z0-9._-]", "_");
                    boolean isPdfFile = "pdf".equalsIgnoreCase(safe(m.getType()));
                    fileName = fileName + (isPdfFile ? ".pdf" : ".jpg");

                    DownloadManager.Request request =
                            new DownloadManager.Request(Uri.parse(url));
                    request.setTitle(safe(m.getTitle()));
                    request.setDescription("Downloading study material...");
                    request.setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(
                            Environment.DIRECTORY_DOWNLOADS, "KIPS/" + fileName);
                    request.allowScanningByMediaScanner();

                    DownloadManager dm = (DownloadManager)
                            getSystemService(Context.DOWNLOAD_SERVICE);
                    if (dm != null) {
                        dm.enqueue(request);
                        Toast.makeText(StudyMaterialActivity.this,
                                "Downloading... check notifications", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(StudyMaterialActivity.this,
                            "Download failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        @Override
        public int getItemCount() {
            return filteredList != null ? filteredList.size() : 0;
        }

        /** Null-safe string helper */
        private String safe(String s) { return s != null ? s : ""; }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView  tvTitle, tvSubject, tvGrade, tvDescription,
                    tvFileType, tvPostedDate;
            ImageView ivFileIcon, btnMenu;
            android.widget.Button btnView, btnShare;

            ViewHolder(@NonNull View v) {
                super(v);
                tvTitle       = v.findViewById(R.id.tvTitle);
                tvSubject     = v.findViewById(R.id.tvSubject);
                tvGrade       = v.findViewById(R.id.tvGrade);
                tvDescription = v.findViewById(R.id.tvDescription);
                tvFileType    = v.findViewById(R.id.tvFileType);
                tvPostedDate  = v.findViewById(R.id.tvPostedDate);
                ivFileIcon    = v.findViewById(R.id.ivFileIcon);
                btnMenu       = v.findViewById(R.id.btnMenu);
                btnView       = v.findViewById(R.id.btnView);
                btnShare      = v.findViewById(R.id.btnShare);
            }
        }
    }
}