package com.example.kipscoachingkharian.dashboard;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kipscoachingkharian.R;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentEnrollmentDetailActivity extends AppCompatActivity {

    public static final String EXTRA_STUDENT_ID = "student_id";

    private DatabaseReference mDatabase;
    private DatabaseReference studentRef;
    private DatabaseReference requestsRef;
    private ValueEventListener requestsListener;
    private String studentId;

    private TextView tvStudentNameHeader;
    private RecyclerView rvSubjectEnrollments;
    private LinearLayout layoutEmptyState;
    private ImageView ivBack;

    // Pending requests UI
    private RecyclerView rvPendingRequests;
    private TextView tvPendingTitle;

    private SubjectEnrollmentAdapter adapter;
    private EnrollmentRequestAdapter requestAdapter;

    private final List<String> currentSubjects = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_enrollment_detail);

        studentId = getIntent().getStringExtra(EXTRA_STUDENT_ID);
        if (studentId == null) {
            Toast.makeText(this, "Student not found.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        mDatabase   = FirebaseDatabase.getInstance().getReference();
        studentRef  = mDatabase.child("Users").child(studentId);
        requestsRef = mDatabase.child("SubjectRequests").child(studentId);

        tvStudentNameHeader  = findViewById(R.id.tvStudentNameHeader);
        rvSubjectEnrollments = findViewById(R.id.rvSubjectEnrollments);
        layoutEmptyState     = findViewById(R.id.layoutEmptyState);
        ivBack               = findViewById(R.id.ivBack);
        rvPendingRequests    = findViewById(R.id.rvPendingRequests);
        tvPendingTitle       = findViewById(R.id.tvPendingTitle);

        ivBack.setOnClickListener(v -> finish());

        setupRecyclerView();
        setupRequestsRecycler();

        loadStudentAndSubjects();
        loadPendingRequests();
    }

    private void setupRecyclerView() {
        rvSubjectEnrollments.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SubjectEnrollmentAdapter(new ArrayList<>(), (subject, position) ->
                confirmAndRemoveEnrollment(subject.getSubjectName(), position));
        rvSubjectEnrollments.setAdapter(adapter);
    }

    private void setupRequestsRecycler() {
        rvPendingRequests.setLayoutManager(new LinearLayoutManager(this));
        requestAdapter = new EnrollmentRequestAdapter(new EnrollmentRequestAdapter.Listener() {
            @Override
            public void onApprove(EnrollmentRequest r) { approveRequest(r); }

            @Override
            public void onReject(EnrollmentRequest r) { rejectRequest(r); }
        });
        rvPendingRequests.setAdapter(requestAdapter);
    }

    private void loadStudentAndSubjects() {
        studentRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String name = snapshot.child("name").getValue(String.class);
                tvStudentNameHeader.setText(name != null ? name : "Student");

                currentSubjects.clear();
                for (DataSnapshot s : snapshot.child("enrolledSubjects").getChildren()) {
                    String subjectName = s.getValue(String.class);
                    if (subjectName != null) currentSubjects.add(subjectName);
                }

                refreshList();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(StudentEnrollmentDetailActivity.this,
                        "Failed to load student: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ---------- Pending requests ----------

    private void loadPendingRequests() {
        requestsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<EnrollmentRequest> pending = new ArrayList<>();
                for (DataSnapshot s : snapshot.getChildren()) {
                    String status    = s.child("status").getValue(String.class);
                    String subject   = s.child("subject").getValue(String.class);
                    String className = s.child("className").getValue(String.class);
                    if (subject == null) subject = s.getKey(); // key hi subject name hai
                    if (status != null && "pending".equalsIgnoreCase(status)) {
                        pending.add(new EnrollmentRequest(s.getKey(), subject, className));
                    }
                }
                requestAdapter.setData(pending);
                int vis = pending.isEmpty() ? View.GONE : View.VISIBLE;
                tvPendingTitle.setVisibility(vis);
                rvPendingRequests.setVisibility(vis);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(StudentEnrollmentDetailActivity.this,
                        "Failed to load requests: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        };
        requestsRef.addValueEventListener(requestsListener);
    }

    private void approveRequest(EnrollmentRequest r) {
        List<String> updated = new ArrayList<>(currentSubjects);
        if (!updated.contains(r.getSubjectName())) updated.add(r.getSubjectName());

        Map<String, Object> updates = new HashMap<>();
        // 1) subject enroll
        updates.put("Users/" + studentId + "/enrolledSubjects", updated);
        // 2) request status
        updates.put("SubjectRequests/" + studentId + "/" + r.getRequestId() + "/status", "Approved");

        // 3) student ke liye notification record
        //    (student app ka listener aur Cloud Function isi ko use karte hain)
        String notifId = mDatabase.child("Notifications").child(studentId).push().getKey();
        Map<String, Object> notif = new HashMap<>();
        notif.put("title", "Enrollment Approved");
        notif.put("message", "Your request for " + r.getSubjectName()
                + " has been approved. You are now enrolled.");
        notif.put("subject", r.getSubjectName());
        notif.put("studentName", tvStudentNameHeader.getText().toString());
        notif.put("timestamp", System.currentTimeMillis());
        notif.put("read", false);
        updates.put("Notifications/" + studentId + "/" + notifId, notif);

        mDatabase.updateChildren(updates)
                .addOnSuccessListener(unused -> {
                    if (!currentSubjects.contains(r.getSubjectName())) {
                        currentSubjects.add(r.getSubjectName());
                    }
                    refreshList();
                    Toast.makeText(this, "Approved: " + r.getSubjectName(), Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void rejectRequest(EnrollmentRequest r) {
        requestsRef.child(r.getRequestId()).child("status").setValue("Rejected")
                .addOnSuccessListener(unused ->
                        Toast.makeText(this, "Rejected: " + r.getSubjectName(), Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    // ---------- Current subjects ----------

    private void refreshList() {
        List<SubjectEnrollment> result = new ArrayList<>();
        for (String subjectName : currentSubjects) {
            result.add(new SubjectEnrollment(subjectName, subjectName));
        }
        adapter.setData(result);
        toggleEmptyState(result.isEmpty());
    }

    private void confirmAndRemoveEnrollment(String subjectName, int position) {
        List<String> updated = new ArrayList<>(currentSubjects);
        updated.remove(subjectName);

        studentRef.child("enrolledSubjects").setValue(updated)
                .addOnSuccessListener(unused -> {
                    currentSubjects.remove(subjectName);
                    adapter.removeAt(position);
                    toggleEmptyState(adapter.getCurrentCount() == 0);
                    Toast.makeText(this, "Removed from " + subjectName, Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to remove: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void toggleEmptyState(boolean isEmpty) {
        layoutEmptyState.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        rvSubjectEnrollments.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (requestsRef != null && requestsListener != null) {
            requestsRef.removeEventListener(requestsListener);
        }
    }

    // =====================================================================
    //  Neeche ki classes isi file mein nested hain (alag file nahi chahiye)
    // =====================================================================

    /** Ek pending request ka model */
    public static class EnrollmentRequest {
        private final String requestId;   // Firebase key (subject name, e.g. "Biology")
        private final String subjectName;
        private final String className;

        public EnrollmentRequest(String requestId, String subjectName, String className) {
            this.requestId = requestId;
            this.subjectName = subjectName;
            this.className = className;
        }

        public String getRequestId() { return requestId; }
        public String getSubjectName() { return subjectName; }
        public String getClassName() { return className; }
    }

    /** Pending requests ka adapter (item view code se banta hai, XML nahi chahiye) */
    public static class EnrollmentRequestAdapter
            extends RecyclerView.Adapter<EnrollmentRequestAdapter.VH> {

        public interface Listener {
            void onApprove(EnrollmentRequest request);
            void onReject(EnrollmentRequest request);
        }

        private final List<EnrollmentRequest> items = new ArrayList<>();
        private final Listener listener;

        public EnrollmentRequestAdapter(Listener listener) {
            this.listener = listener;
        }

        public void setData(List<EnrollmentRequest> data) {
            items.clear();
            items.addAll(data);
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            Context c = parent.getContext();
            float d = c.getResources().getDisplayMetrics().density;
            int p12 = (int) (12 * d);

            LinearLayout row = new LinearLayout(c);
            row.setLayoutParams(new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(p12, p12, p12, p12);

            LinearLayout texts = new LinearLayout(c);
            texts.setOrientation(LinearLayout.VERTICAL);
            texts.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView tvSubject = new TextView(c);
            tvSubject.setTextSize(16);
            tvSubject.setTextColor(0xFF1E293B);
            tvSubject.setTypeface(tvSubject.getTypeface(), android.graphics.Typeface.BOLD);

            TextView tvClass = new TextView(c);
            tvClass.setTextSize(12);
            tvClass.setTextColor(0xFF64748B);

            texts.addView(tvSubject);
            texts.addView(tvClass);

            Button btnApprove = new Button(c);
            btnApprove.setText("Approve");

            Button btnReject = new Button(c);
            btnReject.setText("Reject");
            LinearLayout.LayoutParams rejectLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rejectLp.setMarginStart((int) (8 * d));
            btnReject.setLayoutParams(rejectLp);

            row.addView(texts);
            row.addView(btnApprove);
            row.addView(btnReject);

            return new VH(row, tvSubject, tvClass, btnApprove, btnReject);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            EnrollmentRequest r = items.get(position);
            h.tvSubject.setText(r.getSubjectName());
            String cls = r.getClassName();
            h.tvClass.setText(cls != null && !cls.isEmpty() ? "Class " + cls : "");
            h.btnApprove.setOnClickListener(v -> listener.onApprove(r));
            h.btnReject.setOnClickListener(v -> listener.onReject(r));
        }

        @Override
        public int getItemCount() { return items.size(); }

        static class VH extends RecyclerView.ViewHolder {
            final TextView tvSubject, tvClass;
            final Button btnApprove, btnReject;

            VH(View root, TextView tvSubject, TextView tvClass, Button btnApprove, Button btnReject) {
                super(root);
                this.tvSubject = tvSubject;
                this.tvClass = tvClass;
                this.btnApprove = btnApprove;
                this.btnReject = btnReject;
            }
        }
    }

    /**
     * STUDENT app mein use hota hai (is admin screen mein nahi).
     * Notifications/{uid} sunta hai aur nayi notification phone mein dikhata hai.
     *
     * Student dashboard activity mein:
     *   onCreate:  nl = new StudentEnrollmentDetailActivity.EnrollmentNotificationListener(this, uid); nl.start();
     *   onDestroy: nl.stop();
     */
    public static class EnrollmentNotificationListener {

        public static final String CHANNEL_ID = "enrollment_updates";

        private final Context context;
        private final DatabaseReference ref;
        private ChildEventListener listener;

        public EnrollmentNotificationListener(Context context, String uid) {
            this.context = context.getApplicationContext();
            this.ref = FirebaseDatabase.getInstance().getReference()
                    .child("Notifications").child(uid);
        }

        public void start() {
            createChannel(context);
            listener = new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String prev) {
                    if (Boolean.TRUE.equals(snapshot.child("read").getValue(Boolean.class))) return;

                    String title = snapshot.child("title").getValue(String.class);
                    String message = snapshot.child("message").getValue(String.class);

                    if (show(snapshot.getKey().hashCode(), title, message)) {
                        snapshot.getRef().child("read").setValue(true);
                    }
                }

                @Override public void onChildChanged(@NonNull DataSnapshot s, @Nullable String p) { }
                @Override public void onChildRemoved(@NonNull DataSnapshot s) { }
                @Override public void onChildMoved(@NonNull DataSnapshot s, @Nullable String p) { }
                @Override public void onCancelled(@NonNull DatabaseError e) { }
            };
            ref.addChildEventListener(listener);
        }

        public void stop() {
            if (listener != null) ref.removeEventListener(listener);
        }

        private boolean show(int id, String title, String message) {
            // Android 13+ par POST_NOTIFICATIONS permission zaroori hai
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                    context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }

            Intent open = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
            PendingIntent pi = PendingIntent.getActivity(context, 0, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle(title != null ? title : "Enrollment update")
                    .setContentText(message)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .setContentIntent(pi);

            NotificationManagerCompat.from(context).notify(id, b.build());
            return true;
        }

        public static void createChannel(Context context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL_ID, "Enrollment updates", NotificationManager.IMPORTANCE_HIGH);
                NotificationManager nm = context.getSystemService(NotificationManager.class);
                if (nm != null) nm.createNotificationChannel(ch);
            }
        }
    }
}