package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kipscoachingkharian.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class StudentSelectionActivity extends AppCompatActivity {

    private EditText etStudentName, etFatherName, etStudentClass;
    private Button btnContinue;

    // Firebase se fetch kiya hua data — PaymentActivity ko pass karna hai
    private String fetchedName    = "";
    private String fetchedEmail   = "";
    private String fetchedFee     = "0";
    private String fetchedClass   = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_selection);

        etStudentName  = findViewById(R.id.et_student_name);
        etFatherName   = findViewById(R.id.et_father_name);
        etStudentClass = findViewById(R.id.et_student_class);
        btnContinue    = findViewById(R.id.btn_select_student);

        // Name aur class Firebase se fetch karke fields mein set karo
        fetchStudentData();

        btnContinue.setOnClickListener(v -> {
            String fatherName = etFatherName.getText().toString().trim();

            if (fatherName.isEmpty()) {
                Toast.makeText(this, "Walid ka naam zaroor bharain", Toast.LENGTH_SHORT).show();
                return;
            }

            btnContinue.setEnabled(false);

            // Father name Firebase mein save karo
            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            FirebaseDatabase.getInstance().getReference("Users")
                    .child(uid).child("fatherName").setValue(fatherName)
                    .addOnCompleteListener(task -> {
                        btnContinue.setEnabled(true);

                        // ✅ PaymentActivity pe bhejo (PayNow page) → Pay Now button → WalletPaymentActivity
                        String feeMonth = new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(new Date());
                        Intent intent = new Intent(StudentSelectionActivity.this, PaymentActivity.class);
                        intent.putExtra("fee_amount",    fetchedFee);
                        intent.putExtra("student_name",  fetchedName);
                        intent.putExtra("student_email", fetchedEmail);
                        intent.putExtra("student_class", fetchedClass);
                        intent.putExtra("fee_month",     feeMonth);
                        // skip_wallet nahi bhej rahe — PayNow press pe WalletPaymentActivity khulega
                        startActivity(intent);
                        finish();
                    });
        });
    }

    private void fetchStudentData() {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;

        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        FirebaseDatabase.getInstance().getReference("Users").child(uid).get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        fetchedName  = snapshot.child("name").getValue(String.class);
                        fetchedEmail = snapshot.child("email").getValue(String.class);
                        fetchedClass = snapshot.child("className").getValue(String.class);
                        Object feeObj = snapshot.child("totalFee").getValue();
                        fetchedFee   = feeObj != null ? feeObj.toString() : "0";

                        if (fetchedName  == null) fetchedName  = "";
                        if (fetchedEmail == null) fetchedEmail = "";
                        if (fetchedClass == null) fetchedClass = "";

                        // ✅ FEE CHECK: Agar student pehle hi fee pay kar chuka hai
                        // toh seedha dashboard pe bhejo, yahan rukne ki zaroorat nahi
                        Boolean feePaid = snapshot.child("feePaid").getValue(Boolean.class);
                        if (Boolean.TRUE.equals(feePaid)) {
                            Intent intent = new Intent(StudentSelectionActivity.this,
                                    StudentDashboardActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            finish();
                            return;
                        }

                        // Fields mein set karo aur read-only banao
                        etStudentName.setText(fetchedName);
                        etStudentName.setFocusable(false);
                        etStudentName.setClickable(false);

                        etStudentClass.setText(fetchedClass);
                        etStudentClass.setFocusable(false);
                        etStudentClass.setClickable(false);
                    }
                });
    }
}