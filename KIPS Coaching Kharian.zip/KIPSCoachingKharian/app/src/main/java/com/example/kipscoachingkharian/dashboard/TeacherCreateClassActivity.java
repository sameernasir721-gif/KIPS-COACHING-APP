package com.example.kipscoachingkharian.dashboard;

import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.kipscoachingkharian.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TeacherCreateClassActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private LinearLayout containerClassHistory;

    private final List<Map<String, String>> classDataList = new ArrayList<>();
    private String searchQuery = "";

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private String teacherUid = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_createclasses);

        mAuth     = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        if (mAuth.getCurrentUser() != null)
            teacherUid = mAuth.getCurrentUser().getUid();

        drawerLayout          = findViewById(R.id.drawerLayout);
        containerClassHistory = findViewById(R.id.containerClassHistory);

        // Back button
        View ivMenu = findViewById(R.id.ivMenu);
        if (ivMenu != null) ivMenu.setOnClickListener(v -> finish());

        // Drawer
        NavigationView navigationView = findViewById(R.id.navigationView);
        if (navigationView != null)
            navigationView.setNavigationItemSelectedListener(item -> {
                drawerLayout.closeDrawer(GravityCompat.START); return true;
            });

        // Create button → opens original form
        Button btnCreateClass = findViewById(R.id.btnCreateClass);
        if (btnCreateClass != null)
            btnCreateClass.setOnClickListener(v ->
                    startActivity(new Intent(this, TeacherCreateClassFormActivity.class)));

        // Search bar
        EditText etSearch = findViewById(R.id.etSearch);
        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
                @Override public void afterTextChanged(Editable s) {
                    searchQuery = s.toString().trim().toLowerCase();
                    renderClassList();
                }
            });
        }

        loadClassHistory();
        setupBottomNav();
    }

    private void loadClassHistory() {
        if (containerClassHistory == null || teacherUid.isEmpty()) return;

        mDatabase.child("Classes").child(teacherUid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        classDataList.clear();

                        for (DataSnapshot snap : snapshot.getChildren()) {
                            Map<String, String> item = new HashMap<>();
                            item.put("title",    snap.child("className").getValue(String.class));
                            item.put("subject",  snap.child("subject").getValue(String.class));
                            item.put("date",     snap.child("date").getValue(String.class));
                            item.put("time",     snap.child("time").getValue(String.class));
                            item.put("meetLink", snap.child("classLink").getValue(String.class));
                            item.put("grade",    snap.child("grade").getValue(String.class));
                            // Load duration (minutes)
                            Object durObj = snap.child("duration").getValue();
                            int dur = 45; // default
                            if (durObj instanceof Long) dur = ((Long) durObj).intValue();
                            else if (durObj instanceof Number) dur = ((Number) durObj).intValue();
                            item.put("duration", String.valueOf(dur));
                            classDataList.add(item);
                        }
                        java.util.Collections.reverse(classDataList);
                        renderClassList();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
    }

    // Filters classDataList by the current search query and rebuilds the cards
    private void renderClassList() {
        containerClassHistory.removeAllViews();

        if (classDataList.isEmpty()) {
            TextView tvEmpty = new TextView(this);
            tvEmpty.setText("No classes yet. Tap '+ Create New Class' to schedule one.");
            tvEmpty.setTextColor(0xFF888888);
            tvEmpty.setTextSize(14f);
            tvEmpty.setGravity(Gravity.CENTER);
            tvEmpty.setPadding(16, 48, 16, 16);
            containerClassHistory.addView(tvEmpty);
            return;
        }

        long nowMs = System.currentTimeMillis();
        boolean anyMatched = false;

        for (Map<String, String> item : classDataList) {
            String title    = item.get("title");
            String subject  = item.get("subject");
            String date     = item.get("date");
            String time     = item.get("time");
            String meetLink = item.get("meetLink");
            String grade    = item.get("grade");
            int duration = 45;
            try { duration = Integer.parseInt(item.get("duration")); } catch (Exception ignored) {}

            if (!searchQuery.isEmpty()) {
                String t = title   != null ? title.toLowerCase()   : "";
                String s = subject != null ? subject.toLowerCase() : "";
                String g = grade   != null ? grade.toLowerCase()   : "";
                if (!t.contains(searchQuery) && !s.contains(searchQuery) && !g.contains(searchQuery))
                    continue;
            }

            anyMatched = true;

            boolean isLive = false;
            try {
                if (date != null && time != null) {
                    String[] dp = date.split("/");
                    String clean = time.replaceAll("[^0-9: ]", "").trim();
                    String[] tp = clean.split("[ :]");
                    int d = Integer.parseInt(dp[0]);
                    int m = Integer.parseInt(dp[1]) - 1;
                    int y = Integer.parseInt(dp[2]);
                    int hr = Integer.parseInt(tp[0]);
                    int mn = tp.length > 1 ? Integer.parseInt(tp[1]) : 0;
                    boolean pm = time.toUpperCase().contains("PM");
                    if (pm && hr != 12) hr += 12;
                    if (!pm && hr == 12) hr = 0;
                    Calendar cal = Calendar.getInstance();
                    cal.set(y, m, d, hr, mn, 0);
                    long classMs = cal.getTimeInMillis();
                    isLive = nowMs >= classMs && nowMs <= classMs + (long) duration * 60 * 1000;
                }
            } catch (Exception ignored) {}

            buildClassCard(title, subject, date, time, meetLink, grade, isLive, duration);
        }

        if (!anyMatched) {
            TextView tvEmpty = new TextView(this);
            tvEmpty.setText("No classes found for \"" + searchQuery + "\"");
            tvEmpty.setTextColor(0xFF888888);
            tvEmpty.setTextSize(14f);
            tvEmpty.setGravity(Gravity.CENTER);
            tvEmpty.setPadding(16, 48, 16, 16);
            containerClassHistory.addView(tvEmpty);
        }
    }

    private void buildClassCard(String title, String subject, String date, String time,
                                String meetLink, String grade, boolean isLive, int duration) {
        androidx.cardview.widget.CardView card = new androidx.cardview.widget.CardView(this);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.setMargins(0, 0, 0, 12);
        card.setLayoutParams(cardLp);
        card.setRadius(12f);
        card.setCardElevation(3f);
        card.setCardBackgroundColor(0xFFFFFFFF);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(32, 24, 32, 24);
        row.setGravity(Gravity.CENTER_VERTICAL);

        FrameLayout strip = new FrameLayout(this);
        LinearLayout.LayoutParams stripLp = new LinearLayout.LayoutParams(6, -1);
        stripLp.setMarginEnd(16);
        strip.setLayoutParams(stripLp);
        strip.setBackgroundColor(isLive ? 0xFF4CAF50 : 0xFFD2192B);
        row.addView(strip);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));

        TextView tvTitle = new TextView(this);
        tvTitle.setText((title != null ? title : "Class") + (grade != null ? " · " + grade : ""));
        tvTitle.setTextSize(15f);
        tvTitle.setTextColor(0xFF1A1A1A);
        tvTitle.setTypeface(null, Typeface.BOLD);
        info.addView(tvTitle);

        TextView tvSub = new TextView(this);
        tvSub.setText((subject != null ? subject : "") + "  |  " +
                (date != null ? date : "") + " " + (time != null ? time : "") +
                "  ·  " + duration + " min");
        tvSub.setTextSize(12f);
        tvSub.setTextColor(0xFF888888);
        info.addView(tvSub);
        row.addView(info);

        LinearLayout rightCol = new LinearLayout(this);
        rightCol.setOrientation(LinearLayout.VERTICAL);
        rightCol.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView tvStatus = new TextView(this);
        tvStatus.setText(isLive ? "🟢 Live" : "Ended");
        tvStatus.setTextSize(11f);
        tvStatus.setTextColor(isLive ? 0xFF2E7D32 : 0xFF888888);
        tvStatus.setTypeface(null, Typeface.BOLD);
        rightCol.addView(tvStatus);

        if (meetLink != null && !meetLink.isEmpty()) {
            Button btnJoin = new Button(this);
            if (isLive) {
                // Class is live — show Join button
                btnJoin.setText("Join");
                btnJoin.setTextColor(0xFFFFFFFF);
                btnJoin.setTextSize(12f);
                btnJoin.setBackgroundTintList(
                        android.content.res.ColorStateList.valueOf(0xFF4CAF50));
                btnJoin.setStateListAnimator(null);
                LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-2, -2);
                btnLp.setMargins(0, 6, 0, 0);
                btnJoin.setLayoutParams(btnLp);
                final String link = meetLink;
                btnJoin.setOnClickListener(v -> {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(this, "Cannot open link", Toast.LENGTH_SHORT).show();
                    }
                });
                rightCol.addView(btnJoin);
            }
            // Class ended — Join button hide, no Re-open
        }

        row.addView(rightCol);
        card.addView(row);
        containerClassHistory.addView(card);
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        if (bottomNav == null) return;
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_bottom_home) {
                startActivity(new Intent(this, TeacherDashboardActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_Announcment) {
                startActivity(new Intent(this, TeacherAnnouncementsActivity.class));
                finish(); return true;
            } else if (id == R.id.nav_bottom_Message) {
                startActivity(new Intent(this, CommunicationActivity.class));
                finish(); return true;
            }
            return false;
        });
    }
}