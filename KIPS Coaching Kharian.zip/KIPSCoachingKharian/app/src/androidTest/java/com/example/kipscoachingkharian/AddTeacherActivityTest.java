package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasErrorText;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.AddTeacherActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;


@RunWith(AndroidJUnit4.class)
public class AddTeacherActivityTest {

    private ActivityScenario<AddTeacherActivity> scenario;

    @Before
    public void setUp() {
        scenario = ActivityScenario.launch(AddTeacherActivity.class);
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
    }


    @Test
    public void screen_elementsAreVisible() {
        onView(withId(R.id.etTeacherName)).check(matches(isDisplayed()));
        onView(withId(R.id.etTeacherPhone)).check(matches(isDisplayed()));
        onView(withId(R.id.etTeacherEmail)).check(matches(isDisplayed()));
        onView(withId(R.id.etTeacherSubject)).check(matches(isDisplayed()));
        onView(withId(R.id.etTeacherPass)).check(matches(isDisplayed()));
        onView(withId(R.id.btnCreateTeacherSubmit)).check(matches(isDisplayed()));
    }


    @Test
    public void emptyName_showsError() {
        onView(withId(R.id.btnCreateTeacherSubmit)).perform(click());
        onView(withId(R.id.etTeacherName)).check(matches(hasErrorText("Name required")));
    }


    @Test
    public void emptyPhone_showsError() {
        onView(withId(R.id.etTeacherName)).perform(typeText("Ali Raza"), closeSoftKeyboard());
        onView(withId(R.id.btnCreateTeacherSubmit)).perform(click());
        onView(withId(R.id.etTeacherPhone)).check(matches(hasErrorText("Phone/Username required")));
    }

    @Test
    public void invalidEmailFormat_showsError() {
        onView(withId(R.id.etTeacherName)).perform(typeText("Ali Raza"), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPhone)).perform(typeText("03001234567"), closeSoftKeyboard());
        onView(withId(R.id.etTeacherEmail)).perform(typeText("notanemail"), closeSoftKeyboard());
        onView(withId(R.id.btnCreateTeacherSubmit)).perform(click());
        onView(withId(R.id.etTeacherEmail)).check(matches(hasErrorText("Valid email is required")));
    }

    @Test
    public void emailWithDisallowedDomain_showsError() {
        onView(withId(R.id.etTeacherName)).perform(typeText("Ali Raza"), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPhone)).perform(typeText("03001234567"), closeSoftKeyboard());
        onView(withId(R.id.etTeacherEmail)).perform(typeText("ali@company.pk"), closeSoftKeyboard());
        onView(withId(R.id.btnCreateTeacherSubmit)).perform(click());
        onView(withId(R.id.etTeacherEmail))
                .check(matches(hasErrorText("Please use a real email provider (Gmail/Yahoo/Outlook)")));
    }

    @Test
    public void shortPassword_showsError() {
        onView(withId(R.id.etTeacherName)).perform(typeText("Ali Raza"), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPhone)).perform(typeText("03001234567"), closeSoftKeyboard());
        onView(withId(R.id.etTeacherEmail)).perform(typeText("ali.raza@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPass)).perform(typeText("123"), closeSoftKeyboard());
        onView(withId(R.id.btnCreateTeacherSubmit)).perform(click());
        onView(withId(R.id.etTeacherPass)).check(matches(hasErrorText("Password must be 6+ chars")));
    }

    @Test
    public void noSubjectsSelected_submitIsBlocked() {
        onView(withId(R.id.etTeacherName)).perform(typeText("Ali Raza"), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPhone)).perform(typeText("03001234567"), closeSoftKeyboard());
        onView(withId(R.id.etTeacherEmail)).perform(typeText("ali.raza@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPass)).perform(typeText("Pass123"), closeSoftKeyboard());
        onView(withId(R.id.btnCreateTeacherSubmit)).perform(click());

        onView(withId(R.id.btnCreateTeacherSubmit)).check(matches(withText("Create Account")));
    }

    @Test
    public void tappingSubjectField_opensMultiSelectDialog() {
        onView(withId(R.id.etTeacherSubject)).perform(click());
        onView(withText("Select Subjects")).check(matches(isDisplayed()));
    }

    @Test
    public void tappingClassField_opensMultiSelectDialog() {
        onView(withId(R.id.etTeacherClass)).perform(click());
        onView(withText("Select Classes")).check(matches(isDisplayed()));
    }

    @Test
    public void selectingSubjects_populatesSubjectField() {
        onView(withId(R.id.etTeacherSubject)).perform(click());
        onView(withText("Mathematics")).perform(click());
        onView(withText("OK")).perform(click());

        onView(withId(R.id.etTeacherSubject)).check(matches(withText("Mathematics")));
    }
}