package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isDialog;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import android.view.View;

import androidx.test.espresso.PerformException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.espresso.util.HumanReadables;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class AiSimilarityCheckTest {

    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";


    private static final int QUIZ_INDEX = 2;


    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);


    public static ViewAction clickButtonInChildAtIndex(final int childIndex, final int buttonId) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(android.view.ViewGroup.class);
            }

            @Override
            public String getDescription() {
                return "Click button in child at index " + childIndex;
            }

            @Override
            public void perform(UiController uiController, View view) {
                android.view.ViewGroup container = (android.view.ViewGroup) view;
                if (container.getChildCount() <= childIndex) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException(
                                    "Index " + childIndex + " nahi mila. Total children: "
                                            + container.getChildCount()))
                            .build();
                }
                View child = container.getChildAt(childIndex);
                View btn = child.findViewById(buttonId);
                if (btn == null) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException(
                                    "Button id " + buttonId + " child mein nahi mila"))
                            .build();
                }
                btn.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(1000);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    @Test
    public void checkSimilarityAndAiCheck_onQuizSubmissions() throws InterruptedException {


        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(25);


        onView(withId(R.id.cardQuizzes)).perform(click());
        Thread.sleep(3000);


        onView(withId(R.id.layoutQuizList))
                .perform(clickButtonInChildAtIndex(QUIZ_INDEX, R.id.btnSubmissions));
        Thread.sleep(2500);


        onView(withId(R.id.btnCheckSimilarity)).perform(click());
        Thread.sleep(1500);

        try {
            onView(withText("OK")).inRoot(isDialog()).perform(click());
        } catch (Exception e) {
            System.out.println("Similarity dialog nahi aaya — short answers nahi the.");
        }
        Thread.sleep(1000);


        onView(withId(R.id.btnAiCheck)).perform(click());
        Thread.sleep(1000);

        boolean gotResult = false;
        for (int i = 0; i < 40; i++) {
            try {
                onView(withText("🤖 AI Originality Report")).inRoot(isDialog())
                        .check(matches(isDisplayed()));
                gotResult = true;
                break;
            } catch (Exception e) {
                Thread.sleep(1000);
            }
        }

        if (gotResult) {
            System.out.println("✅ AI Originality Report dialog mil gaya.");
            onView(withText("OK")).inRoot(isDialog()).perform(click());
        } else {
            System.out.println("⚠️ AI Report 40s mein nahi mila.");
        }
    }
}