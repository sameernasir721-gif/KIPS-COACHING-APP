package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertTrue;

import android.widget.ImageView;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.dashboard.AdminFeeActivity;
import com.example.kipscoachingkharian.dashboard.FeeChallanActivity;
import com.example.kipscoachingkharian.dashboard.FeemanagementActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class AdminFeeActivityTest {

    private ActivityScenario<AdminFeeActivity> scenario;

    @Before
    public void setUp() {
        Intents.init();
        scenario = ActivityScenario.launch(AdminFeeActivity.class);
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
        Intents.release();
    }

    @Test
    public void screen_showsToolbarAndSectionLabel() {
        onView(withText("Fee Management")).check(matches(isDisplayed()));
        onView(withText("Select an option")).check(matches(isDisplayed()));
    }

    @Test
    public void bothCards_areDisplayed() {
        onView(withText("💰  Fee Management")).check(matches(isDisplayed()));
        onView(withText("View all students with their fee amount,\npaid/pending status and history."))
                .check(matches(isDisplayed()));

        onView(withText("🧾  Fee Challan")).check(matches(isDisplayed()));
        onView(withText("Generate subject-wise fee challan for\neach student based on enrollment."))
                .check(matches(isDisplayed()));
    }

    @Test
    public void feeManagementCard_opensFeemanagementActivity() {
        onView(withText("💰  Fee Management")).perform(click());
        intended(hasComponent(FeemanagementActivity.class.getName()));
    }

    @Test
    public void feeChallanCard_opensFeeChallanActivity() {
        onView(withText("🧾  Fee Challan")).perform(click());
        intended(hasComponent(FeeChallanActivity.class.getName()));
    }

    @Test
    public void backIcon_finishesActivity() {
        onView(withClassName(equalTo(ImageView.class.getName()))).perform(click());

        assertTrue("Activity should be in DESTROYED state after tapping the back icon",
                scenario.getState() == Lifecycle.State.DESTROYED);
    }
}