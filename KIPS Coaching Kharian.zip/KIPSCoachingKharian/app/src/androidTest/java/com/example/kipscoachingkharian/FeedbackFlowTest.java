package com.example.kipscoachingkharian;

import android.view.View;
import android.widget.RatingBar;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

@RunWith(AndroidJUnit4.class)
public class FeedbackFlowTest {


    private static final String TEST_EMAIL =
            "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID =
            "student048";
    private static final String TEST_PASSWORD =
            "haleemay67?";
    private static final String FEEDBACK_TEXT =
            "Automated test feedback - please ignore "
                    + System.currentTimeMillis();

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void feedbackTabs_switchBetweenSubmitAndAll()
            throws InterruptedException {

        login();

        openFeedbackScreen();

        onView(withId(R.id.layoutSubmitFeedback))
                .check(matches(isDisplayed()));


        onView(withId(R.id.tabAll))
                .perform(scrollTo(), click());

        Thread.sleep(500);

        onView(withId(R.id.layoutAllFeedback))
                .check(matches(isDisplayed()));

        onView(withId(R.id.rvFeedbacks))
                .check(matches(isDisplayed()));

        onView(withId(R.id.tvOverallRatingDigit))
                .check(matches(isDisplayed()));


        onView(withId(R.id.tabSubmit))
                .perform(scrollTo(), click());

        Thread.sleep(500);

        onView(withId(R.id.layoutSubmitFeedback))
                .check(matches(isDisplayed()));
    }

    @Test
    public void submitFeedback_showsSuccessToastAndSwitchesToAllTab()
            throws InterruptedException {

        login();
        openFeedbackScreen();

        onView(withId(R.id.layoutSubmitFeedback))
                .check(matches(isDisplayed()));


        onView(withId(R.id.ratingBarFeedback))
                .perform(
                        scrollTo(),
                        setRating(5f)
                );


        onView(withId(R.id.editName))
                .perform(
                        scrollTo(),
                        clearText(),
                        typeText("Test Student"),
                        closeSoftKeyboard()
                );

        onView(withId(R.id.editFeedback))
                .perform(
                        scrollTo(),
                        replaceText(FEEDBACK_TEXT),
                        closeSoftKeyboard()
                );

        onView(withId(R.id.btnSubmit))
                .perform(
                        scrollTo(),
                        click()
                );

        Thread.sleep(2000);

        onView(withId(R.id.layoutAllFeedback))
                .check(matches(isDisplayed()));

        onView(withId(R.id.rvFeedbacks))
                .check(matches(isDisplayed()));
    }

    private void login() throws InterruptedException {

        onView(withId(R.id.etStudentUsername))
                .perform(
                        typeText(TEST_EMAIL),
                        closeSoftKeyboard()
                );

        onView(withId(R.id.etStudentPassword))
                .perform(
                        typeText(TEST_PASSWORD),
                        closeSoftKeyboard()
                );

        if (isViewDisplayed(R.id.btnEmailVerified)) {

            onView(withId(R.id.btnEmailVerified))
                    .perform(click());

            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(
                        typeText(TEST_STUDENT_ID),
                        closeSoftKeyboard()
                );

        onView(withId(R.id.btnStudentLogin))
                .perform(click());

        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));
    }

    private void openFeedbackScreen()
            throws InterruptedException {


        onView(withId(R.id.nav_bottom_feedback))
                .perform(forceClick());

        Thread.sleep(2500);
    }


    private static ViewAction forceClick() {

        return new ViewAction() {

            @Override
            public Matcher<View> getConstraints() {

                return isAssignableFrom(View.class);
            }


            @Override
            public String getDescription() {

                return "Force click on a view, bypassing visibility constraints.";
            }


            @Override
            public void perform(
                    UiController uiController,
                    View view) {

                view.performClick();

                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    private boolean isViewDisplayed(int viewId) {

        try {

            onView(withId(viewId))
                    .check(matches(isDisplayed()));

            return true;

        } catch (NoMatchingViewException | AssertionError e) {

            return false;
        }
    }

    private static ViewAction setRating(final float rating) {

        return new ViewAction() {

            @Override
            public Matcher<View> getConstraints() {

                return isAssignableFrom(
                        RatingBar.class
                );
            }


            @Override
            public String getDescription() {

                return "Set the rating of a RatingBar.";
            }


            @Override
            public void perform(
                    UiController uiController,
                    View view) {

                ((RatingBar) view).setRating(rating);

                uiController.loopMainThreadUntilIdle();
            }
        };
    }
}