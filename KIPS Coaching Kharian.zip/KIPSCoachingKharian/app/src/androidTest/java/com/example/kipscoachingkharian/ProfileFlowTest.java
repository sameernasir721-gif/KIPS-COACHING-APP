package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isEnabled;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.not;


@RunWith(AndroidJUnit4.class)
public class ProfileFlowTest {

    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void profileMenu_headerAndMenuItemsLoad() throws InterruptedException {
        login();
        openProfileMenu();

        onView(withId(R.id.tv_name)).check(matches(isDisplayed()));
        onView(withId(R.id.tv_role)).check(matches(isDisplayed()));

        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
        onView(withId(R.id.item_notifications)).check(matches(isDisplayed()));
        onView(withId(R.id.item_settings)).check(matches(isDisplayed()));
        onView(withId(R.id.item_help)).check(matches(isDisplayed()));
        onView(withId(R.id.item_logout)).check(matches(isDisplayed()));
    }

    @Test
    public void myProfileInfo_showsDataAndEditToggleWorks() throws InterruptedException {
        login();
        openProfileMenu();

        onView(withId(R.id.item_my_profile)).perform(click());
        Thread.sleep(2500);

        onView(withId(R.id.etName)).check(matches(isDisplayed()));
        onView(withId(R.id.etEmail))
                .check(matches(isDisplayed()))
                .check(matches(withText(TEST_EMAIL)));
        onView(withId(R.id.etPhone)).check(matches(isDisplayed()));
        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .check(matches(not(isEnabled())));
        onView(withId(R.id.etName)).check(matches(not(isEnabled())));
        onView(withId(R.id.etPhone)).check(matches(not(isEnabled())));

        onView(withId(R.id.tvEditProfile))
                .check(matches(withText("Edit")))
                .perform(click());

        onView(withId(R.id.etPhone)).check(matches(isEnabled()));
        onView(withId(R.id.btnUpdateProfile)).check(matches(isDisplayed()));
        onView(withId(R.id.ivChangePasswordArrow)).check(matches(isDisplayed()));
        onView(withId(R.id.tvEditProfile)).check(matches(withText("Cancel")));

        onView(withId(R.id.tvEditProfile)).perform(click());

        onView(withId(R.id.etPhone)).check(matches(not(isEnabled())));
        onView(withId(R.id.tvEditProfile)).check(matches(withText("Edit")));

        onView(withId(R.id.btnBack)).perform(click());
        Thread.sleep(500);
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
    }

    @Test
    public void notifications_opensAnnouncementsScreen() throws InterruptedException {
        login();
        openProfileMenu();

        onView(withId(R.id.item_notifications)).perform(click());
        Thread.sleep(2500);

        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));
        onView(withId(R.id.etSearch)).check(matches(isDisplayed()));
    }

    @Test
    public void settings_opensAndShowsOptionsAndBackWorks() throws InterruptedException {
        login();
        openProfileMenu();

        onView(withId(R.id.item_settings)).perform(click());
        Thread.sleep(1500);

        onView(withId(R.id.itemFontSize)).check(matches(isDisplayed()));
        onView(withId(R.id.itemTheme)).check(matches(isDisplayed()));
        onView(withId(R.id.itemPrivacy)).check(matches(isDisplayed()));

        onView(withId(R.id.btnBack)).perform(click());
        Thread.sleep(500);
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
    }

    @Test
    public void help_opensAndShowsFaqAndBackWorks() throws InterruptedException {
        login();
        openProfileMenu();

        onView(withId(R.id.item_help)).perform(click());
        Thread.sleep(1500);

        onView(withId(R.id.layoutFaqContainer)).check(matches(isDisplayed()));

        onView(withId(R.id.btnBack)).perform(click());
        Thread.sleep(500);
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
    }

    @Test
    public void logout_cancelKeepsUserOnProfileScreen() throws InterruptedException {
        login();
        openProfileMenu();

        onView(withId(R.id.item_logout)).perform(click());
        Thread.sleep(500);

        onView(withText("Logout")).check(matches(isDisplayed()));
        onView(withText("Do you want to logout?")).check(matches(isDisplayed()));

        onView(withText("Cancel")).perform(click());
        Thread.sleep(500);

        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
    }

    @Test
    public void logout_confirmSignsOutAndGoesToLoginScreen() throws InterruptedException {
        login();
        openProfileMenu();

        onView(withId(R.id.item_logout)).perform(click());
        Thread.sleep(500);

        onView(withText("Yes, Logout")).perform(click());
        Thread.sleep(2000);

        onView(withId(R.id.etStudentUsername)).check(matches(isDisplayed()));
        onView(withId(R.id.btnStudentLogin)).check(matches(isDisplayed()));
    }

    private void login() throws InterruptedException {
        onView(withId(R.id.etStudentUsername))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));
    }

    private void openProfileMenu() throws InterruptedException {

        onView(withId(R.id.nav_bottom_profile)).perform(forceClick());

        Thread.sleep(2500);
    }

    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }

    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isEnabled();
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing the 90%-visible constraint.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }
}