package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import android.view.ViewGroup;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.ViewAssertion;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.ManageStudentActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class ManageStudentActivityTest {

    private ActivityScenario<ManageStudentActivity> scenario;

    @Before
    public void setUp() {
        scenario = ActivityScenario.launch(ManageStudentActivity.class);
        try { Thread.sleep(3000); } catch (InterruptedException ignored) {}
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
    }

    private static final ViewAssertion hasAtLeastOneChild = (view, noViewFoundException) -> {
        if (noViewFoundException != null) throw noViewFoundException;
        assertTrue("Container view not found", view instanceof ViewGroup);
        ViewGroup group = (ViewGroup) view;
        assertTrue("Container is EMPTY after data load — no rows and no empty-state text",
                group.getChildCount() >= 1);
    };

    @Test
    public void screen_elementsAreVisible() {
        onView(withId(R.id.containerStudentRequests)).check(matches(isDisplayed()));
    }

    @Test
    public void afterLoad_containerShowsRowsOrEmptyState() {
        onView(withId(R.id.containerStudentRequests)).check(hasAtLeastOneChild);
    }
}