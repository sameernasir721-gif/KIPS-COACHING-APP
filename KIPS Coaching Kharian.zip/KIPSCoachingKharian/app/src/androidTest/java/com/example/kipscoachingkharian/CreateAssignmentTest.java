package com.example.kipscoachingkharian;

import android.widget.DatePicker;

import androidx.test.espresso.contrib.PickerActions;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isPlatformPopup;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.equalTo;


@RunWith(AndroidJUnit4.class)
public class CreateAssignmentTest {

    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    private static final String SUBJECT = "Mathematics";
    private static final String GRADE   = "10A";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    @Test
    public void createAssignment_shareWithClass_verifyInList() throws InterruptedException {

        String uniqueTitle = "Test Assignment "
                + new SimpleDateFormat("dd-MMM HH:mm:ss", Locale.getDefault())
                .format(Calendar.getInstance().getTime());

        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        onView(withId(R.id.btnTeacherLogin)).perform(click());

        Thread.sleep(10000);

        onView(withId(R.id.tvTeacherName))
                .check(matches(isDisplayed()));

        onView(withId(R.id.cardAssignments)).perform(click());
        Thread.sleep(3000);

        onView(withId(R.id.rvAssignments))
                .check(matches(isDisplayed()));

        onView(withId(R.id.btnCreateNew)).perform(click());
        Thread.sleep(2000);

        onView(withId(R.id.etTitle))
                .perform(typeText(uniqueTitle), closeSoftKeyboard());


        onView(withId(R.id.spinnerSubject)).perform(click());
        onView(withText(SUBJECT)).inRoot(isPlatformPopup()).perform(click());


        onView(withId(R.id.spinnerGrade)).perform(click());
        onView(withText(GRADE)).inRoot(isPlatformPopup()).perform(click());


        onView(withId(R.id.etMarks))
                .perform(typeText("50"), closeSoftKeyboard());


        onView(withId(R.id.tvDueDate)).perform(click());
        Thread.sleep(500);
        Calendar dueCal = Calendar.getInstance();
        dueCal.add(Calendar.DAY_OF_MONTH, 7);
        onView(withClassName(equalTo(DatePicker.class.getName()))).perform(
                PickerActions.setDate(
                        dueCal.get(Calendar.YEAR),
                        dueCal.get(Calendar.MONTH) + 1,
                        dueCal.get(Calendar.DAY_OF_MONTH)));
        onView(withId(android.R.id.button1)).perform(click());


        onView(withId(R.id.tvDueTime)).perform(click());
        Thread.sleep(500);
        onView(withId(android.R.id.button1)).perform(click());


        onView(withId(R.id.etDescription))
                .perform(typeText("Yeh ek automated Espresso test se banaya gaya assignment hai."),
                        closeSoftKeyboard());

        onView(withId(R.id.btnCreateAssignment)).perform(click());


        Thread.sleep(6000);


        onView(withId(R.id.rvAssignments))
                .check(matches(isDisplayed()));
    }
}