package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.doesNotExist;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertEquals;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.dashboard.ParentSettingActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ParentSettingActivityTest {

    private ActivityScenario<ParentSettingActivity> scenario;
    private static final String PREFS_NAME = "kips_prefs";

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    @Before
    public void resetPrefs() {

        Context ctx = ApplicationProvider.getApplicationContext();
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove("parent_font_size").remove("parent_theme").apply();
    }

    private void launch() {
        Context ctx = ApplicationProvider.getApplicationContext();
        Intent intent = new Intent(ctx, ParentSettingActivity.class);
        scenario = ActivityScenario.launch(intent);
        sleep(1000);
    }

    @After
    public void tearDown() {
        if (scenario != null) {
            scenario.close();
        }
    }


    @Test
    public void backButton_click_finishesActivity() {
        launch();

        onView(withId(R.id.btnBack)).perform(click());
        sleep(1000);

        assertEquals(Lifecycle.State.DESTROYED, scenario.getState());
    }


    @Test
    public void defaultSettings_showMediumFontAndWhiteTheme() {
        launch();

        onView(withId(R.id.tvFontSizeValue)).check(matches(withText("Medium")));
        onView(withId(R.id.tvThemeValue)).check(matches(withText("White")));
    }

    @Test
    public void fontSizeClick_opensDialog() {
        launch();

        onView(withId(R.id.itemFontSize)).perform(click());
        sleep(1000);

        onView(withText("Font Size")).check(matches(isDisplayed()));
        onView(withText("Apply")).check(matches(isDisplayed()));
    }

    @Test
    public void fontSizeDialog_selectSmall_updatesValueAndPrefs() {
        launch();

        onView(withId(R.id.itemFontSize)).perform(click());
        sleep(1000);
        onView(withText("Small")).perform(click());
        sleep(500);
        onView(withText("Apply")).perform(click());
        sleep(2000);

        Context ctx = ApplicationProvider.getApplicationContext();
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        assertEquals(0, prefs.getInt("parent_font_size", 1));
    }


    @Test
    public void fontSizeDialog_cancel_doesNotChangeValue() {
        launch();

        onView(withId(R.id.itemFontSize)).perform(click());
        sleep(1000);
        onView(withText("Large")).perform(click());
        sleep(500);
        onView(withText("Cancel")).perform(click());
        sleep(1000);

        onView(withId(R.id.tvFontSizeValue)).check(matches(withText("Medium"))); // unchanged
    }


    @Test
    public void themeClick_opensDialog() {
        launch();

        onView(withId(R.id.itemTheme)).perform(click());
        sleep(1000);

        onView(withText("Theme")).check(matches(isDisplayed()));
    }


    @Test
    public void themeDialog_selectBlack_updatesValue() {
        launch();

        onView(withId(R.id.itemTheme)).perform(click());
        sleep(1000);
        onView(withText("Black")).perform(click());
        sleep(500);
        onView(withText("Apply")).perform(click());
        sleep(1000);

        onView(withId(R.id.tvThemeValue)).check(matches(withText("Black")));
    }


    @Test
    public void privacyClick_opensDialog_withCorrectTitle() {
        launch();

        onView(withId(R.id.itemPrivacy)).perform(click());
        sleep(1000);

        onView(withText("Privacy Policy")).check(matches(isDisplayed()));
        onView(withText("OK")).check(matches(isDisplayed()));
    }


    @Test
    public void privacyDialog_ok_dismissesDialog() {
        launch();

        onView(withId(R.id.itemPrivacy)).perform(click());
        sleep(1000);
        onView(withText("OK")).perform(click());
        sleep(500);

        onView(withText("OK")).check(doesNotExist());
    }
}