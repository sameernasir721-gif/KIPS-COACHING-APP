package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import android.view.View;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;
import androidx.test.uiautomator.Until;

import com.example.kipscoachingkharian.auth.ParentLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Parent Module — FULL INTEGRATION TEST.
 *
 * TeacherModuleIntegrationTest / StudentModuleIntegrationTest jaisa hi —
 * yeh saari individual flow-tests (ParentLoginFlowTest, ChildAccountTest,
 * FeePaymentTest, CommunicationTest, FeedbackTest, AnnouncementsTest,
 * ProfileTest waghera) ko "unit" ki tarah alag-alag test karti hain.
 * YEH test un sab se alag hai — yeh EK HI continuous session mein Login
 * se Logout tak, ek-ke-baad-ek saari Dashboard screens explore karta hai,
 * taake yeh confirm ho:
 *   (a) Dashboard se launch hone wali har Activity apni jagah par sahi
 *       khulti/kaam karti hai,
 *   (b) har screen se "back" dabane par parent wapas sahi tarah Dashboard
 *       par pahunchta hai (activity back-stack toot-ta nahi),
 *   (c) poore session mein kahin bhi crash nahi hota,
 *   (d) session ke bilkul end mein Logout karke Login screen par wapas
 *       aana kaam karta hai.
 *
 * Is test ka scope: "screen khulti hai aur crash nahi hoti" (smoke-level)
 * — har screen ke deep/edge-case validations (jaise fee challan download,
 * feedback rating submit karna) un-ki apni dedicated flow-test files mein
 * cover ki jayein; unhein yahan dobara nahi dohraya gaya taake yeh
 * integration test focused aur maintainable rahe.
 *
 * IMPORTANT — Parent login 2 step ka hai:
 *   1) Pehli dafa Email + Password dalne par sirf "I've Verified" button
 *      dikhta hai (kyunke ParentLoginActivity SharedPreferences
 *      "parent_email_verified_done" check karta hai).
 *   2) Ek dafa verify ho jaye to Student ID field + Login button reveal
 *      hote hain, aur agli baar seedha wahi dikhta hai.
 * Yeh test dono states handle karta hai — agar btnEmailVerified visible
 * hai to pehle usay click karta hai, phir Student ID daal kar login karta hai.
 *
 * IMPORTANT — is test ke end mein PARENT LOGOUT ho jata hai. Agar isi
 * test-suite (class) mein koi aur test bhi run ho raha ho jo login state
 * par depend karta ho, to yeh test aakhir mein rakhein ya alag se chalayen.
 *
 * IMPORTANT: Neeche apni asal test-parent ki details daalein. Test account
 * ka email already Firebase mein verified hona chahiye, warna
 * "I've Verified" step fail ho jayega.
 */
@RunWith(AndroidJUnit4.class)
public class ParentModuleIntegrationTest {

    // ── Yahan apni test-parent ki details daalein ──────────────────────────
    private static final String TEST_EMAIL      = "ama319709@gmail.com";
    private static final String TEST_PASSWORD   = "Student048#";
    private static final String TEST_STUDENT_ID = "student048";

    @Rule
    public ActivityScenarioRule<ParentLoginActivity> activityRule =
            new ActivityScenarioRule<>(ParentLoginActivity.class);

    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility check.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    // "Allow notifications?" wala Android system popup GrantPermissionRule
    // se force-grant nahi ho pa raha (kuch emulators is action ko block
    // karte hain — SecurityException). Is liye is popup ko khud UiAutomator
    // se "Allow" click karke hata dete hain, agar wo screen par aaye to.
    // Agar popup na aaye (permission pehle se granted hai) to yeh method
    // chup chaap kuch nahi karta.
    private void dismissNotificationPermissionPopupIfPresent() {
        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        UiObject2 allowButton = device.wait(
                Until.findObject(By.textContains("Allow")), 3000);
        if (allowButton == null) {
            allowButton = device.wait(Until.findObject(
                    By.res("com.android.permissioncontroller:id/permission_allow_button")), 1000);
        }
        if (allowButton != null) {
            allowButton.click();
        }
    }

    private boolean isDisplayedSafely(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (Throwable e) {
            // NoMatchingViewException (Exception) → view exists hi nahi abhi.
            // AssertionError / AssertionFailedWithCauseError (Error) → view
            // exists karta hai magar GONE/INVISIBLE hai (jaisa yahan
            // btnEmailVerified ke saath ho raha tha kyunke test-parent ka
            // email pehle hi verified tha). Dono cases mein matlab same hai:
            // "ye button abhi visible nahi" → false.
            return false;
        }
    }

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.cardChildAccount)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(500);
            }
        }
        onView(withId(R.id.cardChildAccount)).check(matches(isDisplayed()));
    }

    // Dashboard ke root card check karta hai — cardChildAccount hamesha
    // Dashboard par hi hota hai, is liye "hum wapas Dashboard par hain"
    // confirm karne ke liye yeh use karte hain.
    private void waitUntilBackOnDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.cardChildAccount)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(400);
            }
        }
        onView(withId(R.id.cardChildAccount)).check(matches(isDisplayed()));
    }

    // ChildDetailInfoActivity ke root check karta hai — wapas is screen par
    // aane ki confirmation ke liye (Report/Quiz/Assignment cards se back
    // aane ke baad).
    private void waitUntilBackOnChildDetail(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.cardReports)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(400);
            }
        }
        onView(withId(R.id.cardReports)).check(matches(isDisplayed()));
    }

    private void navigateCardAndBack(int cardId, int destinationVerifyId, int waitMs)
            throws InterruptedException {
        onView(withId(cardId)).perform(scrollTo(), click());
        Thread.sleep(waitMs);
        onView(withId(destinationVerifyId)).check(matches(isDisplayed()));
        Espresso.pressBack();
        waitUntilBackOnDashboard(6);
    }

    @Test
    public void fullParentJourney_loginThroughAllFeaturesAndLogout() throws InterruptedException {

        // ═══════════════════════════════════════════════════════════════════
        // STEP 1 — LOGIN (email verification ka 2-step flow handle karta hai)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.etLoginEmail))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etLoginPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        // Pehli dafa sirf "I've Verified" button dikhta hai — agar dikh
        // raha hai to pehle usay click karo taake Student ID + Login
        // fields reveal ho jayein.
        if (isDisplayedSafely(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(2500);
        }

        onView(withId(R.id.etLoginStudentId))
                .perform(scrollTo(), typeText(TEST_STUDENT_ID), closeSoftKeyboard());
        onView(withId(R.id.btnParentLogin)).perform(scrollTo(), click());

        // Dashboard khulte hi Android ka notification permission popup aa
        // sakta hai — usay yahan hata dete hain taake window focus na chhute.
        dismissNotificationPermissionPopupIfPresent();

        waitForDashboard(20);

        // ═══════════════════════════════════════════════════════════════════
        // STEP 2 — CHILD ACCOUNT CARD (aur uske andar Reports/Quiz/Assignment)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.cardChildAccount)).perform(scrollTo(), click());
        Thread.sleep(1500);
        onView(withId(R.id.tvStudentName)).check(matches(isDisplayed()));

        // -- Progress Report --
        onView(withId(R.id.cardReports)).perform(scrollTo(), click());
        Thread.sleep(1500);
        onView(withId(R.id.layoutProgressSection)).check(matches(isDisplayed()));
        Espresso.pressBack();
        waitUntilBackOnChildDetail(6);

        // -- Quiz Report --
        onView(withId(R.id.cardQuizzes)).perform(scrollTo(), click());
        Thread.sleep(1500);
        onView(withId(R.id.layoutQuizCards)).check(matches(isDisplayed()));
        Espresso.pressBack();
        waitUntilBackOnChildDetail(6);

        // -- Assignment Report --
        onView(withId(R.id.cardAssignments)).perform(scrollTo(), click());
        Thread.sleep(1500);
        onView(withId(R.id.rvAssignments)).check(matches(isDisplayed()));
        Espresso.pressBack();
        waitUntilBackOnChildDetail(6);

        // Ab ChildDetailInfoActivity se wapas Dashboard par
        Espresso.pressBack();
        waitUntilBackOnDashboard(6);

        // ═══════════════════════════════════════════════════════════════════
        // STEP 3 — DASHBOARD KE BAAQI CARDS
        // ═══════════════════════════════════════════════════════════════════
        navigateCardAndBack(R.id.cardCommunication, R.id.rvConversations, 1500);
        navigateCardAndBack(R.id.cardFeePayment, R.id.feeContainer, 1500);
        navigateCardAndBack(R.id.cardFeedback, R.id.layoutSubmitFeedback, 1500);

        // ═══════════════════════════════════════════════════════════════════
        // STEP 4 — PROFILE (aur uske andar My Profile / Notifications /
        // Settings / Help)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.parentprofile)).perform(forceClick());
        Thread.sleep(1200);
        onView(withId(R.id.tv_name)).check(matches(isDisplayed()));

        // -- My Profile --
        onView(withId(R.id.item_my_profile)).perform(scrollTo(), click());
        Thread.sleep(1200);
        onView(withId(R.id.etName)).check(matches(isDisplayed()));
        Espresso.pressBack();
        Thread.sleep(800);
        onView(withId(R.id.tv_name)).check(matches(isDisplayed()));

        // -- Notifications / Announcements --
        onView(withId(R.id.item_notifications)).perform(scrollTo(), click());
        Thread.sleep(1500);
        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));
        Espresso.pressBack();
        Thread.sleep(800);
        onView(withId(R.id.tv_name)).check(matches(isDisplayed()));

        // -- Settings --
        onView(withId(R.id.item_settings)).perform(scrollTo(), click());
        Thread.sleep(1000);
        onView(withId(R.id.itemFontSize)).check(matches(isDisplayed()));
        Espresso.pressBack();
        Thread.sleep(800);
        onView(withId(R.id.tv_name)).check(matches(isDisplayed()));

        // -- Help --
        onView(withId(R.id.item_help)).perform(scrollTo(), click());
        Thread.sleep(1000);
        onView(withId(R.id.layoutFaqContainer)).check(matches(isDisplayed()));
        Espresso.pressBack();
        Thread.sleep(800);
        onView(withId(R.id.tv_name)).check(matches(isDisplayed()));

        // ═══════════════════════════════════════════════════════════════════
        // STEP 5 — LOGOUT (session ka aakhri qadam)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.item_logout)).perform(scrollTo(), click());
        Thread.sleep(700);

        onView(withText("Are you sure you want to log out?")).check(matches(isDisplayed()));
        onView(withText("Yes, Logout")).perform(click());
        Thread.sleep(2000);

        // Logout ke baad ParentLoginActivity seedha dubara khulti hai —
        // email field wapas dikhna chahiye — poora session successfully complete
        onView(withId(R.id.etLoginEmail)).check(matches(isDisplayed()));
        System.out.println("✅ Poora Parent Module integration test pass ho gaya!");
    }
}