// LOCATION: app/src/androidTest/java/com/example/kipscoachingkharian/dashboard/SystemReportsActivityTest.java
package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.equalTo;

import android.widget.ImageView;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertTrue;

import com.example.kipscoachingkharian.dashboard.SystemReportsActivity;

/**
 * SystemReportsActivity poori tarah READ-ONLY hai — 6 Firebase paths
 * (Users, Quizzes, QuizAttempts, Assignments, Submissions, DailyLogins) se
 * data parh kar sirf charts/metrics dikhati hai. Koi write/update/delete
 * operation nahi hai, isliye is class me koi bhi test SAFE hai — real data
 * ko kabhi mutate nahi karta.
 *
 * Poori UI Java code se bani hai (koi XML layout ya static IDs nahi), isliye
 * checks yahan withText(...) se ho rahe hain. Content lamba hai (ScrollView
 * ke andar), isliye neeche wale sections ke liye scrollTo() use kiya hai.
 */
@RunWith(AndroidJUnit4.class)
public class SystemReportsActivityTest {

    private ActivityScenario<SystemReportsActivity> scenario;

    @Before
    public void setUp() {
        scenario = ActivityScenario.launch(SystemReportsActivity.class);
        // 6 parallel Firebase single-value listeners load hone ka wait
        try { Thread.sleep(6000); } catch (InterruptedException ignored) {}
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
    }

    // 1) Toolbar title dikhna chahiye
    @Test
    public void screen_showsToolbarTitle() {
        onView(withText("System Reports")).check(matches(isDisplayed()));
    }

    // 2) Data load hone ke baad saare section headers dikhne chahiye
    @Test
    public void afterLoad_allSectionHeadersAreDisplayed() {
        onView(withText("Students Overview")).check(matches(isDisplayed()));

        onView(withText("Parents Overview")).perform(scrollTo()).check(matches(isDisplayed()));
        onView(withText("Teachers Overview")).perform(scrollTo()).check(matches(isDisplayed()));
        onView(withText("Daily Active Users (Last 7 Days)")).perform(scrollTo()).check(matches(isDisplayed()));
        onView(withText("Quizzes Overview")).perform(scrollTo()).check(matches(isDisplayed()));
        onView(withText("Assignments Overview")).perform(scrollTo()).check(matches(isDisplayed()));
    }

    // 3) Students Overview ke metric labels dikhne chahiye
    @Test
    public void studentsOverview_showsMetricLabels() {
        onView(withText("Total")).check(matches(isDisplayed()));
        onView(withText("Approved")).check(matches(isDisplayed()));
        onView(withText("Pending")).check(matches(isDisplayed()));
        onView(withText("Rejected")).check(matches(isDisplayed()));
    }

    // 4) Total Teachers wide card dikhna chahiye
    @Test
    public void teachersOverview_showsTotalTeachersCard() {
        onView(withText("Total Teachers")).perform(scrollTo()).check(matches(isDisplayed()));
    }

    // 5) Quizzes aur Assignments metric labels dikhne chahiye
    @Test
    public void quizzesAndAssignments_showMetricLabels() {
        onView(withText("Total Quizzes")).perform(scrollTo()).check(matches(isDisplayed()));
        onView(withText("Attempted")).perform(scrollTo()).check(matches(isDisplayed()));
        onView(withText("Total Assignments")).perform(scrollTo()).check(matches(isDisplayed()));
        onView(withText("Submissions")).perform(scrollTo()).check(matches(isDisplayed()));
    }

    // 6) Back icon par tap karne se activity band ho jani chahiye
    @Test
    public void backIcon_finishesActivity() {
        onView(withClassName(equalTo(ImageView.class.getName()))).perform(click());
        assertTrue("Back icon dabane ke baad activity DESTROYED state me honi chahiye",
                scenario.getState() == Lifecycle.State.DESTROYED);
    }
}
