package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.espresso.PerformException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.espresso.util.HumanReadables;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withHint;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

@RunWith(AndroidJUnit4.class)
public class GradeSubmissionTest {


    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";
    private static final String MARKS_TO_GIVE = "18";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    public static ViewAction clickChildViewWithId(final int id) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Click on a child view with specified id.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View v = view.findViewById(id);
                if (v == null) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException("No view with id " + id + " found inside row"))
                            .build();
                }
                v.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    @Test
    public void giveMarksToFirstUngradedSubmission() throws InterruptedException {

        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        Thread.sleep(10000);

        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));


        onView(withId(R.id.cardAssignments)).perform(click());
        Thread.sleep(3000);

        onView(withId(R.id.rvAssignments)).perform(
                RecyclerViewActions.actionOnItemAtPosition(
                        0, clickChildViewWithId(R.id.btnViewSubmissions)));

        Thread.sleep(3000);

        onView(withId(R.id.rvSubmissions)).perform(
                RecyclerViewActions.actionOnItemAtPosition(
                        0, clickChildViewWithId(R.id.btnGiveMarks)));

        Thread.sleep(500);


        onView(withHint("Enter obtained marks"))
                .perform(typeText(MARKS_TO_GIVE), closeSoftKeyboard());
        onView(withText("Save")).perform(click());

        Thread.sleep(3000);

        onView(withId(R.id.rvSubmissions))
                .check(matches(hasDescendant(withText("Marks Given ✓"))));
    }
}