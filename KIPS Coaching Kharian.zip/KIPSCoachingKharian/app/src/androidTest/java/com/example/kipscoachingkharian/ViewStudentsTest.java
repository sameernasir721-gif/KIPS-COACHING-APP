package com.example.kipscoachingkharian;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.test.espresso.PerformException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.espresso.util.HumanReadables;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isPlatformPopup;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.containsString;

@RunWith(AndroidJUnit4.class)
public class ViewStudentsTest {

    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    public static ViewAction readFirstChildTextWithId(final int id, final String[] outValue) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(ViewGroup.class);
            }

            @Override
            public String getDescription() {
                return "Read text of a TextView inside the first child of a container.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                ViewGroup container = (ViewGroup) view;
                if (container.getChildCount() == 0) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException("Container khali hai"))
                            .build();
                }
                View firstChild = container.getChildAt(0);
                View target = firstChild.findViewById(id);
                if (target instanceof TextView) {
                    outValue[0] = ((TextView) target).getText().toString();
                }
            }
        };
    }

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(500);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    @Test
    public void viewSearchAndFilterStudents() throws InterruptedException {

        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(20);

        onView(withId(R.id.cardStudent)).perform(click());
        Thread.sleep(2000);

        onView(withId(R.id.containerStudents)).check(matches(isDisplayed()));

        String[] firstName = new String[1];
        onView(withId(R.id.containerStudents))
                .perform(readFirstChildTextWithId(R.id.tvItemStudentName, firstName));

        if (firstName[0] != null && !firstName[0].isEmpty()) {
            String searchTerm = firstName[0].length() > 3
                    ? firstName[0].substring(0, 3) : firstName[0];

            onView(withId(R.id.etSearchStudents))
                    .perform(replaceText(searchTerm), closeSoftKeyboard());
            Thread.sleep(1000);

            onView(withId(R.id.containerStudents))
                    .check(matches(hasDescendant(withText(containsString(searchTerm)))));

            onView(withId(R.id.etSearchStudents))
                    .perform(replaceText(""), closeSoftKeyboard());
            Thread.sleep(1000);
        }

        onView(withId(R.id.spinnerClassFilter)).perform(click());
        Thread.sleep(500);
        try {
            onView(withText("Class 10A")).inRoot(isPlatformPopup()).perform(click());
        } catch (Exception e) {

            System.out.println("'Class 10A' filter option nahi mila, dropdown dismiss kar rahe hain.");
            androidx.test.espresso.Espresso.pressBack();
        }
        Thread.sleep(1500);

        onView(withId(R.id.containerStudents)).check(matches(isDisplayed()));

        System.out.println("✅ View/Search/Filter Students test pass ho gaya!");
    }
}