package com.example.kipscoachingkharian;

import android.os.IBinder;
import android.view.WindowManager;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.Root;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

@RunWith(AndroidJUnit4.class)
public class FeeFlowTest {

    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    private static final String TEST_EMAIL_UNPAID      = "TODO_unpaid_student@example.com";
    private static final String TEST_STUDENT_ID_UNPAID = "TODO_unpaid_student_id";
    private static final String TEST_PASSWORD_UNPAID   = "TODO_unpaid_password";

    private static final String TEST_EMAIL_PAID      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID_PAID = "student048";
    private static final String TEST_PASSWORD_PAID   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void openFee_directFromDashboard_headerAndHistoryLoad() throws InterruptedException {
        loginAndOpenFee(TEST_EMAIL, TEST_STUDENT_ID, TEST_PASSWORD);

        onView(withId(R.id.tvStudentNameFee)).check(matches(isDisplayed()));
        onView(withId(R.id.tvHeaderStudentInfo)).check(matches(isDisplayed()));

        onView(withId(R.id.tvCurrentAmount)).check(matches(isDisplayed()));
        onView(withId(R.id.tvDueDateCurrent)).check(matches(isDisplayed()));

        onView(withId(R.id.btnPayNow)).check(matches(isDisplayed()));

        onView(withId(R.id.feeContainer)).check(matches(isDisplayed()));
    }

    // TODO: Unpaid-fee wala real test-account milte hi @Ignore hata dein
    @Ignore("Unpaid-fee wala test-account abhi tak provide nahi hua")
    @Test
    public void payNow_withPendingChallan_startsPaymentFlow() throws InterruptedException {
        loginAndOpenFee(TEST_EMAIL_UNPAID, TEST_STUDENT_ID_UNPAID, TEST_PASSWORD_UNPAID);

        onView(withId(R.id.btnPayNow)).perform(click());

        onView(withText("Payment process starting..."))
                .inRoot(isToast())
                .check(matches(isDisplayed()));
    }

    @Test
    public void payNow_withNoPendingChallan_showsNoFeeToast() throws InterruptedException {
        loginAndOpenFee(TEST_EMAIL_PAID, TEST_STUDENT_ID_PAID, TEST_PASSWORD_PAID);

        onView(withId(R.id.btnPayNow)).perform(click());

        onView(withText("No pending fee to pay right now."))
                .inRoot(isToast())
                .check(matches(isDisplayed()));


        onView(withId(R.id.btnPayNow)).check(matches(isDisplayed()));
    }

    private void loginAndOpenFee(String email, String studentId, String password)
            throws InterruptedException {

        onView(withId(R.id.etStudentUsername))
                .perform(typeText(email), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(password), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(studentId), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));

        onView(withId(R.id.cardFees)).perform(scrollTo(), click());

        Thread.sleep(3500);
    }

    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }

    private static Matcher<Root> isToast() {
        return new TypeSafeMatcher<Root>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("is toast");
            }

            @Override
            public boolean matchesSafely(Root root) {
                int type = root.getWindowLayoutParams().get().type;
                if (type == WindowManager.LayoutParams.TYPE_TOAST) {
                    IBinder windowToken = root.getDecorView().getWindowToken();
                    IBinder appToken = root.getDecorView().getApplicationWindowToken();
                    return windowToken == appToken;
                }
                return false;
            }
        };
    }
}