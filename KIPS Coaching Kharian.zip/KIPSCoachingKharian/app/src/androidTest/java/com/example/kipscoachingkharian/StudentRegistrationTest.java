package com.example.kipscoachingkharian;

import android.view.View;
import android.widget.CheckBox;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;
import androidx.test.uiautomator.Until;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;
import com.google.android.material.textfield.TextInputLayout;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isEnabled;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class StudentRegistrationTest {

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);
    @Test
    public void tabToggle_switchesBetweenLoginAndRegister() {

        onView(withId(R.id.layoutLogin)).check(matches(isDisplayed()));

        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.layoutRegister)).check(matches(isDisplayed()));

        onView(withId(R.id.tabLogin)).perform(click());
        onView(withId(R.id.layoutLogin)).check(matches(isDisplayed()));
    }

    @Test
    public void feeCalculation_updatesWhenSubjectsToggled() throws InterruptedException {
        openRegisterTab();

        selectSubjectCheckbox("Math");
        onView(withId(R.id.tvRegTotalFee)).check(matches(withText("Total Fee: Rs 3000")));

        selectSubjectCheckbox("Physics");
        onView(withId(R.id.tvRegTotalFee)).check(matches(withText("Total Fee: Rs 6000")));

        selectSubjectCheckbox("Urdu");
        onView(withId(R.id.tvRegTotalFee)).check(matches(withText("Total Fee: Rs 8500")));

        selectSubjectCheckbox("Math");
        onView(withId(R.id.tvRegTotalFee)).check(matches(withText("Total Fee: Rs 5500")));
    }

    @Test
    public void emptyFields_showValidationErrors() {
        openRegisterTab();

        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        onView(withId(R.id.tilRegName))
                .check(matches(hasTextInputLayoutErrorText("Please enter your name")));
        onView(withId(R.id.tilRegEmail))
                .check(matches(hasTextInputLayoutErrorText("Please enter your email")));
    }

    @Test
    public void invalidName_showsError() {
        openRegisterTab();

        onView(withId(R.id.etRegName)).perform(scrollTo(), typeText("Ali123"), closeSoftKeyboard());
        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        onView(withId(R.id.tilRegName))
                .check(matches(hasTextInputLayoutErrorText("Only alphabets allowed")));
    }

    @Test
    public void nonGmailEmail_showsError() {
        openRegisterTab();

        onView(withId(R.id.etRegName)).perform(scrollTo(), typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(scrollTo(), typeText("alikhan@yahoo.com"), closeSoftKeyboard());
        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        onView(withId(R.id.tilRegEmail))
                .check(matches(hasTextInputLayoutErrorText("Only Gmail address allowed (e.g. name@gmail.com)")));
    }

    @Test
    public void invalidPhone_showsError() {
        openRegisterTab();

        onView(withId(R.id.etRegName)).perform(scrollTo(), typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(scrollTo(), typeText("alikhan@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(scrollTo(), typeText("12345"), closeSoftKeyboard());
        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        onView(withId(R.id.tilRegPhone))
                .check(matches(hasTextInputLayoutErrorText("Write 11-digits number")));
    }

    @Test
    public void weakPassword_showsError() throws InterruptedException {
        openRegisterTab();

        onView(withId(R.id.etRegName)).perform(scrollTo(), typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(scrollTo(), typeText("alikhan@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(scrollTo(), typeText("03001234567"), closeSoftKeyboard());
        selectClass("10");
        onView(withId(R.id.etRegPassword)).perform(scrollTo(), typeText("weakpass"), closeSoftKeyboard());
        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        onView(withId(R.id.tilRegPassword))
                .check(matches(hasTextInputLayoutErrorText(
                        "Password must be atleast 8 characters including special symbol")));
    }

    @Test
    public void noSubjectSelected_showsToast() throws InterruptedException {
        openRegisterTab();

        onView(withId(R.id.etRegName)).perform(scrollTo(), typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(scrollTo(), typeText("alikhan@gmail.com"), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(scrollTo(), typeText("03001234567"), closeSoftKeyboard());
        selectClass("10");

        onView(withId(R.id.etRegClass)).check(matches(withText("10")));

        onView(withId(R.id.etRegPassword)).perform(scrollTo(), typeText("Passw0rd!"), closeSoftKeyboard());

        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());


        onView(withId(R.id.btnStudentRegister))
                .check(matches(isEnabled()))
                .check(matches(isDisplayed()));
        onView(withId(R.id.layoutRegister)).check(matches(isDisplayed()));
    }

    @Test
    public void validRegistration_showsSuccessToast() throws InterruptedException {
        openRegisterTab();


        String uniqueEmail = "kipstest" + System.currentTimeMillis() + "@gmail.com";

        onView(withId(R.id.etRegName)).perform(scrollTo(), typeText("Ali Khan"), closeSoftKeyboard());
        onView(withId(R.id.etRegEmail)).perform(scrollTo(), typeText(uniqueEmail), closeSoftKeyboard());
        onView(withId(R.id.etRegPhone)).perform(scrollTo(), typeText("03001234567"), closeSoftKeyboard());
        selectClass("10");
        onView(withId(R.id.etRegPassword)).perform(scrollTo(), typeText("Passw0rd!"), closeSoftKeyboard());
        selectSubjectCheckbox("Math");
        selectSubjectCheckbox("English");

        onView(withId(R.id.btnStudentRegister)).perform(scrollTo(), click());

        waitUntilLoginViewShown(15000);

        onView(withId(R.id.layoutLogin)).check(matches(isDisplayed()));
    }

    private void waitUntilLoginViewShown(long timeoutMillis) throws InterruptedException {
        long deadline = System.currentTimeMillis() + timeoutMillis;
        while (System.currentTimeMillis() < deadline) {
            try {
                onView(withId(R.id.layoutLogin)).check(matches(isDisplayed()));
                return;
            } catch (Throwable notYetVisible) {
                Thread.sleep(300);
            }
        }

        onView(withId(R.id.layoutLogin)).check(matches(isDisplayed()));
    }

    private void openRegisterTab() {
        onView(withId(R.id.tabRegister)).perform(click());
        onView(withId(R.id.layoutRegister)).check(matches(isDisplayed()));
    }

    private void selectClass(String className) {
        onView(withId(R.id.etRegClass)).perform(scrollTo(), click());

        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        boolean popupItemFound = device.wait(
                Until.hasObject(By.text(className)), 5000);
        assertTrue("Class dropdown se \"" + className + "\" wala option 5 second mein nahi mila — popup nahi khula ya bohot slow hai",
                popupItemFound);

        UiObject2 item = device.findObject(By.text(className));
        assertTrue("Popup mein \"" + className + "\" wala item mila to sahi, lekin click ke liye null nikla",
                item != null);
        item.click();

        device.waitForIdle(1000);
    }

    private void selectSubjectCheckbox(String namePrefix) throws InterruptedException {
        long deadline = System.currentTimeMillis() + 10000;
        while (System.currentTimeMillis() < deadline) {
            try {
                onView(withSubjectText(namePrefix)).perform(scrollTo(), click());
                return;
            } catch (Throwable notYetRendered) {
                Thread.sleep(300);
            }
        }

        onView(withSubjectText(namePrefix)).perform(scrollTo(), click());
    }

    private static Matcher<View> withSubjectText(final String namePrefix) {
        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("CheckBox with text starting with: " + namePrefix);
            }

            @Override
            protected boolean matchesSafely(View view) {
                if (!(view instanceof CheckBox)) {
                    return false;
                }
                CharSequence text = ((CheckBox) view).getText();
                return text != null && text.toString().startsWith(namePrefix);
            }
        };
    }

    private static Matcher<View> hasTextInputLayoutErrorText(final String expectedError) {
        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("TextInputLayout with error text: " + expectedError);
            }

            @Override
            protected boolean matchesSafely(View view) {
                if (!(view instanceof TextInputLayout)) {
                    return false;
                }
                CharSequence error = ((TextInputLayout) view).getError();
                return error != null && expectedError.contentEquals(error);
            }
        };
    }
}