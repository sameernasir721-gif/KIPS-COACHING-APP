package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

/**
 * Teacher Dashboard — Full Navigation Smoke Test.
 *
 * Har card, "Today at a Glance" ka har item, bottom nav ka har tab, aur
 * hamburger drawer ke menu items par navigate karta hai, verify karta
 * hai sahi screen khulti hai, phir SYSTEM BACK BUTTON (pressBack) se
 * wapas Dashboard par aata hai.
 *
 * NOTE: pressBack() hi use kar rahe hain (har screen ka apna custom
 * "ivMenu"/"ivBack" button use karna is device par ULTA masla kar raha
 * tha, kyunke kai screens mein woh sirf decoration hai, functional
 * nahi) — Android ka standard back navigation hi sab se consistent hai.
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daal dein.
 */
@RunWith(AndroidJUnit4.class)
public class TeacherDashboardFullNavigationTest {

    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    public static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility check.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(500);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    // Dashboard ke root card check karta hai — cardStudent hamesha Dashboard
    // par hi hota hai, is liye "hum wapas Dashboard par hain" confirm karne
    // ke liye tvTeacherName ki bajaye yeh use karte hain (kyunke tvTeacherName
    // id kai screens mein reuse hoti hai, alag text ke sath).
    private void waitUntilBackOnDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.cardStudent)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(400);
            }
        }
        onView(withId(R.id.cardStudent)).check(matches(isDisplayed()));
    }

    private void navigateCardAndBack(int cardId, int destinationVerifyId, int waitMs)
            throws InterruptedException {
        onView(withId(cardId)).perform(scrollTo(), click());
        Thread.sleep(waitMs);
        onView(withId(destinationVerifyId)).check(matches(isDisplayed()));
        Espresso.pressBack();
        waitUntilBackOnDashboard(6);
    }

    private void navigateBottomNavAndBack(int navId, int destinationVerifyId, int waitMs)
            throws InterruptedException {
        Espresso.closeSoftKeyboard();
        onView(withId(navId)).perform(forceClick());
        Thread.sleep(waitMs);
        onView(withId(destinationVerifyId)).check(matches(isDisplayed()));
        Espresso.pressBack();
        waitUntilBackOnDashboard(6);
    }

    @Test
    public void fullDashboardNavigation_allCardsAndButtonsWork() throws InterruptedException {

        // ── Login ─────────────────────────────────────────────────────────
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());
        waitForDashboard(20);

        // ═══════════════ MAIN DASHBOARD CARDS ═══════════════
        System.out.println("➡️ Students card");
        navigateCardAndBack(R.id.cardStudent, R.id.containerStudents, 1500);

        System.out.println("➡️ Create Classes card");
        navigateCardAndBack(R.id.cardCreateClasses, R.id.btnCreateClass, 1200);

        System.out.println("➡️ Study Material card");
        navigateCardAndBack(R.id.cardStudyMaterial, R.id.rvStudyMaterial, 1200);

        System.out.println("➡️ Quizzes card");
        navigateCardAndBack(R.id.cardQuizzes, R.id.layoutQuizList, 1500);

        System.out.println("➡️ Assignments card");
        navigateCardAndBack(R.id.cardAssignments, R.id.rvAssignments, 1500);

        System.out.println("➡️ Student Progress card");
        navigateCardAndBack(R.id.cardPerformance, R.id.rvStudents, 1500);

        System.out.println("➡️ Syllabus card");
        navigateCardAndBack(R.id.Syllabus, R.id.rvUnits, 1500);

        System.out.println("➡️ Time Schedule card");
        navigateCardAndBack(R.id.TimeSchedule, R.id.layoutPdfActions, 1500);

        // ═══════════════ TODAY AT A GLANCE SECTION ═══════════════
        System.out.println("➡️ 'See All' (Today at a Glance)");
        navigateCardAndBack(R.id.tvSeeAll, R.id.tvTodayDate, 1200);

        System.out.println("➡️ Glance - Classes card");
        navigateCardAndBack(R.id.cardGlanceClasses, R.id.btnCreateClass, 1200);

        System.out.println("➡️ Glance - Assignments card");
        navigateCardAndBack(R.id.cardGlanceAssignments, R.id.rvAssignments, 1500);

        System.out.println("➡️ Glance - Submissions card");
        navigateCardAndBack(R.id.cardGlanceSubmissions, R.id.rvAssignments, 1500);

        System.out.println("➡️ Glance - Quizzes card");
        navigateCardAndBack(R.id.cardGlanceQuizzes, R.id.layoutQuizList, 1500);

        // ═══════════════ BOTTOM NAVIGATION ═══════════════
        System.out.println("➡️ Bottom nav - Message");
        navigateBottomNavAndBack(R.id.nav_bottom_Message, R.id.rvConversations, 1500);

        System.out.println("➡️ Bottom nav - Announcement");
        navigateBottomNavAndBack(R.id.nav_bottom_Announcment, R.id.containerAnnouncements, 1500);

        System.out.println("➡️ Bottom nav - Profile");
        navigateBottomNavAndBack(R.id.nav_bottom_profile, R.id.tv_name, 1200);

        // ═══════════════ HAMBURGER DRAWER MENU ═══════════════
        System.out.println("➡️ Hamburger menu (drawer)");
        onView(withId(R.id.ivMenu)).perform(forceClick());
        Thread.sleep(700);
        onView(withId(R.id.navigationView)).check(matches(isDisplayed()));


        System.out.println("➡️ Logout menu item (Cancel dabate hain)");
        onView(withId(R.id.ivMenu)).perform(forceClick());
        Thread.sleep(700);
        onView(withId(R.id.nav_logout)).perform(click());
        Thread.sleep(700);
        onView(androidx.test.espresso.matcher.ViewMatchers.withText("Cancel"))
                .inRoot(androidx.test.espresso.matcher.RootMatchers.isDialog())
                .perform(click());
        Thread.sleep(1200); // Dialog + drawer close animation settle hone ka wait

        onView(withId(R.id.tvTeacherName)).perform(scrollTo());
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
        System.out.println("✅ Poora Dashboard navigation test pass ho gaya!");
    }
}