package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isEnabled;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import android.view.View;
import android.widget.RatingBar;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;

import com.example.kipscoachingkharian.auth.ParentLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;


@RunWith(AndroidJUnit4.class)
public class ParentFeedbackActivityTest {
    private static final String TEST_EMAIL =
            "raiazaslam063@gmail.com";

    private static final String TEST_STUDENT_ID =
            "student043";

    private static final String TEST_PASSWORD =
            "Student043@@";

    private static final String UNIQUE_FEEDBACK_TEXT =
            "Automated parent feedback test - please ignore "
                    + System.currentTimeMillis();


    // ─────────────────────────────────────────────────────────────
    // ACTIVITY RULE
    // ─────────────────────────────────────────────────────────────

    @Rule
    public ActivityScenarioRule<ParentLoginActivity> activityRule =
            new ActivityScenarioRule<>(ParentLoginActivity.class);


    // ─────────────────────────────────────────────────────────────
    // TEST 1
    // SUBMIT FEEDBACK ↔ ALL FEEDBACK TAB SWITCHING
    // ─────────────────────────────────────────────────────────────

    @Test
    public void feedbackTabs_switchBetweenSubmitAndAll()
            throws InterruptedException {

        login();
        openFeedbackScreen();

        onView(withId(R.id.layoutSubmitFeedback))
                .check(matches(isDisplayed()));

        onView(withId(R.id.tabAll))
                .perform(scrollTo(), click());

        Thread.sleep(5000);

        onView(withId(R.id.layoutAllFeedback))
                .check(matches(isDisplayed()));

        onView(withId(R.id.rvFeedbacks))
                .check(matches(isDisplayed()));

        onView(withId(R.id.tvOverallRatingDigit))
                .check(matches(isDisplayed()));

        onView(withId(R.id.tabSubmit))
                .perform(scrollTo(), click());

        Thread.sleep(500);

        onView(withId(R.id.layoutSubmitFeedback))
                .check(matches(isDisplayed()));
    }


    // ─────────────────────────────────────────────────────────────
    // TEST 2
    // EMPTY FEEDBACK -> BLOCKED
    // ─────────────────────────────────────────────────────────────

    @Test
    public void submit_withEmptyFeedback_staysOnSubmitTab()
            throws InterruptedException {

        login();
        openFeedbackScreen();

        onView(withId(R.id.etFeedback))
                .perform(scrollTo(), clearText(), closeSoftKeyboard());

        onView(withId(R.id.rbInput))
                .perform(scrollTo(), setRating(4f));

        onView(withId(R.id.btnSubmitFeedback))
                .perform(scrollTo(), click());

        Thread.sleep(1000);

        onView(withId(R.id.layoutSubmitFeedback))
                .check(matches(isDisplayed()));

        onView(withId(R.id.btnSubmitFeedback))
                .check(matches(isEnabled()));
    }


    // ─────────────────────────────────────────────────────────────
    // TEST 3
    // FEEDBACK FILLED, ZERO RATING -> BLOCKED
    // ─────────────────────────────────────────────────────────────

    @Test
    public void submit_withZeroRating_staysOnSubmitTab()
            throws InterruptedException {

        login();
        openFeedbackScreen();

        onView(withId(R.id.etFeedback))
                .perform(scrollTo(), replaceText(UNIQUE_FEEDBACK_TEXT), closeSoftKeyboard());

        onView(withId(R.id.rbInput))
                .perform(scrollTo(), setRating(0f));

        onView(withId(R.id.btnSubmitFeedback))
                .perform(scrollTo(), click());

        Thread.sleep(1000);

        onView(withId(R.id.layoutSubmitFeedback))
                .check(matches(isDisplayed()));
    }


    // ─────────────────────────────────────────────────────────────
    // TEST 4
    // VALID SUBMIT -> ALL TAB + LIST KE TOP PAR CORRECT TEXT
    // ─────────────────────────────────────────────────────────────

    @Test
    public void submitFeedback_switchesToAllTabAndShowsAtTopOfList()
            throws InterruptedException {

        login();
        openFeedbackScreen();

        onView(withId(R.id.etFeedback))
                .perform(scrollTo(), replaceText(UNIQUE_FEEDBACK_TEXT), closeSoftKeyboard());

        onView(withId(R.id.rbInput))
                .perform(scrollTo(), setRating(5f));

        onView(withId(R.id.btnSubmitFeedback))
                .perform(scrollTo(), click());

        Thread.sleep(2500);

        onView(withId(R.id.layoutAllFeedback))
                .check(matches(isDisplayed()));

        onView(withId(R.id.rvFeedbacks))
                .check(matches(isDisplayed()));

        onView(withId(R.id.rvFeedbacks))
                .perform(RecyclerViewActions.scrollToPosition(0));

        onView(withId(R.id.rvFeedbacks))
                .check(matches(hasDescendant(withText(UNIQUE_FEEDBACK_TEXT))));
    }


    // ─────────────────────────────────────────────────────────────
    // LOGIN HELPER
    // ─────────────────────────────────────────────────────────────

    private void login() throws InterruptedException {

        onView(withId(R.id.etLoginEmail))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etLoginPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etLoginStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnParentLogin))
                .perform(click());

        Thread.sleep(5000);

        // ✅ FIX: ParentDashboardActivity onCreate() mein POST_NOTIFICATIONS
        // runtime-permission maangti hai (Android 13+/API 33+). Wo system
        // dialog agar screen par aa jaye to koi activity RESUMED state mein
        // nahi hoti aur Espresso "NoActivityResumedException" de deta hai.
        // GrantPermissionRule kuch emulator images (Play Store wale) par
        // "GRANT_RUNTIME_PERMISSIONS" SecurityException deta hai, is liye
        // shell-grant ke bajaye UiAutomator se dialog khud "Allow" click
        // karwate hain — asal user jaisa, koi special permission nahi chahiye.
        allowNotificationPermissionIfShown();

        // Dashboard load hone ka wait — Feedback card visible hona chahiye
        onView(withId(R.id.cardFeedback))
                .check(matches(isDisplayed()));
    }

    // ─────────────────────────────────────────────────────────────
    // ALLOW NOTIFICATION PERMISSION DIALOG (agar dikhe to)
    // ─────────────────────────────────────────────────────────────

    private void allowNotificationPermissionIfShown() {
        try {
            UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());

            // "Allow" / "While using the app" / "Allow only while using the app"
            // — device/OEM ke hisaab se text alag ho sakta hai, is liye kai
            // possible button-text patterns try karte hain.
            String[] possibleLabels = {
                    "Allow", "ALLOW", "While using the app",
                    "Allow only while using the app", "OK"
            };

            for (String label : possibleLabels) {
                UiObject2 button = device.wait(
                        androidx.test.uiautomator.Until.findObject(By.text(label)), 3000);
                if (button != null) {
                    button.click();
                    break;
                }
            }
        } catch (Exception e) {
            // Dialog aaya hi nahi, ya already resolve ho chuka — ignore karo,
            // test normal flow continue karega.
        }
    }


    // ─────────────────────────────────────────────────────────────
    // OPEN FEEDBACK SCREEN
    // ─────────────────────────────────────────────────────────────

    private void openFeedbackScreen() throws InterruptedException {

        onView(withId(R.id.cardFeedback))
                .perform(forceClick());

        Thread.sleep(2500);
    }


    // ─────────────────────────────────────────────────────────────
    // FORCE CLICK
    // ─────────────────────────────────────────────────────────────

    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility constraints.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }


    // ─────────────────────────────────────────────────────────────
    // CHECK VIEW DISPLAYED
    // ─────────────────────────────────────────────────────────────

    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }


    // ─────────────────────────────────────────────────────────────
    // SET RATING
    // ─────────────────────────────────────────────────────────────

    private static ViewAction setRating(final float rating) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return isAssignableFrom(RatingBar.class);
            }

            @Override
            public String getDescription() {
                return "Set the rating of a RatingBar.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                ((RatingBar) view).setRating(rating);
                uiController.loopMainThreadUntilIdle();
            }
        };
    }
}