package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasErrorText;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.auth.AdminLoginActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class AdminLoginActivityTest {

    private ActivityScenario<AdminLoginActivity> scenario;

    private static final String TEST_ADMIN_EMAIL = "admin@kipskharian.com";
    private static final String TEST_ADMIN_PASSWORD = "Admin@123";

    @Before
    public void setUp() {
        scenario = ActivityScenario.launch(AdminLoginActivity.class);
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
    }

    @Test
    public void loginScreen_elementsAreVisible() {
        onView(withId(R.id.etAdminEmail)).check(matches(isDisplayed()));
        onView(withId(R.id.etAdminPassword)).check(matches(isDisplayed()));
        onView(withId(R.id.btnAdminLogin)).check(matches(isDisplayed()));
        onView(withId(R.id.tvForgotPassword)).check(matches(isDisplayed()));
    }

    @Test
    public void emptyEmail_showsError() {
        onView(withId(R.id.etAdminEmail)).perform(clearText(), closeSoftKeyboard());
        onView(withId(R.id.etAdminPassword)).perform(typeText("Test@1234"), closeSoftKeyboard());
        onView(withId(R.id.btnAdminLogin)).perform(click());

        onView(withId(R.id.etAdminEmail))
                .check(matches(hasErrorText("Email is required")));
    }

    @Test
    public void invalidEmailFormat_showsError() {
        onView(withId(R.id.etAdminEmail)).perform(typeText("notanemail"), closeSoftKeyboard());
        onView(withId(R.id.etAdminPassword)).perform(typeText("Test@1234"), closeSoftKeyboard());
        onView(withId(R.id.btnAdminLogin)).perform(click());

        onView(withId(R.id.etAdminEmail))
                .check(matches(hasErrorText("Invalid email format — example@domain.com")));
    }

    @Test
    public void emptyPassword_showsError() {
        onView(withId(R.id.etAdminEmail)).perform(typeText("admin@kips.com"), closeSoftKeyboard());
        onView(withId(R.id.etAdminPassword)).perform(clearText(), closeSoftKeyboard());
        onView(withId(R.id.btnAdminLogin)).perform(click());

        onView(withId(R.id.etAdminPassword))
                .check(matches(hasErrorText("Password is required")));
    }

    @Test
    public void shortPassword_showsError() {
        onView(withId(R.id.etAdminEmail)).perform(typeText("admin@kips.com"), closeSoftKeyboard());
        onView(withId(R.id.etAdminPassword)).perform(typeText("Ab@1"), closeSoftKeyboard());
        onView(withId(R.id.btnAdminLogin)).perform(click());

        onView(withId(R.id.etAdminPassword))
                .check(matches(hasErrorText("Password must be at least 8 characters")));
    }

    @Test
    public void passwordWithoutSpecialChar_showsError() {
        onView(withId(R.id.etAdminEmail)).perform(typeText("admin@kips.com"), closeSoftKeyboard());
        onView(withId(R.id.etAdminPassword)).perform(typeText("Password1"), closeSoftKeyboard());
        onView(withId(R.id.btnAdminLogin)).perform(click());

        onView(withId(R.id.etAdminPassword)).check(matches(
                hasErrorText("Password must contain at least one special character (!@#$%...)")));
    }

    @Test
    public void forgotPassword_opensDialog() {
        onView(withId(R.id.tvForgotPassword)).perform(click());
        onView(withText("🔑 Forgot Password")).check(matches(isDisplayed()));
    }

    @Test
    public void validCredentials_logsInSuccessfully() {
        onView(withId(R.id.etAdminEmail)).perform(typeText(TEST_ADMIN_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etAdminPassword)).perform(typeText(TEST_ADMIN_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnAdminLogin)).perform(click());

        try {
            Thread.sleep(4000);
        } catch (InterruptedException ignored) {
        }

        onView(withId(R.id.drawerLayout)).check(matches(isDisplayed()));
    }
}