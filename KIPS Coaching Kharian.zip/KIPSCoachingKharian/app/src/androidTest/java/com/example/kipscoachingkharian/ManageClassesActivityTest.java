package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertNotNull;

import android.content.Context;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.ManageClassesActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

@RunWith(AndroidJUnit4.class)
public class ManageClassesActivityTest {

    private DatabaseReference classesRef;

    @Before
    public void setUp() throws InterruptedException {
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertNotNull(appContext);

        classesRef = FirebaseDatabase.getInstance().getReference().child("AcademicClasses");

        CountDownLatch latch = new CountDownLatch(1);
        classesRef.removeValue((error, ref) -> latch.countDown());
        latch.await(10, TimeUnit.SECONDS);
    }

    @After
    public void tearDown() throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        classesRef.removeValue((error, ref) -> latch.countDown());
        latch.await(10, TimeUnit.SECONDS);
    }

    @Test
    public void headerElements_areDisplayed_onLaunch() {
        try (ActivityScenario<ManageClassesActivity> scenario =
                     ActivityScenario.launch(ManageClassesActivity.class)) {

            onView(withId(R.id.ivBack)).check(matches(isDisplayed()));
            onView(withId(R.id.tvTotalClassesCount)).check(matches(isDisplayed()));
            onView(withId(R.id.btnAddNewClass)).check(matches(isDisplayed()));
        }
    }

    @Test
    public void classCount_isZero_whenNoClassesExist() {
        try (ActivityScenario<ManageClassesActivity> scenario =
                     ActivityScenario.launch(ManageClassesActivity.class)) {

            waitFor(2000);

            onView(withId(R.id.tvTotalClassesCount)).check(matches(withText("0")));
        }
    }

    @Test
    public void addClassButton_opensClassPicker_withAllFourFixedClasses() {
        try (ActivityScenario<ManageClassesActivity> scenario =
                     ActivityScenario.launch(ManageClassesActivity.class)) {

            waitFor(2000);

            onView(withId(R.id.btnAddNewClass)).perform(click());

            onView(withText("9th")).check(matches(isDisplayed()));
            onView(withText("10th")).check(matches(isDisplayed()));
            onView(withText("11th")).check(matches(isDisplayed()));
            onView(withText("12th")).check(matches(isDisplayed()));
        }
    }

    @Test
    public void addingAClass_showsItInTheList_andUpdatesCount() {
        try (ActivityScenario<ManageClassesActivity> scenario =
                     ActivityScenario.launch(ManageClassesActivity.class)) {

            waitFor(2000);

            onView(withId(R.id.btnAddNewClass)).perform(click());
            onView(withText("9th")).perform(click());

            waitFor(2500);

            onView(withText("🏫 9th")).check(matches(isDisplayed()));
            onView(withId(R.id.tvTotalClassesCount)).check(matches(withText("1")));
        }
    }

    @Test
    public void addingSection_underAClass_isReflectedInUI() {
        try (ActivityScenario<ManageClassesActivity> scenario =
                     ActivityScenario.launch(ManageClassesActivity.class)) {

            waitFor(2000);

            onView(withId(R.id.btnAddNewClass)).perform(click());
            onView(withText("10th")).perform(click());
            waitFor(2500);

            onView(withText("+ Section")).perform(click());
            onView(withText("Section A")).perform(click());
            waitFor(2500);

            onView(withText("Section A  (0 students)")).check(matches(isDisplayed()));
        }
    }

    private void waitFor(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }
}