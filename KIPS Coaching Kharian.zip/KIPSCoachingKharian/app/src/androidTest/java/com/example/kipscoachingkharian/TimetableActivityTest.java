package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.TimetableActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class TimetableActivityTest {

    private ActivityScenario<TimetableActivity> scenario;

    @Before
    public void setUp() {
        scenario = ActivityScenario.launch(TimetableActivity.class);
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
    }

    @Test
    public void screen_elementsAreVisible() {
        onView(withId(R.id.btnBack)).check(matches(isDisplayed()));
        onView(withId(R.id.btnShare)).check(matches(isDisplayed()));
        onView(withId(R.id.mainTable)).check(matches(isDisplayed()));
    }

    @Test
    public void backButton_finishesActivity() {
        onView(withId(R.id.btnBack)).perform(click());
        assertTrue("Activity should be in DESTROYED state after tapping the back button",
                scenario.getState() == Lifecycle.State.DESTROYED);
    }

    @Test
    public void shareButton_opensConfirmationDialogWithOptions() {
        onView(withId(R.id.btnShare)).perform(click());

        onView(withText("Confirm Timetable Update")).check(matches(isDisplayed()));
        onView(withText("Students")).check(matches(isDisplayed()));
        onView(withText("Teachers")).check(matches(isDisplayed()));
        onView(withText("Both")).check(matches(isDisplayed()));
        onView(withText("Process & Upload")).check(matches(isDisplayed()));
        onView(withText("Cancel")).check(matches(isDisplayed()));
    }

    @Test
    public void selectingStudentsOption_updatesSelection() {
        onView(withId(R.id.btnShare)).perform(click());
        onView(withText("Students")).perform(click());

        onView(withText("Confirm Timetable Update")).check(matches(isDisplayed()));
    }

    @Test
    public void cancelButton_dismissesDialogWithoutProcessing() {
        onView(withId(R.id.btnShare)).perform(click());
        onView(withText("Cancel")).perform(click());

        assertTrue(scenario.getState() == Lifecycle.State.RESUMED);
        onView(withText("Processing schedule data...")).check(
                androidx.test.espresso.assertion.ViewAssertions.doesNotExist());
    }
}