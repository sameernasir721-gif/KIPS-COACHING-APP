package com.example.kipscoachingkharian;

import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.test.espresso.PerformException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.espresso.util.HumanReadables;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.List;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isDialog;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;


@RunWith(AndroidJUnit4.class)
public class StudentProgressTest {

    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    private static final String CLASS_ATTENDED  = "18";
    private static final String CLASS_TOTAL     = "20";
    private static final String ASSIGN_OBTAINED = "45";
    private static final String ASSIGN_TOTAL    = "50";
    private static final String QUIZ_OBTAINED   = "8";
    private static final String QUIZ_TOTAL      = "10";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    public static ViewAction clickChildViewWithId(final int id) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Click on a child view with specified id.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View v = view.findViewById(id);
                if (v == null) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException("No view with id " + id + " found inside row"))
                            .build();
                }
                v.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    private static void collectEditTexts(View v, List<EditText> out) {
        if (v instanceof EditText) {
            out.add((EditText) v);
        } else if (v instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) v;
            for (int i = 0; i < group.getChildCount(); i++) {
                collectEditTexts(group.getChildAt(i), out);
            }
        }
    }

    public static ViewAction setNthEditTextInWindow(final int index, final String value) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Set text on the Nth EditText found in this window.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View root = view.getRootView();
                List<EditText> editTexts = new ArrayList<>();
                collectEditTexts(root, editTexts);

                if (index >= editTexts.size()) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException(
                                    "Sirf " + editTexts.size() + " EditTexts mile, index " + index + " maujood nahi"))
                            .build();
                }

                EditText target = editTexts.get(index);

                click().perform(uiController, target);
                uiController.loopMainThreadUntilIdle();
                clearText().perform(uiController, target);
                uiController.loopMainThreadUntilIdle();
                typeText(value).perform(uiController, target);
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    public static ViewAction readChildTextWithId(final int id, final String[] outValue) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Read text from a child view with specified id.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View v = view.findViewById(id);
                if (v instanceof android.widget.TextView) {
                    outValue[0] = ((android.widget.TextView) v).getText().toString();
                }
            }
        };
    }

    public static ViewAction getNthEditTextInWindow(final int index, final String[] outValue) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Read text from the Nth EditText found in this window.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View root = view.getRootView();
                List<EditText> editTexts = new ArrayList<>();
                collectEditTexts(root, editTexts);
                if (index < editTexts.size()) {
                    outValue[0] = editTexts.get(index).getText().toString();
                }
            }
        };
    }

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(1000);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    private void fillDialogField(int index, String value) throws InterruptedException {
        onView(withText("Save")).inRoot(isDialog())
                .perform(setNthEditTextInWindow(index, value));
        Thread.sleep(400);
    }

    @Test
    public void enterMarks_verifySaved() throws InterruptedException {

        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(25);

        onView(withId(R.id.cardPerformance)).perform(scrollTo(), click());
        Thread.sleep(3000);

        String[] studentName = new String[1];
        onView(withId(R.id.rvStudents)).perform(
                RecyclerViewActions.actionOnItemAtPosition(
                        0, readChildTextWithId(R.id.tvStudentName, studentName)));

        onView(withId(R.id.rvStudents)).perform(
                RecyclerViewActions.actionOnItemAtPosition(
                        0, clickChildViewWithId(R.id.btnEnterMarks)));
        Thread.sleep(1000);

        fillDialogField(0, CLASS_ATTENDED);
        fillDialogField(1, CLASS_TOTAL);
        fillDialogField(2, ASSIGN_OBTAINED);
        fillDialogField(3, ASSIGN_TOTAL);
        fillDialogField(4, QUIZ_OBTAINED);
        fillDialogField(5, QUIZ_TOTAL);


        onView(withText("Save")).inRoot(isDialog()).perform(click());

        Thread.sleep(4000);

        onView(withId(R.id.rvStudents)).perform(
                RecyclerViewActions.actionOnItem(
                        hasDescendant(withText(studentName[0])),
                        clickChildViewWithId(R.id.btnEnterMarks)));
        Thread.sleep(1000);

        onView(withText("Save")).inRoot(isDialog()).check(matches(isDisplayed()));

        String[] savedValue = new String[1];
        onView(withText("Save")).inRoot(isDialog())
                .perform(getNthEditTextInWindow(0, savedValue));

        org.junit.Assert.assertEquals(
                "Classes Attended ki value save nahi hui!",
                CLASS_ATTENDED, savedValue[0]);
    }
}