// LOCATION: app/src/androidTest/java/com/example/kipscoachingkharian/dashboard/AdminDashboardCardsNavigationTest.java
package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.junit.Assert.assertTrue;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.AddTeacherActivity;
import com.example.kipscoachingkharian.dashboard.AdminDashboardActivity;
import com.example.kipscoachingkharian.dashboard.AdminFeeActivity;
import com.example.kipscoachingkharian.dashboard.AdminPaymentConfigActivity;
import com.example.kipscoachingkharian.dashboard.FeedManagmentActivity;
import com.example.kipscoachingkharian.dashboard.ManageAnnouncementsActivity;
import com.example.kipscoachingkharian.dashboard.ManageClassesActivity;
import com.example.kipscoachingkharian.dashboard.ManageParentRequestsActivity;
import com.example.kipscoachingkharian.dashboard.ManageStudentRequestsActivity;
import com.example.kipscoachingkharian.dashboard.ManageSubjectsActivity;
import com.example.kipscoachingkharian.dashboard.ManageUserActivity;
import com.example.kipscoachingkharian.dashboard.SystemReportsActivity;
import com.example.kipscoachingkharian.dashboard.TimetableActivity;
import com.google.firebase.auth.FirebaseAuth;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Har card ke liye ek alag @Test hai — ye check karta hai ke card par tap
 * karne se sahi Activity launch hoti hai (asli navigation, sirf intent record
 * hota hai check karne ke liye — activity waqai khulti hai).
 *
 * AdminDashboardActivity ke onCreate() me auth check hai, isliye @Before me
 * pehle Firebase se sign-in karte hain, phir Dashboard launch karte hain.
 */
@RunWith(AndroidJUnit4.class)
public class AdminDashboardCardsNavigationTest {

    // Aapka real test-admin account
    private static final String TEST_ADMIN_EMAIL = "raimanasir260@gmail.com";
    private static final String TEST_ADMIN_PASSWORD = "#kipsadmin";

    private ActivityScenario<AdminDashboardActivity> scenario;

    @Before
    public void signInAndLaunchDashboard() throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        FirebaseAuth.getInstance()
                .signInWithEmailAndPassword(TEST_ADMIN_EMAIL, TEST_ADMIN_PASSWORD)
                .addOnCompleteListener(task -> latch.countDown());

        boolean completed = latch.await(15, TimeUnit.SECONDS);
        assertTrue("Firebase sign-in timeout — internet/credentials check karein", completed);
        assertTrue("Sign-in fail ho gaya — email/password ya role check karein",
                FirebaseAuth.getInstance().getCurrentUser() != null);

        Intents.init();
        scenario = ActivityScenario.launch(AdminDashboardActivity.class);
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
        Intents.release();
        FirebaseAuth.getInstance().signOut();
    }

    // 1) Student card -> ManageStudentRequestsActivity
    @Test
    public void studentCard_opensManageStudentRequests() {
        onView(withId(R.id.Student)).perform(click());
        intended(hasComponent(ManageStudentRequestsActivity.class.getName()));
    }

    // 2) Teacher card -> AddTeacherActivity
    @Test
    public void teacherCard_opensAddTeacherActivity() {
        onView(withId(R.id.Teacher)).perform(click());
        intended(hasComponent(AddTeacherActivity.class.getName()));
    }

    // 3) Parents card -> ManageParentRequestsActivity
    @Test
    public void parentsCard_opensManageParentRequests() {
        onView(withId(R.id.Parents)).perform(click());
        intended(hasComponent(ManageParentRequestsActivity.class.getName()));
    }

    // 4) Timetable/Schedule card -> TimetableActivity
    @Test
    public void scheduleCard_opensTimetableActivity() {
        onView(withId(R.id.cardTimetable)).perform(click());
        intended(hasComponent(TimetableActivity.class.getName()));
    }

    // 5) Feedback card -> FeedManagmentActivity
    @Test
    public void feedbackCard_opensFeedManagmentActivity() {
        onView(withId(R.id.cardFeedback)).perform(click());
        intended(hasComponent(FeedManagmentActivity.class.getName()));
    }

    // 6) Notifications card -> ManageAnnouncementsActivity
    @Test
    public void notificationsCard_opensManageAnnouncements() {
        onView(withId(R.id.Notifications)).perform(click());
        intended(hasComponent(ManageAnnouncementsActivity.class.getName()));
    }

    // 7) Payments card -> AdminFeeActivity
    @Test
    public void paymentsCard_opensAdminFeeActivity() {
        onView(withId(R.id.Payments)).perform(click());
        intended(hasComponent(AdminFeeActivity.class.getName()));
    }

    // 8) System Reports card -> SystemReportsActivity
    @Test
    public void systemReportsCard_opensSystemReportsActivity() {
        onView(withId(R.id.SystemReports)).perform(click());
        intended(hasComponent(SystemReportsActivity.class.getName()));
    }

    // 10) Manage User card -> ManageUserActivity
    @Test
    public void manageUserCard_opensManageUserActivity() {
        onView(withId(R.id.cardManageUser)).perform(click());
        intended(hasComponent(ManageUserActivity.class.getName()));
    }

    // 11) Manage Subjects card -> ManageSubjectsActivity
    @Test
    public void manageSubjectsCard_opensManageSubjectsActivity() {
        onView(withId(R.id.cardManageSubjects)).perform(click());
        intended(hasComponent(ManageSubjectsActivity.class.getName()));
    }

    // 12) Manage Classes card -> ManageClassesActivity
    @Test
    public void manageClassesCard_opensManageClassesActivity() {
        onView(withId(R.id.cardManageClasses)).perform(click());
        intended(hasComponent(ManageClassesActivity.class.getName()));
    }
}