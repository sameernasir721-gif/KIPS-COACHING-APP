package com.example.kipscoachingkharian;

import android.view.View;
import android.view.ViewGroup;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.PerformException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.espresso.util.HumanReadables;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Assume;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;


@RunWith(AndroidJUnit4.class)
public class AnnouncementFlowTest {


    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void openAnnouncements_directFromDashboard_headerAndSearchWork() throws InterruptedException {
        login();


        onView(withId(R.id.cardAnnouncements)).perform(scrollTo(), click());


        Thread.sleep(3500);


        onView(withId(R.id.tvStudentInfo)).check(matches(isDisplayed()));
        onView(withId(R.id.etSearch)).check(matches(isDisplayed()));
        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));


        onView(withId(R.id.etSearch))
                .perform(typeText("class"), closeSoftKeyboard());

        Thread.sleep(1000);


        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));


        onView(withId(R.id.etSearch)).perform(androidx.test.espresso.action.ViewActions.clearText());
        Thread.sleep(1000);
        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));
    }

    @Test
    public void openFirstAnnouncement_marksAsSeen() throws InterruptedException {
        login();

        onView(withId(R.id.cardAnnouncements)).perform(scrollTo(), click());
        Thread.sleep(3500);


        Assume.assumeTrue(
                "Test-student ke paas koi announcement maujood nahi — test skip ho raha hai",
                hasAtLeastOneAnnouncement());


        onView(withId(R.id.containerAnnouncements)).perform(clickFirstChild());

        Thread.sleep(500);


        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));
    }


    private void login() throws InterruptedException {
        onView(withId(R.id.etStudentUsername))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));
    }


    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }


    private boolean hasAtLeastOneAnnouncement() {
        final boolean[] result = {false};
        try {
            onView(withId(R.id.containerAnnouncements)).perform(new ViewAction() {
                @Override
                public Matcher<View> getConstraints() {
                    return ViewMatchers.isAssignableFrom(ViewGroup.class);
                }

                @Override
                public String getDescription() {
                    return "Check child count of container.";
                }

                @Override
                public void perform(UiController uiController, View view) {
                    ViewGroup container = (ViewGroup) view;
                    result[0] = container.getChildCount() > 0;
                }
            });
        } catch (Exception ignored) {
            result[0] = false;
        }
        return result[0];
    }


    private static ViewAction clickFirstChild() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(ViewGroup.class);
            }

            @Override
            public String getDescription() {
                return "Click on the first child of a ViewGroup.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                ViewGroup container = (ViewGroup) view;
                if (container.getChildCount() == 0) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException("Container mein koi child hi nahi (list khali hai)"))
                            .build();
                }
                View firstChild = container.getChildAt(0);
                firstChild.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }
}
