package com.example.kipscoachingkharian;

import android.view.View;
import android.view.ViewGroup;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.Espresso.pressBack;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;


@RunWith(AndroidJUnit4.class)
public class StudentDashboardButtonsTest {

    private static final String TEST_EMAIL      = "haleemaiftikhar718@gmail.com";
    private static final String TEST_STUDENT_ID = "student048";
    private static final String TEST_PASSWORD   = "haleemay67?";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void gridCards_eachNavigatesToCorrectScreen() throws InterruptedException {
        login();

        clickDashboardCard(R.id.cardSubjects);
        onView(withId(R.id.toggleLayout)).check(matches(isDisplayed()));
        backToDashboard();

        clickDashboardCard(R.id.cardClassSchedule);
        onView(withId(R.id.tvStudentInfo))
                .check(matches(isDisplayed()));
        backToDashboard();

        clickDashboardCard(R.id.cardStudyMaterial);
        onView(withId(R.id.rvStudyMaterial)).check(matches(isDisplayed()));
        backToDashboard();

        clickDashboardCard(R.id.cardQuizzes);
        onView(withId(R.id.layoutQuizCards)).check(matches(isDisplayed()));
        backToDashboard();

        clickDashboardCard(R.id.cardAssignments);
        onView(withId(R.id.rvAssignments)).check(matches(isDisplayed()));
        backToDashboard();

        clickDashboardCard(R.id.cardReports);
        onView(withId(R.id.chipProgress)).check(matches(isDisplayed()));
        backToDashboard();

        clickDashboardCard(R.id.cardFees);
        onView(withId(R.id.feeContainer)).check(matches(isDisplayed()));
        backToDashboard();

        clickDashboardCard(R.id.cardAnnouncements);
        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));
        backToDashboard();
    }

    @Test
    public void menuIcon_opensNavigationDrawer() throws InterruptedException {
        login();

        onView(withId(R.id.ivMenu)).perform(forceClick());
        Thread.sleep(500);

        onView(withId(R.id.navigationView)).check(matches(isDisplayed()));
    }

    @Test
    public void bottomNav_feedback_navigatesToFeedbackScreen() throws InterruptedException {
        login();

        onView(withId(R.id.nav_bottom_feedback)).perform(forceClick());
        Thread.sleep(2500);

        onView(withId(R.id.layoutSubmitFeedback)).check(matches(isDisplayed()));
    }

    @Test
    public void bottomNav_profile_navigatesToProfileScreen() throws InterruptedException {
        login();

        onView(withId(R.id.nav_bottom_profile)).perform(forceClick());
        Thread.sleep(2000);

        onView(withId(R.id.tv_name)).check(matches(isDisplayed()));
    }

    @Test
    public void bottomNav_home_staysOnDashboard() throws InterruptedException {
        login();

        onView(withId(R.id.nav_bottom_home)).perform(forceClick());
        Thread.sleep(500);

        onView(withId(R.id.tvStudentName)).check(matches(isDisplayed()));
        onView(withId(R.id.bottomNav)).check(matches(isDisplayed()));
    }

    @Test
    public void upcomingScheduleCards_eachNavigatesToCorrectScreen() throws InterruptedException {
        login();

        Thread.sleep(2000);

        onView(withId(R.id.containerUpcomingClasses))
                .perform(scrollTo(), clickFirstChildOf());
        Thread.sleep(1500);
        onView(withId(R.id.containerHistory)).check(matches(isDisplayed()));
        backToDashboard();
        Thread.sleep(500);

        onView(withId(R.id.containerUpcomingQuizzes))
                .perform(scrollTo(), clickFirstChildOf());
        Thread.sleep(1500);
        onView(withId(R.id.layoutQuizCards)).check(matches(isDisplayed()));
        backToDashboard();
        Thread.sleep(500);

        onView(withId(R.id.containerUpcomingAssignments))
                .perform(scrollTo(), clickFirstChildOf());
        Thread.sleep(1500);
        onView(withId(R.id.rvAssignments)).check(matches(isDisplayed()));
    }

    private void login() throws InterruptedException {
        onView(withId(R.id.etStudentUsername))
                .perform(replaceText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(replaceText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(replaceText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);

        onView(withId(R.id.tvStudentName))
                .check(matches(isDisplayed()));
    }

    private void clickDashboardCard(int cardId) throws InterruptedException {
        onView(withId(cardId)).perform(scrollTo(), forceClick());
        Thread.sleep(1500);
    }

    private void backToDashboard() throws InterruptedException {
        pressBack();
        Thread.sleep(1000);
        onView(withId(R.id.tvStudentName)).check(matches(isDisplayed()));
    }

    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }

    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility constraints.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    private static ViewAction clickFirstChildOf() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(ViewGroup.class);
            }

            @Override
            public String getDescription() {
                return "Click the first child view inside this container.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                ViewGroup group = (ViewGroup) view;
                if (group.getChildCount() > 0) {
                    group.getChildAt(0).performClick();
                }
                uiController.loopMainThreadUntilIdle();
            }
        };
    }
}