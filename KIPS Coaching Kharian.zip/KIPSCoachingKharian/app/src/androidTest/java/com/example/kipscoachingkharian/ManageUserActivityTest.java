package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.ManageParentsActivity;
import com.example.kipscoachingkharian.dashboard.ManageStudentActivity;
import com.example.kipscoachingkharian.dashboard.ManageTeacherActivity;
import com.example.kipscoachingkharian.dashboard.ManageUserActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class ManageUserActivityTest {

    private ActivityScenario<ManageUserActivity> scenario;

    @Before
    public void setUp() {
        Intents.init();
        scenario = ActivityScenario.launch(ManageUserActivity.class);
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
        Intents.release();
    }

    @Test
    public void screen_allCardsAreVisible() {
        onView(withId(R.id.cardManageStudent)).check(matches(isDisplayed()));
        onView(withId(R.id.cardManageTeacher)).check(matches(isDisplayed()));
        onView(withId(R.id.cardManageParent)).check(matches(isDisplayed()));
    }

    @Test
    public void studentCard_opensManageStudentActivity() {
        onView(withId(R.id.cardManageStudent)).perform(click());
        intended(hasComponent(ManageStudentActivity.class.getName()));
    }

    @Test
    public void teacherCard_opensManageTeacherActivity() {
        onView(withId(R.id.cardManageTeacher)).perform(click());
        intended(hasComponent(ManageTeacherActivity.class.getName()));
    }

    @Test
    public void parentCard_opensManageParentsActivity() {
        onView(withId(R.id.cardManageParent)).perform(click());
        intended(hasComponent(ManageParentsActivity.class.getName()));
    }
}