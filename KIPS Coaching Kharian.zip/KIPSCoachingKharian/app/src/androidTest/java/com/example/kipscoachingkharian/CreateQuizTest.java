package com.example.kipscoachingkharian;

import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.TimePicker;

import androidx.test.espresso.contrib.PickerActions;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isPlatformPopup;
import static androidx.test.espresso.matcher.ViewMatchers.hasSibling;
import static androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withHint;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.equalTo;


@RunWith(AndroidJUnit4.class)
public class CreateQuizTest {

    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    private static final String SUBJECT = "Mathematics";
    private static final String GRADE   = "10A";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    @Test
    public void createQuiz_shareWithClass_verifyInList() throws InterruptedException {

        String uniqueTitle = "Test Quiz "
                + new SimpleDateFormat("dd-MMM HH:mm:ss", Locale.getDefault())
                .format(Calendar.getInstance().getTime());

        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        onView(withId(R.id.btnTeacherLogin)).perform(click());

        Thread.sleep(10000);

        onView(withId(R.id.tvTeacherName))
                .check(matches(isDisplayed()));

        onView(withId(R.id.cardQuizzes)).perform(scrollTo(), click());
        Thread.sleep(3000);

        onView(withId(R.id.btnCreate)).perform(scrollTo(), click());
        Thread.sleep(2000);

        onView(withId(R.id.etQuizTitle))
                .perform(scrollTo(), typeText(uniqueTitle), closeSoftKeyboard());

        onView(withId(R.id.spinnerSubject)).perform(scrollTo(), click());
        onView(withText(SUBJECT)).inRoot(isPlatformPopup()).perform(click());

        onView(withId(R.id.spinnerClass)).perform(scrollTo(), click());
        onView(withText(GRADE)).inRoot(isPlatformPopup()).perform(click());

        onView(withId(R.id.spinnerQuestionType)).perform(scrollTo(), click());
        onView(withText("MCQs")).inRoot(isPlatformPopup()).perform(click());

        onView(withId(R.id.etTimeLimit))
                .perform(scrollTo(), typeText("15"), closeSoftKeyboard());

        onView(withId(R.id.tvStartDate)).perform(scrollTo(), click());
        Thread.sleep(500);
        onView(withId(android.R.id.button1)).perform(click());

        onView(withId(R.id.tvStartTime)).perform(scrollTo(), click());
        Thread.sleep(500);
        onView(withId(android.R.id.button1)).perform(click());

        onView(withId(R.id.tvEndDate)).perform(scrollTo(), click());
        Thread.sleep(500);
        Calendar endCal = Calendar.getInstance();
        endCal.add(Calendar.DAY_OF_MONTH, 7);
        onView(withClassName(equalTo(DatePicker.class.getName()))).perform(
                PickerActions.setDate(
                        endCal.get(Calendar.YEAR),
                        endCal.get(Calendar.MONTH) + 1,
                        endCal.get(Calendar.DAY_OF_MONTH)));
        onView(withId(android.R.id.button1)).perform(click());


        onView(withId(R.id.tvEndTime)).perform(scrollTo(), click());
        Thread.sleep(500);
        onView(withId(android.R.id.button1)).perform(click());

        onView(withId(R.id.etQuizDescription))
                .perform(scrollTo(), typeText("Yeh ek automated Espresso test se banaya gaya quiz hai."),
                        closeSoftKeyboard());

        onView(withId(R.id.btnAddQuestion)).perform(scrollTo(), click());
        Thread.sleep(500);

        onView(withHint("Enter question 1"))
                .perform(scrollTo(), typeText("2 + 2 kitne hote hain?"), closeSoftKeyboard());

        onView(withHint("Option A")).perform(scrollTo(), typeText("3"), closeSoftKeyboard());
        onView(withHint("Option B")).perform(scrollTo(), typeText("4"), closeSoftKeyboard());
        onView(withHint("Option C")).perform(scrollTo(), typeText("5"), closeSoftKeyboard());
        onView(withHint("Option D")).perform(scrollTo(), typeText("6"), closeSoftKeyboard());

        onView(allOf(isAssignableFrom(RadioButton.class), hasSibling(withHint("Option B"))))
                .perform(scrollTo(), click());


        onView(withId(R.id.btnShareQuiz)).perform(click());

        Thread.sleep(6000);

        onView(withId(R.id.btnCreate))
                .check(matches(isDisplayed()));
    }
}