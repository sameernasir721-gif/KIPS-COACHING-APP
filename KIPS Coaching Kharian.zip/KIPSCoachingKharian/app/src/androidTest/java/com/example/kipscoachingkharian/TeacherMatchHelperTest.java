package com.example.kipscoachingkharian;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.example.kipscoachingkharian.dashboard.TeacherMatchHelper;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;


public class TeacherMatchHelperTest {

    private static Set<String> set(String... items) {
        return new HashSet<>(Arrays.asList(items));
    }


    @Test
    public void subject_trailingSpaceAndCase_areIgnored() {
        assertEquals("computer", TeacherMatchHelper.normalizeSubject("Computer "));
        assertEquals("physics", TeacherMatchHelper.normalizeSubject("PHYSICS"));
        assertEquals("", TeacherMatchHelper.normalizeSubject(null));
    }

    @Test
    public void matchedSubjects_ignoresCaseAndSpaces_returnsTrimmedTeacherName() {

        Set<String> enrolled = set("computer", "physics");
        assertEquals(Arrays.asList("Computer", "PHYSICS"),
                TeacherMatchHelper.matchedSubjects(
                        Arrays.asList("Computer ", "PHYSICS", "Biology"), enrolled));
    }

    @Test
    public void matchedSubjects_noOverlap_isEmpty() {
        assertTrue(TeacherMatchHelper.matchedSubjects(
                Arrays.asList("Urdu", "English"), set("physics")).isEmpty());
    }

    @Test
    public void matchedSubjects_duplicatesAreRemoved() {
        assertEquals(Collections.singletonList("Physics"),
                TeacherMatchHelper.matchedSubjects(
                        Arrays.asList("Physics", "physics ", "PHYSICS"), set("physics")));
    }

    @Test
    public void matchedSubjects_nullInputs_areSafe() {
        assertTrue(TeacherMatchHelper.matchedSubjects(null, set("physics")).isEmpty());
        assertTrue(TeacherMatchHelper.matchedSubjects(Arrays.asList("Physics"), null).isEmpty());
    }


    @Test
    public void splitList_trimsAndDropsBlanksAndDashPlaceholder() {
        assertEquals(Arrays.asList("9A", "10B"), TeacherMatchHelper.splitList(" 9A , ,10B,"));
        assertTrue(TeacherMatchHelper.splitList("-").isEmpty());
        assertTrue(TeacherMatchHelper.splitList(null).isEmpty());
        assertTrue(TeacherMatchHelper.splitList("").isEmpty());
    }


    @Test
    public void normalizeClass_variants_allBecome9A() {
        assertEquals("9A", TeacherMatchHelper.normalizeClass("9A"));
        assertEquals("9A", TeacherMatchHelper.normalizeClass("Class 9a"));
        assertEquals("9A", TeacherMatchHelper.normalizeClass(" 9 A "));
        assertEquals("", TeacherMatchHelper.normalizeClass(null));
    }

    @Test
    public void studentClass_approvedFormat_9A() {
        // Approval ke baad: className="9A", assignedSection="A"
        Set<String> c = TeacherMatchHelper.studentClassCandidates("9A", "A");
        assertEquals(set("9A"), c);
        assertEquals("9A", TeacherMatchHelper.studentClassLabel("9A", "A"));
    }

    @Test
    public void studentClass_numberOnlyPlusSection_addsCombined() {
        assertEquals(set("9", "9B"), TeacherMatchHelper.studentClassCandidates("9", "B"));
        assertEquals("9B", TeacherMatchHelper.studentClassLabel("9", "B"));
    }

    @Test
    public void studentClass_ordinalPlusSection_addsCombined() {
        assertEquals(set("9TH", "9A"), TeacherMatchHelper.studentClassCandidates("9th", "A"));
        assertEquals("9A", TeacherMatchHelper.studentClassLabel("9th", "A"));
    }

    @Test
    public void studentClass_sectionAlreadyInClassName_isNotMixedWithOtherSection() {

        assertEquals(set("9A"), TeacherMatchHelper.studentClassCandidates("9A", "B"));
    }

    @Test
    public void studentClass_unknown_isEmpty() {
        assertTrue(TeacherMatchHelper.studentClassCandidates(null, null).isEmpty());
        assertTrue(TeacherMatchHelper.studentClassCandidates("  ", "").isEmpty());
        assertEquals("", TeacherMatchHelper.studentClassLabel(null, null));
    }


    @Test
    public void teachesClass_sameClass_true() {
        assertTrue(TeacherMatchHelper.teachesClass(
                Arrays.asList("9A", "10B"), set("9A")));
    }

    @Test
    public void teachesClass_differentSection_false() {
        assertFalse(TeacherMatchHelper.teachesClass(
                Arrays.asList("9B", "10A"), set("9A")));
    }

    @Test
    public void teachesClass_teacherWrittenAsClass9a_true() {
        assertTrue(TeacherMatchHelper.teachesClass(
                Arrays.asList("Class 9a"), set("9A")));
    }

    @Test
    public void teachesClass_teacherHasNoClasses_false_whenStudentClassKnown() {
        assertFalse(TeacherMatchHelper.teachesClass(Collections.<String>emptyList(), set("9A")));
        assertFalse(TeacherMatchHelper.teachesClass(null, set("9A")));
    }

    @Test
    public void teachesClass_studentClassUnknown_noClassFilter() {
        assertTrue(TeacherMatchHelper.teachesClass(Arrays.asList("9A"), Collections.<String>emptySet()));
        assertTrue(TeacherMatchHelper.teachesClass(Collections.<String>emptyList(), Collections.<String>emptySet()));
    }

    @Test
    public void teachesClass_legacyNumberOnlyStudent_matchesEitherForm() {
        Set<String> cands = TeacherMatchHelper.studentClassCandidates("9", "A"); // {"9","9A"}
        assertTrue(TeacherMatchHelper.teachesClass(Arrays.asList("9A"), cands));
        assertTrue(TeacherMatchHelper.teachesClass(Arrays.asList("9"), cands));
        assertFalse(TeacherMatchHelper.teachesClass(Arrays.asList("9B"), cands));
    }


    @Test
    public void scenario_studentOfClass9A_physicsAndComputer() {
        Set<String> enrolled = set("physics", "computer");
        Set<String> cands = TeacherMatchHelper.studentClassCandidates("9A", "A");


        assertTrue(shows(Arrays.asList("Physics"), Arrays.asList("9A", "9B"), enrolled, cands));

        assertTrue(shows(Arrays.asList("Computer "), Arrays.asList("9A"), enrolled, cands));

        assertFalse(shows(Arrays.asList("Physics"), Arrays.asList("10A"), enrolled, cands));

        assertFalse(shows(Arrays.asList("Biology"), Arrays.asList("9A"), enrolled, cands));

        assertEquals(Collections.singletonList("Physics"),
                TeacherMatchHelper.matchedSubjects(Arrays.asList("Physics", "Biology"), enrolled));
    }

    private static boolean shows(java.util.List<String> teacherSubjects,
                                 java.util.List<String> teacherClasses,
                                 Set<String> enrolled, Set<String> cands) {
        return !TeacherMatchHelper.matchedSubjects(teacherSubjects, enrolled).isEmpty()
                && TeacherMatchHelper.teachesClass(teacherClasses, cands);
    }
}