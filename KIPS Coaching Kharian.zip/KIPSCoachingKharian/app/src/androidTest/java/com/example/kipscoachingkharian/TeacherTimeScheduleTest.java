package com.example.kipscoachingkharian;

import android.os.Environment;

import androidx.test.espresso.Espresso;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

@RunWith(AndroidJUnit4.class)
public class TeacherTimeScheduleTest {

    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(500);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    private int countTimetableFiles(File dir) {
        if (dir == null || !dir.exists()) return 0;
        File[] files = dir.listFiles((d, name) ->
                name.startsWith("KIPS_Timetable_") && name.endsWith(".pdf"));
        return files == null ? 0 : files.length;
    }

    @Test
    public void viewAndDownloadTimetablePdf() throws InterruptedException {

        UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());

        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(20);

        boolean onCorrectScreen = false;
        for (int attempt = 1; attempt <= 3 && !onCorrectScreen; attempt++) {
            onView(withId(R.id.TimeSchedule)).perform(scrollTo(), click());
            Thread.sleep(2500);
            try {
                onView(withId(R.id.layoutPdfActions)).check(matches(isDisplayed()));
                onCorrectScreen = true;
            } catch (Exception e) {
                System.out.println("⚠️ Attempt " + attempt + ": Time Schedule screen nahi khuli, " +
                        "UiDevice back dabaa kar dobara try kar rahe hain...");
                device.pressBack();
                Thread.sleep(1500);
            }
        }
        org.junit.Assert.assertTrue("3 koshishon ke baad bhi Time Schedule screen nahi khuli!",
                onCorrectScreen);

        System.out.println("➡️ 'View' button dabate hain (asal PDF viewer/browser khulegi)...");
        onView(withId(R.id.btnViewTimetablePdf)).perform(click());
        Thread.sleep(4000);

        System.out.println("➡️ UiDevice back se wapas app mein aa rahe hain...");
        device.pressBack();
        Thread.sleep(2000);

        onView(withId(R.id.layoutPdfActions)).check(matches(isDisplayed()));
        System.out.println("✅ 'View' se PDF khuli aur wapas app mein aa gaye.");

        System.out.println("➡️ 'Share' (Download) button dabate hain...");

        File downloadsDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS);
        int filesBefore = countTimetableFiles(downloadsDir);

        onView(withId(R.id.btnShareTimetablePdf)).perform(click());

        boolean downloaded = false;
        for (int i = 0; i < 20; i++) {
            Thread.sleep(1000);
            int filesNow = countTimetableFiles(downloadsDir);
            if (filesNow > filesBefore) {
                downloaded = true;
                break;
            }
        }

        if (downloaded) {
            System.out.println("✅ PDF Downloads folder mein successfully download ho gayi!");
        } else {
            System.out.println("⚠️ 20 second mein download confirm nahi hui.");
        }

        org.junit.Assert.assertTrue(
                "Timetable PDF Downloads folder mein download nahi hui!", downloaded);

        System.out.println("✅ Time Schedule (View + Download) test pass ho gaya!");
    }
}