package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.action.ViewActions.swipeLeft;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.test.espresso.PerformException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.espresso.util.HumanReadables;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class TeacherAnnouncementsTest {

    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    public static ViewAction readFirstChildTextWithId(final int id, final String[] outValue) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(ViewGroup.class);
            }

            @Override
            public String getDescription() {
                return "Read text of a TextView inside the first child of a container.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                ViewGroup container = (ViewGroup) view;
                if (container.getChildCount() == 0) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException("Container khali hai"))
                            .build();
                }
                View firstChild = container.getChildAt(0);
                View target = firstChild.findViewById(id);
                if (target instanceof TextView) {
                    outValue[0] = ((TextView) target).getText().toString();
                }
            }
        };
    }

    public static ViewAction swipeFirstChildLeft() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(ViewGroup.class);
            }

            @Override
            public String getDescription() {
                return "Swipe left on the first child of a container.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                ViewGroup container = (ViewGroup) view;
                if (container.getChildCount() == 0) {
                    throw new PerformException.Builder()
                            .withActionDescription(this.getDescription())
                            .withViewDescription(HumanReadables.describe(view))
                            .withCause(new RuntimeException("Container khali hai, swipe nahi ho sakta"))
                            .build();
                }
                View firstChild = container.getChildAt(0);
                swipeLeft().perform(uiController, firstChild);
            }
        };
    }

    public static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility check.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(1000);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    @Test
    public void searchAndDeleteAnnouncement() throws InterruptedException {

        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(25);

        androidx.test.espresso.Espresso.closeSoftKeyboard();
        Thread.sleep(500);
        onView(withId(R.id.nav_bottom_Announcment)).perform(forceClick());
        Thread.sleep(2500);

        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));

        String[] firstTitle = new String[1];
        onView(withId(R.id.containerAnnouncements))
                .perform(readFirstChildTextWithId(R.id.tvItemTitle, firstTitle));

        if (firstTitle[0] != null && !firstTitle[0].isEmpty()) {
            String searchTerm = firstTitle[0].length() > 4
                    ? firstTitle[0].substring(0, 4) : firstTitle[0];
            onView(withId(R.id.etSearchAnnouncements))
                    .perform(replaceText(searchTerm), closeSoftKeyboard());
            Thread.sleep(1000);

            onView(withId(R.id.containerAnnouncements))
                    .check(matches(hasDescendant(
                            ViewMatchers.withText(org.hamcrest.Matchers.containsString(searchTerm)))));

            onView(withId(R.id.etSearchAnnouncements)).perform(
                    androidx.test.espresso.action.ViewActions.clearText(), closeSoftKeyboard());
            Thread.sleep(1000);
        }

        int[] countBefore = new int[1];
        onView(withId(R.id.containerAnnouncements)).perform(readChildCount(countBefore));

        onView(withId(R.id.containerAnnouncements)).perform(swipeFirstChildLeft());
        Thread.sleep(1500);

        int[] countAfter = new int[1];
        onView(withId(R.id.containerAnnouncements)).perform(readChildCount(countAfter));

        org.junit.Assert.assertEquals(
                "Delete ke baad announcement count 1 kam hona chahiye tha!",
                countBefore[0] - 1, countAfter[0]);
    }

    public static ViewAction readChildCount(final int[] outCount) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(ViewGroup.class);
            }

            @Override
            public String getDescription() {
                return "Read child count of a container.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                outCount[0] = ((ViewGroup) view).getChildCount();
            }
        };
    }

    private static Matcher<View> withText_exact(String text) {
        return ViewMatchers.withText(text);
    }
}