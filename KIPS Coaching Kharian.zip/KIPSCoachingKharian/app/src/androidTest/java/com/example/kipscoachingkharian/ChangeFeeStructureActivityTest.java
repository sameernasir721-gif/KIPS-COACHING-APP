package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isDialog;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withHint;
import static androidx.test.espresso.matcher.ViewMatchers.withTagValue;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertTrue;

import android.view.View;
import android.widget.ImageView;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.dashboard.ChangeFeeStructureActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;


@RunWith(AndroidJUnit4.class)
public class ChangeFeeStructureActivityTest {

    private static final long SLEEP_MS = 1500L;

    private ActivityScenario<ChangeFeeStructureActivity> scenario;

    @Before
    public void launchActivity() {
        scenario = ActivityScenario.launch(ChangeFeeStructureActivity.class);
        sleep(SLEEP_MS);
    }

    @After
    public void closeActivity() {
        if (scenario != null) {
            scenario.close();
        }
    }

    @Test
    public void toolbarTitle_isDisplayed() {
        onView(withText("Change Fee Structure")).check(matches(isDisplayed()));
    }

    @Test
    public void sectionHeader_isDisplayed() {
        onView(withText("Update fee amounts (Rs.) used for challan generation"))
                .check(matches(isDisplayed()));
    }

    @Test
    public void feeCards_labelsAreDisplayed() {
        onView(withText("📘  Regular Subject Fee")).check(matches(isDisplayed()));
        onView(withText("📗  Special Subject Fee")).check(matches(isDisplayed()));
        onView(withText("🗓  Registration Deadline")).check(matches(isDisplayed()));
    }

    @Test
    public void saveButton_isDisplayed() {
        onView(withText("SAVE CHANGES")).check(matches(isDisplayed()));
    }

    @Test
    public void regularFeeInput_acceptsNumericValue() {
        onView(withHint("e.g. 3000"))
                .perform(clearText(), typeText("3500"), closeSoftKeyboard());

        onView(withHint("e.g. 3000")).check(matches(withText("3500")));
    }

    @Test
    public void specialFeeInput_acceptsNumericValue() {
        onView(withHint("e.g. 2500"))
                .perform(clearText(), typeText("2800"), closeSoftKeyboard());

        onView(withHint("e.g. 2500")).check(matches(withText("2800")));
    }

    @Test
    public void emptyFeeFields_showsValidationToast_onSave() {
        onView(withHint("e.g. 3000")).perform(clearText(), closeSoftKeyboard());
        onView(withHint("e.g. 2500")).perform(clearText(), closeSoftKeyboard());

        onView(withText("SAVE CHANGES")).perform(click());

        onView(testStatusMatcher()).check(matches(withText("Please fill the fee fields.")));
    }

    @Test
    public void deadlineField_isNotDirectlyEditable() {
        onView(withHint("Tap to select date & time")).check(matches(isDisplayed()));
    }

    @Test
    public void tappingDeadlineField_opensDatePickerDialog() {
        onView(withHint("Tap to select date & time")).perform(click());
        sleep(500);

        onView(isRoot()).inRoot(isDialog()).check(matches(isDisplayed()));
    }

    @Test
    public void clearDeadlineLink_emptiesTheField() {
        onView(withText("Clear (no deadline — always open)")).perform(click());
        sleep(200);

        onView(withHint("Tap to select date & time")).check(matches(withText("")));
    }

    @Test
    public void validFeeValues_saveSuccessfully_showsSuccessToast() {
        onView(withHint("e.g. 3000")).perform(clearText(), typeText("3200"), closeSoftKeyboard());
        onView(withHint("e.g. 2500")).perform(clearText(), typeText("2600"), closeSoftKeyboard());
        onView(withText("Clear (no deadline — always open)")).perform(click());

        onView(withText("SAVE CHANGES")).perform(click());
        sleep(SLEEP_MS);

        onView(testStatusMatcher())
                .check(matches(withText("Fee structure & deadline updated successfully.")));
    }

    @Test
    public void backIcon_finishesActivity() {
        onView(allOf(withClassName(equalTo(ImageView.class.getName())), isDisplayed()))
                .perform(click());
        sleep(300);

        assertTrue(scenario.getState().isAtLeast(androidx.lifecycle.Lifecycle.State.DESTROYED)
                || scenario.getState() == androidx.lifecycle.Lifecycle.State.CREATED);
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static org.hamcrest.Matcher<View> testStatusMatcher() {
        return withTagValue(equalTo((Object) "test_status_message"));
    }

    private static org.hamcrest.Matcher<View> isRoot() {
        return androidx.test.espresso.matcher.ViewMatchers.isRoot();
    }
}