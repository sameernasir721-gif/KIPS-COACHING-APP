package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.isPlatformPopup;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;

import android.view.WindowManager;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.ManageAnnouncementsActivity;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class ManageAnnouncementsActivityTest {

    private ActivityScenario<ManageAnnouncementsActivity> scenario;

    @Before
    public void setUp() {
        scenario = ActivityScenario.launch(ManageAnnouncementsActivity.class);
        try { Thread.sleep(4000); } catch (InterruptedException ignored) {}
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
    }

    @Test
    public void screen_elementsAreVisible() {
        onView(withId(R.id.ivBack)).check(matches(isDisplayed()));
        onView(withId(R.id.tvTotalAnnouncementsCount)).check(matches(isDisplayed()));
        onView(withId(R.id.tvAnnouncementAllCount)).check(matches(isDisplayed()));
        onView(withId(R.id.tvAnnouncementClassCount)).check(matches(isDisplayed()));
        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));
        onView(withText("➕ New Announcement")).check(matches(isDisplayed()));
    }

    @Test
    public void backButton_finishesActivity() {
        onView(withId(R.id.ivBack)).perform(click());
        assertTrue("Activity should be in DESTROYED state after tapping the back button",
                scenario.getState() == Lifecycle.State.DESTROYED);
    }

    @Test
    public void newAnnouncementButton_opensCreateDialogWithAllFields() {
        onView(withText("➕ New Announcement")).perform(click());

        onView(withText("📢 New Announcement")).check(matches(isDisplayed()));
        onView(withText("Title:")).check(matches(isDisplayed()));
        onView(withText("Message:")).check(matches(isDisplayed()));
        onView(withText("Send To:")).check(matches(isDisplayed()));
        onView(withText("Target Class:")).check(matches(isDisplayed()));
        onView(withText("Post")).check(matches(isDisplayed()));
        onView(withText("Cancel")).check(matches(isDisplayed()));
    }

    @Test
    public void emptyTitleAndMessage_showsWarningToast_andDoesNotPost() {
        onView(withText("➕ New Announcement")).perform(click());
        onView(withText("Post")).perform(click());

        onView(withText("Title and Message are required!"))
                .inRoot(isToast())
                .check(matches(isDisplayed()));

        assertTrue(scenario.getState() == Lifecycle.State.RESUMED);
    }

    private static Matcher<androidx.test.espresso.Root> isToast() {
        return new TypeSafeMatcher<androidx.test.espresso.Root>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("is toast");
            }

            @Override
            public boolean matchesSafely(androidx.test.espresso.Root root) {
                return root.getWindowLayoutParams().get().type == WindowManager.LayoutParams.TYPE_TOAST;
            }
        };
    }

    @Test
    public void selectingTeachersAudience_hidesTargetClassField() {
        onView(withText("➕ New Announcement")).perform(click());

        onView(withText("Students")).perform(click());
        onData(allOf(instanceOf(String.class), is("Teachers")))
                .inRoot(isPlatformPopup())
                .perform(click());

        onView(withText("Target Class:")).check(
                androidx.test.espresso.assertion.ViewAssertions.matches(
                        org.hamcrest.CoreMatchers.not(isDisplayed())));
    }

    @Test
    public void cancelButton_dismissesCreateDialog() {
        onView(withText("➕ New Announcement")).perform(click());
        onView(withText("Cancel")).perform(click());

        assertTrue(scenario.getState() == Lifecycle.State.RESUMED);
        onView(withText("📢 New Announcement")).check(
                androidx.test.espresso.assertion.ViewAssertions.doesNotExist());
    }
}