package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.FeedManagmentActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class FeedManagmentActivityTest {

    private ActivityScenario<FeedManagmentActivity> scenario;

    @Before
    public void setUp() {
        scenario = ActivityScenario.launch(FeedManagmentActivity.class);
        try { Thread.sleep(3000); } catch (InterruptedException ignored) {}
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
    }

    @Test
    public void screen_elementsAreVisible() {
        onView(withId(R.id.containerFeedbacks)).check(matches(isDisplayed()));
        onView(withId(R.id.btnBackFeedback)).check(matches(isDisplayed()));
    }

    @Test
    public void afterDataLoad_activityIsStillRunning() {
        assertTrue("Activity should be in RESUMED state after data loads",
                scenario.getState() == Lifecycle.State.RESUMED);
    }

    @Test
    public void backButton_finishesActivity() {
        onView(withId(R.id.btnBackFeedback)).perform(click());

        assertTrue("Activity should be in DESTROYED state after tapping the back button",
                scenario.getState() == Lifecycle.State.DESTROYED);
    }
}