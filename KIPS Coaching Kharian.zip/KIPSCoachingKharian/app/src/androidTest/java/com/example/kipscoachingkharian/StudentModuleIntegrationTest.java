package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.Espresso.pressBack;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.any;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class StudentModuleIntegrationTest {

    private static final String TEST_EMAIL      = "raffaymirza8@gmail.com";
    private static final String TEST_STUDENT_ID = "student051";
    private static final String TEST_PASSWORD   = "raffay789!";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void fullStudentJourney_loginThroughAllFeaturesAndLogout() throws InterruptedException {

        login();
        assertOnDashboard();

        onView(withId(R.id.cardSubjects)).perform(click());
        Thread.sleep(3000);

        onView(withId(R.id.cardSubject1)).check(matches(isDisplayed()));
        onView(withId(R.id.cardSubject1)).perform(click());
        Thread.sleep(3000);

        onView(withId(R.id.rvStudyMaterial)).check(matches(isDisplayed()));

        pressBack();
        Thread.sleep(500);
        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        onView(withId(R.id.cardStudyMaterial)).perform(click());
        Thread.sleep(3000);

        onView(withId(R.id.rvStudyMaterial)).check(matches(isDisplayed()));
        onView(withId(R.id.containerSubjectChips)).check(matches(isDisplayed()));

        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        onView(withId(R.id.cardQuizzes)).perform(click());
        Thread.sleep(3000);

        onView(first(allOf(withText("Start Quiz"), isDisplayed()))).perform(click());
        Thread.sleep(2000);

        onView(withId(R.id.tvDialogQuizTitle)).check(matches(isDisplayed()));
        onView(withId(R.id.btnSubmitQuiz)).perform(click());
        Thread.sleep(3000);

        onView(first(withText(containsString("Score")))).check(matches(isDisplayed()));

        onView(withText("Done")).perform(click());
        Thread.sleep(1000);

        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        onView(withId(R.id.cardAssignments)).perform(click());
        Thread.sleep(3000);

        onView(withId(R.id.rvAssignments)).check(matches(isDisplayed()));
        onView(withId(R.id.rvAssignments))
                .perform(RecyclerViewActions.actionOnItemAtPosition(0, clickChildViewWithId(R.id.btnView)));
        Thread.sleep(1000);

        onView(withId(R.id.tvDialogTitle)).check(matches(isDisplayed()));

        pressBack();
        Thread.sleep(500);
        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        onView(withId(R.id.cardReports)).perform(click());
        Thread.sleep(3000);

        assertListOrEmptyDisplayed(R.id.rvProgress);

        onView(withId(R.id.chipReport)).perform(click());
        Thread.sleep(1500);
        onView(withId(R.id.layoutReportSection)).check(matches(isDisplayed()));

        onView(withId(R.id.chipProgress)).perform(click());
        Thread.sleep(500);
        onView(withId(R.id.layoutProgressSection)).check(matches(isDisplayed()));

        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        onView(withId(R.id.cardFees)).perform(scrollTo(), click());
        Thread.sleep(3000);

        onView(withId(R.id.tvStudentNameFee)).check(matches(isDisplayed()));

        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        onView(withId(R.id.cardAnnouncements)).perform(scrollTo(), click());
        Thread.sleep(3500);

        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));
        onView(withId(R.id.etSearch)).check(matches(isDisplayed()));

        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        onView(withId(R.id.nav_bottom_feedback)).perform(forceClick());
        Thread.sleep(2500);

        onView(withId(R.id.layoutSubmitFeedback)).check(matches(isDisplayed()));

        onView(withId(R.id.nav_bottom_home)).perform(forceClick());
        Thread.sleep(2000);
        assertOnDashboard();

        onView(withId(R.id.nav_bottom_profile)).perform(forceClick());
        Thread.sleep(2500);

        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
        onView(withId(R.id.item_notifications)).check(matches(isDisplayed()));
        onView(withId(R.id.item_settings)).check(matches(isDisplayed()));
        onView(withId(R.id.item_help)).check(matches(isDisplayed()));

        onView(withId(R.id.item_my_profile)).perform(click());
        Thread.sleep(2500);

        onView(withId(R.id.etEmail))
                .check(matches(isDisplayed()))
                .check(matches(withText(TEST_EMAIL)));

        onView(withId(R.id.btnBack)).perform(click());
        Thread.sleep(500);
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));

        onView(withId(R.id.item_logout)).perform(click());
        Thread.sleep(500);

        onView(withText("Do you want to logout?")).check(matches(isDisplayed()));
        onView(withText("Yes, Logout")).perform(click());
        Thread.sleep(2000);

        onView(withId(R.id.etStudentUsername)).check(matches(isDisplayed()));
        onView(withId(R.id.btnStudentLogin)).check(matches(isDisplayed()));
    }

    private void login() throws InterruptedException {
        onView(withId(R.id.etStudentUsername))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);
    }

    private void assertOnDashboard() {
        onView(withId(R.id.tvStudentName)).check(matches(isDisplayed()));
    }

    private void assertListOrEmptyDisplayed(int listViewId) {
        boolean listVisible = isViewDisplayed(listViewId);
        boolean emptyVisible = isViewDisplayed(R.id.layoutEmpty);
        assertTrue("Na to list na hi empty-state dikh rahi — screen crash/broken lagti hai",
                listVisible || emptyVisible);
    }

    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }

    private static Matcher<View> first(final Matcher<View> matcher) {
        return new TypeSafeMatcher<View>() {
            boolean isFirstMatchFound = false;

            @Override
            public void describeTo(Description description) {
                description.appendText("should return first matching view");
            }

            @Override
            public boolean matchesSafely(View view) {
                if (isFirstMatchFound) {
                    return false;
                }
                if (matcher.matches(view)) {
                    isFirstMatchFound = true;
                    return true;
                }
                return false;
            }
        };
    }

    private static ViewAction clickChildViewWithId(final int id) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return any(View.class);
            }

            @Override
            public String getDescription() {
                return "Click on a child view with specified id.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View v = view.findViewById(id);
                if (v != null) {
                    v.performClick();
                }
            }
        };
    }

    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isEnabled();
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing the 90%-visible constraint.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }
}