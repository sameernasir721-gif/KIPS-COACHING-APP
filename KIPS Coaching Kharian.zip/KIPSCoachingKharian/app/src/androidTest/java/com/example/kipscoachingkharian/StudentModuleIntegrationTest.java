package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.StudentLoginActivity;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.Espresso.pressBack;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.any;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.assertTrue;

/**
 * Student Module — FULL INTEGRATION TEST.
 *
 * Yeh saari individual flow-tests (StudentLoginFlowTest, SubjectsFlowTest,
 * StudyMaterialFlowTest, QuizFlowTest, AssignmentFlowTest, ProgressFlowTest,
 * FeeFlowTest, AnnouncementFlowTest, FeedbackFlowTest, ProfileFlowTest) ko
 * "unit" ki tarah alag-alag test karti hain. YEH test un sab se alag hai —
 * yeh EK HI continuous session mein Login se Logout tak, ek-ke-baad-ek
 * saari screens explore karta hai, taake yeh confirm ho:
 *   (a) Dashboard se launch hone wali har Activity apni jagah par sahi
 *       khulti/kaam karti hai,
 *   (b) har screen se "back" dabane par student wapas sahi tarah Dashboard
 *       par pahunchta hai (activity back-stack toot-ta nahi),
 *   (c) poore session mein kahin bhi crash nahi hota,
 *   (d) session ke bilkul end mein Logout karke Login screen par wapas
 *       aana kaam karta hai.
 *
 * Is test ka scope: "screen khulti hai aur crash nahi hoti" (smoke-level)
 * — har screen ke deep/edge-case validations (jaise Fee ka Unpaid/Paid
 * scenario, ya Registration ki field-by-field validation) un-ki apni
 * dedicated flow-test files mein already covered hain; unhein yahan
 * dobara nahi dohraya gaya taake yeh integration test focused aur
 * maintainable rahe.
 *
 * IMPORTANT — is test ke end mein STUDENT LOGOUT ho jata hai. Agar isi
 * test-suite (class) mein koi aur test bhi run ho raha ho jo login state
 * par depend karta ho, to yeh test aakhir mein rakhein ya alag se chalayen.
 *
 * IMPORTANT: Neeche apni asal test-student ki details daalein. Yeh test
 * tabhi mukammal tarah pass hoga jab test-student ke paas: kam se kam 1
 * enrolled subject, kam se kam 1 "Start Quiz" state wala quiz, aur kam se
 * kam 1 shared assignment ho.
 */
@RunWith(AndroidJUnit4.class)
public class StudentModuleIntegrationTest {

    // ── Yahan apni test-student ki details daalein ─────────────────────────
    private static final String TEST_EMAIL      = "raffaymirza8@gmail.com";
    private static final String TEST_STUDENT_ID = "student051";
    private static final String TEST_PASSWORD   = "raffay789!";

    @Rule
    public ActivityScenarioRule<StudentLoginActivity> activityRule =
            new ActivityScenarioRule<>(StudentLoginActivity.class);

    @Test
    public void fullStudentJourney_loginThroughAllFeaturesAndLogout() throws InterruptedException {

        // ═══════════════════════════════════════════════════════════════════
        // STEP 1 — LOGIN
        // ═══════════════════════════════════════════════════════════════════
        login();
        assertOnDashboard();

        // ═══════════════════════════════════════════════════════════════════
        // STEP 2 — SUBJECTS → (subject-card click) → STUDY MATERIAL
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.cardSubjects)).perform(click());
        Thread.sleep(3000);

        onView(withId(R.id.cardSubject1)).check(matches(isDisplayed()));
        onView(withId(R.id.cardSubject1)).perform(click());
        Thread.sleep(3000);

        onView(withId(R.id.rvStudyMaterial)).check(matches(isDisplayed()));

        // Study Material se, phir Subjects list se — 2 baar back dabayen
        pressBack();
        Thread.sleep(500);
        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        // ═══════════════════════════════════════════════════════════════════
        // STEP 3 — STUDY MATERIAL (direct, dashboard se)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.cardStudyMaterial)).perform(click());
        Thread.sleep(3000);

        onView(withId(R.id.rvStudyMaterial)).check(matches(isDisplayed()));
        onView(withId(R.id.containerSubjectChips)).check(matches(isDisplayed()));

        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        // ═══════════════════════════════════════════════════════════════════
        // STEP 4 — QUIZZES (attempt + submit)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.cardQuizzes)).perform(click());
        Thread.sleep(3000);

        onView(first(allOf(withText("Start Quiz"), isDisplayed()))).perform(click());
        Thread.sleep(2000);

        onView(withId(R.id.tvDialogQuizTitle)).check(matches(isDisplayed()));
        onView(withId(R.id.btnSubmitQuiz)).perform(click());
        Thread.sleep(3000);

        onView(first(withText(containsString("Score")))).check(matches(isDisplayed()));

        // NOTE: Result screen ek NAYI Activity (QuizResultActivity) nahi
        // hai — asal code (QuizActivity.java) confirm karta hai ke submit
        // hone ke baad dialog.dismiss() (attempt-dialog band) ke turant
        // baad showResultDialog(...) sirf EK AUR DIALOG dikhata hai, usi
        // QuizActivity ke andar. Uska button ".setPositiveButton("Done",
        // null)" hai — matlab "Done" sirf dialog dismiss karta hai, koi
        // navigation nahi. Is liye "Done" sirf EK baar dabana kaafi hai —
        // uske baad hum seedha wapas Quiz-list (QuizActivity) par hote
        // hain.
        onView(withText("Done")).perform(click());
        Thread.sleep(1000);

        // Ab hum Quiz-list screen (QuizActivity) par hain, Dashboard par nahi —
        // yahan se ek pressBack() se Dashboard aata hai
        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        // ═══════════════════════════════════════════════════════════════════
        // STEP 5 — ASSIGNMENTS (pehla assignment view karein)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.cardAssignments)).perform(click());
        Thread.sleep(3000);

        onView(withId(R.id.rvAssignments)).check(matches(isDisplayed()));
        onView(withId(R.id.rvAssignments))
                .perform(RecyclerViewActions.actionOnItemAtPosition(0, clickChildViewWithId(R.id.btnView)));
        Thread.sleep(1000);

        onView(withId(R.id.tvDialogTitle)).check(matches(isDisplayed()));

        pressBack();
        Thread.sleep(500);
        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        // ═══════════════════════════════════════════════════════════════════
        // STEP 6 — PROGRESS REPORT (list/empty + tab toggle)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.cardReports)).perform(click());
        Thread.sleep(3000);

        assertListOrEmptyDisplayed(R.id.rvProgress);

        onView(withId(R.id.chipReport)).perform(click());
        Thread.sleep(1500);
        onView(withId(R.id.layoutReportSection)).check(matches(isDisplayed()));

        onView(withId(R.id.chipProgress)).perform(click());
        Thread.sleep(500);
        onView(withId(R.id.layoutProgressSection)).check(matches(isDisplayed()));

        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        // ═══════════════════════════════════════════════════════════════════
        // STEP 7 — FEE (scroll to card, ScrollView ke aakhir mein hai)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.cardFees)).perform(scrollTo(), click());
        Thread.sleep(3000);

        onView(withId(R.id.tvStudentNameFee)).check(matches(isDisplayed()));

        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        // ═══════════════════════════════════════════════════════════════════
        // STEP 8 — ANNOUNCEMENTS (scroll to card)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.cardAnnouncements)).perform(scrollTo(), click());
        Thread.sleep(3500);

        onView(withId(R.id.containerAnnouncements)).check(matches(isDisplayed()));
        onView(withId(R.id.etSearch)).check(matches(isDisplayed()));

        pressBack();
        Thread.sleep(500);
        assertOnDashboard();

        // ═══════════════════════════════════════════════════════════════════
        // STEP 9 — FEEDBACK (bottom-nav)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.nav_bottom_feedback)).perform(forceClick());
        Thread.sleep(2500);

        onView(withId(R.id.layoutSubmitFeedback)).check(matches(isDisplayed()));

        // NOTE: pressBack() yahan kaam nahi karta — StudentDashboardActivity
        // khud finish() ho jati hai jab bottom-nav se Feedback par navigate
        // hota hai (back-stack mein Dashboard hoti hi nahi), is liye
        // physical-back poori app close kar deta hai
        // (NoActivityResumedException). Asal app mein wapas jane ka tareeqa
        // bottom-nav ka "Home" icon hai, is liye yahan wahi use karte hain.
        onView(withId(R.id.nav_bottom_home)).perform(forceClick());
        Thread.sleep(2000);
        assertOnDashboard();

        // ═══════════════════════════════════════════════════════════════════
        // STEP 10 — PROFILE (bottom-nav) → My Profile info screen
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.nav_bottom_profile)).perform(forceClick());
        Thread.sleep(2500);

        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));
        onView(withId(R.id.item_notifications)).check(matches(isDisplayed()));
        onView(withId(R.id.item_settings)).check(matches(isDisplayed()));
        onView(withId(R.id.item_help)).check(matches(isDisplayed()));

        onView(withId(R.id.item_my_profile)).perform(click());
        Thread.sleep(2500);

        onView(withId(R.id.etEmail))
                .check(matches(isDisplayed()))
                .check(matches(withText(TEST_EMAIL)));

        // Wapas Profile-menu par jayen (My Profile screen ka apna back button)
        onView(withId(R.id.btnBack)).perform(click());
        Thread.sleep(500);
        onView(withId(R.id.item_my_profile)).check(matches(isDisplayed()));

        // ═══════════════════════════════════════════════════════════════════
        // STEP 11 — LOGOUT (session ka aakhri qadam)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.item_logout)).perform(click());
        Thread.sleep(500);

        onView(withText("Do you want to logout?")).check(matches(isDisplayed()));
        onView(withText("Yes, Logout")).perform(click());
        Thread.sleep(2000);

        // Wapas Login screen par pahunch jana chahiye — poora session
        // successfully complete
        onView(withId(R.id.etStudentUsername)).check(matches(isDisplayed()));
        onView(withId(R.id.btnStudentLogin)).check(matches(isDisplayed()));
    }

    // ── Shared login helper ──────────────────────────────────────────────────
    private void login() throws InterruptedException {
        onView(withId(R.id.etStudentUsername))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());

        onView(withId(R.id.etStudentPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());

        if (isViewDisplayed(R.id.btnEmailVerified)) {
            onView(withId(R.id.btnEmailVerified)).perform(click());
            Thread.sleep(4000);
        }

        onView(withId(R.id.etStudentId))
                .check(matches(isDisplayed()))
                .perform(typeText(TEST_STUDENT_ID), closeSoftKeyboard());

        onView(withId(R.id.btnStudentLogin)).perform(click());
        Thread.sleep(5000);
    }

    private void assertOnDashboard() {
        onView(withId(R.id.tvStudentName)).check(matches(isDisplayed()));
    }

    /**
     * rvProgress/rvStudyMaterial jaisi ID aur layoutEmpty mein se kam az
     * kam ek visible honi chahiye — dono ek sath GONE hona iska matlab
     * screen broken/crash hai.
     */
    private void assertListOrEmptyDisplayed(int listViewId) {
        boolean listVisible = isViewDisplayed(listViewId);
        boolean emptyVisible = isViewDisplayed(R.id.layoutEmpty);
        assertTrue("Na to list na hi empty-state dikh rahi — screen crash/broken lagti hai",
                listVisible || emptyVisible);
    }

    /**
     * Helper — check karta hai ke di gayi ID wala view is waqt VISIBLE hai
     * ya nahi (GONE/hidden ho to false return karega).
     */
    private boolean isViewDisplayed(int viewId) {
        try {
            onView(withId(viewId)).check(matches(isDisplayed()));
            return true;
        } catch (NoMatchingViewException | AssertionError e) {
            return false;
        }
    }

    /**
     * Custom matcher — jab screen par ek jaisi (matching) MULTIPLE views
     * hon (jaise kai "Start Quiz" buttons), yeh sirf PEHLI wali ko target
     * karta hai, taake Espresso "AmbiguousViewMatcherException" na de.
     */
    private static Matcher<View> first(final Matcher<View> matcher) {
        return new TypeSafeMatcher<View>() {
            boolean isFirstMatchFound = false;

            @Override
            public void describeTo(Description description) {
                description.appendText("should return first matching view");
            }

            @Override
            public boolean matchesSafely(View view) {
                if (isFirstMatchFound) {
                    return false;
                }
                if (matcher.matches(view)) {
                    isFirstMatchFound = true;
                    return true;
                }
                return false;
            }
        };
    }

    /**
     * Custom action — RecyclerView ke andar kisi specific item ke andar
     * chhupe hue child-view (jaise btnView) ko click karta hai. Espresso
     * ka RecyclerViewActions sirf poori row par click support karta hai,
     * isliye row ke andar ka specific button click karne ke liye yeh
     * helper zaroori hai.
     */
    private static ViewAction clickChildViewWithId(final int id) {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return any(View.class);
            }

            @Override
            public String getDescription() {
                return "Click on a child view with specified id.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                View v = view.findViewById(id);
                if (v != null) {
                    v.performClick();
                }
            }
        };
    }

    /**
     * Custom ViewAction — Espresso ke normal click() ki "<90% visible"
     * constraint ko bypass karke seedha view.performClick() call karta
     * hai. Zaroori hai bottom-nav items (nav_bottom_feedback,
     * nav_bottom_profile) ke liye, jo is app ke dashboard-layout ke
     * negative bottom-margin curved-design ki wajah se hamesha thoda
     * screen se bahar clip hote hain (ProfileFlowTest mein detail se
     * explain kiya gaya hai).
     */
    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isEnabled();
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing the 90%-visible constraint.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }
}