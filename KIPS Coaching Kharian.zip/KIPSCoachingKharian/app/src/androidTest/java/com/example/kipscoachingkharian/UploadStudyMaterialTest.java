package com.example.kipscoachingkharian;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;

import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.intent.Intents.intending;
import static androidx.test.espresso.intent.matcher.IntentMatchers.anyIntent;
import static androidx.test.espresso.matcher.RootMatchers.isPlatformPopup;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.containsString;

@RunWith(AndroidJUnit4.class)
public class UploadStudyMaterialTest {

    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    private static final String SUBJECT = "Mathematics";
    private static final String GRADE   = "Class 10A";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    @Before
    public void setUpIntents() {
        Intents.init();
    }

    @After
    public void tearDownIntents() {
        Intents.release();
    }

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(1000);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    private Uri createTestImageUri() throws Exception {
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();

        byte[] tinyPng = new byte[]{
                (byte) 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00,
                0x0D, 0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00,
                0x01, 0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, (byte) 0xC4, (byte) 0x89,
                0x00, 0x00, 0x00, 0x0D, 0x49, 0x44, 0x41, 0x54, 0x78, (byte) 0x9C, 0x62,
                0x00, 0x01, 0x00, 0x00, 0x05, 0x00, 0x01, 0x0D, 0x0A, 0x2D, (byte) 0xB4,
                0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4E, 0x44, (byte) 0xAE, 0x42, 0x60,
                (byte) 0x82
        };

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, "espresso_test_image.png");
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");

        Uri collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        Uri imageUri = context.getContentResolver().insert(collection, values);

        try (OutputStream out = context.getContentResolver().openOutputStream(imageUri)) {
            out.write(tinyPng);
        }

        return imageUri;
    }

    @Test
    public void uploadStudyMaterial_verifyInList() throws Exception {

        String uniqueTitle = "Test Material "
                + new SimpleDateFormat("dd-MMM HH:mm:ss", Locale.getDefault())
                .format(Calendar.getInstance().getTime());

        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());

        waitForDashboard(25);

        onView(withId(R.id.cardStudyMaterial)).perform(scrollTo(), click());
        Thread.sleep(3000);

        onView(withId(R.id.btnUpload)).perform(click());
        Thread.sleep(2000);

        Uri fakeSelectedFile = createTestImageUri();
        Intent resultData = new Intent();
        resultData.setData(fakeSelectedFile);
        Instrumentation.ActivityResult fakeResult =
                new Instrumentation.ActivityResult(Activity.RESULT_OK, resultData);
        intending(anyIntent()).respondWith(fakeResult);


        onView(withId(R.id.cardFilePicker)).perform(click());
        Thread.sleep(1000);

        onView(withId(R.id.etTitle))
                .perform(typeText(uniqueTitle), closeSoftKeyboard());

        onView(withId(R.id.spinnerSubject)).perform(click());
        onView(withText(SUBJECT)).inRoot(isPlatformPopup()).perform(click());

        onView(withId(R.id.spinnerGrade)).perform(click());
        onView(withText(GRADE)).inRoot(isPlatformPopup()).perform(click());

        onView(withId(R.id.btnUploadAndShare)).perform(scrollTo(), click());

        Thread.sleep(10000);

        onView(withId(R.id.rvStudyMaterial))
                .check(matches(hasDescendant(withText(containsString(uniqueTitle)))));
    }
}