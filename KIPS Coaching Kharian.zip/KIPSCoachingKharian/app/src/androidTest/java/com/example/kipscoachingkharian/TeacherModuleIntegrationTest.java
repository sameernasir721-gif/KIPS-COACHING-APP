package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;


@RunWith(AndroidJUnit4.class)
public class TeacherModuleIntegrationTest {

    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility check.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(500);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    private void waitUntilBackOnDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.cardStudent)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(400);
            }
        }
        onView(withId(R.id.cardStudent)).check(matches(isDisplayed()));
    }

    private void navigateCardAndBack(int cardId, int destinationVerifyId, int waitMs)
            throws InterruptedException {
        onView(withId(cardId)).perform(scrollTo(), click());
        Thread.sleep(waitMs);
        onView(withId(destinationVerifyId)).check(matches(isDisplayed()));
        Espresso.pressBack();
        waitUntilBackOnDashboard(6);
    }

    private void navigateBottomNavAndBack(int navId, int destinationVerifyId, int waitMs)
            throws InterruptedException {
        Espresso.closeSoftKeyboard();
        onView(withId(navId)).perform(forceClick());
        Thread.sleep(waitMs);
        onView(withId(destinationVerifyId)).check(matches(isDisplayed()));
        Espresso.pressBack();
        waitUntilBackOnDashboard(6);
    }

    @Test
    public void fullTeacherJourney_loginThroughAllFeaturesAndLogout() throws InterruptedException {

        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());
        waitForDashboard(20);

        navigateCardAndBack(R.id.cardStudent, R.id.containerStudents, 1500);
        navigateCardAndBack(R.id.cardCreateClasses, R.id.btnCreateClass, 1200);
        navigateCardAndBack(R.id.cardStudyMaterial, R.id.rvStudyMaterial, 1200);
        navigateCardAndBack(R.id.cardQuizzes, R.id.layoutQuizList, 1500);
        navigateCardAndBack(R.id.cardAssignments, R.id.rvAssignments, 1500);
        navigateCardAndBack(R.id.cardPerformance, R.id.rvStudents, 1500);
        navigateCardAndBack(R.id.Syllabus, R.id.rvUnits, 1500);
        navigateCardAndBack(R.id.TimeSchedule, R.id.layoutPdfActions, 1500);

        navigateCardAndBack(R.id.tvSeeAll, R.id.tvTodayDate, 1200);
        navigateCardAndBack(R.id.cardGlanceClasses, R.id.btnCreateClass, 1200);
        navigateCardAndBack(R.id.cardGlanceAssignments, R.id.rvAssignments, 1500);
        navigateCardAndBack(R.id.cardGlanceSubmissions, R.id.rvAssignments, 1500);
        navigateCardAndBack(R.id.cardGlanceQuizzes, R.id.layoutQuizList, 1500);

        navigateBottomNavAndBack(R.id.nav_bottom_Message, R.id.rvConversations, 1500);
        navigateBottomNavAndBack(R.id.nav_bottom_Announcment, R.id.containerAnnouncements, 1500);
        navigateBottomNavAndBack(R.id.nav_bottom_profile, R.id.tv_name, 1200);

        onView(withId(R.id.ivMenu)).perform(forceClick());
        Thread.sleep(700);
        onView(withId(R.id.navigationView)).check(matches(isDisplayed()));

        onView(withId(R.id.ivMenu)).perform(forceClick());
        Thread.sleep(700);
        onView(withId(R.id.nav_logout)).perform(click());
        Thread.sleep(700);

        onView(withText("Do you want to logout?")).check(matches(isDisplayed()));
        onView(withText("Yes, Logout")).perform(click());
        Thread.sleep(2000);


        onView(withId(R.id.cardTeacher)).check(matches(isDisplayed()));
        System.out.println("✅ Poora Teacher Module integration test pass ho gaya!");
    }
}