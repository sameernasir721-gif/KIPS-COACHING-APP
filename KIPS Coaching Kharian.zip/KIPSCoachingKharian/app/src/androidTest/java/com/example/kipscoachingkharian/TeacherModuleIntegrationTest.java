package com.example.kipscoachingkharian;

import android.view.View;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.TeacherLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

/**
 * Teacher Module — FULL INTEGRATION TEST.
 *
 * StudentModuleIntegrationTest jaisa hi — yeh saari individual flow-tests
 * (TeacherLoginFlowTest, CreateClassTest, CreateQuizTest, CreateAssignmentTest,
 * UploadStudyMaterialTest, TeacherMessagingTest, TeacherAnnouncementsTest,
 * TeacherProfileSettingsTest, TeacherTimeScheduleTest) ko "unit" ki tarah
 * alag-alag test karti hain. YEH test un sab se alag hai — yeh EK HI
 * continuous session mein Login se Logout tak, ek-ke-baad-ek saari
 * Dashboard screens explore karta hai, taake yeh confirm ho:
 *   (a) Dashboard se launch hone wali har Activity apni jagah par sahi
 *       khulti/kaam karti hai,
 *   (b) har screen se "back" dabane par teacher wapas sahi tarah Dashboard
 *       par pahunchta hai (activity back-stack toot-ta nahi),
 *   (c) poore session mein kahin bhi crash nahi hota,
 *   (d) session ke bilkul end mein Logout karke Login-selection screen par
 *       wapas aana kaam karta hai.
 *
 * Is test ka scope: "screen khulti hai aur crash nahi hoti" (smoke-level)
 * — har screen ke deep/edge-case validations (jaise quiz create karna,
 * marks enter karna) un-ki apni dedicated flow-test files mein already
 * covered hain; unhein yahan dobara nahi dohraya gaya taake yeh
 * integration test focused aur maintainable rahe.
 *
 * IMPORTANT — is test ke end mein TEACHER LOGOUT ho jata hai. Agar isi
 * test-suite (class) mein koi aur test bhi run ho raha ho jo login state
 * par depend karta ho, to yeh test aakhir mein rakhein ya alag se chalayen.
 *
 * IMPORTANT: Neeche apni asal test-teacher ki details daalein.
 */
@RunWith(AndroidJUnit4.class)
public class TeacherModuleIntegrationTest {

    // ── Yahan apni test-teacher ki details daalein ─────────────────────────
    private static final String TEST_EMAIL    = "kz277838@gmail.com";
    private static final String TEST_PASSWORD = "@Ayesha56";

    @Rule
    public ActivityScenarioRule<TeacherLoginActivity> activityRule =
            new ActivityScenarioRule<>(TeacherLoginActivity.class);

    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility check.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(500);
            }
        }
        onView(withId(R.id.tvTeacherName)).check(matches(isDisplayed()));
    }

    // Dashboard ke root card check karta hai — cardStudent hamesha Dashboard
    // par hi hota hai, is liye "hum wapas Dashboard par hain" confirm karne
    // ke liye tvTeacherName ki bajaye yeh use karte hain (kyunke tvTeacherName
    // id kai screens mein reuse hoti hai, alag text ke sath).
    private void waitUntilBackOnDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.cardStudent)).check(matches(isDisplayed()));
                return;
            } catch (Exception e) {
                Thread.sleep(400);
            }
        }
        onView(withId(R.id.cardStudent)).check(matches(isDisplayed()));
    }

    private void navigateCardAndBack(int cardId, int destinationVerifyId, int waitMs)
            throws InterruptedException {
        onView(withId(cardId)).perform(scrollTo(), click());
        Thread.sleep(waitMs);
        onView(withId(destinationVerifyId)).check(matches(isDisplayed()));
        Espresso.pressBack();
        waitUntilBackOnDashboard(6);
    }

    private void navigateBottomNavAndBack(int navId, int destinationVerifyId, int waitMs)
            throws InterruptedException {
        Espresso.closeSoftKeyboard();
        onView(withId(navId)).perform(forceClick());
        Thread.sleep(waitMs);
        onView(withId(destinationVerifyId)).check(matches(isDisplayed()));
        Espresso.pressBack();
        waitUntilBackOnDashboard(6);
    }

    @Test
    public void fullTeacherJourney_loginThroughAllFeaturesAndLogout() throws InterruptedException {

        // ═══════════════════════════════════════════════════════════════════
        // STEP 1 — LOGIN
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.etTeacherId))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etTeacherPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnTeacherLogin)).perform(click());
        waitForDashboard(20);

        // ═══════════════════════════════════════════════════════════════════
        // STEP 2 — MAIN DASHBOARD CARDS
        // ═══════════════════════════════════════════════════════════════════
        navigateCardAndBack(R.id.cardStudent, R.id.containerStudents, 1500);
        navigateCardAndBack(R.id.cardCreateClasses, R.id.btnCreateClass, 1200);
        navigateCardAndBack(R.id.cardStudyMaterial, R.id.rvStudyMaterial, 1200);
        navigateCardAndBack(R.id.cardQuizzes, R.id.layoutQuizList, 1500);
        navigateCardAndBack(R.id.cardAssignments, R.id.rvAssignments, 1500);
        navigateCardAndBack(R.id.cardPerformance, R.id.rvStudents, 1500);
        navigateCardAndBack(R.id.Syllabus, R.id.rvUnits, 1500);
        navigateCardAndBack(R.id.TimeSchedule, R.id.layoutPdfActions, 1500);

        // ═══════════════════════════════════════════════════════════════════
        // STEP 3 — TODAY AT A GLANCE SECTION
        // ═══════════════════════════════════════════════════════════════════
        navigateCardAndBack(R.id.tvSeeAll, R.id.tvTodayDate, 1200);
        navigateCardAndBack(R.id.cardGlanceClasses, R.id.btnCreateClass, 1200);
        navigateCardAndBack(R.id.cardGlanceAssignments, R.id.rvAssignments, 1500);
        navigateCardAndBack(R.id.cardGlanceSubmissions, R.id.rvAssignments, 1500);
        navigateCardAndBack(R.id.cardGlanceQuizzes, R.id.layoutQuizList, 1500);

        // ═══════════════════════════════════════════════════════════════════
        // STEP 4 — BOTTOM NAVIGATION
        // ═══════════════════════════════════════════════════════════════════
        navigateBottomNavAndBack(R.id.nav_bottom_Message, R.id.rvConversations, 1500);
        navigateBottomNavAndBack(R.id.nav_bottom_Announcment, R.id.containerAnnouncements, 1500);
        navigateBottomNavAndBack(R.id.nav_bottom_profile, R.id.tv_name, 1200);

        // ═══════════════════════════════════════════════════════════════════
        // STEP 5 — HAMBURGER DRAWER MENU
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.ivMenu)).perform(forceClick());
        Thread.sleep(700);
        onView(withId(R.id.navigationView)).check(matches(isDisplayed()));

        // ═══════════════════════════════════════════════════════════════════
        // STEP 6 — LOGOUT (session ka aakhri qadam)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.ivMenu)).perform(forceClick());
        Thread.sleep(700);
        onView(withId(R.id.nav_logout)).perform(click());
        Thread.sleep(700);

        onView(withText("Do you want to logout?")).check(matches(isDisplayed()));
        onView(withText("Yes, Logout")).perform(click());
        Thread.sleep(2000);

        // Logout ke baad LoginSelectionActivity khulti hai (Teacher role
        // card wapas dikhna chahiye) — poora session successfully complete
        onView(withId(R.id.cardTeacher)).check(matches(isDisplayed()));
        System.out.println("✅ Poora Teacher Module integration test pass ho gaya!");
    }
}