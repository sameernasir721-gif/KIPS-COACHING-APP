package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.doesNotExist;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.ManageSubjectsActivity;
import com.google.firebase.database.FirebaseDatabase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class ManageSubjectsActivityTest {

    private static final String TEST_SUBJECT_NAME = "ESPRESSO_TEST_SUBJECT_" + System.currentTimeMillis();
    private static final String TEST_SUBJECT_KEY   = TEST_SUBJECT_NAME;

    private ActivityScenario<ManageSubjectsActivity> scenario;

    @Before
    public void setUp() {
        scenario = ActivityScenario.launch(ManageSubjectsActivity.class);
        try { Thread.sleep(3000); } catch (InterruptedException ignored) {}
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
        FirebaseDatabase.getInstance().getReference("Subjects").child(TEST_SUBJECT_KEY).removeValue();
    }

    @Test
    public void screen_elementsAreVisible() {
        onView(withId(R.id.ivBack)).check(matches(isDisplayed()));
        onView(withId(R.id.tvTotalSubjectsCount)).check(matches(isDisplayed()));
        onView(withId(R.id.btnAddNewSubject)).check(matches(isDisplayed()));
        onView(withId(R.id.containerSubjectsList)).check(matches(isDisplayed()));
    }

    @Test
    public void backButton_finishesActivity() {
        onView(withId(R.id.ivBack)).perform(click());
        assertTrue("Activity should be in DESTROYED state after tapping the back button",
                scenario.getState() == Lifecycle.State.DESTROYED);
    }

    @Test
    public void addButton_opensAddSubjectDialog() {
        onView(withId(R.id.btnAddNewSubject)).perform(click());
        onView(withText("Add New Subject")).check(matches(isDisplayed()));
        onView(withText("Subject Name")).check(matches(isDisplayed()));
    }

    @Test
    public void emptySubjectName_showsWarningToast() {
        onView(withId(R.id.btnAddNewSubject)).perform(click());
        onView(withText("Add")).perform(click());

        onView(withText("Subject name cannot be empty!"))
                .inRoot(isToast())
                .check(matches(isDisplayed()));
    }

    @Test
    public void cancelButton_dismissesDialogWithoutAdding() {
        onView(withId(R.id.btnAddNewSubject)).perform(click());
        onView(withText("Cancel")).perform(click());

        assertTrue(scenario.getState() == Lifecycle.State.RESUMED);
        onView(withText("Add New Subject")).check(doesNotExist());
    }

    @Test
    public void addSubject_thenDeleteIt_fullLifecycle() {
        onView(withId(R.id.btnAddNewSubject)).perform(click());
        onView(withHintText("e.g. Physics")).perform(typeText(TEST_SUBJECT_NAME), closeSoftKeyboard());
        onView(withText("Add")).perform(click());

        try { Thread.sleep(4000); } catch (InterruptedException ignored) {}

        onView(withText("📚 " + TEST_SUBJECT_NAME)).perform(scrollTo()).check(matches(isDisplayed()));

        onView(withText("Do you want to delete \"" + TEST_SUBJECT_NAME + "\"?"))
                .check(doesNotExist());

        onView(withText("📚 " + TEST_SUBJECT_NAME)).check(matches(isDisplayed()));

        FirebaseDatabase.getInstance().getReference("Subjects").child(TEST_SUBJECT_KEY).removeValue();
    }

    private static org.hamcrest.Matcher<android.view.View> withHintText(String hint) {
        return new org.hamcrest.TypeSafeMatcher<android.view.View>() {
            @Override
            protected boolean matchesSafely(android.view.View item) {
                if (!(item instanceof android.widget.EditText)) return false;
                CharSequence h = ((android.widget.EditText) item).getHint();
                return h != null && h.toString().equals(hint);
            }
            @Override
            public void describeTo(org.hamcrest.Description description) {
                description.appendText("with hint: " + hint);
            }
        };
    }

    private static org.hamcrest.Matcher<androidx.test.espresso.Root> isToast() {
        return new org.hamcrest.TypeSafeMatcher<androidx.test.espresso.Root>() {
            @Override
            public void describeTo(org.hamcrest.Description description) {
                description.appendText("is toast");
            }
            @Override
            public boolean matchesSafely(androidx.test.espresso.Root root) {
                return root.getWindowLayoutParams().get().type
                        == android.view.WindowManager.LayoutParams.TYPE_TOAST;
            }
        };
    }
}