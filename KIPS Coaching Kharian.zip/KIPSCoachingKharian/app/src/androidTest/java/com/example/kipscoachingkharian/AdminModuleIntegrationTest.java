package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import android.view.View;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.AdminLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Admin Module — FULL INTEGRATION TEST.
 *
 * Teacher/Student/Parent ModuleIntegrationTest jaisa hi — yeh saari
 * individual flow-tests ko "unit" ki tarah alag-alag test karti hain.
 * YEH test un sab se alag hai — yeh EK HI continuous session mein Login
 * se Logout tak, ek-ke-baad-ek saari Dashboard screens explore karta hai,
 * taake yeh confirm ho:
 *   (a) Dashboard se launch hone wali har Activity apni jagah par sahi
 *       khulti/kaam karti hai,
 *   (b) har screen se "back" dabane par admin wapas sahi tarah Dashboard
 *       par pahunchta hai (activity back-stack toot-ta nahi),
 *   (c) poore session mein kahin bhi crash nahi hota,
 *   (d) session ke bilkul end mein Logout karke role-selection screen
 *       par wapas aana kaam karta hai.
 *
 * Is test ka scope: "screen khulti hai aur crash nahi hoti" (smoke-level)
 * — har screen ke deep/edge-case validations (jaise naya teacher add
 * karna, request approve/reject karna) un-ki apni dedicated flow-test
 * files mein cover ki jayein; unhein yahan dobara nahi dohraya gaya
 * taake yeh integration test focused aur maintainable rahe.
 *
 * IMPORTANT — Admin ke "My Profile" / "Settings" / "Help" alag screens
 * nahi hain — yeh teeno AlertDialog ki tarah khulte hain (AdminProfileActivity
 * ke andar hi). Is liye in teeno ko dialog-open → verify → dismiss ke
 * tareeke se test kiya gaya hai, activity navigate/back karne ki tarah nahi.
 *
 * IMPORTANT — is test ke end mein ADMIN LOGOUT ho jata hai. Agar isi
 * test-suite (class) mein koi aur test bhi run ho raha ho jo login state
 * par depend karta ho, to yeh test aakhir mein rakhein ya alag se chalayen.
 *
 * IMPORTANT: Neeche apni asal test-admin ki details daalein. Test account
 * ka role Firebase mein "Admin" hona chahiye, warna login "Access Denied"
 * de kar reject kar dega.
 */
@RunWith(AndroidJUnit4.class)
public class AdminModuleIntegrationTest {

    // ── Yahan apni test-admin ki details daalein ────────────────────────────
    private static final String TEST_EMAIL    = "raimanasir260@gmail.com";
    private static final String TEST_PASSWORD = "#kipsadmin";

    @Rule
    public ActivityScenarioRule<AdminLoginActivity> activityRule =
            new ActivityScenarioRule<>(AdminLoginActivity.class);

    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility check.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.Student)).check(matches(isDisplayed()));
                return;
            } catch (Throwable e) {
                Thread.sleep(500);
            }
        }
        onView(withId(R.id.Student)).check(matches(isDisplayed()));
    }

    // Dashboard ke root card (Student management) check karta hai — hamesha
    // Dashboard par hi hota hai, is liye "hum wapas Dashboard par hain"
    // confirm karne ke liye yeh use karte hain.
    private void waitUntilBackOnDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.Student)).check(matches(isDisplayed()));
                return;
            } catch (Throwable e) {
                Thread.sleep(400);
            }
        }
        onView(withId(R.id.Student)).check(matches(isDisplayed()));
    }

    private void navigateCardAndBack(int cardId, Matcher<View> destinationVerify, int waitMs)
            throws InterruptedException {
        onView(withId(cardId)).perform(scrollTo(), click());
        Thread.sleep(waitMs);
        onView(destinationVerify).check(matches(isDisplayed()));
        Espresso.pressBack();
        waitUntilBackOnDashboard(6);
    }

    @Test
    public void fullAdminJourney_loginThroughAllFeaturesAndLogout() throws InterruptedException {

        // ═══════════════════════════════════════════════════════════════════
        // STEP 1 — LOGIN
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.etAdminEmail))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etAdminPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnAdminLogin)).perform(click());
        waitForDashboard(20);

        // ═══════════════════════════════════════════════════════════════════
        // STEP 2 — DASHBOARD KE SAARE MANAGEMENT CARDS
        // Har destination screen ka STATIC (data-independent) element check
        // kiya gaya hai — dynamic list/RecyclerView containers ki jagah
        // (jaise ManageStudentRequestsActivity ka "Student Requests" header,
        // ya AddTeacherActivity ka etTeacherName field) — taake test data
        // hone/na hone se fail na ho.
        // ═══════════════════════════════════════════════════════════════════
        navigateCardAndBack(R.id.Student, withText("Student Requests"), 1500);
        navigateCardAndBack(R.id.Teacher, withId(R.id.etTeacherName), 1500);
        navigateCardAndBack(R.id.Parents, withText("Parent Requests"), 1500);
        navigateCardAndBack(R.id.Payments, withText("Fee Management"), 1500);
        navigateCardAndBack(R.id.SystemReports, withText("System Reports"), 1500);
        navigateCardAndBack(R.id.Notifications, withId(R.id.ivBack), 1500);
        navigateCardAndBack(R.id.cardFeedback, withId(R.id.btnBackFeedback), 1500);
        navigateCardAndBack(R.id.PaymentConfig, withId(R.id.et_merchant_id), 1500);
        navigateCardAndBack(R.id.cardTimetable, withId(R.id.btnBack), 1500);
        navigateCardAndBack(R.id.cardManageUser, withId(R.id.cardManageStudent), 1500);
        navigateCardAndBack(R.id.cardManageSubjects, withId(R.id.ivBack), 1500);
        navigateCardAndBack(R.id.cardManageClasses, withId(R.id.ivBack), 1500);

        // ═══════════════════════════════════════════════════════════════════
        // STEP 3 — HAMBURGER DRAWER MENU
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.ivMenuToggle)).perform(scrollTo(), forceClick());
        Thread.sleep(700);
        onView(withId(R.id.navigationView)).check(matches(isDisplayed()));
        Espresso.pressBack();
        Thread.sleep(500);
        waitUntilBackOnDashboard(6);

        // ═══════════════════════════════════════════════════════════════════
        // STEP 4 — PROFILE (My Profile / Settings / Help teeno DIALOGS hain,
        // alag screens nahi — is liye har dialog ko open → verify → dismiss
        // karte hain, activity-back ki zaroorat nahi)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.ivProfile)).perform(scrollTo(), forceClick());
        Thread.sleep(1200);

        // -- My Profile dialog --
        onView(withId(R.id.item_my_profile)).perform(scrollTo(), click());
        Thread.sleep(800);
        onView(withText("👤  Admin Profile")).check(matches(isDisplayed()));
        onView(withText("Close")).perform(click());
        Thread.sleep(500);

        // -- Settings (Change Password) dialog --
        onView(withId(R.id.item_settings)).perform(scrollTo(), click());
        Thread.sleep(800);
        onView(withText("🔑 Change Password")).check(matches(isDisplayed()));
        onView(withText("Cancel")).perform(click());
        Thread.sleep(500);

        // -- Help (About App) dialog --
        onView(withId(R.id.item_help)).perform(scrollTo(), click());
        Thread.sleep(800);
        onView(withText("About App")).check(matches(isDisplayed()));
        onView(withText("OK")).perform(click());
        Thread.sleep(500);

        // ═══════════════════════════════════════════════════════════════════
        // STEP 5 — LOGOUT (session ka aakhri qadam)
        // ═══════════════════════════════════════════════════════════════════
        onView(withId(R.id.item_logout)).perform(scrollTo(), click());
        Thread.sleep(700);

        onView(withText("Kya aap logout karna chahte hain?")).check(matches(isDisplayed()));
        onView(withText("Yes")).perform(click());
        Thread.sleep(2000);

        // Logout ke baad LoginSelectionActivity khulti hai (Admin role card
        // wapas dikhna chahiye) — poora session successfully complete
        onView(withId(R.id.cardAdmin)).check(matches(isDisplayed()));
        System.out.println("✅ Poora Admin Module integration test pass ho gaya!");
    }
}