package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import android.view.View;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.auth.AdminLoginActivity;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class AdminModuleIntegrationTest {

    private static final String TEST_EMAIL    = "raimanasir260@gmail.com";
    private static final String TEST_PASSWORD = "#kipsadmin";

    @Rule
    public ActivityScenarioRule<AdminLoginActivity> activityRule =
            new ActivityScenarioRule<>(AdminLoginActivity.class);

    private static ViewAction forceClick() {
        return new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return ViewMatchers.isAssignableFrom(View.class);
            }

            @Override
            public String getDescription() {
                return "Force click on a view, bypassing visibility check.";
            }

            @Override
            public void perform(UiController uiController, View view) {
                view.performClick();
                uiController.loopMainThreadUntilIdle();
            }
        };
    }

    private void waitForDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.Student)).check(matches(isDisplayed()));
                return;
            } catch (Throwable e) {
                Thread.sleep(500);
            }
        }
        onView(withId(R.id.Student)).check(matches(isDisplayed()));
    }

    private void waitUntilBackOnDashboard(int maxSeconds) throws InterruptedException {
        for (int i = 0; i < maxSeconds; i++) {
            try {
                onView(withId(R.id.Student)).check(matches(isDisplayed()));
                return;
            } catch (Throwable e) {
                Thread.sleep(400);
            }
        }
        onView(withId(R.id.Student)).check(matches(isDisplayed()));
    }

    private void navigateCardAndBack(int cardId, Matcher<View> destinationVerify, int waitMs)
            throws InterruptedException {
        onView(withId(cardId)).perform(scrollTo(), click());
        Thread.sleep(waitMs);
        onView(destinationVerify).check(matches(isDisplayed()));
        Espresso.pressBack();
        waitUntilBackOnDashboard(6);
    }

    @Test
    public void fullAdminJourney_loginThroughAllFeaturesAndLogout() throws InterruptedException {

        onView(withId(R.id.etAdminEmail))
                .perform(typeText(TEST_EMAIL), closeSoftKeyboard());
        onView(withId(R.id.etAdminPassword))
                .perform(typeText(TEST_PASSWORD), closeSoftKeyboard());
        onView(withId(R.id.btnAdminLogin)).perform(click());
        waitForDashboard(20);

        navigateCardAndBack(R.id.Student, withText("Student Requests"), 1500);
        navigateCardAndBack(R.id.Teacher, withId(R.id.etTeacherName), 1500);
        navigateCardAndBack(R.id.Parents, withText("Parent Requests"), 1500);
        navigateCardAndBack(R.id.Payments, withText("Fee Management"), 1500);
        navigateCardAndBack(R.id.SystemReports, withText("System Reports"), 1500);
        navigateCardAndBack(R.id.Notifications, withId(R.id.ivBack), 1500);
        navigateCardAndBack(R.id.cardFeedback, withId(R.id.btnBackFeedback), 1500);
        navigateCardAndBack(R.id.cardTimetable, withId(R.id.btnBack), 1500);
        navigateCardAndBack(R.id.cardManageUser, withId(R.id.cardManageStudent), 1500);
        navigateCardAndBack(R.id.cardManageSubjects, withId(R.id.ivBack), 1500);
        navigateCardAndBack(R.id.cardManageClasses, withId(R.id.ivBack), 1500);

        onView(withId(R.id.ivMenuToggle)).perform(scrollTo(), forceClick());
        Thread.sleep(700);
        onView(withId(R.id.navigationView)).check(matches(isDisplayed()));
        Espresso.pressBack();
        Thread.sleep(500);
        waitUntilBackOnDashboard(6);

        onView(withId(R.id.ivProfile)).perform(scrollTo(), forceClick());
        Thread.sleep(1200);

        onView(withId(R.id.item_my_profile)).perform(scrollTo(), click());
        Thread.sleep(800);
        onView(withText("👤  Admin Profile")).check(matches(isDisplayed()));
        onView(withText("Close")).perform(click());
        Thread.sleep(500);

        onView(withId(R.id.item_settings)).perform(scrollTo(), click());
        Thread.sleep(800);
        onView(withText("🔑 Change Password")).check(matches(isDisplayed()));
        onView(withText("Cancel")).perform(click());
        Thread.sleep(500);

        onView(withId(R.id.item_help)).perform(scrollTo(), click());
        Thread.sleep(800);
        onView(withText("About App")).check(matches(isDisplayed()));
        onView(withText("OK")).perform(click());
        Thread.sleep(500);

        onView(withId(R.id.item_logout)).perform(scrollTo(), click());
        Thread.sleep(700);

        onView(withText("Do you want to logout?")).check(matches(isDisplayed()));
        onView(withText("Yes")).perform(click());
        Thread.sleep(2000);

        onView(withId(R.id.cardAdmin)).check(matches(isDisplayed()));
        System.out.println("✅ Full Admin Module integration test passed!");
    }
}