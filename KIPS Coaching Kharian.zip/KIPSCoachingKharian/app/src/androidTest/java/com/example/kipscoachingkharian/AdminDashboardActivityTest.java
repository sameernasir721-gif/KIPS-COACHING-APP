package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.junit.Assert.assertTrue;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.AdminDashboardActivity;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

@RunWith(AndroidJUnit4.class)
public class AdminDashboardActivityTest {

    private static final String TEST_ADMIN_EMAIL = "raimanasir260@gmail.com";
    private static final String TEST_ADMIN_PASSWORD = "#kipsadmin";

    private ActivityScenario<AdminDashboardActivity> scenario;

    @Before
    public void signInBeforeLaunch() throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        FirebaseAuth.getInstance()
                .signInWithEmailAndPassword(TEST_ADMIN_EMAIL, TEST_ADMIN_PASSWORD)
                .addOnCompleteListener(task -> latch.countDown());

        boolean completed = latch.await(15, TimeUnit.SECONDS);
        assertTrue("Firebase sign-in timed out — check internet/credentials", completed);
        assertTrue("Sign-in failed — check TEST_ADMIN_EMAIL/PASSWORD",
                FirebaseAuth.getInstance().getCurrentUser() != null);

        scenario = ActivityScenario.launch(AdminDashboardActivity.class);
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
        FirebaseAuth.getInstance().signOut();
    }

    @Test
    public void dashboard_mainElementsAreVisible() {
        onView(withId(R.id.drawerLayout)).check(matches(isDisplayed()));
        onView(withId(R.id.Student)).check(matches(isDisplayed()));
        onView(withId(R.id.Teacher)).check(matches(isDisplayed()));
        onView(withId(R.id.Parents)).check(matches(isDisplayed()));
        onView(withId(R.id.Payments)).check(matches(isDisplayed()));
    }

    @Test
    public void menuToggle_opensNavigationDrawer() {
        onView(withId(R.id.ivMenuToggle)).perform(click());
        onView(withId(R.id.navigationView)).check(matches(isDisplayed()));
    }

    @Test
    public void teacherCard_opensAddTeacherActivity() {
        onView(withId(R.id.Teacher)).perform(click());
    }
}