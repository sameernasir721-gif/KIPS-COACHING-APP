package com.example.kipscoachingkharian;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertTrue;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.kipscoachingkharian.R;
import com.example.kipscoachingkharian.dashboard.ManageStudentRequestsActivity;
import com.google.firebase.auth.FirebaseAuth;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

@RunWith(AndroidJUnit4.class)
public class ManageStudentRequestsActivityTest {

    private static final String TEST_ADMIN_EMAIL = "raimanasir260@gmail.com";
    private static final String TEST_ADMIN_PASSWORD = "#kipsadmin";

    private ActivityScenario<ManageStudentRequestsActivity> scenario;

    @Before
    public void signInAndLaunch() throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        FirebaseAuth.getInstance()
                .signInWithEmailAndPassword(TEST_ADMIN_EMAIL, TEST_ADMIN_PASSWORD)
                .addOnCompleteListener(task -> latch.countDown());

        boolean completed = latch.await(15, TimeUnit.SECONDS);
        assertTrue("Firebase sign-in timed out — check internet connection", completed);
        assertTrue("Sign-in failed", FirebaseAuth.getInstance().getCurrentUser() != null);

        scenario = ActivityScenario.launch(ManageStudentRequestsActivity.class);

        waitForDataLoad();
    }

    @After
    public void tearDown() {
        if (scenario != null) scenario.close();
        FirebaseAuth.getInstance().signOut();
    }

    private void waitForDataLoad() {
        try {
            Thread.sleep(4000);
        } catch (InterruptedException ignored) {
        }
    }

    @Test
    public void screen_showsHeaderTitle() {
        onView(withText("Student Requests")).check(matches(isDisplayed()));
    }

    @Test
    public void loadingText_disappearsAfterDataLoads() {
        onView(withId(R.id.tvStudentLoading)).check((view, noViewFoundException) -> {
            if (view != null) {
                assertTrue("Loading text is still VISIBLE — data has not loaded or is slow",
                        view.getVisibility() == android.view.View.GONE);
            }
        });
    }

    @Test
    public void refreshButton_isDisplayedAndClickable() {
        onView(withText("🔄 Refresh Verification Status")).check(matches(isDisplayed()));
        onView(withText("🔄 Refresh Verification Status")).perform(click());

        waitForDataLoad();
        onView(withText("Student Requests")).check(matches(isDisplayed()));
    }

    @Test
    public void defaultFilter_showsPendingRequestsHeader() {
        onView(withText("Pending Requests")).check(matches(isDisplayed()));
    }

    @Test
    public void tappingTotalCard_switchesToAllStudentsView() {
        onView(withText("Total")).perform(click());
        onView(withText("All Students")).check(matches(isDisplayed()));
    }

    @Test
    public void tappingApprovedCard_switchesToApprovedRequestsView() {
        onView(withText("Approved")).perform(click());
        onView(withText("Approved Requests")).check(matches(isDisplayed()));
    }

    @Test
    public void tappingRejectedCard_switchesToRejectedRequestsView() {
        onView(withText("Rejected")).perform(click());
        onView(withText("Rejected Requests")).check(matches(isDisplayed()));
    }
}